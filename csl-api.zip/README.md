# Console API Project

## Setup de l'environnement

### Installation de Java 17

~~~bash
#!/bin/bash

ver=3.8.4
dir=apache-maven-$ver
url=https://dlcdn.apache.org/maven/maven-3/3.8.4/binaries/$dir-bin.tar.gz

sudo apt install -y openjdk-17-jre openjdk-17-jdk curl
mkdir -p ~/Téléchargements 
cd ~/Téléchargements
curl -O https://dlcdn.apache.org/maven/maven-3/3.8.4/binaries/apache-maven-3.8.4-bin.tar.gz
tar xvf apache-maven-3.8.4-bin.tar.gz
sudo mv $dir /usr/bin
cd -
~~~

~~~
mvn -N io.takari:maven:wrapper
~~~

### Configuration de Maven
Définir les paramètres système Maven :
~~~
MAVEN_OPTS="-Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=8888 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=8888" mvn -N io.takari:maven:wrapper
MAVEN_OPTS="-Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=8888 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=8888" .mvnw clean package
~~~
Modifier le fichier ```settings.xml``` avec les lignes suivant avec
* les paramètres du proxy Orion
* les paramètres de connexion au serveur Nexus
~~~xml
...
<servers>

    <proxies>
        <proxy>
            <id>default-http-proxy</id>
            <active>true</active>
            <protocol>http</protocol>
            <host>localhost</host>
            <port>8888</port>
            <username>Login ORION</username>
            <password>Mot de passe ORION</password>
        </proxy>

        <proxy>
            <id>default-https-proxy</id>
            <active>true</active>
            <protocol>https</protocol>
            <host>localhost</host>
            <port>8888</port>
            <username>Login ORION</username>
            <password>Mot de passe ORION</password>
        </proxy>
    </proxies>

    <mirrors>
        <mirror>
            <id>nexus</id>
            <url>https://nexus.forge-dc.cloudmi.minint.fr/repository/maven-public</url>
            <mirrorOf>central</mirrorOf>
        </mirror>
    </mirrors>
    
    <server>
        <id>nexus-snapshots</id>
        <username>Votre login LDAP SSO</username>
        <password>mot de passe</password>
    </server>
    <server>
        <id>nexus-release</id>
        <username>Votre login LDAP SSO</username>
        <password>mot de passe</password>
    </server>
</servers>
...
~~~

### Installation de Docker

Docker et docker-compose doivent être installé à l'aide de la commande suivante :
~~~bash
sudo apt install docker docker-compose golang-docker-credential-helpers
~~~
Après l'installation, il est alors de nécessaire de spécifier le proxy de Docker en suivant les instructions suivantes :
* se placer dans */etc/docker*
* Vérifier que le fichier *daemon.json* existe bien, quitte à le créer
* Modifier le fichier *daemon.json* avec le contenu suivant :
~~~
{
    "dns": ["10.221.166.9", "10.235.125.112", "10.243.16.14"],
    "dns-search": ["ac.int"],
    "insecure-registries": ["https://dml.forge.pi.dsic.minint.fr", "dml.forge.pi.minint.fr"],
    "registry-mirrors": ["https://dml.forge.pi.dsic.minint.fr"]
}
~~~
* Se placer dans le dossier */etc/systemd/system/docker.service.d*
* Modifier le fichier avec le contenu suivant :
~~~
[Service]
Environment="HTTP_PROXY=http://127.0.0.1:8888"
Environment="HTTPS_PROXY=http://127.0.0.1:8888"
Environment="NO_PROXY=localhost,127.0.0.1,172.17.0.1,172.30.1.1"
~~~
* Se placer dans le dossier *~/.docker~ ou créer avec la commande ``mkdir ~/.docker``
* Créer le fichier *config.json* avec le contenu suivant :
~~~
{
	"auths": {
		"dml.forge.pi-bas.cloudmi.minint.fr": {},
		"dml.forge.pi.dsic.minint.fr": {},
		"dml.forge.pi.minint.fr": {}
	},
	"credsStore": "secretservice",
	"proxies": {
		"default": {
			"httpProxy": "http://172.17.0.1:8888",
			"httpsProxy": "http://172.17.0.1:8888",
			"noProxy": "172.17.0.1,crl.interieur.gouv.fr"
		}
	}
}
~~~
* Redémarrer le service docker : ``sudo service docker restart`` et ``sudo systemctl daemon-reload``

## Installation / Lancement du projet
### Configuration pré-lancement lors de la première connexion :
Avant de lancer l'application en local pour la première fois, il est nécessaire 
d'effectuer les configurations manuelles ci-dessous.
Attention, ces étapes devront être répétées après l'exécution de la commande ``docker system prune -f``

#### Configuration du LDAP local :
* Se placer à la racine du projet
* Modifier le fichier **helpers/ldap/generate-ldap-users.js**
* Modifier la valeur de la variable *users* en ajoutant votre utilisateur :
~~~javascript
const users = [
  { firstname: 'daniel', lastname: 'radeau', company: 'econocom' },
  { firstname: 'slim', lastname: 'ben-hazez', company: 'econocom' },
  { firstname: 'trecy', lastname: 'fournier', company: 'oiseaurare' },
  { firstname: 'priscillia', lastname: 'tartr', company: 'capgemini' }, // Faute volontaire
  { firstname: 'juliette', lastname: 'bombard' },
  { firstname: 'charlotte', lastname: 'herrero' },
  { firstname: 'germain', lastname: 'lemaitre', company: 'atos' },
  { firstname: 'mickael', lastname: 'jaguenaud' },
  { firstname: 'karine', lastname: 'adjibabi' },
  { firstname: 'youssef', lastname: 'jbari', company: 'atos' },
  // Autres
  { firstname: 'votre prénom', lastname: 'votre nom', company: 'votre entreprise' }  
]
~~~

### Lancement du back (via docker-compose)
Pour lancer le back-office, exécutez les commandes suivantes :
* cd ***dossier du projet***
* Lancer la commande suivante ``docker-compose up -d`` 
pour démarrer les briques logicielles nécessaires au back-office.
* Lancer ensuite le projet (via, par exemple, une configuration Spring avec la classe principale *fr.minint.console.api.project.ConsoleApiProjectApplication*)

### Lancement du front
Lorsque le back-office est lancé, il suffit alors de lancer le front
* cd ***dossier de console-front***
* Installer, si besoin les bibliothèques Javascript: ``yarn``
* Lancer le serveur ``yarn serve``
* Se connecter ensuite à l'adresse suivante: http://localhost:8080

### Configuration post-lancement lors de la première connexion :
#### Configuration de Keycloak :
Après que l'application est lancée (c'est-à-dire le back-office et le front), il va être nécessaire 
de configurer *Keycloak*
* Se connecter à la console d'administration de Keycloak : http://localhost:13000/auth/
* Cliquer sur la rubrique *Administration Console*
* Se connecter en utilisant le login et mot de passe administrateur définis dans le fichier *docker-compose.yml*
* Cliquer ensuite sur la sous-rubrique *User Federation*
* Cliquer sur *ldap-ag* (et sur *ldap-ag-pi*)
* Modifier le *Bind Credential* avec la valeur **LDAP_ADMIN_PASSWORD** du fichier *docker-compose.yml*
* Sauver ensuite ces modifications.

#### Configuration du LDAP :
##### Import du fichier des utilisateurs
* Au niveau de la racine du projet, effectuer la commande suivante : ``node helpers/ldap/generate-ldap-users.js``
* Sauvegarder dans un fichier ou dans le presse-papier le résultat de la commande ci-dessus
* Se connecter : https://localhost:10001 (en utilisant le mot de passe dans le *docker-compose*)
* Sélectionner ensuite le menu *import* et copier le contenu sauvegardé précédemment dans la fenêtre
* Valider ensuite l'import

##### Ajout des rôles au niveau du LDAP :
* Se connecter à l'adresse suivante : https://localhost:10001/cmd.php
* Naviguer jusqu'au sous-menu *grp-users* puis sélectionner *cn=souscripteur*
* Cliquer sur *Modify group members*
* Ajouter ensuite votre utilisateur dans le groupe
* Sauver les modifications

### BUG-FIX :
Afin de diagnostiquer, lancer la commande ``docker-compose ps`` afin de vérifier que tous les services ont bien démarré.
Puis, dans le cas contraire, lancer la commande ``docker logs <nom du service>``

## Ressources documentaires
Cette rubrique regroupe toutes les ressources documentaires en lien avec le projet
### Utilisation de templates thymeleaf.
Les templates sont à positionner dans resources/templates.
Voici les liens :
* https://www.thymeleaf.org/doc/tutorials/3.0/usingthymeleaf.html
* https://www.baeldung.com/spring-template-engines

### Liens utilisés pour réaliser les fonctionnalités relatives aux emails :
Voici les liens documentaires concernant les templates de mails 
* https://www.baeldung.com/spring-email-templates
* https://docs.spring.io/spring-boot/docs/1.5.6.RELEASE/reference/html/boot-features-external-config.html
* https://github.com/thymeleaf/thymeleafexamples-springmail/tree/3.0-master/src/main/resources/mail
* https://www.thymeleaf.org/doc/articles/springmail.html
* https://github.com/eugenp/tutorials/blob/master/spring-web-modules/spring-mvc-basics-2/src/main/java/com/baeldung/spring/mail/EmailService.java
* https://www.baeldung.com/spring-email
* https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html

~~~
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout tls.key -out tls.crt -subj "/CN=host" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1,IP:10.237.6.157"
sudo cp tls.crt /usr/local/share/ca-certificates/custom/
~~~