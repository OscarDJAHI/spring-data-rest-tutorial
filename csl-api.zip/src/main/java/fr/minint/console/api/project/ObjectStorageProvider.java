package fr.minint.console.api.project;

public enum ObjectStorageProvider {
    SWIFT("swift"),
    ECS("ecs");

    private final String name;

    ObjectStorageProvider(String name) {
        this.name = name;
    }

    public String value() {
        return name;
    }
}
