package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.dto.utilisateur.CreateUtilisateurDto;
import fr.minint.console.api.project.dto.utilisateur.UpdateUtilisateurDto;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repositories.UserRepository;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static fr.minint.console.library.utils.json.JSONUtils.*;
import static fr.minint.console.library.utils.predicate.BeanFieldPredicate.withFieldEqualTo;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;
import static org.springframework.ldap.query.LdapQueryBuilder.query;

// TODO : A fusionner avec la classe UserController
@RestController
@RequestMapping("/utilisateurs")
@Setter(onMethod = @__(@Autowired))
public class UtilisateurController extends AbstractRestController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UtilisateurController.class);
    private UserLdapRepository userLdapRepository;
    private UserRepository userRepository;


    ///// Définition des "endPoints" :

    @ResponseStatus(BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(final MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

    @PostMapping
    @ResponseStatus(code = CREATED)
    User create(KeycloakAuthenticationToken keycloakAuthenticationToken,
                @Valid @RequestBody final CreateUtilisateurDto createUserDto) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        final User user = new User();
        user.setLastName(createUserDto.getNom());
        user.setFirstName(createUserDto.getPrenom());
        user.setEmail(createUserDto.getEmail());
        user.setUid(createUserDto.getRio());
        try {
            return userRepository.save(user);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }


    @GetMapping
    public ResponseEntity<String> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        try {
            final List<User> users =userRepository.findAll();
            if (users.isEmpty()) {
                return ok(EMPTY_JSON_ARRAY.toString());
            }
            return ok(buildJSONCodeFromCollection(users));
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @GetMapping("/{user_id}")
    Optional<User> get(KeycloakAuthenticationToken keycloakAuthenticationToken,
                       @PathVariable("user_id") final Long userId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);

        try {
            return userRepository.findById(userId);
        } catch (Exception e) {
            getLogger().error(e.getMessage(), e);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PutMapping("/{user_id}")
    @ResponseStatus(code = OK)
    ResponseEntity<String> update(KeycloakAuthenticationToken keycloakAuthenticationToken,
                                  @Valid @RequestBody final UpdateUtilisateurDto updateUserDto) {
        final StringBuilder errorMessageBuilder = new StringBuilder();
        boolean isOK = NOT_NULL_VALIDATOR.validate("document", updateUserDto, errorMessageBuilder);
        if (!isOK) {
            LOGGER.warn("Attention : {}", errorMessageBuilder);
            LOGGER.warn("---> On ne fait donc rien !!");
            return new ResponseEntity<>("{}", OK);
        }
        try {
            final Optional<User> optionalUtilisateur = userRepository.findById(updateUserDto.getId());
            final User user = optionalUtilisateur.get();
            user.setUid(updateUserDto.getRio());
            user.setLastName(updateUserDto.getNom());
            user.setFirstName(updateUserDto.getPrenom());
            user.setEmail(updateUserDto.getEmail());
            return ok(buildJSONCode(userRepository.save(user)));

        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }


    @GetMapping("/search")
    public Iterable<LdapUser> search(KeycloakAuthenticationToken keycloakAuthenticationToken,
                                     @RequestParam Map<String, String> allParams) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return search(allParams);
    }

    public Iterable<LdapUser> search(@RequestParam Map<String, String> allParams) {
        LdapQuery query = null;
        if (allParams.containsKey("uid")) {
            String uid = allParams.get("uid");
            query = query()
                    .where("objectclass").is("inetOrgPerson")
                    .and("uid").like(uid);
        } else if (allParams.containsKey("mail")) {
            String mail = allParams.get("mail");
            query = query()
                    .where("objectclass").is("inetOrgPerson")
                    .and("mail").like(mail);
        } else {
            query = query()
                    .where("objectclass").is("inetOrgPerson");
        }

        return userLdapRepository.findAll(query);
    }


    ///// Getters & Setters :

    @Autowired
    public void setUserLdapRepository(final UserLdapRepository userLdapRepository) {
        this.userLdapRepository = userLdapRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
