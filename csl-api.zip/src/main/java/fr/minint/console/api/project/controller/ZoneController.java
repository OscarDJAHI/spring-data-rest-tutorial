package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.Zone;
import fr.minint.console.api.project.repositories.ZoneRepository;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/zones")
@Setter(onMethod = @__(@Autowired))
public class ZoneController extends AbstractRestController {
    private ZoneRepository zoneRepository;

    @GetMapping
    public Iterable<Zone> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return zoneRepository.findAll();
    }

    @GetMapping("/{zone_id}")
    public Optional<Zone> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                              @PathVariable("zone_id") final Long id) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return zoneRepository.findById(id);
    }

    ///// Getters & Setters :

    @Autowired
    public void setZoneRepository(final ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }
}
