package fr.minint.console.api.project.ldap.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.minint.console.api.project.ldap.model.OrganisationalUnit;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repository.ldap.OrganizationalUnitRepository;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import fr.minint.console.api.project.service.sequence.SequenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.support.LdapNameBuilder;
import org.springframework.stereotype.Service;

import javax.naming.Name;
import java.util.List;
import java.util.Optional;

import static fr.minint.console.api.project.utils.LdapPasswordUtils.hashWithSaltedSha256;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Service
public class UserService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
    final String SERVICE_ACCOUNT_PREFIX = "c2s";
    final Long DEFAULT_GID_NUMBER = 1000000L;
    private LdapTemplate ldapTemplate;
    private UserLdapRepository userLdapRepository;
    private OrganizationalUnitRepository organizationalUnitRepository;
    private SequenceService extUserRioSequence;
    private SequenceService extUserUidNumberSequence;
    private String externalUserDn;

    @Autowired
    public void setExternalUserDn(@Value("${console.api.ldap.external-users-dn}") final String externalUserDn) {
        this.externalUserDn = externalUserDn;
    }

    ///// Méthodes générales :

    public void create(final String rdn,
                       final String uid,
                       final String cn,
                       final String sn,
                       final String uidNumber,
                       final String gidNumber,
                       final String password) {
        final Name dn = LdapNameBuilder.newInstance()
                .add(rdn)
                .build();
        final DirContextAdapter context = new DirContextAdapter(dn);
        context.setAttributeValues("objectclass", new String[]{
                "posixAccount",
                "inetOrgPerson",
                "top"
        });
        context.setAttributeValue("uid", uid);
        context.setAttributeValue("cn", cn);
        context.setAttributeValue("sn", sn);
        context.setAttributeValue("uidNumber", uidNumber);
        context.setAttributeValue("gidNumber", gidNumber);
        context.setAttributeValue("homeDirectory", "/home/%s".formatted(uid));
        if (password != null && !isEmpty(password)) {
            context.setAttributeValue("userPassword", password);
        }
        ldapTemplate.bind(context);
    }

    public void create(final String rdn,
                       final String uid,
                       final String cn,
                       final String sn,
                       final String uidNumber,
                       final String gidNumber) {
        this.create(rdn, uid, cn, sn, uidNumber, gidNumber, null);
    }

    public void create(final LdapUser ldapUser) {
        userLdapRepository.save(ldapUser);
    }

    public Long createExternalUser(final String firstName,
                                   final String lastname,
                                   final String email,
                                   final String password,
                                   final String organization) {
        final Long generatedRioNumber = this.extUserRioSequence.getNextValue();
        final Long generatedUidNumber = this.extUserUidNumberSequence.getNextValue();
        final LdapUser externalLdapUser = LdapUser.createExternalUser(generatedRioNumber, externalUserDn, firstName, lastname, email, hashWithSaltedSha256(password), organization);
        externalLdapUser.setUidNumber(generatedUidNumber.toString());
        externalLdapUser.setGidNumber(DEFAULT_GID_NUMBER.toString());
        final Optional<LdapUser> foundUserOption = userLdapRepository.findByUid(generatedRioNumber.toString());
        externalLdapUser.setNew(foundUserOption.isEmpty());
        userLdapRepository.save(externalLdapUser);
        return generatedRioNumber;
    }

    public LdapUser createServiceUser(final String category,
                                      final String coreName,
                                      final String password) {
        final String serviceUserName = "%s-%s-%s".formatted(SERVICE_ACCOUNT_PREFIX, category, coreName);
        final String hardcodedFilter = "(ou=cpt-svc-%s)".formatted(category);
        LOGGER.debug(serviceUserName);
        LOGGER.debug(hardcodedFilter);
        Iterable<OrganisationalUnit> organisationalUnits = organizationalUnitRepository.findAll(
                LdapQueryBuilder.query().filter(hardcodedFilter)
        );
        organisationalUnits.forEach(organisationalUnit -> {
            LOGGER.debug(organisationalUnit.getId());
            this.create(
                    "uid=%s,%s".formatted(serviceUserName, organisationalUnit.getId()),
                    serviceUserName,
                    serviceUserName,
                    serviceUserName,
                    Long.toString(this.extUserUidNumberSequence.getNextValue()),
                    DEFAULT_GID_NUMBER.toString(),
                    password
            );
        });
        return userLdapRepository.findByUid(serviceUserName).orElseThrow();
    }

    public Optional<LdapUser> get(String uid) {
        return userLdapRepository.findByUid(uid);
    }

    public List<LdapUser> list() {
        return userLdapRepository.findAll();
    }

    public void update(final LdapUser ldapUser) {
        final Optional<LdapUser> optionalUser = get(ldapUser);
        if (optionalUser.isEmpty()) {
            LOGGER.warn("User %s not found, not possible to update");
            return;
        }
        delete(optionalUser.get());
        final LdapUser next = optionalUser.get();
        final ObjectMapper objectMapper = new ObjectMapper();
        try {
            LOGGER.debug(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(next));
        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error(jsonProcessingException.getMessage(), jsonProcessingException);
        }
        next.setNew(true);
        next.setPassword(ldapUser.getPassword());
        create(next);
    }

    public Optional<LdapUser> get(LdapUser ldapUser) {
        return userLdapRepository.findById(ldapUser.getDn());
    }

    public void delete(LdapUser ldapUser) {
        userLdapRepository.delete(ldapUser);
    }

    public Optional<LdapUser> findLDAPUserByEmail(final String userEmail) {
        return userLdapRepository.findByMail(userEmail);
    }

    public Optional<LdapUser> findLDAPUserByUid(final String uid) {
        if (isEmpty(uid)) {
            return Optional.empty();
        }
        return userLdapRepository.findByUid(uid);
    }

    ///// Getters & Setters :

    @Autowired
    public void setExtUserRioSequence(@Qualifier("extUserRIOSeqService") final SequenceService extUserRioSequence) {
        this.extUserRioSequence = extUserRioSequence;
    }

    @Autowired
    public void setExtUserUidNumberSequence(@Qualifier("extUserUidNumberSeqService") final SequenceService extUserUidNumberSequence) {
        this.extUserUidNumberSequence = extUserUidNumberSequence;
    }

    @Autowired
    public void setLdapTemplate(final LdapTemplate ldapTemplate) {
        this.ldapTemplate = ldapTemplate;
    }

    @Autowired
    public void setUserLdapRepository(final UserLdapRepository userLdapRepository) {
        this.userLdapRepository = userLdapRepository;
    }

    public UserLdapRepository getUserLdapRepository() {
        return userLdapRepository;
    }

    @Autowired
    public void setOrganizationalUnitRepository(final OrganizationalUnitRepository organizationalUnitRepository) {
        this.organizationalUnitRepository = organizationalUnitRepository;
    }
}
