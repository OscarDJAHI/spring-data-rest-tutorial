package fr.minint.console.api.project.service;

@Deprecated
public interface BusinessRule {
    boolean isProjectOwnerOrManager(Long projectId, String uid) throws Exception;
    void checkResourceOwnership(Long projectId, Long resourceId, String uid) throws Exception;
}
