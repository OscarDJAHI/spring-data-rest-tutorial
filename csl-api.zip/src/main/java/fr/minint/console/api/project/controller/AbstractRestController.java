package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.ConsoleRole;
import fr.minint.console.api.project.controller.validator.EmailValidator;
import fr.minint.console.library.mock.CanBeMocked;
import fr.minint.console.library.validator.NotNullValidator;
import fr.minint.console.library.validator.Validator;
import fr.minint.console.library.validator.rest.RequestBodyValidator;
import fr.minint.console.library.validator.string.NotBlankStringValidator;
import org.json.JSONObject;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.json.JSONUtils.isJSONFieldNull;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.http.HttpStatus.FORBIDDEN;

public abstract class AbstractRestController implements CanBeMocked {
    protected static final Logger DEFAULT_LOGGER = LoggerFactory.getLogger(AbstractRestController.class);
    protected static final Logger DEFAULT_SSI_LOGGER = LoggerFactory.getLogger("SSI-LOGGER");
    protected static final Validator<Map<String, Object>> REQUEST_BODY_VALIDATOR = new RequestBodyValidator();
    protected static final Validator<Object> NOT_NULL_VALIDATOR = new NotNullValidator();
    protected static final Validator<Object> NOT_BLANK_VALIDATOR = new NotBlankStringValidator();
    protected static final Validator<String> EMAIL_VALIDATOR = new EmailValidator();
    protected transient Logger logger;
    protected transient Logger ssiLogger;
    protected Predicate<KeycloakAuthenticationToken> hasSubscriberGroupPredicate;
    protected Predicate<KeycloakAuthenticationToken> hasSubscriberOrDelegatedSubscriberGroupPredicate;

    ///// Constructeur(s) :

    public AbstractRestController() {
        this.setLogger(DEFAULT_LOGGER);
        this.setSsiLogger(DEFAULT_SSI_LOGGER);
        this.hasSubscriberGroupPredicate = new DefaultHasSubscriberGroup();
        this.hasSubscriberOrDelegatedSubscriberGroupPredicate = new DefaultHasSubscriberOrDelegatedSubscriberGroup();
    }

    ///// Méthodes générales :

    @Override
    public boolean isMocked() {
        return false;
    }

    // TODO : Inliner cette fonction car cette logique doit apparaître dans les contrôleurs
    protected void assertHasSubscriberOrDelegatedSubscriberGroup(final KeycloakAuthenticationToken token) {
        final boolean isOK = this.hasSubscriberOrDelegatedSubscriberGroupPredicate.test(token);
        if (!isOK) {
            this.getSsiLogger().info("L'utilisateur {} a tenté d'accéder à des droits souscripteur ou souscripteur-délégué", token.getName());
            throw new ResponseStatusException(FORBIDDEN, "You are not in subscriber group nor in delegated subscriber group");
        }
    }

    ///// Getters & Setters :

    public void setLogger(final Logger logger) {
        this.logger = (logger == null ? DEFAULT_LOGGER : logger);
    }

    public Logger getLogger() {
        return (logger != null ? logger : DEFAULT_LOGGER);
    }

    public void setSsiLogger(final Logger ssiLogger) {
        this.ssiLogger = ssiLogger;
    }

    public Logger getSsiLogger() {
        return (ssiLogger != null ? ssiLogger : DEFAULT_SSI_LOGGER);
    }

    public void setHasSubscriberGroupPredicate(final Predicate<KeycloakAuthenticationToken> hasSubscriberGroupPredicate) {
        this.hasSubscriberGroupPredicate = hasSubscriberGroupPredicate;
    }

    public Predicate<KeycloakAuthenticationToken> getHasSubscriberGroupPredicate() {
        return hasSubscriberGroupPredicate;
    }

    public void setHasSubscriberOrDelegatedSubscriberGroupPredicate(final Predicate<KeycloakAuthenticationToken> hasSubscriberOrDelegatedSubscriberGroupPredicate) {
        this.hasSubscriberOrDelegatedSubscriberGroupPredicate = hasSubscriberOrDelegatedSubscriberGroupPredicate;
    }

    public Predicate<KeycloakAuthenticationToken> getHasSubscriberOrDelegatedSubscriberGroupPredicate() {
        return hasSubscriberOrDelegatedSubscriberGroupPredicate;
    }

    ///// Méthodes statiques :

    public static boolean hasTokenRole(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                       final ConsoleRole adminRole) {
        return keycloakAuthenticationToken
                .getAuthorities()
                .stream()
                .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(adminRole.value()));
    }

    protected static String getJSONStringValue(final JSONObject jsonResourceRole,
                                               final String fieldName) {
        if (jsonResourceRole == null || isEmpty(fieldName)) {
            return null;
        }
        return isJSONFieldNull(jsonResourceRole, fieldName) ? null : jsonResourceRole.getString(fieldName);
    }


    protected static Long getJSONLongValue(final JSONObject jsonResourceRole,
                                           final String fieldName) {
        if (jsonResourceRole == null || isEmpty(fieldName)) {
            return null;
        }
        return isJSONFieldNull(jsonResourceRole, fieldName) ? null : jsonResourceRole.getLong(fieldName);
    }


    protected static boolean getJSONBooleanValue(final JSONObject jsonResourceRole,
                                              final String fieldName,
                                              final boolean defaultValue) {
        if (jsonResourceRole == null || isEmpty(fieldName)) {
            return defaultValue;
        }
        return isJSONFieldNull(jsonResourceRole, fieldName) ? defaultValue : jsonResourceRole.getBoolean(fieldName);
    }

    ///// Classe(s) interne(s) :

    protected class DefaultHasSubscriberGroup implements Predicate<KeycloakAuthenticationToken> {

        @Override
        public boolean test(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
            if (hasTokenRole(keycloakAuthenticationToken, ConsoleRole.ADMIN)) {
                AbstractRestController.this.getLogger().info("You are in admin group, group belonging assertion cancelled.");
                return true;
            }
            return hasTokenRole(keycloakAuthenticationToken, ConsoleRole.SOUSCRIPTEUR);
        }
    }

    protected class DefaultHasSubscriberOrDelegatedSubscriberGroup implements Predicate<KeycloakAuthenticationToken> {

        @Override
        public boolean test(final KeycloakAuthenticationToken token) {
            if (hasTokenRole(token, ConsoleRole.ADMIN)) {
                AbstractRestController.this.getLogger().info("You are in admin group, group belonging assertion cancelled.");
                return true;
            }
            return hasTokenRole(token, ConsoleRole.SOUSCRIPTEUR) || hasTokenRole(token, ConsoleRole.DELEGUE);
        }
    }


}
