package fr.minint.console.api.project.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "versioned_document", schema = "public", catalog = "ConsoleAdapation")
public class VersionedDocument {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "doc_path", nullable = false, length = 150)
    private String docPath;

    @Basic
    @Column(name = "doc_type_name", nullable = false, length = 150)
    private String docTypeName;

    @Basic
    @Column(name = "version_number", nullable = false)
    private int versionNumber;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @OneToMany(mappedBy = "versionedDocument")
    @JsonManagedReference("parent-versionned-document")
    private Set<Project> projects = new LinkedHashSet<>();

}
