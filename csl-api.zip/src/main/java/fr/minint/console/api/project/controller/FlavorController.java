package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.Flavor;
import fr.minint.console.api.project.repositories.FlavorRepository;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;


@RestController
@RequestMapping("/flavors")
@Setter(onMethod = @__(@Autowired))
public class FlavorController {
    private FlavorRepository flavorRepository;

    @Autowired
    private void setFlavorRepository(FlavorRepository flavorRepository) {
        this.flavorRepository = flavorRepository;
    }

    @GetMapping
    public Iterable<Flavor> list() {
        return flavorRepository.findAll();
    }

    @GetMapping("/{flavor_id}")
    public Optional<Flavor> get(@PathVariable("flavor_id") Long id) {
        return flavorRepository.findById(id);
    }
}
