package fr.minint.console.api.project.configuration.dao;

import fr.minint.console.api.project.dao.JDBCHistoryRecordDAO;
import fr.minint.console.api.project.dao.JDBCUserDAO;
import fr.minint.console.api.project.dao.ZoneDAO;
import fr.minint.console.api.project.dao.ldap.LdapUserDAO;
import fr.minint.console.api.project.dao.pai.JDBCPaiDAO;
import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.dao.project.JDBCProjectRoleDAO;
import fr.minint.console.api.project.dao.quota.JDBCQuotaPricingDAO;
import fr.minint.console.api.project.dao.quota.JDBCQuotaTypeDAO;
import fr.minint.console.api.project.dao.region.JDBCRegionDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceRoleDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceTagDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceTypeDAO;
import fr.minint.console.api.project.dao.role.RoleDAO;
import fr.minint.console.api.project.dao.serviceAccount.JDBCServiceAccountDAO;
import fr.minint.console.api.project.dao.tag.JDBCTagDAO;
import fr.minint.console.api.project.entities.VersionedDocument;
import fr.minint.console.api.project.ldap.PosixGroupDAO;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.model.*;
import fr.minint.console.api.project.repositories.VersionedDocumentRepository;
import fr.minint.console.api.project.repository.ldap.PosixGroupRepository;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.jpa.data.DefaultCrudRepositoryDAO;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.CrudRepository;

import javax.sql.DataSource;

@Configuration
public class DAOConfiguration {



    @Bean(name = "posixGroupDAO")
    @Scope("prototype")
    public PosixGroupDAO getPosixGroupDAO(final PosixGroupRepository posixGroupRepository) {
        return new PosixGroupDAO(posixGroupRepository);
    }

    @Bean(name = "regionDAO")
    @Scope("prototype")
    public DAO<Region> getRegionDAO(final DataSource dataSource) throws Exception {
        final JDBCRegionDAO areaDAO = new JDBCRegionDAO(dataSource);
        areaDAO.start();
        return areaDAO;
    }




    @Bean(name = "serviceAccountDAO")
    @Scope("prototype")
    public DAO<ServiceAccount> getServiceAccountDAO(final DataSource dataSource) throws Exception {
        final JDBCServiceAccountDAO serviceAccountDAO = new JDBCServiceAccountDAO(dataSource);
        serviceAccountDAO.start();
        return serviceAccountDAO;
    }

    @Bean(name = "historiqueDAO")
    @Scope("prototype")
    public DAO<HistoryRecord> getHistoryDAO(final DataSource dataSource) throws Exception {
        final JDBCHistoryRecordDAO jdbcHistoryRecordDAO = new JDBCHistoryRecordDAO(dataSource);
        jdbcHistoryRecordDAO.start();
        return jdbcHistoryRecordDAO;
    }



    @Bean(name = "resourceTypeDAO")
    @Scope("prototype")
    public DAO<ResourceType> buildResourceTypeDAO(final DataSource dataSource) throws Exception {
        final JDBCResourceTypeDAO jdbcResourceTypeDAO = new JDBCResourceTypeDAO(dataSource);
        jdbcResourceTypeDAO.start();
        return jdbcResourceTypeDAO;
    }


    @Bean(name = "tagDAO")
    @Scope("prototype")
    public DAO<Tag> buildTagDAO(final DataSource dataSource) throws Exception {
        final JDBCTagDAO jdbcTagDAO = new JDBCTagDAO(dataSource);
        jdbcTagDAO.start();
        return jdbcTagDAO;
    }

    @Bean(name = "quotaTypeDAO")
    @Scope("prototype")
    public DAO<QuotaType> buildQuotaTypeDAO(final DataSource dataSource) throws Exception {
        final JDBCQuotaTypeDAO jdbcQuotaTypeDAO = new JDBCQuotaTypeDAO(dataSource);
        jdbcQuotaTypeDAO.start();
        return jdbcQuotaTypeDAO;
    }

    @Bean(name = "quotaPricingDAO")
    @Scope("prototype")
    public DAO<QuotaPricing> buildQuotaPricingDAO(final DataSource dataSource) throws Exception {
        final JDBCQuotaPricingDAO jdbcQuotaPricingDAO = new JDBCQuotaPricingDAO(dataSource);
        jdbcQuotaPricingDAO.start();
        return jdbcQuotaPricingDAO;
    }

    @Bean(name = "userDAO")
    @Scope("prototype")
    public DAO<User> buildUserDAO(final DataSource dataSource) throws Exception {
        final JDBCUserDAO jdbcUserDAO = new JDBCUserDAO(dataSource);
        jdbcUserDAO.start();
        return jdbcUserDAO;
    }

    @Bean(name = "paiDAO")
    @Scope("prototype")
    public DAO<Pai> buildPaiDAO(final DataSource dataSource) throws Exception {
        final JDBCPaiDAO jdbcPaiDAO = new JDBCPaiDAO(dataSource);
        jdbcPaiDAO.start();
        return jdbcPaiDAO;
    }
    ///// DAO's des tables de correspondances :



    ///// DAo's pour le LDAP :

    @Bean(name = "ldapUserDAO")
    public DAO<LdapUser> buildLdapUserDAO(@Qualifier("userLdapRepository") final UserLdapRepository ldapUserRepository) throws Exception {
        final LdapUserDAO ldapUserDAO = new LdapUserDAO(ldapUserRepository);
        ldapUserDAO.start();
        return ldapUserDAO;
    }
}
