package fr.minint.console.api.project.types;

public enum ResourceType {
    TENANT("tenant"),
    NAMESPACE("namespace");

    private final String name;

    ResourceType(final String name) {
        this.name = name;
    }

    ///// Getters & Setters :

    public String value() {
        return name;
    }

    public String getName() {
        return name;
    }
}
