package fr.minint.console.api.project.model.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.*;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table
public class ResourceRegion extends AbstractDAOBean<Long> implements ToJSON, Copyable<ResourceRegion> {
    @Id
    private Long id;
    @JsonProperty("resourceId")
    private Long resource;
    @JsonProperty("regionId")
    private Long region;

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonResourceArea = new JSONObject();
        jsonResourceArea.put("id", this.getId());
        jsonResourceArea.put("resourceId", this.getResource());
        jsonResourceArea.put("regionId", this.getRegion());
        return jsonResourceArea;
    }

    ///// Définition de l'égalité et du hashCode :

    @Override
    public int hashCode() {
        return this.functionnalHashCode();
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AbstractDAOBean<?> abstractDAOBean)) {
            return false;
        }
        return this.isFunctionnallyEquals(abstractDAOBean);
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.resource, this.region);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final ResourceRegion area = (ResourceRegion) that;
        boolean areOK = Objects.equals(this.resource, area.getResource());
        areOK = areOK && Objects.equals(this.region, area.getRegion());
        return areOK;
    }

    @Override
    public ResourceRegion copy() {
        return new ResourceRegion(this.id, this.resource, this.region);
    }
}
