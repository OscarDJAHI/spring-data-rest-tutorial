package fr.minint.console.api.project;

import lombok.extern.slf4j.Slf4j;
import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;
import org.keycloak.adapters.springsecurity.client.KeycloakClientRequestFactory;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.keycloak.adapters.springsecurity.config.KeycloakWebSecurityConfigurerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.core.GrantedAuthorityDefaults;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.authority.mapping.SimpleAuthorityMapper;
import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

@Slf4j
@KeycloakConfiguration
@Import(KeycloakSpringBootConfigResolver.class)
public class KeycloakConfig extends KeycloakWebSecurityConfigurerAdapter {
    private static final String[] AUTHENTICATED_ENDPOINTS = {
            "/flavors",
            "/flavor-quotas",
            "/quota-pricing",
            "/quota-types",
            "/regions",
            "/resource-types",
            "/roles",
            "/status",
            "/zones",
            "/pais",
            "/tags"
    };
    private static final String[] PUBLIC_ENDPOINTS = {
            "/version",
            "/swagger-ui/**",
            "/v3/api-docs/**"
    };
    private static final String[] ERROR_ENDPOINTS = {
            "/error"
    };

    @Autowired
    public KeycloakClientRequestFactory keycloakClientRequestFactory;

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public KeycloakRestTemplate keycloakRestTemplate() {
        return new KeycloakRestTemplate(keycloakClientRequestFactory);
    }

    @Bean
    public GrantedAuthorityDefaults grantedAuthorityDefaults() {
        return new GrantedAuthorityDefaults("");
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) {
        KeycloakAuthenticationProvider keycloakAuthenticationProvider = keycloakAuthenticationProvider();
        SimpleAuthorityMapper simpleAuthorityMapper = new SimpleAuthorityMapper();
        simpleAuthorityMapper.setPrefix("");
        keycloakAuthenticationProvider.setGrantedAuthoritiesMapper(simpleAuthorityMapper);
        auth.authenticationProvider(keycloakAuthenticationProvider);
    }

    @Bean
    @Override
    protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        return new NullAuthenticatedSessionStrategy();
    }

    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        super.configure(http);
        String[] ADMIN_ENDPOINTS = {
                "/api/ldap/external-users"
        };
        http.csrf().disable()
                .cors().and()
                .sessionManagement()
                .sessionAuthenticationStrategy(sessionAuthenticationStrategy())
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers(PUBLIC_ENDPOINTS).permitAll()
                .antMatchers(ERROR_ENDPOINTS).permitAll()
                .antMatchers(AUTHENTICATED_ENDPOINTS).authenticated()
                .antMatchers(ADMIN_ENDPOINTS).hasRole(ConsoleRole.ADMIN.value())
                .anyRequest().hasAnyRole(
                        ConsoleRole.ADMIN.value(),
                        ConsoleRole.SOUSCRIPTEUR.value(),
                        ConsoleRole.DELEGUE.value()
                );
    }
}
