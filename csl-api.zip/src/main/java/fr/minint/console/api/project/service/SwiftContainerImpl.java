package fr.minint.console.api.project.service;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * Bidouille pour parser le champs metadata du json reçu plutôt que de faire
 * un get à l'api swift comme dans la lib openstack4j.
 */
public class SwiftContainerImpl extends org.openstack4j.openstack.storage.object.domain.SwiftContainerImpl {
    @JsonProperty
    private Map<String, String> metadata;

    @Override
    public Map<String, String> getMetadata() {
        return metadata;
    }
}
