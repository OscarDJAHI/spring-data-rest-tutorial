package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.dto.project.CreateProjectRoleDto;
import fr.minint.console.api.project.dto.project.UpdateProjectRoleDto;
import fr.minint.console.api.project.entities.RoleAssignement;
import fr.minint.console.api.project.entities.User;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.api.project.service.ProjectRoleService;
import fr.minint.console.persistence.dao.DAO;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.ExecutorService;

import static fr.minint.console.api.project.dao.ldap.LdapUserDAO.LdapUserRIOPredicate.withLdapUserRIO;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCodeFromCollection;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping(path = "/project-roles", produces = MediaType.APPLICATION_JSON_VALUE)
@Setter(onMethod = @__(@Autowired))
public class ProjectRoleController extends AbstractRestController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProjectRoleController.class);
    private ProjectRoleService projectRoleService;
    private EmailNotificationService emailNotificationService;
    private ExecutorService executorService;
    private ProjectRepository projectRepository;
    private RoleAssignementRepository roleAssignementRepository;
    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private DAO<LdapUser> userDAO;

    // DAO's :

    @PostMapping()
    @ResponseStatus(CREATED)
    RoleAssignement create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                           @RequestBody final CreateProjectRoleDto createProjectRoleDto) {
        try {
            String userUid = getUserId(keycloakAuthenticationToken);
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            RoleAssignement projectRoleToCreate = new RoleAssignement();
             Optional<User> ownerOpt = userRepository.findFirstByUid(createProjectRoleDto.getUserId());
            User userRole = null;
            if(ownerOpt.isEmpty()){
                final Optional<LdapUser> existingLdapUser = userDAO.selectFirst(withLdapUserRIO(createProjectRoleDto.getUserId()));
                if(existingLdapUser.isPresent()){
                    final LdapUser ldapUser = existingLdapUser.get();
                    User newUser = new User(
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getMail(),
                            ldapUser.getUid(),
                            true
                    );
                    userRole = userRepository.save(newUser);
                }
            }else{
                userRole = ownerOpt.get();
            }
            projectRoleToCreate.setUser(userRole);
            projectRoleToCreate.setRole(roleRepository.findById(createProjectRoleDto.getRoleId()).get());
            projectRoleToCreate.setProject(projectRepository.findById(createProjectRoleDto.getProjectId()).get());
            projectRoleToCreate.setIsSynchronized(createProjectRoleDto.isSynchronized());
            boolean hasUidXorServiceAccount =
                    (projectRoleToCreate.getUser() == null) == (projectRoleToCreate.getServiceAccount() != null);
            if (!hasUidXorServiceAccount) {
                throw new ResponseStatusException(BAD_REQUEST, "The field uid and serviceAccountId are mutually exclusive");
            }
            final RoleAssignement projectRole = projectRoleService.create(projectRoleToCreate);
            if (projectRoleToCreate.getIsSynchronized()) {
                this.executorService.submit(() -> {
                    try {
                        emailNotificationService.sendProjectRoleCreationNotification(projectRole);
                    } catch (final Exception exception) {
                        LOGGER.error("ERREUR lors de l'envoi par mail de la notification de création de projet : %s".formatted(exception.getMessage()),
                                exception);
                    }
                });
            }
            return projectRole;
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @GetMapping()
    public ResponseEntity<String> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(UNAUTHORIZED, "Non autorisé");
        }
        try {
            return ok(buildJSONCodeFromCollection((Collection<?>) projectRepository.findAll()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getReason());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @GetMapping("/{project_role_id}")
    RoleAssignement get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                    @PathVariable("project_role_id") final Long resourceRoleId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            return roleAssignementRepository.findById(resourceRoleId).get();
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @PutMapping("/{project_role_id}")
    RoleAssignement update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                       @PathVariable("project_role_id") final Long projectRoleId,
                       @RequestBody final UpdateProjectRoleDto updateProjectRoleDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!projectRoleId.equals(updateProjectRoleDto.getId())) {
                throw new ResponseStatusException(FORBIDDEN, "Resource role to update not corresponding with query parameter one");
            }
            RoleAssignement projectRole = roleAssignementRepository.findById(projectRoleId).get();
            projectRole.setId(updateProjectRoleDto.getId());
            projectRole.setIsSynchronized(updateProjectRoleDto.isSynchronized());
            projectRole.setRole(roleRepository.findById(updateProjectRoleDto.getRoleId()).get());
            projectRole.setProject(projectRepository.findById(updateProjectRoleDto.getProjectId()).get());

            return roleAssignementRepository.save(projectRole);
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @DeleteMapping("/{project_role_id}")
    void delete(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                @PathVariable("project_role_id") final Long projectRoleId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            RoleAssignement projectRole = roleAssignementRepository.deleteByProjectId(projectRoleId);
            this.executorService.submit(() -> {
                try {
                    emailNotificationService.sendProjectRoleDeletionNotification(projectRole);
                } catch (final Exception exception) {
                    LOGGER.error("ERREUR lors de l'envoi par mail de la notification de suppression de projet : %s".formatted(exception.getMessage()),
                            exception);
                }
            });
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    ///// Getters & Setters :


    @Autowired
    public void setProjectRoleService(ProjectRoleService projectRoleService) {
        this.projectRoleService = projectRoleService;
    }

    @Autowired
    public void setEmailNotificationService(EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }

    @Autowired
    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }

    @Autowired
    public void setProjectRepository(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
}
