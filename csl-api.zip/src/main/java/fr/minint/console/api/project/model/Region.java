package fr.minint.console.api.project.model;

import fr.minint.console.library.bean.HasName;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table
public class Region extends AbstractDAOBean<Long> implements Comparable<Region>, HasName {
    @Id
    Long id;
    String name;
    String label;
    String color;

    ///// Constructeurs :

    public Region(final Long id, final String name, final String label) {
        this.id = id;
        this.name = name;
        this.label = label;
    }

    public Region(final Long id, final String name, final String label, final String color) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.color = color;
    }

    public Region(final String name, final String label) {
        this.name = name;
        this.label = label;
    }

    public Region() {
        // EMPTY
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.name);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.name, ((Region) that).name);
    }

    ///// Méthodes :

    @Override
    public int compareTo(final Region region) {
        if (region == null) {
            return 1;
        }
        if (name != null) {
            return name.compareTo(region.name);
        }
        if (id == null && region.id == null) {
            return 0;
        } else if (id == null) {
            return -1;
        }
        return id.compareTo(region.id);
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}
