package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Role;
import fr.minint.console.api.project.entities.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface StatusRepository extends JpaRepository<Status, Long>, JpaSpecificationExecutor<Role> {
    Optional<Status> findByName(String name);
}
