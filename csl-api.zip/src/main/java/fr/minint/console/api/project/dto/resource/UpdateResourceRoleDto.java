package fr.minint.console.api.project.dto.resource;

import fr.minint.console.api.project.model.resource.ResourceRole;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class UpdateResourceRoleDto extends CreateResourceRoleDto {

    @NotNull
    Long id;

    @Override
    public ResourceRole toResourceRole() {
        final ResourceRole resourceRole = super.toResourceRole();
        resourceRole.setId(this.getId());
        return resourceRole;
    }
}
