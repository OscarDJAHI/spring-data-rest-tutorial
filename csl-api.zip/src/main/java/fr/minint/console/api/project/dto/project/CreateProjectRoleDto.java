package fr.minint.console.api.project.dto.project;

import fr.minint.console.api.project.model.project.ProjectRole;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class CreateProjectRoleDto {
    @NotNull
    Long projectId;
    @NotNull
    Long roleId;
    String userId;
    Long serviceAccountId;
    boolean isSynchronized;

    public ProjectRole toProjectRole() {
        ProjectRole projectRole = new ProjectRole();

        projectRole.setProject(this.getProjectId());
        projectRole.setRole(this.getRoleId());
        projectRole.setUid(this.getUserId());
        projectRole.setServiceAccount(this.getServiceAccountId());
        projectRole.setSynchronized(this.isSynchronized());

        return projectRole;
    }
}
