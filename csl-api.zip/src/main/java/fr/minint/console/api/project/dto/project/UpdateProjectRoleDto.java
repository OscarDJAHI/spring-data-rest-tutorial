package fr.minint.console.api.project.dto.project;

import fr.minint.console.api.project.model.project.ProjectRole;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class UpdateProjectRoleDto extends CreateProjectRoleDto {

    @NotNull
    Long id;

    @Override
    public ProjectRole toProjectRole() {
        ProjectRole projectRole = super.toProjectRole();

        projectRole.setId(this.getProjectId());

        return projectRole;
    }
}
