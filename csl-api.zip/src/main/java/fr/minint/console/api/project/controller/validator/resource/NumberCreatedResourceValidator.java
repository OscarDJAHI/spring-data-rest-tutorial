package fr.minint.console.api.project.controller.validator.resource;

import fr.minint.console.api.project.model.HistoryRecord;
import fr.minint.console.api.project.repositories.HistoryRepository;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.library.validator.Validator;
import fr.minint.console.persistence.dao.DAO;
import lombok.Getter;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static fr.minint.console.persistence.dao.sql.predicate.time.JDBCTimeBetweenPredicate.withJDBCFieldBetween;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
@Setter
@Getter
public class NumberCreatedResourceValidator implements Validator<KeycloakAuthenticationToken> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NumberCreatedResourceValidator.class);
    private  HistoryRepository historyRepository;
    private final long nbMaxCreatedResource;
    private final Duration maxDuration;
    private final EmailNotificationService emailNotificationService;
    private final transient ExecutorService executorService;

    public NumberCreatedResourceValidator(final HistoryRepository historyReposHistory,
                                          final Number nbMaxCreatedResource,
                                          final Duration maxDuration,
                                          final EmailNotificationService emailNotificationService) {
        this.historyRepository = historyReposHistory;
        this.nbMaxCreatedResource = (nbMaxCreatedResource == null ? 0L : nbMaxCreatedResource.longValue());
        this.maxDuration = maxDuration;
        this.emailNotificationService = emailNotificationService;
        this.executorService = new ThreadPoolExecutor(2, 5, 100, MILLISECONDS, new LinkedBlockingQueue<>());
    }


    @Override
    public boolean validate(final String fieldName,
                            final KeycloakAuthenticationToken keycloakAuthenticationToken,
                            final StringBuilder errorMsgBuffer) {
        try {

            final String userId = getUserId(keycloakAuthenticationToken);
            final Instant now = Instant.now();
            final Date endInstant = Date.from(now);
            final Date beginInstant = Date.from( now.minus(this.maxDuration));
            final Integer countHistory = this.historyRepository.countByUpdatedByAndActionAndUpdatedAtBetween(userId, "create-tenant", beginInstant, endInstant);
            boolean isOK = (countHistory < nbMaxCreatedResource);
            if (!isOK) {
                errorMsgBuffer.append("L'utilisateur (uid = %s) a dépassé la limite de création de ressources".formatted(userId));
                this.executorService.submit(() -> {
                    try {
                        emailNotificationService.sendWorkFlowTenantCreationNotificationEmail(userId);
                    } catch (final MessagingException | IOException exception) {
                        LOGGER.error(exception.getMessage(), exception);
                    }
                });
            }
            return isOK;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return false;
        }
    }

}
