package fr.minint.console.api.project.service.resource.role;

import com.google.common.collect.Lists;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@Setter(onMethod = @__(@Autowired))
public class ResourceRoleServiceImpl implements ResourceRoleService {
    private RoleAssignementRepository resourceRoleRepository;

    @Override
    public RoleAssignement create(RoleAssignement resourceRole) {
        return resourceRoleRepository.save(resourceRole);
    }

    @Override
    public Optional<RoleAssignement> get(Long id) {
        return resourceRoleRepository.findById(id);
    }

    @Override
    public List<RoleAssignement> list() {
        return Lists.newArrayList(resourceRoleRepository.findAll());
    }

    @Override
    public RoleAssignement update(RoleAssignement resourceRole) {
        return resourceRoleRepository.save(resourceRole);
    }

    @Override
    public void delete(RoleAssignement resourceRole) {
        resourceRoleRepository.delete(resourceRole);
    }

    @Override
    public void delete(Long id) {
        resourceRoleRepository.deleteById(id);
    }
}
