package fr.minint.console.api.project;

public enum ConsoleRole {
    ADMIN("admin"),
    SOUSCRIPTEUR("souscripteur"),
    DELEGUE("delegue"),
    S3("s3");

    private final String name;

    ConsoleRole(String name) {
        this.name = name;
    }

    public String value() {
        return name;
    }
}