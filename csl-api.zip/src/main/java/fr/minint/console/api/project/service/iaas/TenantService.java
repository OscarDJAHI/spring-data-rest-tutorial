package fr.minint.console.api.project.service.iaas;

import fr.minint.console.api.project.client.ConsoleApiIaasClient;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.ResourceQuotaService;
import lombok.Setter;
import org.openstack4j.model.identity.v3.Domain;
import org.openstack4j.model.identity.v3.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static fr.minint.console.api.project.types.QuotaType.OBJECT;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

/**
 * <p>
 * Service permettant de gérer les resources de type IAAS c'est à dire
 * les tenants Openstack. <br />
 * </p>
 */
@Service
@Setter(onMethod = @__(@Autowired))
public class TenantService extends AbstractIAASService {
    private final static String OBJECT_QUOTA_TYPE = OBJECT.value();
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final QuotaTypeRepository quotaTypeRepository;
    private Environment environment;
    private ConsoleApiIaasClient consoleApiIaasClient;
    private ResourceQuotaService resourceQuotaService;

    // Définition des DAO's :
    private ResourceRepository resourceRepository;

    public TenantService(UserRepository userRepository, RoleRepository roleRepository, QuotaTypeRepository quotaTypeRepository) {
        super();
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.quotaTypeRepository = quotaTypeRepository;
    }

    @Override
    public Resource create(final Resource resource) throws Exception {
        final Project tenant = consoleApiIaasClient.createOpenstackProject(resource);
        resource.setExternalId(tenant.getId());
        return resourceRepository.save(resource);
//        return (savedResource == null ? null : savedResource.getId());
    }

    private void updateQuota(final ResourceQuota resourceQuota) throws Exception {
        final Optional<QuotaType> foundQuotaTypeOptional = quotaTypeRepository.findById(resourceQuota.getQuotaType().getId());
        if (foundQuotaTypeOptional.isEmpty()) {
            LOGGER.error("Le type de quota ayant l'id {} n'a pas été trouvé", resourceQuota.getQuotaType());
            throw new Exception("Le type de quota ayant l'id %d n'a pas été trouvé".formatted(resourceQuota.getQuotaType()));
        }
        final QuotaType foundQuotaType = foundQuotaTypeOptional.get();
        if (resourceQuotaService.isSkipped(resourceQuota)) {
            LOGGER.info("Le quota %s n'est pas traiter...");
            return;
        }
        if (!foundQuotaType.validate(resourceQuota.getQuotaValue())) {
            throw new Exception("La valeur du quota %s n'est pas dans intervalle définit par le type de quota: [%d; %d] (%d)".formatted(
                    foundQuotaType.getName(),
                    foundQuotaType.getQuotaMin(),
                    foundQuotaType.getQuotaMax(),
                    resourceQuota.getQuotaValue()));
        }

        LOGGER.debug("Mise à jour du quota %s à la valeur %d".formatted(foundQuotaType.getName(), resourceQuota.getQuotaValue()));

        try {
            if (foundQuotaType.getName().equals(OBJECT_QUOTA_TYPE)) {
                consoleApiIaasClient.updateEcsQuota(resourceQuota);
            } else {
                consoleApiIaasClient.updateOpenstackQuota(resourceQuota);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new ResponseStatusException(
                    INTERNAL_SERVER_ERROR,
                    "Une erreur s'est produite lors de la tentative de mise à jour du quota %s".formatted(foundQuotaType.getName())
            );
        }
    }

    @Override
    public Resource get(final Long resourceId) throws Exception {
        final Optional<Resource> foundResourceOptional = resourceRepository.findById(resourceId);
        if (foundResourceOptional == null || foundResourceOptional.isEmpty()) {
            LOGGER.error("La ressource d'id {} n'a pas été trouvée en base de données", resourceId);
            throw new Exception("La ressource d'id %d n'a pas été trouvée".formatted(resourceId));
        }
        return foundResourceOptional.get();
    }

    @Override
    public List<Resource> list() throws Exception {
        return resourceRepository.findAll();
    }

    @Override
    public Long update(final Resource resource) throws Exception {
        final Project currentOpenstackProject = consoleApiIaasClient.getOpenstackProject(resource);
        if (currentOpenstackProject == null) {
            throw new Exception("Le projet OpenStack référencé par la ressource ne semble pas exister");
        }

        if (!currentOpenstackProject.isEnabled()) {
            LOGGER.debug("Activation du project OpenStack %s (id: %s)".formatted(resource.getName(), resource.getExternalId()));
            final Project project = consoleApiIaasClient.enableOpenstackProject(resource);
            if (project == null) {
                throw new Exception("Echec de l'activation du projet %s (id: %s), le projet OpenStack ne semble de pas exister".formatted(resource.getName(), resource.getExternalId()));
            }
        }

        LOGGER.debug("Mise à jour des quotas du project OpenStack %s (id: %s)".formatted(resource.getName(), resource.getExternalId()));
        try {
            for (ResourceQuota quota : resource.getResourceQuotas()) {
                this.updateQuota(quota);
            }
        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new Exception("Une erreur s'est produite lors de la mise à jour des quotas de la ressource %s (id: %s)".formatted(resource.getName(), resource.getId()));
        }

        LOGGER.debug("Mise à jour des données du project OpenStack %s (id: %s)".formatted(resource.getName(), resource.getExternalId()));
        try {
            consoleApiIaasClient.updateOpenstackProject(resource);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new Exception("Echec de la mise à jour des données du projet OpenStack %s".formatted(resource.getExternalId()));
        }
        return resourceRepository.save(resource).getId();
    }

    @Override
    public void delete(final Resource resource) {
        throw new RuntimeException("Methode non implémentée");
    }

    @Override
    public boolean addMember(final RoleAssignement resourceRole) throws Exception {
        final Resource resource = resourceRepository.findById(resourceRole.getResource().getId()).orElse(null);
        if (resource == null) {
            LOGGER.warn("No resource found");
            return false;
        }
        final Role consoleRole = roleRepository.findById(resourceRole.getRole().getId()).orElse(null);
        if (consoleRole == null) {
            LOGGER.warn("No role found");
            return false;
        }
        final String domainName = environment.getProperty("console.api.iaas.openstack.user.domain.name");
        final Region region = consoleApiIaasClient.getRegion(resource.getResourceRegions().stream().findFirst().get().getRegion().getId());
        List<? extends Domain> domains = consoleApiIaasClient.searchOpenstackDomainByName(region, domainName);
        if (domains.isEmpty()) {
            LOGGER.warn("No domain with name '%s' found".formatted(domainName));
            return false;
        }

        final String uid = populateUid(resourceRole);
        if (uid == null) {
            LOGGER.warn("No user id found for the current resource role '%d'".formatted(resourceRole.getId()));
            return false;
        }

        final String roleName = environment.getProperty("console.api.iaas.openstack.user.role.member");
        String targetRoleName = null;
        if (consoleRole.getName().equals("concepteur")
                || consoleRole.getName().equals("iaas-reader")
                || consoleRole.getName().equals("iaas-admin")) {
            targetRoleName = roleName;
        }
        if (targetRoleName == null) {
            LOGGER.warn("No console role matches resource category one");
            return false;
        }

        // Ajout dans le groupe POSIX :
        this.addMemberIntoPosixGroup(resourceRole.getUser().getUid(), resource.getResourceRegions().stream().findFirst().get().getId(), resource.getZone().getId());

        final List<? extends org.openstack4j.model.identity.v3.Role> roles = consoleApiIaasClient.searchOpenstackRoleByName(region, roleName);
        if (roles.isEmpty()) {
            LOGGER.warn("No resource category role with name '%s' found".formatted(roleName));
            return false;
        }

        final Domain domain = domains.get(0);
        final org.openstack4j.model.identity.v3.Role openstackRole = roles.get(0);
        List<? extends org.openstack4j.model.identity.v3.User> keystoneUsers = consoleApiIaasClient.searchOpenstackUserByNameAndDomainId(
                region,
                uid, // consoleUser.getName(),
                domain.getId()
        );

        if (keystoneUsers.isEmpty()) {
            LOGGER.warn("No OpenStack %s domain user matches console user's name".formatted(domainName));
            return false;
        }
        if (keystoneUsers.size() > 1) {
            LOGGER.warn("Too many %s domain users matches console user's name".formatted(domainName));
            return false;
        }

        // ajout
        final org.openstack4j.model.identity.v3.User keystoneUser = keystoneUsers.get(0);
        final Project project = consoleApiIaasClient.getOpenstackProject(region, resource.getExternalId());
        consoleApiIaasClient.grantUserSwiftOperator(region, project, keystoneUser);
        consoleApiIaasClient.grantProjectUserRole(
                region,
                resource.getExternalId(),
                keystoneUser.getId(),
                openstackRole.getId()
        );
        return true;
    }

    @Override
    public Map<String, Object> addMember(final Resource resource,
                                         final LdapUser ldapUser,
                                         final Role role) throws Exception {
        final RoleAssignement resourceRole = new RoleAssignement();
        resourceRole.setResource(resource );
        resourceRole.setUser(userRepository.findFirstByUid(ldapUser.getUid()).get());
        resourceRole.setRole(role);
        resourceRole.setServiceAccount(null);
        final Map<String, Object> returnParamaters = new HashMap<>();
        returnParamaters.put("result", this.addMember(resourceRole));
        return returnParamaters;
    }

    @Override
    public boolean removeMember(final RoleAssignement resourceRole) throws Exception {
        final Resource resource = resourceRepository.findById(resourceRole.getResource().getId()).orElse(null);
        if (resource == null) {
            LOGGER.warn("Pas de resource / tenant trouvé en base de données avec id = {}", resourceRole.getResource());
            return false;
        }

        final Role consoleRole = roleRepository.findById(resourceRole.getRole().getId()).orElse(null);
        if (consoleRole == null) {
            LOGGER.warn("Pas de rôle trouvé en base de données avec l'id = {}", resourceRole.getRole());
            return false;
        }

        final String domainName = environment.getProperty("console.api.iaas.openstack.user.domain.name");
        final Region region = consoleApiIaasClient.getRegion(resource.getResourceRegions().stream().findFirst().get().getRegion().getId());
        final List<? extends Domain> domains = consoleApiIaasClient.searchOpenstackDomainByName(region, domainName);
        if (domains.isEmpty()) {
            LOGGER.warn("No domain with name '%s' found".formatted(domainName));
            return false;
        }

        String uid = populateUid(resourceRole);
        if (uid == null) {
            LOGGER.warn("No user id found for the current resource role '%d'".formatted(resourceRole.getId()));
            return false;
        }

        String roleName = environment.getProperty("console.api.iaas.openstack.user.role.member");
        String targetRoleName = null;
        if (consoleRole.getName().equals("concepteur")
                || consoleRole.getName().equals("iaas-reader")
                || consoleRole.getName().equals("iaas-admin")) {
            targetRoleName = roleName;
        }
        if (targetRoleName == null) {
            LOGGER.warn("No console role matches resource category one");
            return false;
        }

        List<? extends org.openstack4j.model.identity.v3.Role> roles = consoleApiIaasClient.searchOpenstackRoleByName(region, roleName);
        boolean hasNoRoles = roles.isEmpty();
        if (hasNoRoles) {
            LOGGER.warn("No resource category role with name '%s' found".formatted(roleName));
            return false;
        }

        final Domain domain = domains.get(0);
        org.openstack4j.model.identity.v3.Role openstackRole = roles.get(0);
        final List<? extends org.openstack4j.model.identity.v3.User> keystoneUsers = consoleApiIaasClient.searchOpenstackUserByNameAndDomainId(
                region,
                uid, // consoleUser.getName(),
                domain.getId()
        );

        if (keystoneUsers.isEmpty()) {
            LOGGER.warn("No OpenStack %s domain user matches console user's name".formatted(domainName));
            return false;
        }
        if (keystoneUsers.size() > 1) {
            LOGGER.warn("Too many %s domain users matches console user's name".formatted(domainName));
            return false;
        }

        org.openstack4j.model.identity.v3.User keystoneUser = keystoneUsers.get(0);
        final Project project = consoleApiIaasClient.getOpenstackProject(region, resource.getExternalId());
        consoleApiIaasClient.revokeUserSwiftOperator(region, project, keystoneUser);
        consoleApiIaasClient.revokeProjectUserRole(
                region,
                resource.getExternalId(),
                keystoneUser.getId(),
                openstackRole.getId()
        );
        return true;
    }

    ///// Getters & Setters :


}