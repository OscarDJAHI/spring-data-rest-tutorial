package fr.minint.console.api.project.service.sequence;

/**
 * <p>
 * Interface représentant tous les services permettant
 * de gérer les séquences de nombres. <br />
 * </p>
 */
public interface SequenceService {

    Long getCurrentValue();

    void setCurrentValue(Long value);

    Long getNextValue();
}
