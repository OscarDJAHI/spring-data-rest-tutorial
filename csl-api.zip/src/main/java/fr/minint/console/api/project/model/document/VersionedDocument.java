package fr.minint.console.api.project.model.document;

import fr.minint.console.library.bean.HasId;
import fr.minint.console.library.comparator.ComparatorUtils;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;
import java.util.function.Predicate;

@Table
public class VersionedDocument extends AbstractDAOBean<Long> implements HasId<Long>, Comparable<VersionedDocument>, ToJSON {

    @Id
    private Long id;
    private String docPath;
    private String docTypeName;
    private int versionNumber;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    ///// Constructeurs :

    public VersionedDocument(final Long id,
                             final String docPath,
                             final String docTypeName,
                             final int versionNumber,
                             final Instant createdAt,
                             final Instant updatedAt) {
        this.id = id;
        this.docPath = docPath;
        this.docTypeName = docTypeName;
        this.versionNumber = versionNumber;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public VersionedDocument(final Long id,
                             final String docPath,
                             final VersionedDocumentType typeDocument,
                             final int versionNumber) {
        this(id, docPath, (typeDocument == null ? null : typeDocument.getTypeName()), versionNumber, Instant.now(), Instant.now());
    }

    public VersionedDocument(final String docPath,
                             final VersionedDocumentType typeDocument,
                             final int versionNumber) {
        this(null, docPath, (typeDocument == null ? null : typeDocument.getTypeName()), versionNumber, Instant.now(), Instant.now());
    }

    public VersionedDocument(final String docPath) {
        this(null, docPath, null, -1);
    }

    public VersionedDocument() {
        this(null);
    }

    ///// Méthode de la classe AbstractDAOBean

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.docPath, this.docTypeName, this.versionNumber);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final VersionedDocument doc = (VersionedDocument) that;
        boolean areEquals = Objects.equals(this.docPath, doc.docPath);
        areEquals = areEquals && Objects.equals(this.docTypeName, doc.docTypeName);
        areEquals = areEquals && Objects.equals(this.versionNumber, doc.versionNumber);
        return areEquals;
    }

    ///// Méthode de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", this.id);
        jsonObject.put("type", this.getDocTypeName());
        jsonObject.put("path", this.getDocPath());
        jsonObject.put("version", this.versionNumber);
        return jsonObject;
    }

    ///// Méthodes de l'interface Comparable :

    @Override
    public int compareTo(final VersionedDocument versionedDocument) {
        if (versionedDocument == null) {
            return 1;
        }
        if (this.equals(versionedDocument)) {
            return 0;
        }
        int compareResult = ComparatorUtils.compare(this.versionNumber, versionedDocument.versionNumber);
        if (compareResult != 0) {
            return compareResult;
        }
        compareResult = ComparatorUtils.compare(this.docTypeName, versionedDocument.docTypeName);
        if (compareResult != 0) {
            return compareResult;
        }
        return ComparatorUtils.compare(this.docPath, versionedDocument.docPath);
    }

    ///// Méthodes statiques :

    public static Predicate<VersionedDocument> withDocTypePredicate(final VersionedDocumentType docType) {
        return new VersionedDocumentTypePredicate(docType);
    }

    ///// Getters & Setters :

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocPath() {
        return docPath;
    }

    public void setDocPath(String docPath) {
        this.docPath = docPath;
    }

    public String getDocTypeName() {
        return docTypeName;
    }

    public void setDocTypeName(final String docTypeName) {
        this.docTypeName = docTypeName;
    }

    public VersionedDocumentType getDocType() {
        return VersionedDocumentType.getVersionedDocumentTypeFromName(this.docTypeName).orElse(null);
    }

    public void setDocType(final VersionedDocumentType docType) {
        this.setDocTypeName((docType == null ? null : docType.getTypeName()));
    }

    public int getVersionNumber() {
        return versionNumber;
    }

    public void setVersionNumber(final Integer versionNumber) {
        this.versionNumber = versionNumber;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(final Instant updatedAt) {
        this.updatedAt = updatedAt;
    }


    ///// Classe(s) interne(s)

    @SuppressWarnings("ClassCanBeRecord")
    private static class VersionedDocumentTypePredicate implements Predicate<VersionedDocument> {
        private final VersionedDocumentType docType;

        public VersionedDocumentTypePredicate(final VersionedDocumentType docType) {
            this.docType = docType;
        }

        @Override
        public boolean test(final VersionedDocument versionedDocument) {
            if (versionedDocument == null) {
                return false;
            }
            return Objects.equals(docType, versionedDocument.getDocType());
        }
    }

}
