package fr.minint.console.api.project;

import lombok.extern.slf4j.Slf4j;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.representations.AccessToken;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

@Slf4j
@Component
public class UserContextInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        if (httpServletRequest.getMethod().equals(HttpMethod.OPTIONS.name())) {
            return true;
        }

        Enumeration<String> reqHeaders = httpServletRequest.getHeaderNames();
        Set<String> headers = new HashSet<>();
        while (reqHeaders.hasMoreElements()) {
            headers.add(reqHeaders.nextElement().toLowerCase());
        }
        if (headers.contains(HttpHeaders.AUTHORIZATION.toLowerCase())) {
            KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal = (KeycloakPrincipal<KeycloakSecurityContext>) httpServletRequest.getUserPrincipal();

            if (keycloakPrincipal == null) {
                log.debug("No keycloak principal found. Did you enabled at least one security constrains ?");
                return true;
            }

            AccessToken accessToken = keycloakPrincipal
                    .getKeycloakSecurityContext()
                    .getToken();

            String method = httpServletRequest.getMethod();
            String url = httpServletRequest.getRequestURI();
            String userMail = accessToken.getEmail();

            log.info("%s %s by user %s".formatted(method, url, userMail)); // TODO: Create a logger for this information
            // MDC.put("userEmail", String.format("%s", accessToken.getEmail()));
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        MDC.clear();
    }
}
