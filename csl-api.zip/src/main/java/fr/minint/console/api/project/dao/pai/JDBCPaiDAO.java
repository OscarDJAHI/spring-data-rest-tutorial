package fr.minint.console.api.project.dao.pai;

import fr.minint.console.api.project.model.Pai;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.apache.commons.lang3.StringUtils.isEmpty;

public class JDBCPaiDAO extends AbstractJDBCDAO<Long, Pai> {
    private static final Transcoder<ResultSet, Pai> RESULT_SET_PAI_TRANSCODER = new ResultSetPaiTranscoder("pai");

    public JDBCPaiDAO(final DataSource dataSource) {
        super(dataSource, "pai", "pai");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_PAI_TRANSCODER);
    }

    @Override
    public String getSelectAllQuery() {
        return "SELECT " +
                "id AS pai_id," +
                "\"name\" AS pai_name," +
                "code AS pai_code," +
                "description AS pai_description," +
                "created_at AS pai_created_at," +
                "updated_at AS pi_updated_at " +
                " FROM " + this.tableName + " AS " + this.tableAlias;
    }

    @Override
    protected String getInsertQuery(final Pai pai) throws Exception {
        return "INSERT INTO pai (\"name\", code, description, created_at, updated_at) " +
                "VALUES (%s, %s, %s, now(), now())".formatted(escapeSQL(pai.getName()),
                        escapeSQL(pai.getCode()),
                        escapeSQL(pai.getDescription()));
    }

    @Override
    protected String getUpdateQuery(final Pai pai) throws Exception {
        return "UPDATE pai " +
                "SET \"name\"=%s, code=%s, description=%s, updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(pai.getName()),
                                escapeSQL(pai.getCode()),
                                escapeSQL(pai.getDescription()),
                                pai.getId());
    }

    ///// Classe(s) interne(s) :

    public static class ResultSetPaiTranscoder extends AbstractResultSetTranscoder<Pai> {
        private final String sqlFieldPrefix;

        ///// Constructeur(s) :

        public ResultSetPaiTranscoder(final String sqlFieldPrefix) {
            this.sqlFieldPrefix = (sqlFieldPrefix == null ? null : sqlFieldPrefix.trim());
        }

        public ResultSetPaiTranscoder() {
            this(null);
        }

        ///// Méthodes privées :

        private String getFieldName(final String fieldName) {
            if (isEmpty(sqlFieldPrefix)) {
                return fieldName;
            } else {
                return this.sqlFieldPrefix + "_" + fieldName;
            }
        }

        ///// Méthodes de la classe AbstractResultSetTranscoder :

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, this.getFieldName("id")) == null);
            return isNull;
        }

        @Override
        protected Pai doTranscode(final ResultSet resultSet) throws SQLException {
            final Pai pai = new Pai();
            pai.setId(processLongValue(resultSet, this.getFieldName("id")));
            pai.setName(resultSet.getString(this.getFieldName("name")));
            pai.setCode(resultSet.getString(this.getFieldName("code")));
            pai.setDescription(resultSet.getString(this.getFieldName("description")));
            return pai;
        }
    }
}
