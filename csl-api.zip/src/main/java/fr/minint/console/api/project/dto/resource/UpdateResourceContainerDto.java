package fr.minint.console.api.project.dto.resource;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Map;

@Data
public class UpdateResourceContainerDto {
    @NotBlank String name;
    boolean isPublic;
    Map<String, String> metadata;
}
