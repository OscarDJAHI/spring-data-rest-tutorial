package fr.minint.console.api.project.repository.ldap;

import fr.minint.console.api.project.ldap.model.Pers;
import org.springframework.data.ldap.repository.LdapRepository;

public interface PersRepository extends LdapRepository<Pers> {
}
