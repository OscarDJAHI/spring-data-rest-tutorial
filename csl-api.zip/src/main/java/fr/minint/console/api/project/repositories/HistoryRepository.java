package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.History;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Date;

public interface HistoryRepository extends JpaRepository<History, Long>, JpaSpecificationExecutor<History> {
    Integer countByUpdatedByAndActionAndUpdatedAtBetween(String userId, String s, Date beginInstant, Date endInstant);
}
