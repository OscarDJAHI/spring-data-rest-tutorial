package fr.minint.console.api.project.model;

public interface RoleAssignment {
    Long getId();

    Long getTargetKey();

    Long getRole();

    String getUid();

    void setId(Long Id);

    void setTargetKey(Long targetKey);

    void setRole(Long roleKey);

    void setUid(String uid);

    Long getServiceAccountId();
}
