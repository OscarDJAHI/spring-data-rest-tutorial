package fr.minint.console.api.project.service.persistence;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.iaas.AbstractIAASService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;

import static fr.minint.console.api.project.types.Category.IAAS;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;

@Service
public class DefaultBDDResourceService extends AbstractIAASService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultBDDResourceService.class);
    private ResourceRepository resourceRepository;
    private RoleAssignementRepository roleAssignementRepository;

    @Override
    public Resource create(final Resource resource) throws Exception {
        if (resource == null) {
            return null;
        }
//        return resourceDAO.save(resource).getId();
        return resourceRepository.save(resource);
    }

    @Override
    public Resource get(final Long resourceId) throws Exception {
        if (resourceId == null) {
            return null;
        }
        return resourceRepository.findById( resourceId)
                .orElse(null);
    }

    @Override
    public List<Resource> list() throws Exception {
        return resourceRepository.findAll();
    }

    @Override
    public Long update(final Resource resource) throws Exception {
        return resourceRepository
                .save(resource)
                .getId();
    }

    @Override
    public void delete(final Resource resource) throws Exception {
        if (resource == null || resource.getId() == null) {
            LOGGER.info("null ou n'ayant pas d'identifiant => on ne fait rien");
            return;
        }
        resourceRepository.deleteById(resource.getId());
    }

    @Override
    public boolean addMember(final RoleAssignement resourceRole) throws Exception {
        if (resourceRole == null) {
            LOGGER.warn("L'instance ResourceRole à ajouter en base est nulle => on ne fait rien");
            return false;
        }
        final Optional<Resource> foundRepositoryOpt = resourceRepository.findById(resourceRole.getResource().getId());
        if (foundRepositoryOpt.isEmpty()) {
            LOGGER.warn("Pas d'instance Resource avec l'id  = {} => on ne fait rien", resourceRole.getResource());
            return false;
        }
        final Resource resource = foundRepositoryOpt.get();
        final ResourceType resourceType = resource.getResourceType();
        final Long iaasAreaId = resource.getResourceRegions().stream().findFirst().get().getRegion().getId();
        if ((iaasAreaId != null) || (resourceType != null && IAAS .equals(resourceType.getCategory().toString()))) {
            LOGGER.debug("---> IAAS : On rajoute les droits sur le groupe LDAP des bastions POSIX");
            if (iaasAreaId != null) {
                this.addMemberIntoPosixGroup(resourceRole.getUser().getUid(), iaasAreaId, resource.getZone().getId());
            }
        } else {
            LOGGER.debug("---> S3 : Pas d'ajout dans le groupe LDAP des bastion POSIX");
        }
        roleAssignementRepository.save(resourceRole);
        return true;
    }

    @Override
    public Map<String, Object> addMember(final Resource resource,
                                         final LdapUser ldapUser,
                                         final Role role) throws Exception {
        final RoleAssignement resourceRole = this.buildResourceRole(resource, ldapUser, role);
        final Map<String, Object> returnParameters = new HashMap<>();
        returnParameters.put("result", this.addMember(resourceRole));
        return returnParameters;
    }

    @Override
    public boolean removeMember(final RoleAssignement resourceRole) {
        roleAssignementRepository.deleteById(resourceRole.getId());
        return true;
    }

    ///// Getters & Setters :

    @Autowired
    @Override
    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }

    public ExecutorService getExecutorService() {
        return this.executorService;
    }

    @Autowired
    public void setResourceRepository(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }
    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
}
