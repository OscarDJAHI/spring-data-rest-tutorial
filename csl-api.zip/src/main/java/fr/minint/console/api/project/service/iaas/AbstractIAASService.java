package fr.minint.console.api.project.service.iaas;

import fr.minint.console.api.project.entities.RoleAssignement;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.ResourceService;
import fr.minint.console.persistence.dao.DAO;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Optional;
import java.util.concurrent.ExecutorService;

import static fr.minint.console.api.project.ldap.model.PosixGroup.PosixGroupCnPredicat.withCn;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Getter
@Setter
public abstract class AbstractIAASService implements ResourceService {
    protected final static Logger LOGGER = LoggerFactory.getLogger(AbstractIAASService.class);
    protected DAO<PosixGroup> posixGroupDAO;

    // Repositories :
    protected ResourceTagRepository resourceTagRepository;
    protected ResourceRegionRepository resourceRegionRepository;
    protected ResourceQuotaRepository resourceQuotaRepository;
    protected ExecutorService executorService;
    protected ServiceAccountRepository serviceAccountRepository;
    protected RegionRepository regionRepository;
    protected RoleAssignement roleAssignement;
    protected ZoneRepository zoneRepository;
    protected UserRepository userRepository;

    protected String populateUid(final RoleAssignement resourceRole) throws Exception {
        String uid = resourceRole.getUser().getUid();
        if (!isEmpty(uid)) {
            return uid;
        }
        final Optional<ServiceAccount> foundServiceAccountOpt = serviceAccountRepository.findById(resourceRole.getServiceAccount().getId());
        if (foundServiceAccountOpt.isEmpty()) {
            throw new Exception("Pas de compte de service avec id = %d".formatted(resourceRole.getServiceAccount().getId()));
        }
        return foundServiceAccountOpt.get().getUid();
    }

    protected void addMemberIntoPosixGroup(final String userUid,
                                           final Long regionId,
                                           final Long zoneId) throws Exception {
        if (this.posixGroupDAO == null) {
            throw new Exception("Le DAO des groupes POSIX est nul !!");
        }
        final Optional<Region> foundAreaOpt = regionRepository.findById(regionId);
        if (foundAreaOpt.isEmpty()) {
            throw new Exception("Par de région dans la BDD avec l'id = %d".formatted(regionId));
        }
        final Optional<Zone> foundZoneOpt = zoneRepository.findById(zoneId);
        if (foundZoneOpt.isEmpty()) {
            throw new Exception("Par de zone dans la BDD avec l'id = %d".formatted(zoneId));
        }
        final String posixGroupName = "bastion-%s-%s".formatted(foundAreaOpt.get().getName(), foundZoneOpt.get().getName());
        final Optional<PosixGroup> foundPosixGroupOptional = this.posixGroupDAO.selectFirst(withCn(posixGroupName));
        if (foundPosixGroupOptional.isEmpty()) {
            throw new Exception("Pas de groupe POSIX dans le LDAP avec cn = %s".formatted(posixGroupName));
        }
        final PosixGroup foundPosixGroup = foundPosixGroupOptional.get();
        foundPosixGroup.addMember(userUid);
        this.posixGroupDAO.save(foundPosixGroup);
    }

    /**
     * <p>
     * Méthode permettant de constuire une instance de ResourceRole. <br />
     * C'est cette fonction qui distingue les comptes de services des membres physiques. <br />
     * </p>
     *
     * @param resource
     * @param ldapUser
     * @param role
     * @return
     * @throws Exception
     */
    protected RoleAssignement buildResourceRole(final Resource resource, final LdapUser ldapUser, final Role role) throws Exception {
        final RoleAssignement resourceRole = new RoleAssignement();
        resourceRole.setResource(resource);
        final Optional<ServiceAccount> serviceAccountOptional = serviceAccountRepository.findByUid(ldapUser.getUid());
        if (serviceAccountOptional.isEmpty()) {
            resourceRole.setUser(userRepository.findFirstByUid(ldapUser.getUid()).get());
            resourceRole.setRole(role);
            resourceRole.setServiceAccount(null);
        } else {
            resourceRole.setUser(null);
            resourceRole.setRole(role);
            resourceRole.setServiceAccount(serviceAccountOptional.get());
        }
        resourceRole.setIsSynchronized(true);
        return resourceRole;
    }

    ///// Getters & Setters :

    @Autowired
    public void setPosixGroupDAO(@Qualifier("posixGroupDAO") final DAO<PosixGroup> posixGroupDAO) {
        this.posixGroupDAO = posixGroupDAO;
    }

    public DAO<PosixGroup> getPosixGroupDAO() {
        return posixGroupDAO;
    }






    @Autowired
    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
    @Autowired
    public void setRegionRepository(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }

    @Autowired
    public void setResourceTagRepository(ResourceTagRepository resourceTagRepository) {
        this.resourceTagRepository = resourceTagRepository;
    }

    @Autowired
    public void setResourceRegionRepository(ResourceRegionRepository resourceRegionRepository) {
        this.resourceRegionRepository = resourceRegionRepository;
    }

    @Autowired
    public void setResourceQuotaRepository(ResourceQuotaRepository resourceQuotaRepository) {
        this.resourceQuotaRepository = resourceQuotaRepository;
    }

    @Autowired
    public void setServiceAccountRepository(ServiceAccountRepository serviceAccountRepository) {
        this.serviceAccountRepository = serviceAccountRepository;
    }


    @Autowired
    public void setZoneRepository(ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
