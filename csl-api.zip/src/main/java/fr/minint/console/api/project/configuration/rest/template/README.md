# Configuration du client http (RestTemplate)

## Principe

Capturer le jeton JWT de l'utilisateur connecté afin de le propager vers le client http utilisé pour les échanges
micro-service vers micro-service.

## Les classes

Fichier | Description
:-------|:-----------
RequestFilter | Filtre servlet pour capturer le header 'Authorization' lors de l'échange client/api-project.
RequestContext | Contexte (store thread-safe) contenant la valeur du header 'Authorisation'.
RestTemplateInterceptor | Intercepteur RestTemplate qui injecte le header 'Authorization' lors d'échanges api-project/any-micro-service.
RestTemplateConfig | Configuration du filtre et de l'intercepteur via injection de dépendance.

## Liens

* <https://stackoverflow.com/questions/46729203/propagate-http-header-jwt-token-over-services-using-spring-rest-template>