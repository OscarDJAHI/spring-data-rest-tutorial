package fr.minint.console.api.project.ldap.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.Objects;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

import static org.apache.commons.lang3.StringUtils.isEmpty;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entry(objectClasses = {
        "posixGroup",
        "top"
})
final public class PosixGroup implements Persistable<String> {
    @Id
    Name dn;

    @Attribute(name = "cn")
    String cn;

    @Attribute(name = "gidNumber")
    String gidNumber;

    @Attribute(name = "memberUid")
    Set<String> members;

    @JsonIgnore
    @Transient
    boolean isNew;

    ///// Méthodes générales :

    public void addMember(final String member) {
        if (isEmpty(member)) {
            return;
        }
        if (this.members == null) {
            this.members = new HashSet<>();
        }
        this.members.add(member.trim());
    }

    public boolean containsMember(final Predicate<String> predicate) {
        if (predicate == null) {
            return false;
        }
        for (String member : members) {
            if (!predicate.test(member)) {
                continue;
            }
            return true;
        }
        return false;
    }

    ///// Getters & Setters :

    @Override
    public boolean isNew() {
        return isNew;
    }

    @JsonProperty("dn")
    public String getId() {
        return dn.toString();
    }

    @JsonProperty("dn")
    public void setId(final String id) {
        dn = LdapUtils.newLdapName(id);
    }

    ///// Prédicats

    public static class PosixGroupCnPredicat implements Predicate<PosixGroup> {
        private final String cn;

        public PosixGroupCnPredicat(final String cn) {
            this.cn = cn;
        }

        @Override
        public boolean test(final PosixGroup posixGroup) {
            boolean isOK = (posixGroup != null);
            isOK = isOK && Objects.equal(cn, posixGroup.getCn());
            return isOK;
        }

        public static Predicate<PosixGroup> withCn(final String cn) {
            return new PosixGroupCnPredicat(cn);
        }
    }
}

