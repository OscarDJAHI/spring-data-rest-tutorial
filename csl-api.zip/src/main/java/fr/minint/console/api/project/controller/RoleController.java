package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.Role;
import fr.minint.console.api.project.repositories.RoleRepository;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/roles")
@Setter(onMethod = @__(@Autowired))
public class RoleController extends AbstractRestController {
    private RoleRepository roleRepository;

    ///// Définition des "endPoints" :

    @GetMapping
    Iterable<Role> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return roleRepository.findAll();
    }

    @GetMapping("/{role_id}")
    Optional<Role> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("role_id") final Long roleId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return roleRepository.findById(roleId);
    }

    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    ///// Getters & Setters :

}
