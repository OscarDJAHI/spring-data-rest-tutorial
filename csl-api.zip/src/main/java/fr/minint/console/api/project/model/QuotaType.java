package fr.minint.console.api.project.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.NoArgsConstructor;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@NoArgsConstructor
@Table
public class QuotaType extends AbstractDAOBean<Long> implements Copyable<QuotaType>, ToJSON {
    @Id
    private Long id;
    private String name;
    private String label;
    private String quotaIcon;
    private Long quotaMin;
    private Long quotaMax;
    private Long quotaDefault;
    private String quotaUnit;
    private Long priority;

    @JsonProperty("resourceTypeId")
    private Long resourceType;

    // Champs transients

    @Transient
    private QuotaPricing quotaPricing;

    ///// Constructeurs :

    public QuotaType(final Long id,
                     final String name,
                     final String label,
                     final String quotaIcon,
                     final Long quotaMin,
                     final Long quotaMax,
                     final Long quotaDefault,
                     final String quotaUnit,
                     final Long priority,
                     final Long resourceType) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.quotaIcon = quotaIcon;
        this.quotaMin = quotaMin;
        this.quotaMax = quotaMax;
        this.quotaDefault = quotaDefault;
        this.quotaUnit = quotaUnit;
        this.priority = priority;
        this.resourceType = resourceType;
    }

    public QuotaType(final Long id,
                     final String quotaTypeName,
                     final String labelQuota,
                     final String icon,
                     final Long quotaMin,
                     final Long quotaMax,
                     final Long quotaDefault,
                     final String unit,
                     final Long priority) {
        this(id, quotaTypeName, labelQuota, icon, quotaMin, quotaMax, quotaDefault, unit, priority, null);
    }

    public QuotaType(final Long id, final String quotaName) {
        this(id, quotaName, "", null, null, null, null, null, null, null);
    }

    public QuotaType(final Long id, final String quotaName, final Long resourceTypeId) {
        this(id, quotaName, "", null, null, null, null, null, null, resourceTypeId);
    }

    ///// Méthodes de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonQuotaType = new JSONObject();
        jsonQuotaType.put("id", getJSONValueOrNull(this.id));
        jsonQuotaType.put("name", getJSONValueOrNull(this.name));
        jsonQuotaType.put("label", getJSONValueOrNull(this.label));
        jsonQuotaType.put("quotaIcon", getJSONValueOrNull(this.quotaIcon));
        jsonQuotaType.put("quotaMin", getJSONValueOrNull(this.quotaMin));
        jsonQuotaType.put("quotaMax", getJSONValueOrNull(this.quotaMax));
        jsonQuotaType.put("quotaDefault", getJSONValueOrNull(this.quotaDefault));
        jsonQuotaType.put("quotaUnit", getJSONValueOrNull(this.quotaUnit));
        jsonQuotaType.put("pricing", getJSONValueOrNull(this.quotaPricing));
        return jsonQuotaType;
    }


    ///// Méthodes de la classe AbstractDAOBean & Object :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.resourceType, this.name);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final QuotaType quotaType = (QuotaType) that;
        boolean areEquals = Objects.equals(this.resourceType, quotaType.resourceType);
        areEquals = areEquals && Objects.equals(this.name, quotaType.name);
        return areEquals;
    }

    @Override
    public int hashCode() {
        return this.functionnalHashCode();
    }

    /**
     * <p>
     * Les instances de QuotaTypes étant des constantes, l'égalité doit se
     * faire sur la clé fonctionnelle et non l'identifiant dans la base. <br />
     * En conséquence, implémenter l'égalité tel quel est équivalent à avoir ajouter
     * une contrainte d'unicité sur le nom et l'identifiant du type de ressource au niveau de la base de données.<br />
     * </p>
     *
     * @param obj : objet à tester
     * @return résultat du test
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof QuotaType quotaType)) {
            return false;
        }
        return this.isFunctionnallyEquals(quotaType);
    }

    @Override
    public String toString() {
        return "QuotaType [name = '%s', resourceTypeId = %d]".formatted(this.name, this.resourceType);
    }

    public Boolean validate(final Long value) {
        return this.quotaMin <= value && value <= this.quotaMax;
    }

    @Override
    public QuotaType copy() {
        final QuotaType quotaType = new QuotaType();
        quotaType.setId(this.id);
        quotaType.setName(this.name);
        quotaType.setResourceType(this.resourceType);
        quotaType.setLabel(this.label);
        quotaType.setQuotaIcon(this.quotaIcon);
        quotaType.setQuotaMin(this.quotaMin);
        quotaType.setQuotaMax(this.quotaMax);
        quotaType.setQuotaDefault(this.quotaDefault);
        quotaType.setQuotaUnit(this.quotaUnit);
        quotaType.setPriority(this.priority);
        return quotaType;
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public String getQuotaIcon() {
        return quotaIcon;
    }

    public void setQuotaIcon(String quotaIcon) {
        this.quotaIcon = quotaIcon;
    }

    public Long getQuotaMin() {
        return quotaMin;
    }

    public void setQuotaMin(Long quotaMin) {
        this.quotaMin = quotaMin;
    }

    public Long getQuotaMax() {
        return quotaMax;
    }

    public void setQuotaMax(Long quotaMax) {
        this.quotaMax = quotaMax;
    }

    public Long getQuotaDefault() {
        return quotaDefault;
    }

    public void setQuotaDefault(Long quotaDefault) {
        this.quotaDefault = quotaDefault;
    }

    public String getQuotaUnit() {
        return quotaUnit;
    }

    public void setQuotaUnit(String quotaUnit) {
        this.quotaUnit = quotaUnit;
    }

    public Long getPriority() {
        return priority;
    }

    public void setPriority(final Long priority) {
        this.priority = priority;
    }

    public Long getResourceType() {
        return resourceType;
    }

    public void setResourceType(final Long resourceType) {
        this.resourceType = resourceType;
    }

    public QuotaPricing getQuotaPricing() {
        return quotaPricing;
    }

    public void setQuotaPricing(final QuotaPricing quotaPricing) {
        this.quotaPricing = (quotaPricing == null ? null : quotaPricing.copy());
        if (this.quotaPricing != null) {
            this.quotaPricing.setQuotaType(this.id);
        }
    }
}
