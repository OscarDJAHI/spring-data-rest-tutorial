package fr.minint.console.api.project.ldap.model;

import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

import javax.naming.Name;

@Entry(objectClasses = {"organization", "top"})
final public class Organisation {
    @Id
    private Name dn;
    private String o;
}
