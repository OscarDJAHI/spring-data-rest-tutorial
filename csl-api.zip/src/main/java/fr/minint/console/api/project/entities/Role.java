package fr.minint.console.api.project.entities;

import javax.persistence.*;

import fr.minint.console.library.bean.HasId;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Role implements HasId<Long> {
    public static final String RSSI_ROLE_NAME = "rssi";
    public static final String DELEGUE_ROLE_NAME = "delegue";

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", length = -1)
    private String name;

    @Basic
    @Column(name = "label", length = -1)
    private String label;

    @Basic
    @Column(name = "color", length = -1)
    private String color;

    @Basic
    @Column(name = "description", length = -1)
    private String description;

    @Basic
    @Column(name = "ldap_group_rdn", length = -1)
    private String ldapGroupRdn;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    public Role(long id, String label) {
        this.id = id;
        this.label = label;
    }
}
