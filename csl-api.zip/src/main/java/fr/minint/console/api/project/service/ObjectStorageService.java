package fr.minint.console.api.project.service;

import fr.minint.console.api.project.dto.resource.UpdateResourceContainerDto;
import fr.minint.console.api.project.entities.Resource;
import org.openstack4j.model.storage.object.SwiftContainer;
import org.springframework.http.ResponseEntity;

public interface ObjectStorageService {
    void createContainer(Resource resource, UpdateResourceContainerDto updateResourceContainerDto);
    ResponseEntity<SwiftContainer[]> listContainers(Resource resource);
    ResponseEntity<SwiftContainer> getContainer(Resource resource, String containerName);
    void deleteContainer(Resource resource, String containerName);
}
