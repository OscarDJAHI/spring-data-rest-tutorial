package fr.minint.console.api.project.dto.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.api.project.model.resource.ResourceRole;
import fr.minint.console.library.utils.ToMap;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.ldap.odm.annotations.Transient;

import javax.validation.constraints.NotNull;
import java.util.Map;

@Data
@AllArgsConstructor
public class CreateResourceRoleDto implements ToMap {
    @NotNull
    Long resourceId;

    @NotNull
    Long roleId;
    String userId;
    Long serviceAccountId;
    boolean isSynchronized;
    @Deprecated
    @JsonProperty("isS3")
    boolean isS3;  // TODO: A supprimer ultérieurement

    //// Constructeurs :

    public CreateResourceRoleDto() {
        // EMPTY
    }

    public ResourceRole toResourceRole() {
        final ResourceRole resourceRole = new ResourceRole();
        resourceRole.setResource(this.getResourceId());
        resourceRole.setRole(this.getRoleId());
        resourceRole.setUid(this.getUserId());
        resourceRole.setServiceAccount(this.getServiceAccountId());
        resourceRole.setSynchronized(this.isSynchronized());
        return resourceRole;
    }

    @Override
    public Map<String, Object> toMap() {
        return this.toResourceRole().toMap();
    }

    public boolean isServiceAccount() {
       return (serviceAccountId != null);
    }

}
