package fr.minint.console.api.project.ldap.service;

import fr.minint.console.api.project.ldap.model.Group;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repository.ldap.GroupRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
public class LdapGroupService implements GroupService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapGroupService.class);
    @Autowired
    UserService userService;

    @Autowired
    Environment env;

    @Autowired
    GroupRepository groupRepository;

    @Override
    public List<Group> list() {
        return groupRepository.findAll();
    }

    @Override
    public Optional<Group> get(final String cn) {
        return groupRepository.findByCn(cn);
    }

    @Override
    public Optional<Group> update(Group updateGroup) {
        groupRepository.save(updateGroup);
        return groupRepository.findById(updateGroup.getDn());
    }

    @Override
    public void addToSubscriberGroup(final String userUid) {
        addToGroup(userUid, "souscripteur");
    }

    @Override
    public void addToDesignerGroup(String userUid) {
        addToGroup(userUid, "concepteur");
    }

    @Override
    public void addToManagerGroup(String userUid) {
        addToGroup(userUid, "delegue");
    }

    @Override
    public void addToGroup(final String userUid, final String groupCn) {
        final Optional<LdapUser> optionalUser = userService.get(userUid);
        if (optionalUser.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "No user with this uid");
        }
        final LdapUser ldapUser = optionalUser.get();
        if (ldapUser.getId() == null) {
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "LDAP User has DN null i.e getId()");
        }
        final List<Group> allLdapGroups = groupRepository.findAll();
        if (allLdapGroups.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "Pas de groupe LDAP [cn = '%s'] trouvé".formatted(groupCn));
        }
        for (Group subscriberGroup : allLdapGroups) {
            if (!groupCn.equals(subscriberGroup.getCn())) {
                continue;
            }
            if (subscriberGroup.getMembers().stream().anyMatch(member -> member.contains(ldapUser.getId()))) {
                LOGGER.warn("User already present in group {} ==> on ne fait donc rien !!", groupCn);
                continue;
//                throw new ResponseStatusException(OK, "User already present in group %s".formatted(groupCn));
            }
            subscriberGroup.getMembers().add("%s,%s".formatted(ldapUser.getId(), env.getProperty("spring.ldap.base")));
            update(subscriberGroup);
            LOGGER.info("User %s added to group %s".formatted(userUid, groupCn));
        }
    }
}
