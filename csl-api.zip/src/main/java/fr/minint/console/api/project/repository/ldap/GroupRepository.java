package fr.minint.console.api.project.repository.ldap;

import fr.minint.console.api.project.ldap.model.Group;
import org.springframework.data.ldap.repository.LdapRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GroupRepository extends LdapRepository<Group> {
    Optional<Group> findByCn(String cn);
}
