package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.QuotaPricing;
import fr.minint.console.api.project.repositories.QuotaPricingRepository;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCode;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCodeFromCollection;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.ResponseEntity.ok;


@RestController
@RequestMapping("/quota-pricing")
@Setter(onMethod = @__(@Autowired))
public class QuotaPricingController extends AbstractRestController {
    private QuotaPricingRepository quotaPricingRepository;
    ///// Endpoints :

    @GetMapping
    public ResponseEntity<String> list() {
        try {
            return ok(buildJSONCodeFromCollection(quotaPricingRepository.findAll()));
        } catch (final Exception exception) {
            this.logger.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @GetMapping("/{quota_pricing_id}")
    public ResponseEntity<String> get(@PathVariable("quota_pricing_id") final Long quotaPricingId) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOK = NOT_NULL_VALIDATOR.validate("quota_pricing_id", quotaPricingId, errorMsgBuffer);
        if (!isOK) {
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, errorMsgBuffer.toString());
        }
        try {
            final Optional<QuotaPricing> foundQuotaPricingOpt = quotaPricingRepository.findById(quotaPricingId);
            if (foundQuotaPricingOpt.isEmpty()) {
                final String errorMessage = "Pas de quotaPricing avec cet id = %d".formatted(quotaPricingId);
                this.logger.error(errorMessage);
                return createErrorResponseEntity(NOT_FOUND, errorMessage);
            }
            return ok(buildJSONCode(foundQuotaPricingOpt.get()));
        } catch (final Exception e) {
            this.logger.error(e.getMessage(), e);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }
    @Autowired
    public void setQuotaPricingRepository(QuotaPricingRepository quotaPricingRepository) {
        this.quotaPricingRepository = quotaPricingRepository;
    }

    ///// Définition des endPoints :


}
