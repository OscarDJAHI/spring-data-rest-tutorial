package fr.minint.console.api.project.dao.quota;

import fr.minint.console.api.project.dao.resource.JDBCResourceQuotaDAO;
import fr.minint.console.api.project.model.QuotaPricing;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.flavor.FlavorQuota;
import fr.minint.console.api.project.model.resource.ResourceQuota;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCNotNullFieldPredicate.withNotNullJDBCField;
import static java.util.stream.Collectors.toSet;

public class JDBCQuotaTypeDAO extends AbstractJDBCDAO<Long, QuotaType> {
    private static final Transcoder<ResultSet, QuotaType> RESULT_SET_QUOTA_TYPE_TRANSCODER = new ResultSetQuotaTypeTranscoder();
    private static final Transcoder<ResultSet, QuotaPricing> RESULT_SET_QUOTA_PRICING_TRANSCODER = new ResultSetQuotaPricingTranscoder();
    private final DAO<QuotaPricing> quotaPricingDAO;
    private final DAO<ResourceQuota> resourceQuotaDAO;
    private final DAO<FlavorQuota> flavorQuotaDAO;

    ///// Constructeurs :

    public JDBCQuotaTypeDAO(final DataSource dataSource) {
        super(dataSource, "quota_type", "quotaType");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_QUOTA_TYPE_TRANSCODER);

        // Initialisation
        quotaPricingDAO = new JDBCQuotaPricingDAO(dataSource);
        resourceQuotaDAO = new JDBCResourceQuotaDAO(dataSource);
        flavorQuotaDAO = new JDBCFlavorQuotaDAO(dataSource);
    }

    ///// Méthodes de l'interface DAO :

    @Override
    public void start() throws Exception {
        super.start();
        this.quotaPricingDAO.start();
        this.resourceQuotaDAO.start();
        this.flavorQuotaDAO.start();
    }

    @Override
    public void close() throws IOException {
        closeDAO(flavorQuotaDAO);
        closeDAO(resourceQuotaDAO);
        closeDAO(quotaPricingDAO);
        super.close();
    }

    @Override
    public void delete(final Predicate<QuotaType> predicate) throws Exception {

        // On récupère les types de quota à supprimer :
        final List<QuotaType> quotaTypes = this.select(predicate);
        if (isCollectionEmpty(quotaTypes)) {
            return;
        }

        final Set<Long> quotaTypeIds = quotaTypes.stream().map(QuotaType::getId).filter(Objects::nonNull).collect(toSet());

        // On supprime d'abord les "pricings" associés
        if (!isCollectionEmpty(quotaTypeIds)) {
            this.quotaPricingDAO.delete(withFieldInCollection(QuotaPricing.class, "quota_type", quotaTypeIds));
            this.flavorQuotaDAO.delete(withFieldInCollection(FlavorQuota.class, "quota_type", quotaTypeIds));
            this.resourceQuotaDAO.delete(withFieldInCollection(ResourceQuota.class, "quota_type", quotaTypeIds));
        }

        // On supprime les "quota-types"
        super.delete(predicate);
    }

    @Override
    public void delete(final Collection<? extends QuotaType> quotaTypes) throws Exception {
        if (isCollectionEmpty(quotaTypes)) {
            return;
        }

        // On supprime d'abord les "pricings" associés
        final Set<Long> quotaTypeIds = quotaTypes.stream()
                .map(QuotaType::getId)
                .filter(Objects::nonNull)
                .collect(toSet());
        if (!isCollectionEmpty(quotaTypeIds)) {
            this.quotaPricingDAO.delete(withFieldInCollection(QuotaPricing.class, "quota_type", quotaTypeIds));
            this.flavorQuotaDAO.delete(withFieldInCollection(FlavorQuota.class, "quota_type", quotaTypeIds));
            this.resourceQuotaDAO.delete(withFieldInCollection(ResourceQuota.class, "quota_type", quotaTypeIds));
        }

        // On supprime les quota-types :
        super.delete(quotaTypes);
    }

    @Override
    public void deleteAll() throws Exception {

        // On supprime toutes les tables de correspondances :
        this.quotaPricingDAO.delete(withNotNullJDBCField(QuotaPricing.class, "quota_type"));
        this.flavorQuotaDAO.delete(withNotNullJDBCField(FlavorQuota.class, "quota_type"));
        this.resourceQuotaDAO.delete(withNotNullJDBCField(ResourceQuota.class, "quota_type"));

        // On supprime tous les types de quotas :
        super.deleteAll();
    }

    @Override
    protected List<QuotaType> selectFromQuery(final String selectQuery) throws Exception {
        final Connection connection = this.getConnection();
        final Set<QuotaType> quotaTypes = new HashSet<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        QuotaType quotaType;
        try {
            //noinspection SqlSourceToSinkFlow
            preparedStatement = connection.prepareStatement(selectQuery);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                quotaType = RESULT_SET_QUOTA_TYPE_TRANSCODER.transcode(resultSet);
                quotaType.setQuotaPricing(RESULT_SET_QUOTA_PRICING_TRANSCODER.transcode(resultSet));
                quotaTypes.add(quotaType);
            }
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }
        return new ArrayList<>(quotaTypes);
    }

    @Override
    public QuotaType save(final QuotaType quotaType) throws Exception {
        if (quotaType == null) {
            return null;
        }
        final QuotaType savedQuotaType = super.save(quotaType);
        final QuotaPricing quotaPricing = quotaType.getQuotaPricing();
        if (quotaPricing != null) {
            quotaPricing.setQuotaType(savedQuotaType.getId());
            savedQuotaType.setQuotaPricing(this.quotaPricingDAO.save(quotaPricing));
        }
        return savedQuotaType;
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT quotaType.id AS quota_type_id," +
                "   quotaType.\"name\" AS quota_type_name," +
                "   quotaType.\"label\" AS quota_type_label," +
                "   quotaType.quota_icon AS quota_type_icon," +
                "   quotaType.quota_min AS quota_type_min," +
                "   quotaType.quota_max AS quota_type_max," +
                "   quotaType.quota_default AS quota_type_default," +
                "   quotaType.quota_unit AS quota_type_unit," +
                "   quotaType.resource_type AS quota_type_resource_type_id," +
                "   quotaType.priority AS quota_type_priority, " +
                "   quotaPricing.id AS quota_pricing_id, " +
                "   quotaPricing.quota_unit AS quota_pricing_quota_unit, " +
                "   quotaPricing.monthly_price AS quota_pricing_monthly_price, " +
                "   quotaPricing.yearly_price AS quota_pricing_yearly_price " +
                " FROM " + this.tableName + " AS quotaType " +
                "  LEFT JOIN quota_pricing AS quotaPricing ON (quotaPricing.quota_type = quotaType.id)";
    }

    @Override
    protected String getInsertQuery(final QuotaType quotaType) throws Exception {
        if (quotaType == null) {
            throw new Exception("L'instance QuotaType est nulle => on ne peut donc pas créer la requête SQL");
        }
        return "INSERT INTO " +
                this.tableName +
                " (\"name\", \"label\", quota_icon, quota_min, quota_max, quota_default, quota_unit, resource_type, priority, created_at, updated_at) " +
                "VALUES (%s, %s, %s, %d, %d, %d, %s, %d, %d, now(), now())".formatted(
                        escapeSQL(quotaType.getName()),
                        escapeSQL(quotaType.getLabel()),
                        escapeSQL(quotaType.getQuotaIcon()),
                        quotaType.getQuotaMin(),
                        quotaType.getQuotaMax(),
                        quotaType.getQuotaDefault(),
                        escapeSQL(quotaType.getQuotaUnit()),
                        quotaType.getResourceType(),
                        quotaType.getPriority());
    }

    @Override
    protected String getUpdateQuery(final QuotaType quotaType) throws Exception {
        if (quotaType == null) {
            throw new Exception("L'instance QuotaType est nulle => on ne peut donc pas créer la requête de mise à jour");
        }
        return "UPDATE " +
                this.tableName +
                " SET \"name\"=%s, \"label\"=%s, quota_icon=%s, quota_min=%d, quota_max=%d, quota_default=%d, quota_unit=%s, resource_type=%d, priority=%d, updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(quotaType.getName()),
                                escapeSQL(quotaType.getLabel()),
                                escapeSQL(quotaType.getQuotaIcon()),
                                quotaType.getQuotaMin(),
                                quotaType.getQuotaMax(),
                                quotaType.getQuotaDefault(),
                                escapeSQL(quotaType.getQuotaUnit()),
                                quotaType.getResourceType(),
                                quotaType.getPriority(),
                                quotaType.getId());
    }

    ///// Classe(s) interne(s) :

    public static class ResultSetQuotaTypeTranscoder extends AbstractResultSetTranscoder<QuotaType> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "quota_type_id") == null);
            return isNull;
        }

        @Override
        protected QuotaType doTranscode(final ResultSet resultSet) throws SQLException {
            final QuotaType quotaType = new QuotaType();
            quotaType.setId(processLongValue(resultSet, "quota_type_id"));
            quotaType.setName(resultSet.getString("quota_type_name"));
            quotaType.setLabel(resultSet.getString("quota_type_label"));
            quotaType.setQuotaIcon(resultSet.getString("quota_type_icon"));
            quotaType.setQuotaMin(processLongValue(resultSet, "quota_type_min"));
            quotaType.setQuotaMax(processLongValue(resultSet, "quota_type_max"));
            quotaType.setQuotaDefault(processLongValue(resultSet, "quota_type_default"));
            quotaType.setQuotaUnit(resultSet.getString("quota_type_unit"));
            quotaType.setResourceType(processLongValue(resultSet, "quota_type_resource_type_id"));
            quotaType.setPriority(processLongValue(resultSet, "quota_type_priority"));
            return quotaType;
        }
    }

    private static class ResultSetQuotaPricingTranscoder extends AbstractResultSetTranscoder<QuotaPricing> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "quota_pricing_id") == null);
            return isNull;
        }

        @Override
        protected QuotaPricing doTranscode(final ResultSet resultSet) throws SQLException {
            final QuotaPricing quotaPricing = new QuotaPricing();
            quotaPricing.setId(processLongValue(resultSet, "quota_pricing_id"));
            quotaPricing.setQuotaUnit(resultSet.getString("quota_pricing_quota_unit"));
            quotaPricing.setMonthlyPrice(processDoubleValue(resultSet, "quota_pricing_monthly_price"));
            quotaPricing.setYearlyPrice(processDoubleValue(resultSet, "quota_pricing_yearly_price"));
            return quotaPricing;
        }
    }
}
