package fr.minint.console.api.project.ldap.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.domain.Persistable;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;
import java.util.HashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entry(objectClasses = {
//        "gosaGroupOfNames",
        "groupOfNames",
        "top"
})
final public class Group implements Persistable<String> {
    @Id
    Name dn;

    @Attribute(name = "description")
    String description;

    @Attribute(name = "cn")
    String cn;

    @Attribute(name = "gosaGroupObjects")
    Set<String> gosaGroupObjects;

    @Attribute(name = "member")
    Set<String> members;

    @JsonIgnore
    @Transient
    boolean isNew;

    ///// Getters & Setters :

    @Override
    public boolean isNew() {
        return isNew;
    }

    @JsonProperty("dn")
    public String getId() {
        return dn.toString();
    }

    @JsonProperty("dn")
    public void setId(final String id) {
        dn = LdapUtils.newLdapName(id);
    }

    public Set<String> getMembers() {
        return (members == null ? new HashSet<>() : this.members);
    }
}
