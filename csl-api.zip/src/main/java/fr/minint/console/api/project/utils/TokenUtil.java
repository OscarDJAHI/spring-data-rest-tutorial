package fr.minint.console.api.project.utils;

import org.keycloak.representations.AccessToken;

public class TokenUtil {
    private final static String EMPTY_STRING = "";

    public static String[] getUsernameFragments(String givenName) {
        return givenName.split(" ");
    }

    public static String getFirstname(AccessToken accessToken) {
        final String givenName = accessToken.getGivenName();

        if (givenName == null) {
            return EMPTY_STRING;
        }

        final String filteredGivenName = accessToken.getGivenName().trim();
        final String[] fragments = getUsernameFragments(filteredGivenName);

        if (fragments.length > 0) {
            return fragments[0];
        }

        return EMPTY_STRING;
    }

    public static String getRio(AccessToken accessToken) {
        final String givenName = accessToken.getGivenName().trim();
        final String[] fragments = getUsernameFragments(givenName);

        if (fragments.length > 0) {
            return fragments[fragments.length - 1];
        }

        return EMPTY_STRING;
    }
}
