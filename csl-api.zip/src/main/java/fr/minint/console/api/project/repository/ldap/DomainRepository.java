package fr.minint.console.api.project.repository.ldap;

import fr.minint.console.api.project.ldap.model.Domain;
import org.springframework.data.ldap.repository.LdapRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DomainRepository extends LdapRepository<Domain> {
}
