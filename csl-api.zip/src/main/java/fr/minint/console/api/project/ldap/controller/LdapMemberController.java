package fr.minint.console.api.project.ldap.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.minint.console.api.project.ldap.model.Group;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.GroupService;
import fr.minint.console.api.project.ldap.service.PosixGroupService;
import fr.minint.console.api.project.ldap.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Slf4j

@RestController
public class LdapMemberController {
    @Autowired
    UserService userService;

    @Autowired
    GroupService groupService;

    @Autowired
    PosixGroupService posixGroupService;

    @Autowired
    LdapTemplate ldapTemplate;

    @GetMapping("/api/ldap/members/{uid}")
    LdapUser get(@PathVariable String uid) {
        Optional<LdapUser> optionalUser = userService.get(uid);
        if (optionalUser.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "User not found");
        }
        return optionalUser.get();
    }


    private void logGroupLists(String message, List<Group> groupOfNames, List<PosixGroup> posixGroups) {
        ObjectMapper objectMapper = new ObjectMapper();
        log.debug(message);
        try {
            String groupOfNamesStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(groupOfNames);
            String posixGroupsStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(posixGroups);
            log.debug(groupOfNamesStr);
            log.debug(posixGroupsStr);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @GetMapping("/api/ldap/members/{uid}/groups")
    Map<String, Object> getGroups(@PathVariable String uid) {
        LdapUser ldapUser = get(uid);
        HashMap<String, Object> groups = new HashMap<>();

        List<Group> groupOfNames = groupService.list();
        List<PosixGroup> posixGroups = posixGroupService.list();

        logGroupLists("Before group lists cleanup", groupOfNames, posixGroups);

        List<Group> cleanedGroupOfNames = groupOfNames.stream().filter(Objects::nonNull).toList();
        List<PosixGroup> cleanedPosixGroups = posixGroups.stream().filter(Objects::nonNull).toList();

        logGroupLists("After group lists cleanup", cleanedGroupOfNames, cleanedPosixGroups);

        List<Group> filteredGroupOfNames = cleanedGroupOfNames.stream().filter(group -> group.getMembers().stream().anyMatch(member -> member.contains(ldapUser.getUid()))).toList();
        List<PosixGroup> filteredPosixGroups = cleanedPosixGroups.stream().filter(group -> group.getMembers().stream().anyMatch(member -> member.contains(ldapUser.getUid()))).toList();

        List<String> groupOfNamesCn = filteredGroupOfNames.stream().map(Group::getCn).toList();
        List<String> posixGroupsCn = filteredPosixGroups.stream().map(PosixGroup::getCn).toList();

        groups.put("groupOfNames", filteredGroupOfNames);
        groups.put("posixGroups", filteredPosixGroups);
        groups.put("groupOfNamesCn", groupOfNamesCn);
        groups.put("posixGroupsCn", posixGroupsCn);
        return groups;
    }

    @PutMapping("/api/ldap/members/{uid}")
    public void update(@PathVariable String uid, @RequestBody LdapUser ldapUser) {
        Optional<LdapUser> optionalUser = userService.get(uid);
        if (optionalUser.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "User not found");
        }
        if (!optionalUser.get().getUid().equals(ldapUser.getUid())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Uid not matches body one");
        }
        userService.update(ldapUser);
    }
}
