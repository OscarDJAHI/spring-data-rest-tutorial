package fr.minint.console.api.project.controller;

 import fr.minint.console.api.project.repositories.ZoneRepository;
 import lombok.Getter;
 import lombok.extern.slf4j.Slf4j;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
@Getter
public class TestController {
    private final HttpServletRequest request;
    private final ZoneRepository zoneRepository;

    @Autowired
    public TestController(HttpServletRequest request, ZoneRepository zoneRepository) {
        this.request = request;
        this.zoneRepository = zoneRepository;
    }

    @GetMapping(value = "/access-token")
    public AccessToken getAccessToken() {
        SecurityContextHolder.getContext().getAuthentication().getAuthorities().forEach(grantedAuthority -> log.debug(grantedAuthority.getAuthority()));
        return getKeycloakSecurityContext().getToken();
    }

    private KeycloakSecurityContext getKeycloakSecurityContext() {
        return (KeycloakSecurityContext) request.getAttribute(KeycloakSecurityContext.class.getName());
    }
}
