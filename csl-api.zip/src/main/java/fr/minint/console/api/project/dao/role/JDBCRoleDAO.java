package fr.minint.console.api.project.dao.role;

import fr.minint.console.api.project.model.Role;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCRoleDAO extends AbstractJDBCDAO<Long, Role> {

    public JDBCRoleDAO(final DataSource dataSource) {
        super(dataSource, "role", "role");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(new ResultSetRoleTranscoder());
    }

    @Override
    public String getSelectAllQuery() {
        return "SELECT id AS role_id, " +
                "\"name\" AS role_name," +
                "\"label\" AS role_label," +
                "color AS role_color," +
                "description AS role_description," +
                "ldap_group_rdn AS role_ldap_group_rdn," +
                "enabled AS role_enabled," +
                "created_at AS role_created_at," +
                "updated_at AS role_updated_at" +
                " FROM \"role\" AS role";
    }

    @Override
    protected String getInsertQuery(final Role role) throws Exception {
        if (role == null) {
            throw new Exception("Le role est nul => on ne peut donc créer la requête d'insertion dans la table Role");
        }
        return "INSERT INTO \"role\" " +
                "(\"name\", \"label\", color, description, ldap_group_rdn, enabled, created_at, updated_at) " +
                " VALUES (%s, %s, %s, %s, %s, %s, now(), now())"
                        .formatted(escapeSQL(role.getName()),
                                escapeSQL(role.getLabel()),
                                escapeSQL(role.getColor()),
                                escapeSQL(role.getDescription()),
                                escapeSQL(role.getLdapGroupRdn()),
                                (role.isEnabled() ? "true" : "false"));
    }

    @Override
    protected String getUpdateQuery(final Role role) throws Exception {
        if (role == null) {
            throw new Exception("Le role est nul => on ne peut donc créer la requête de mise à jour dans la table Role");
        }
        return "UPDATE \"role\" " +
                "SET \"name\"=%s, \"label\"=%s, color=%s, description=%s, ldap_group_rdn=%s, enabled=%s, created_at=now(), updated_at=now() WHERE id=%d"
                        .formatted(
                                escapeSQL(role.getName()),
                                escapeSQL(role.getLabel()),
                                escapeSQL(role.getColor()),
                                escapeSQL(role.getDescription()),
                                escapeSQL(role.getLdapGroupRdn()),
                                (role.isEnabled() ? "true" : "false"),
                                role.getId());
    }

    ///// Classe(s) internes(s) :


    private static class ResultSetRoleTranscoder extends AbstractResultSetTranscoder<Role> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "role_id") == null);
            return isNull;
        }

        @Override
        protected Role doTranscode(final ResultSet resultSet) throws SQLException {
            final Role role = new Role();
            role.setId(processLongValue(resultSet, "role_id"));
            role.setName(resultSet.getString("role_name"));
            role.setDescription(resultSet.getString("role_description"));
            role.setColor(resultSet.getString("role_color"));
            role.setLdapGroupRdn(resultSet.getString("role_ldap_group_rdn"));
            role.setEnabled(resultSet.getBoolean("role_enabled"));
            return role;
        }
    }
}
