package fr.minint.console.api.project.email.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "console.api.email")
public class EmailConfiguration {
    String encoding;
    String noReply;
    String consoleUrl;
    List<TemplateConfiguration> templates = new ArrayList<>();
}
