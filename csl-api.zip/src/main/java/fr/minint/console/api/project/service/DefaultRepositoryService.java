package fr.minint.console.api.project.service;

import fr.minint.console.library.bean.HasId;
import fr.minint.console.library.utils.predicate.IdPredicate;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.function.Predicate;

import static com.google.common.collect.Lists.newArrayList;

public class DefaultRepositoryService<ID, T extends HasId<ID>> implements GeneralService<T> {
    protected final CrudRepository<T, ID> entityRepository;

    public <R extends CrudRepository<T, ID>> DefaultRepositoryService(final R entityRepository) {
        this.entityRepository = entityRepository;
    }

    ///// Méthodes de la classe AbstractGeneralService :

    @Override
    public List<T> find(final Predicate<T> predicate) {
        if (predicate instanceof IdPredicate<?, ?>) {
            this.entityRepository.findById(((IdPredicate<ID, T>) predicate).getId());
        }
        return GeneralService.super.find(predicate);
    }

    ///// Méthodes de l'interface GeneralService

    @Override
    public List<T> list() {
        return newArrayList(entityRepository.findAll());
    }

    @Override
    public T update(final T bean) {
        return this.save(bean);
    }

    @Override
    public T save(final T bean) {
        return entityRepository.save(bean);
    }

    @Override
    public void delete(final T bean) {
        if (bean == null) {
            return;
        }
        entityRepository.delete(bean);
    }
}
