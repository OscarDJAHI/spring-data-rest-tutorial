package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.model.HistoryRecord;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * DAO des Historique utilisant les connexions JDBC.
 * </p>
 */
public class JDBCHistoryRecordDAO extends AbstractJDBCDAO<Long, HistoryRecord> {
    private static final Transcoder<ResultSet, HistoryRecord> HISTORIQUE_RESULT_SET_TRANSCODER = new HistoriqueResultSetTranscoder();

    ///// Constructeur(s) :

    public JDBCHistoryRecordDAO(final DataSource dataSource) {
        super(dataSource, "history", "hist");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(HISTORIQUE_RESULT_SET_TRANSCODER);
    }

    @Override
    public void start() throws Exception {
        this.logInfo("---> Démarrage de HistoryRecordDAO");
    }

    @Override
    public void close() throws IOException {
        this.logInfo("---> Fermeture de HistoryRecordDAO");
    }

    ///// Méthode de la classe AbstractJDBCDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT * "+
                "  FROM " + this.tableName + " AS " + this.tableAlias;
    }

    @Override
    protected String getInsertQuery(final HistoryRecord historyRecord) throws Exception {
        if (historyRecord == null) {
            throw new Exception("L'instance de Historique est nulle => on ne peut donc pas créer la requête SQL d'insertion");
        }
        return "INSERT INTO " + this.tableName + " AS " + this.tableAlias +
                "(action, ancienne_valeur, nouvelle_valeur, modified_table, updated_by, updated_at, created_at) " +
                "VALUES (%s, %s, %s, %s, %s, now(), now())"
                        .formatted(escapeSQL(historyRecord.getAction()),
                                escapeSQL(historyRecord.getAncienneValeur()),
                                escapeSQL(historyRecord.getNouvelleValeur()),
                                escapeSQL(historyRecord.getModifiedTable()),
                                escapeSQL(historyRecord.getUpdatedBy()));
    }

    @Override
    protected String getUpdateQuery(final HistoryRecord historyRecord) throws Exception {
        if (historyRecord == null) {
            throw new Exception("L'instance de ServiceAccount est nulle => on ne peut donc pas créer la requête SQL de mise à jour");
        }
        return "UPDATE " + this.tableName + " AS " + this.tableAlias +
                " SET action=%s, ancienne_valeur=%s, nouvelle_valeur=%s, modified_table=%s, updated_by=%s, updated_at=now() WHERE id=%d".formatted(
                        escapeSQL(historyRecord.getAction()),
                        escapeSQL(historyRecord.getAncienneValeur()),
                        escapeSQL(historyRecord.getNouvelleValeur()),
                        escapeSQL(historyRecord.getModifiedTable()),
                        escapeSQL(historyRecord.getUpdatedBy()),
                        historyRecord.getId());
    }

    @Override
    protected List<HistoryRecord> selectFromQuery(final String selectQuery) throws Exception {
        if (isEmpty(selectQuery)) {
            throw new Exception("SelectFromQuery ---> La requête SQL à exécuter est soit vide ou nulle");
        }
        final List<HistoryRecord> historyRecords = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        HistoryRecord historyRecord;
        try {
            connection = this.getConnection();
            //noinspection SqlSourceToSinkFlow
            preparedStatement = connection.prepareStatement(selectQuery);
            resultSet = preparedStatement.executeQuery();

            // Boucle sur le résultat :
            while (resultSet.next()) {
                historyRecord = HISTORIQUE_RESULT_SET_TRANSCODER.transcode(resultSet);
                historyRecords.add(historyRecord);
            }

            // On renvoie la liste :
            return historyRecords;
        } catch (final Exception exception) {
            this.getLogger().error(exception.getMessage(), exception);
            throw exception;
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }

    }

    ///// Classe(s) interne(s) :

    private static class HistoriqueResultSetTranscoder extends AbstractResultSetTranscoder<HistoryRecord> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected HistoryRecord doTranscode(final ResultSet resultSet) throws SQLException {
            final HistoryRecord historyRecord = new HistoryRecord();
            historyRecord.setId(processLongValue(resultSet, "id"));
            historyRecord.setAction(resultSet.getString("action"));
            historyRecord.setAncienneValeur(resultSet.getString("ancienne_valeur"));
            historyRecord.setNouvelleValeur(resultSet.getString("nouvelle_valeur"));
            historyRecord.setModifiedTable(resultSet.getString("modified_table"));
            historyRecord.setUpdatedBy(resultSet.getString("updated_by"));
            historyRecord.setCreatedAt(processTimestampField(resultSet, "created_at"));
            historyRecord.setUpdatedAt(processTimestampField(resultSet, "updated_at"));
            return historyRecord;
        }
    }

}
