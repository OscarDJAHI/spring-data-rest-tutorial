package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.ResourceTag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ResourceTagRepository extends JpaRepository<ResourceTag, Long>, JpaSpecificationExecutor<ResourceTag> {
}
