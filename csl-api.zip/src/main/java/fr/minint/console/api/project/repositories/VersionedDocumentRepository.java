package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.VersionedDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface VersionedDocumentRepository extends JpaRepository<VersionedDocument, Long>, JpaSpecificationExecutor<VersionedDocument> {
    Optional<VersionedDocument> findFirstByDocTypeNameOrderByVersionNumberDesc(String typeDocument);

    Optional<VersionedDocument> findFirstByDocTypeNameAndVersionNumber(String typeDocument, int versionNumber);

    Optional<VersionedDocument> findByDocTypeName(String docTypeName);
}
