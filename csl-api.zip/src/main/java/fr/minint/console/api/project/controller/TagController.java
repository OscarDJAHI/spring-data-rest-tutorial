package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.dto.CreateTagDto;
import fr.minint.console.api.project.dto.TagDto;
import fr.minint.console.api.project.entities.Tag;
import fr.minint.console.api.project.repositories.TagRepository;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


@Slf4j
@RestController
@Setter(onMethod = @__(@Autowired))
public class TagController extends AbstractRestController {
    @Autowired
    private  TagRepository tagRepository;
    @PostMapping("/tags")
    ResponseEntity<Tag> create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                               @RequestBody final CreateTagDto createTagDto) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        final Tag tag = tagRepository.save(new Tag(createTagDto.getName(), createTagDto.getLabel(), createTagDto.getColor()));
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{tag_id}")
                .buildAndExpand(tag.getId())
                .toUri();
        return ResponseEntity.created(location).build();
    }

    @GetMapping("/tags")
    List<Tag> list(KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return tagRepository.findAll();
    }

    @GetMapping("/tags/:tag_id")
    ResponseEntity<Tag> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("tag_id") final Long tagId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        Optional<Tag> optionalTag = tagRepository.findById(tagId);
        return optionalTag
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/tags/:tag_id")
    ResponseEntity<Tag> update(
            KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("tag_id") Long tagId,
            @RequestBody TagDto tagDto
    ) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);

        if (!Objects.equals(tagId, tagDto.getId()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ids not match");

        Optional<Tag> optionalOldTag = tagRepository.findById(tagId);

        Tag updatedTag =optionalOldTag.get();
        updatedTag.setName(tagDto.getName());
        updatedTag.setLabel(tagDto.getLabel());
        updatedTag.setColor(tagDto.getColor());

        tagRepository.save(updatedTag);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{tag_id}")
                .buildAndExpand(updatedTag.getId())
                .toUri();

        if (optionalOldTag.isEmpty())
            return ResponseEntity.created(location).build();
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/tags/:tag_id")
    void delete(final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("tag_id") final Long tagId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        tagRepository.deleteById(tagId);
    }



    ///// Getters & Setters :

    @Autowired
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }
}
