package fr.minint.console.api.project.utils;

import java.math.BigDecimal;

import static java.math.BigDecimal.ZERO;
import static java.math.RoundingMode.HALF_EVEN;

public enum RAMUnit {
    KILO(1),
    MEGA(1024),
    GIGA(1024*1024);

    private final BigDecimal coef;

    RAMUnit(final Number coef) {
        this.coef = new BigDecimal(coef.toString());
    }

    public static BigDecimal convertTo(final Number value, final RAMUnit startUnit, final RAMUnit endUnit) {
        BigDecimal result = (value == null ? ZERO : new BigDecimal(value.toString()));
        result = result.multiply(startUnit.getCoef());
        result = result.divide(endUnit.getCoef(), 4, HALF_EVEN);
        return result;
    }

    public BigDecimal getCoef() {
        return coef;
    }

    public static RAMUnit fromUnit(String unit) {
        return switch (unit) {
            case "Ko" -> KILO;
            case "Mo" -> MEGA;
            case "Go" -> GIGA;
            default -> null;
        };
    }
}
