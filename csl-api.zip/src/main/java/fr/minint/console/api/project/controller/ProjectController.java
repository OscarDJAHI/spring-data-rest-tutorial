package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.ObjectStorageProvider;
import fr.minint.console.api.project.client.ConsoleApiIaasClient;
import fr.minint.console.api.project.dto.CreateProjectServiceAccountDto;
import fr.minint.console.api.project.dto.CreateResourceServiceAccountDto;
import fr.minint.console.api.project.dto.UpdateServiceAccountDto;
import fr.minint.console.api.project.dto.project.CreateProjectDto;
import fr.minint.console.api.project.dto.resource.CreateResourceDto;
import fr.minint.console.api.project.dto.resource.UpdateResourceContainerDto;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.entities.*;

import fr.minint.console.api.project.service.*;
import fr.minint.console.api.project.utils.RAMUnit;
import fr.minint.console.api.project.utils.TokenUtil;
import fr.minint.console.library.exception.BadRequestException;
import fr.minint.console.library.validator.AbstractValidator;
import fr.minint.console.library.validator.Validator;
import fr.minint.console.persistence.dao.DAO;
import io.swagger.v3.oas.annotations.Operation;
import lombok.Setter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.openstack4j.model.storage.object.SwiftContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.validation.Valid;
import java.io.IOException;
import java.net.URI;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static fr.minint.console.api.project.dao.ldap.LdapUserDAO.LdapUserRIOPredicate.withLdapUserRIO;
import static fr.minint.console.api.project.model.Role.*;
import static fr.minint.console.api.project.model.document.VersionedDocumentType.CGU;
import static fr.minint.console.library.utils.NumberUtils.convertToLong;
import static fr.minint.console.library.utils.collection.MapUtils.hasNotNullField;
import static fr.minint.console.library.utils.json.JSONUtils.*;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getAccessToken;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static fr.minint.console.library.validator.EqualValueValidator.valueEqualsToValidator;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/projects")
@Setter(onMethod = @__(@Autowired))
public class ProjectController extends AbstractRestController {
    private ProjectRepository projectRepository;
    private ResourceTypeRepository resourceTypeRepository;
    private ResourceController resourceController;
    private QuotaTypeRepository quotaTypeRepository;
    private EmailNotificationService emailNotificationService;
    private RegionRepository regionRepository;
    private ConsoleApiIaasClient consoleApiIaasClient;
    private ResourceRepository resourceRepository;
    private BusinessRule businessRule;
    private ObjectStorageService objectStorageService;
    private ObjectStorageProvider objectStorageProvider;

    private DAO<LdapUser> ldapUserDAO;

    // Multi-threading :
    private ExecutorService executorService;
    private RoleRepository roleRepository;
    private VersionedDocumentRepository versionedDocumentRepository;
    private StatusRepository statusRepository;
    private PaiRepository paiRepository;
    private UserRepository userRepository;
    private RoleAssignementRepository roleAssignementRepository;
    private ServiceAccountRepository serviceAccountRepository;
    private ResourceRegionRepository resourceRegionRepository;
    private DAO<LdapUser> userDAO;

    ///// Méthode(s) privée(s) :
/*
    private void synchroniseResourceRoleUtilisateurs(final Collection<? extends Resource> resources) throws Exception {
        final Set<ResourceRole> resourceRoles = new HashSet<>();
        for (Resource resource : resources) {
            if (resource == null || isCollectionEmpty(resource.getResourceRoles())) {
                continue;
            }
            resourceRoles.addAll(resource.getResourceRoles());
        }
        setResourceRoleUser(resourceRoles);
    }

    private void setResourceRoleUser(final Collection<? extends ResourceRole> resourceRoles) throws Exception {

        // Utilisateurs déjà persistés :
        final Set<String> resourceRios = resourceRoles.stream().map(ResourceRole::getUid).collect(toSet());
        final List<User> existingUsers = this.userDAO
                .select(withFieldInCollection(User.class, "rio", resourceRios));
        final List<LdapUser> existingLdapUsers = this.ldapUserDAO
                .select(withLdapUserRIOInCollection(resourceRios));

        // Affichage :
        if (existingLdapUsers == null) {
            this.getLogger().info("===> existingLDAPUsers nulle");
        } else {
            this.getLogger().info("===> existingLDAPUsers size = {}", existingLdapUsers.size());
            for (LdapUser existingLdapUser : existingLdapUsers) {
                this.getLogger().info("---> LdapUser rio=%s, cn=%s".formatted(existingLdapUser.getUid(), existingLdapUser.getCn()));
            }
        }

        // Traitement des comptes de services :
        final Set<User> usersToSave = new HashSet<>();
        final List<ServiceAccount> existingServiceAccount = serviceAccountDAO
                .select(withFieldInCollection(ServiceAccount.class, "id", resourceRoles.stream().filter(ResourceRole::isServiceAccount).map(ResourceRole::getServiceAccountId).collect(toSet())));
        String userUid;
        ServiceAccount foundServAccount;
        User foundUser, newUser;
        LdapUser foundLdapUser;
        for (ResourceRole resourceRole : resourceRoles) {
            userUid = resourceRole.getUid();
            if (isEmpty(userUid) && !resourceRole.isServiceAccount()) {
                this.getLogger().warn("uid de l'utilisateur est null ou vide pour la ligne id = {} de la table ResourceRole", resourceRole.getId());
                continue;
            } else if (isEmpty(userUid)) {
                foundServAccount = findFirst(existingServiceAccount, withId(resourceRole.getServiceAccountId()));
                if (foundServAccount == null || isEmpty(foundServAccount.getUserUid())) {
                    this.getLogger().warn("---> Attention : Le compte de service id = {} n'existe pas ou n'a pas de uid", resourceRole.getServiceAccountId());
                    continue;
                }
                userUid = foundServAccount.getUserUid();
            }
            foundUser = findFirst(existingUsers, hasRIO(userUid));
            if (foundUser != null) {
                resourceRole.setUser(foundUser);
                continue;
            }
            if (resourceRole.isServiceAccount()) {
                newUser = new User(userUid, "", "", null, true);
            } else {
                foundLdapUser = findFirst(existingLdapUsers, hasRIO(userUid));
                if (foundLdapUser == null) {
                    this.getLogger().info("---> Cas Utilisateur non trouvé dans le LDAP");
                    newUser = new User(resourceRole.getUid(), "", "", null, false);
                } else {
                    this.getLogger().info("---> Cas Utilisateur dans le LDAP avec cn = %s".formatted(foundLdapUser.getCn()));
                    this.getLogger().info("---> Utilisateur trouvé  : {}", foundLdapUser);
                    newUser = new User(resourceRole.getUid(), "", "", foundLdapUser.getMail(), false);
                    newUser.setCn(foundLdapUser.getCn());
                }
            }
            resourceRole.setUser(newUser);
            usersToSave.add(newUser);
        }


        // Sauvegarde en base en mode parallelisme :
        executorService.submit(() -> {
            try {
                userDAO.save(usersToSave);
            } catch (final Exception exception) {
                ProjectController.this.getLogger().error(exception.getMessage(), exception);
            }
        });

    }

    private void synchroniseProjectRoleUtilisateurs(final Collection<? extends Project> projects) throws Exception {

        // Récupération des rôles :
        final Optional<Role> subscriberRoleOpt = roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "souscripteur"));
        if (subscriberRoleOpt.isEmpty()) {
            throw new Exception("Le role 'souscripteur' est manquant dans la table 'Role'");
        }
        final Optional<Role> rssiRoleOpt = roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", RSSI_ROLE_NAME));
        if (rssiRoleOpt.isEmpty()) {
            throw new Exception("Le role 'rssi' est manquant dans la table 'Role'");
        }

        // Récupération des utilisateurs existants :
        final Set<ProjectRole> projectRoles = new HashSet<>();
        for (Project project : projects) {

            // TODO : Traiter le champs "owner" en tant que lien projet <-> rôle => ce code devra disparaître
            if (!project.hasUserWithRole(project.getOwnerId(), subscriberRoleOpt.get())) {
                project.addRoleToUser(project.getOwnerId(), subscriberRoleOpt.get());
            }
            projectRoles.addAll(project.getProjectRoles());
        }
        this.setProjectRoleUser(projectRoles);

    }

    private void setProjectRoleUser(final Collection<? extends ProjectRole> projectRoles) throws Exception {

        // Cas limite :
        if (isCollectionEmpty(projectRoles)) {
            return;
        }

        // Récupératon des données de la base de données :
        final Set<String> projectRoleUids = projectRoles.stream().map(ProjectRole::getUid).collect(toSet());
        final List<User> existingUsers = this.userDAO
                .select(withFieldInCollection(User.class, "rio", projectRoleUids));
        final List<LdapUser> existingLdapUsers = this.ldapUserDAO
                .select(withLdapUserRIOInCollection(diff(projectRoleUids,
                        (existingUsers == null ? new HashSet<>() : existingUsers.stream().map(User::getRio).collect(toSet())))));

        // On boucle :
        final Set<User> newUsers = new HashSet<>();
        String userUid;
        User existingUser, newUser;
        LdapUser existingLdapUser;
        for (ProjectRole projectRole : projectRoles) {
            userUid = projectRole.getUid();
            existingUser = findFirst(existingUsers, hasRIO(userUid));
            if (existingUser != null) {
                projectRole.setUser(existingUser);
                continue;
            }
            if (projectRole.isServiceAccount()) {
                newUser = new User(userUid, "", "", null, true);
            } else {
                existingLdapUser = findFirst(existingLdapUsers, hasRIO(userUid));
                if (existingLdapUser == null) {
                    newUser = new User(projectRole.getUid(), "", "", null, false);
                } else {
                    newUser = new User(projectRole.getUid(), "", "", existingLdapUser.getMail(), false);
                    newUser.setCn(existingLdapUser.getCn());
                }
            }
            projectRole.setUser(newUser);
            newUsers.add(newUser);
        }

        // Sauvegarde dans la BDD en parallèle :
        this.executorService.submit(() -> {
            try {
                userDAO.save(newUsers);
            } catch (final Exception exception) {
                ProjectController.this.getLogger().error(exception.getMessage(), exception);
            }
        });

    }
*/
    ///// Définition des "endpoints" :

    @Operation(summary = "Create a project")
    @PostMapping
    @ResponseStatus(code = CREATED)
    Project create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                   @Valid @RequestBody final CreateProjectDto createProjectDto) {

        // Vérification des champs :
        if (!this.hasSubscriberGroupPredicate.test(keycloakAuthenticationToken)) {
            this.getLogger().error("L'utilisateur {} a essayé de créer un project alors qu'il n'est pas souscripteur ou administrateur", keycloakAuthenticationToken.getName());
            this.getSsiLogger().info("L'utilisateur {} a essayé de créer un project alors qu'il n'est pas souscripteur ou administrateur", keycloakAuthenticationToken.getName());
            throw new ResponseStatusException(FORBIDDEN, "You are not in subscriber group.");
        }
        try {

            // Vérification des paramètres :
            final StringBuilder errorMsgBuffer = new StringBuilder();
            boolean isOK = NOT_NULL_VALIDATOR.validate("ldapUserDAO", this.ldapUserDAO, errorMsgBuffer);
            isOK = RSSIUserValidator.createRSSIUserValidator(this.ldapUserDAO).validate("rssi", createProjectDto.getRssi(), errorMsgBuffer) && isOK;
            if (!isOK) {
                this.getLogger().error("BAD REQUEST : {}", errorMsgBuffer);
                throw new BadRequestException("BAD REQUEST : %s".formatted(errorMsgBuffer));
            }
            final AccessToken accessToken = getAccessToken(keycloakAuthenticationToken);

            final Project project = new Project();
            project.setName(createProjectDto.getName());
            project.setLabel(createProjectDto.getLabel());
            project.setDescription(createProjectDto.getDescription());
            project.setEnabled(true);
            project.setPai(paiRepository.findById(createProjectDto.getPaiId()).get());

            // Traitement du RSSI :
//            final Optional<Role> foundRssiRoleOpt = roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", RSSI_ROLE_NAME));
            final Optional<Role> foundRssiRoleOpt = roleRepository.findByName(RSSI_ROLE_NAME);
            if (foundRssiRoleOpt.isEmpty()) {
                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Pas de rôle 'rssi' dans la base de données");
            }
            final Optional<VersionedDocument> lastCguDocOptional = versionedDocumentRepository.findFirstByDocTypeNameOrderByVersionNumberDesc(CGU.getTypeName());
            if (lastCguDocOptional.isPresent()) {
                project.setVersionedDocument(lastCguDocOptional.get());
            } else {
                getLogger().warn("CGU introuvable, merci de vérifier les versions disponibles ! ");
                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "CGU introuvable, merci de vérifier les versions disponibles ! ");
            }

            // Création du projet :
            final Project createdProject = projectRepository.save(project);
            // Add Role RSSI
            RoleAssignement roleAssignementRssi = new RoleAssignement();
            roleAssignementRssi.setRole(foundRssiRoleOpt.get());
            roleAssignementRssi.setProject(createdProject);
            roleAssignementRssi.setIsSynchronized(true);
            Optional<User> rssiOpt = userRepository.findFirstByUid(createProjectDto.getRssi());
            User rssiUser = null , OwnerUser=null;
            if(rssiOpt.isEmpty()){
                final Optional<LdapUser> existingLdapUser = userDAO.selectFirst(withLdapUserRIO(createProjectDto.getRssi()));
                if(existingLdapUser.isPresent()){
                    final LdapUser ldapUser = existingLdapUser.get();
                    rssiUser = new User(
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getMail(),
                            ldapUser.getUid(),
                            true
                    );
                    rssiUser = userRepository.save(rssiUser);
                }
            }else {
                rssiUser = rssiOpt.get();
            }
            roleAssignementRssi.setUser(rssiUser);
            roleAssignementRssi.setServiceAccount(null);
            roleAssignementRepository.save(roleAssignementRssi);
            RoleAssignement roleAssignementOwner = new RoleAssignement();
            roleAssignementOwner.setProject(createdProject);
            roleAssignementOwner.setIsSynchronized(true);
            Optional<User> ownerOpt = userRepository.findFirstByUid(createProjectDto.getOwnerId());
            if(ownerOpt.isEmpty()){
                final Optional<LdapUser> existingLdapUser = userDAO.selectFirst(withLdapUserRIO(createProjectDto.getOwnerId()));
                if(existingLdapUser.isPresent()){
                    final LdapUser ldapUser = existingLdapUser.get();
                    OwnerUser = new User(
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getFirstAndLastNames().getLeft(),
                            ldapUser.getMail(),
                            ldapUser.getUid(),
                            true
                    );
                    OwnerUser = userRepository.save(OwnerUser);
                }
            }else{
                OwnerUser = ownerOpt.get();
            }
            roleAssignementOwner.setUser(OwnerUser);
            roleAssignementOwner.setRole(roleRepository.findByName(SOUSCRIPTEUR_ROLE_NAME).get());
            roleAssignementOwner.setIsSynchronized(true);
            roleAssignementRepository.save(roleAssignementOwner);
            // Envoi de l'email
            this.executorService.submit(() -> {
                try {
                    getLogger().info("Envoi de l'email de confirmation de création de projet");
                    emailNotificationService.sendProjectCreationNotificationEmail(
                            accessToken.getEmail(),
                            TokenUtil.getFirstname(accessToken),
                            createdProject.getName()
                    );
                    getLogger().info("Fin de l'envoi de l'email de confirmation de création de projet");
                } catch (final SendFailedException sendFailedException) {
                    getLogger().error(sendFailedException.getMessage());
                    getLogger().warn("L'email de notification n'a pas pu être envoyé, probablement une erreur serveur smtp ?");
                } catch (final Exception exception) {
                    getLogger().error(exception.getMessage());
                }
            });

            // Envoi de la réponse :
            return createdProject;
        } catch (final BadRequestException badRequestException) {
            this.getLogger().error(badRequestException.getMessage(), badRequestException);
            throw new ResponseStatusException(BAD_REQUEST, badRequestException.getMessage());
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getMessage(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Operation(summary = "Get a project")
    @GetMapping("/{projectId}")
    public ResponseEntity<String> get(final KeycloakAuthenticationToken keycloakAuthenticationToken, @PathVariable final Long projectId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        try {
            final Optional<Project> foundProjectOpt = projectRepository.findById(projectId);
            if (foundProjectOpt.isEmpty()) {
                throw new ResponseStatusException(NOT_FOUND, "Pas de project avec id = %d".formatted(projectId));
            }
            final Project project = foundProjectOpt.get();
            final RoleAssignement roleAssignementOwner = roleAssignementRepository.findByRoleIdAndProjectId(3L, projectId).get();
            if (!roleAssignementOwner.getUser().getFirstName().equals(keycloakAuthenticationToken.getName())) {
                throw new ResponseStatusException(FORBIDDEN, "L'utilisateur n'est pas autorisé");
            }

            // Récupération des CGU's

            final VersionedDocument versionedDocument = project.getVersionedDocument();
            int numVersion;
            if (null == versionedDocument) {
                getLogger().debug("Pas de cgu trouvé avec l'id = {}", project.getId());
                numVersion = -1;
            } else {
                numVersion = versionedDocument.getVersionNumber();
            }
            final JSONObject jsonProject = buildJSONObject(project);
            jsonProject.put("cguVersion", numVersion);
            return ok(jsonProject.toString());
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getReason());
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Operation(summary = "List projects")
    @GetMapping
    public ResponseEntity<String> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final Optional<Role> delegueRoleOpt = roleRepository.findByName("delegue");
            if (delegueRoleOpt.isEmpty()) {
                throw new Exception("Le rôle 'delegue' n'a pas été trouvé dans la base de données");
            }

            // Récupération des projets :

            Optional<User> user = userRepository.findFirstByUid(keycloakAuthenticationToken.getName());
            final List<RoleAssignement> roleAssignements = roleAssignementRepository.findByUserIdAndRoleIdIn(user.get().getId(), Arrays.asList(delegueRoleOpt.get().getId(), 3L));
            final List<Project> projects = new ArrayList<>();

            if (!roleAssignements.isEmpty()) {
                roleAssignements.parallelStream().allMatch(roleAssignement ->
                        projects.add(roleAssignement.getProject())
                );
            }
            // Synchronisation Project Role Utilisateurs
            // synchroniseProjectRoleUtilisateurs(projects);

            // Récupération de la dernière version des CGU :
            final Optional<VersionedDocument> lastCGU = versionedDocumentRepository.findFirstByDocTypeNameOrderByVersionNumberDesc(CGU.getTypeName());
            final Long lastVersionCguId = lastCGU.isEmpty() ? null : lastCGU.get().getId();

            final JSONArray jsonProjects = new JSONArray();
            JSONObject jsonProject;
            for (Project project : projects) {
                jsonProject = buildJSONObject(project);
                jsonProject.put("cguVersion", project.getVersionedDocument().getVersionNumber());
                jsonProject.put("hasLastCguVersion", Objects.equals(lastVersionCguId, project.getVersionedDocument().getId()));
                jsonProjects.put(jsonProject);
            }
            return ResponseEntity.ok(jsonProjects.toString());
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Operation(summary = "update version cgu for List of projects")
    @PutMapping("/update_cgu_projects")
    public ResponseEntity<String> updateVersionCguDoc(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final Optional<Role> delegueRoleOpt = roleRepository.findByName("delegue");
            if (delegueRoleOpt.isEmpty()) {
                throw new Exception("Le rôle 'delegue' n'a pas été trouvé dans la base de données");
            }

            // Récupération de la dernière version :
            final Optional<VersionedDocument> versionedDocumentOptional = versionedDocumentRepository.findFirstByDocTypeNameOrderByVersionNumberDesc(CGU.getTypeName());
            if (versionedDocumentOptional.isEmpty()) {
                getLogger().error("Pas de document versionné avec type = {}", CGU.getTypeName());
                return createErrorResponseEntity(NOT_FOUND, "Pas de document versionné avec type = %s".formatted(CGU.getTypeName()));
            }
            final VersionedDocument lastCGUDocument = versionedDocumentOptional.get();
            getLogger().info("---> Mise à jour des projets avec la nouvelle version = {}", lastCGUDocument.getVersionNumber());

            // Récupération des projets :
            Optional<User> user = userRepository.findFirstByUid(keycloakAuthenticationToken.getName());
            final List<RoleAssignement> roleAssignements = roleAssignementRepository.findByUserIdAndRoleIdIn(user.get().getId(), Arrays.asList(delegueRoleOpt.get().getId(), 3L));
            final List<Project> projects = new ArrayList<>();

            if (!roleAssignements.isEmpty()) {
                roleAssignements.parallelStream().allMatch(roleAssignement ->
                        projects.add(roleAssignement.getProject())
                );
            }
            final JSONArray jsonProjects = new JSONArray();
            JSONObject jsonProject;
            Project savedProject;
            for (Project project : projects) {
                project.setVersionedDocument(lastCGUDocument);
                savedProject = projectRepository.save(project);
                jsonProject = buildJSONObject(savedProject);
                jsonProject.put("cguVersion", savedProject.getVersionedDocument().getVersionNumber());
                jsonProject.put("hasLastCguVersion", Objects.equals(lastCGUDocument.getId(), savedProject.getVersionedDocument().getId()));
                jsonProjects.put(jsonProject);
            }
            return ok(jsonProjects.toString());
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Operation(summary = "Update a project")
    @PutMapping("/{project_id}")
    public ResponseEntity<String> update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                         @PathVariable("project_id") final Long projectId,
                                         @RequestBody final Map<String, Object> requestBody) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final StringBuilder errorMsgBuffer = new StringBuilder();
            boolean isOK = NOT_NULL_VALIDATOR.validate("requestBody", requestBody, errorMsgBuffer);
            isOK = REQUEST_BODY_VALIDATOR.validate("id", requestBody, errorMsgBuffer) && isOK;
            isOK = valueEqualsToValidator(projectId).validate("id", convertToLong(requestBody.get("id")), errorMsgBuffer) && isOK;
            if (requestBody.containsKey("rssi")) {
                isOK = NOT_NULL_VALIDATOR.validate("ldapUserDAO", this.ldapUserDAO, errorMsgBuffer) && isOK;
                isOK = RSSIUserValidator.createRSSIUserValidator(this.ldapUserDAO).validate("rssi", requestBody.get("rssi").toString(), errorMsgBuffer) && isOK;
            }
            if (!isOK) {
                throw new BadRequestException("BAD_REQUEST : %s".formatted(errorMsgBuffer));
            }
            final Optional<Project> projectOptional = projectRepository.findById(projectId);
            if (projectOptional.isEmpty()) {
                throw new ResponseStatusException(NOT_FOUND, "Le projet %d n'existe pas".formatted(projectId));
            }
            final Project project = projectOptional.get();
            if (getOwnerRoleAssignement(keycloakAuthenticationToken, projectId).isEmpty()) {
                throw new ResponseStatusException(FORBIDDEN);
            }
            if (hasNotNullField(requestBody, "name")) {
                project.setName(requestBody.get("name").toString());
            }
            if (hasNotNullField(requestBody, "label")) {
                project.setLabel(requestBody.get("label").toString());
            }
            if (hasNotNullField(requestBody, "description")) {
                project.setDescription(requestBody.get("description").toString());
            }
            if (hasNotNullField(requestBody, "statusId")) {
                project.setEnabled(Boolean.valueOf(statusRepository.findById(Long.valueOf(requestBody.get("statusId").toString())).get().getName()));
            }
//            if (hasNotNullField(requestBody, "ownerId")) {
//                project.setOwnerId(requestBody.get("ownerId").toString());
//            }
            if (hasNotNullField(requestBody, "paiId")) {
                final Long paiId = Long.valueOf(requestBody.get("paiId").toString());
                final Optional<Pai> paiOptional = paiRepository.findById(paiId);
                if (paiOptional.isEmpty()) {
                    throw new BadRequestException("Pas de PAI trouvé avec paiId = %d".formatted(paiId));
                }
                project.setPai(paiOptional.get());
            }
            if (hasNotNullField(requestBody, "rssi")) {
                final Optional<Role> rssiRoleOpt = roleRepository.findByName(RSSI_ROLE_NAME);
                if (rssiRoleOpt.isEmpty()) {
                    throw new Exception("Pas de rôle 'rssi' dans la base de données");
                }
                projectRepository.save(project);
                final String rssiUserUid = requestBody.get("rssi").toString();
                if (!isEmpty(rssiUserUid)) {
                   /* project.removeRoleToUser(rolePair -> {
                        boolean isOK1 = rolePair != null;
                        isOK1 = isOK1 && (rolePair.getRight() != null);
                        isOK1 = isOK1 && (RSSI_ROLE_NAME.equals(rolePair.getRight().getName()));
                        return isOK1;
                    });
                    project.addRoleToUser(rssiUserUid, rssiRoleOpt.get());*/
                    Role roleRssi = roleRepository.findByName(RSSI_ROLE_NAME).get();
                    RoleAssignement roleAssignementRssi = new RoleAssignement();
                    roleAssignementRssi.setRole(roleRssi);
                    roleAssignementRssi.setUser(userRepository.findFirstByUid(rssiUserUid).get());
                    roleAssignementRssi.setProject(project);
                    roleAssignementRssi.setIsSynchronized(true);
                    final RoleAssignement saveRssiRoleAssignement = roleAssignementRepository.save(roleAssignementRssi);
                    project.getRoleAssignements().add(saveRssiRoleAssignement);
                }
            }
            return ResponseEntity.ok(buildJSONCode(projectRepository.save(project)));
        } catch (final NumberFormatException numberFormatException) {
            this.getLogger().error("Problème de conversion : %s".formatted(numberFormatException.getMessage()), numberFormatException);
            return createErrorResponseEntity(BAD_REQUEST, "Problème de conversion : " + numberFormatException.getMessage());
        } catch (final BadRequestException badRequestException) {
            this.getLogger().error(badRequestException.getMessage(), badRequestException);
            return createErrorResponseEntity(BAD_REQUEST, badRequestException.getMessage());
        } catch (final Exception exception) {
            this.getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    private Optional<RoleAssignement> getOwnerRoleAssignement(KeycloakAuthenticationToken keycloakAuthenticationToken, Long projectId) {
        Role roleSouscripteur = roleRepository.findByName(SOUSCRIPTEUR_ROLE_NAME).get();
        return roleAssignementRepository.findByRoleIdAndProjectIdAndUserId(roleSouscripteur.getId(), projectId, userRepository.findFirstByUid(keycloakAuthenticationToken.getName()).get().getId());

    }

    @Operation(summary = "Remove a project")
    @DeleteMapping("/{projectId}")
    void remove(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                @PathVariable final Long projectId) {
        if (!this.hasSubscriberGroupPredicate.test(keycloakAuthenticationToken)) {
            this.getLogger().error("L'utilisateur {} ne possède pas les droits de souscripteur", keycloakAuthenticationToken.getName());
            this.getSsiLogger().info("L'utilisateur {} a essayé de créer un project alors qu'il n'est pas souscripteur ou administrateur", keycloakAuthenticationToken.getName());
            throw new ResponseStatusException(FORBIDDEN, "You are not in subscriber group.");
        }
        final Project project = projectRepository.findById(projectId).orElse(null);
        if (project == null) {
            throw new ResponseStatusException(NOT_FOUND);
        }
        if (getOwnerRoleAssignement(keycloakAuthenticationToken, projectId).isEmpty()) {
            this.getLogger().error("L'utilisateur {} a tenté de supprimer le projet {} alors qu'il ne possède pas les droits", keycloakAuthenticationToken.getName(), projectId);
            this.getSsiLogger().info("L'utilisateur {} a tenté de supprimer le projet {} alors qu'il ne possède pas les droits", keycloakAuthenticationToken.getName(), projectId);
            throw new ResponseStatusException(FORBIDDEN);
        }
        projectRepository.deleteById(project.getId());
    }

    @Operation(summary = "Create a project service account")
    @PostMapping("/{project_id}/service-accounts")
    ServiceAccount createProjectServiceAccount(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                               final AccessToken accessToken,
                                               @PathVariable("project_id") final Long projectId,
                                               @Valid @RequestBody final CreateProjectServiceAccountDto createProjectServiceAccountDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final String uid = keycloakAuthenticationToken.getName();
            final Project project = projectRepository.findById(projectId).orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Project not found"));
            if (!businessRule.isProjectOwnerOrManager(projectId, uid)) {
                throw new ResponseStatusException(
                        FORBIDDEN,
                        "Only owner or managers can create service account on this project"
                );
            }
            // à revoir
            final ServiceAccount newServiceAccount = new ServiceAccount(uid,createProjectServiceAccountDto.getDescription(), true, true, null,keycloakAuthenticationToken.getName());
            final ServiceAccount savedServiceAccount = serviceAccountRepository.save(newServiceAccount);
            RoleAssignement roleAssignementServiceAccount = new RoleAssignement();
            roleAssignementServiceAccount.setId(savedServiceAccount.getId());
            roleAssignementServiceAccount.setServiceAccount(savedServiceAccount);
            roleAssignementRepository.save(roleAssignementServiceAccount);
            this.executorService.submit(() -> {
                try {
                    emailNotificationService.sendServiceAccountCreatedEmail(
                            accessToken.getEmail(),
                            TokenUtil.getFirstname(accessToken),
                            savedServiceAccount.getUid()
                    );
                } catch (final SendFailedException e) {
                    getLogger().error(e.getMessage());
                    getLogger().warn("L'email de notification n'a pas pu être envoyé, probablement une erreur serveur smtp ?");
                } catch (final IOException | MessagingException e) {
                    getLogger().error(e.getMessage(), e);
                }
            });
            return savedServiceAccount;
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception e) {
            getLogger().error(e.getMessage(), e);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @Operation(summary = "Get project service account")
    @GetMapping("/{project_id}/service-accounts/{service_account_id}")
    ResponseEntity<ServiceAccount> getServiceAccount(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                     @PathVariable("project_id") final Long projectId,
                                                     @PathVariable("service_account_id") final Long serviceAccountId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!businessRule.isProjectOwnerOrManager(projectId, keycloakAuthenticationToken.getName())) {
                throw new ResponseStatusException(
                        FORBIDDEN,
                        "Only owner or managers can get service accounts on this project"
                );
            }
            ServiceAccount serviceAccount = serviceAccountRepository.findById(serviceAccountId).orElse(null);
            return ok(serviceAccount);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Update project service account")
    @PutMapping("/{project_id}/service-accounts/{service_account_id}")
    ResponseEntity<ServiceAccount> updateServiceAccount(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                        @PathVariable("project_id") final Long projectId,
                                                        @PathVariable("service_account_id") final Long serviceAccountId,
                                                        @RequestBody final UpdateServiceAccountDto updateServiceAccountDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!businessRule.isProjectOwnerOrManager(projectId, keycloakAuthenticationToken.getName())) {
                throw new ResponseStatusException(
                        FORBIDDEN,
                        "Only owner or managers can list service accounts on this project"
                );
            }
            final ServiceAccount serviceAccount = serviceAccountRepository.findById(serviceAccountId).orElseThrow();
            serviceAccount.setDescription(updateServiceAccountDto.getDescription());
            if (updateServiceAccountDto.getEnabled() != null) {
                serviceAccount.setEnabled(updateServiceAccountDto.getEnabled());
            }
//            if (updateServiceAccountDto.getPassword() != null) {
//                //serviceAccountService.updateServiceAccountPassword(serviceAccount, updateServiceAccountDto.getPassword());
//            }
            //serviceAccountService.update(serviceAccount);
            URI location = ServletUriComponentsBuilder.fromCurrentRequest().build().toUri();
            return ResponseEntity.noContent().location(location).build();
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Get project stats")
    @GetMapping("/{project_id}/stats")
    public List<Map<String, Object>> stats(KeycloakAuthenticationToken keycloakAuthenticationToken,
                                           @PathVariable("project_id") Long projectId,
                                           @RequestParam(required = false) Long resourceTypeId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!projectRepository.existsById(projectId)) {
                throw new ResponseStatusException(NOT_FOUND, "Project not found");
            }
            if (!businessRule.isProjectOwnerOrManager(projectId, keycloakAuthenticationToken.getName())) {
                throw new ResponseStatusException(FORBIDDEN, "You are not owner or manager on this project");
            }
            final List<Resource> resources ;
            if (resourceTypeId != null) {
                resources = resourceRepository.findByProjectIdAndResourceTypeId(projectId, resourceTypeId);
            }else {
                  resources = resourceRepository.findAllByProject(projectId);
            }

            Iterable<QuotaType> quotaTypes = quotaTypeRepository.findAll();
            List<Map<String, Object>> data = new ArrayList<>();
            for (QuotaType quotaType : quotaTypes) {
                Long totalQuota = 0L;
                Double totalConsumed = .0;
                try {
                    for (Resource resource : resources) {
                        ResourceQuota resourceQuota = resource.getResourceQuotas()
                                .stream().filter(rq -> rq.getQuotaType().equals(quotaType.getId()))
                                .findFirst().orElse(null);

                        if (resourceQuota == null) {
                            getLogger().debug("Le type de quota {} n'a pas été trouvé dans la ressource {}", quotaType.getName(), resource.getName());
                            continue;
                        }

                        boolean isEcsMode = objectStorageProvider.equals(ObjectStorageProvider.ECS);
                        boolean isObjectStorageType = (quotaType.getName().equals("object") || quotaType.getName().equals("object-storage"));

                        if (isEcsMode && isObjectStorageType) {
                            final Long regionId = resourceRegionRepository.findById(resource.getId()).get().getRegion().getId();
                            final Optional<Region> regionOpt = regionRepository.findById(regionId);
                            if (regionOpt.isEmpty()) {
                                getLogger().error("Pas de région trouvée avec id={}", regionId);
                                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Pas de région trouvée avec id=%d".formatted(regionId));
                            }
                            final Region region = regionOpt.get();
                            if (isEmpty(region.getName())) {
                                getLogger().error("Pas de nom pour la région trouvée avec id={}", regionId);
                                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Pas de nom pour la région trouvée avec id=%d".formatted(regionId));
                            }
                            final EcsUsage currentResourceEcsUsage = consoleApiIaasClient.getEcsQuota(resourceQuota, "s3", region.getName());
                            getLogger().debug("Usage ECS collectés {}", currentResourceEcsUsage);
                            totalQuota += currentResourceEcsUsage.getTotalQuota();
                            totalConsumed += currentResourceEcsUsage.getUsedQuota();
                        } else {
                            final Long currentResourceOpenstackUsage = consoleApiIaasClient.getOpenstackUsedQuota(resource, quotaType);
                            if (quotaType.getName().equals("ram")) {
                                final long convertedCurrentRessourceOpenStackUsage = RAMUnit.convertTo(
                                        currentResourceOpenstackUsage,
                                        RAMUnit.MEGA, RAMUnit.fromUnit(quotaType.getQuotaUnit())
                                ).toBigInteger().longValueExact();
                                totalQuota += resourceQuota.getQuotaValue();
                                totalConsumed += convertedCurrentRessourceOpenStackUsage;
                            } else {
                                getLogger().debug("Usage OpenStack collectés {}", currentResourceOpenstackUsage);
                                totalQuota += resourceQuota.getQuotaValue();
                                totalConsumed += currentResourceOpenstackUsage;
                            }
                        }
                    }

                     final Map<String, Object> stat = new HashMap<>();
                    stat.put("name", quotaType.getName());
                    stat.put("label", quotaType.getLabel());
                    stat.put("quotaTypeId", quotaType.getId());
                    stat.put("resourceTypeId", resourceTypeId);
                    stat.put("total", totalQuota);
                    stat.put("consumed", totalConsumed);
                    stat.put("icon", quotaType.getQuotaIcon());
                    stat.put("unit", quotaType.getQuotaUnit());
                    data.add(stat);
                } catch (Exception e) {
                    getLogger().error("Impossible de calculer l'utilisation pour le quota %s pour l'ensemble du projet car une erreur s'est produite pendant sont calcul".formatted(quotaType.getName()), e);
                }
            }
            if (resourceTypeId != null) {
                return data.stream().filter(stringObjectMap -> stringObjectMap.get("resourceTypeId").equals(resourceTypeId)).toList();
            }
            return data;
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "List project role assignments")
    @GetMapping("/{project_id}/role-assignments")
    public Collection<RoleAssignement> listProjectRoleAssignments(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                        @PathVariable("project_id") final Long projectId){
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        final Optional<Project> project = projectRepository.findById(projectId);
        if(project.isEmpty()) {
            return Collections.EMPTY_LIST;
        }else {
            return project.get().getRoleAssignements();
        }
    }

    @Operation(summary = "List project resources role assignments")
    @GetMapping("/{project_id}/resources/role-assignments")
    List<RoleAssignement> findProjectResourcesRoleAssignments(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") final Long projectId)  {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return roleAssignementRepository.findAllByProjectIdAndResourceIdNotNull(projectId);
    }

    @Operation(summary = "List resource role assignments")
    @GetMapping("/{project_id}/resources/{resource_id}/role-assignments")
    List<RoleAssignement> listProjectResourceRoleAssignments(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") final Long projectId,
            @PathVariable("resource_id") final Long resourceId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            return roleAssignementRepository.findAllByProjectIdAndResourceId(projectId,resourceId);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Operation(summary = "Create a resource service account")
    @PostMapping("/{project_id}/resources/{resource_id}/service-accounts")
    public ServiceAccount createResourceServiceAccount(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") final Long projectId,
            @PathVariable("resource_id") final Long resourceId,
            @Valid @RequestBody final CreateResourceServiceAccountDto createResourceServiceAccountDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final AccessToken accessToken = getAccessToken(keycloakAuthenticationToken);
            final String uid = keycloakAuthenticationToken.getName();
            businessRule.checkResourceOwnership(projectId, resourceId, uid);
            final Optional<Resource> foundResourceOpt = resourceRepository.findById(resourceId);
            if (foundResourceOpt.isEmpty()) {
                throw new Exception("Pas de ressource dans la base de données avec id = %d".formatted(resourceId));
            }
            final Resource foundResource = foundResourceOpt.get();
            final ServiceAccount serviceAccount =
                    new ServiceAccount(uid, "", true, true, "approuvedby", Instant.now().toString());
            final ServiceAccount savedServiceAccount = serviceAccountRepository.save(serviceAccount);
            RoleAssignement roleAssignement = new RoleAssignement();
            roleAssignement.setResource(foundResource);
            roleAssignement.setServiceAccount(savedServiceAccount);
            roleAssignement.setProject(foundResource.getProject());
            roleAssignement.setUser(null);
            roleAssignement.setIsSynchronized(true);
            Optional<Role> role = roleRepository.findById(5L);
            roleAssignement.setRole(role.get());
            roleAssignementRepository.save(roleAssignement);

            // Envoi de l'email
            this.executorService.submit(() -> {
                try {
                    emailNotificationService.sendServiceAccountCreatedEmail(
                            accessToken.getEmail(),
                            TokenUtil.getFirstname(accessToken),
                            serviceAccount.getUid()
                    );
                } catch (final SendFailedException sendFailedException) {
                    getLogger().error(sendFailedException.getMessage());
                    getLogger().warn("L'email de notification n'a pas pu être envoyé, probablement une erreur serveur smtp ?");
                } catch (Exception e) {
                    getLogger().error(e.getMessage());
                }
            });
            return serviceAccount;
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "List resource service accounts")
    @GetMapping("/{project_id}/resources/{resource_id}/service-accounts")
    List<ServiceAccount> listResourceServiceAccount(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") final Long projectId,
            @PathVariable("resource_id") final Long resourceId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            return roleAssignementRepository.findAllByProjectIdAndResourceIdAndServiceAccountNotNull(projectId, resourceId).stream().map(RoleAssignement::getServiceAccount).toList();
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Create a project resource")
    @PostMapping("/{project_id}/resources")
    ResponseEntity<String> createProjectResource(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                 @PathVariable final Long projectId,
                                                 @Valid final CreateResourceDto createResourceDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!projectRepository.existsById(projectId)) {
                throw new ResponseStatusException(NOT_FOUND, "Project not found");
            }
            if (!businessRule.isProjectOwnerOrManager(projectId, keycloakAuthenticationToken.getName())) {
                throw new ResponseStatusException(FORBIDDEN, "You are not owner or manager on this project");
            }
            if (!projectId.equals(createResourceDto.getProjectId())) {
                throw new ResponseStatusException(BAD_REQUEST, "You are trying to create a resource in other project");
            }
            return resourceController.create(keycloakAuthenticationToken, createResourceDto);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "List a project resources")
    @GetMapping("/{project_id}/resources")
    public ResponseEntity<String> listProjectResources(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                       @PathVariable("project_id") final Long projectId,
                                                       @RequestParam(required = false) final String category) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);

            // Recherche des rôles :
            final Optional<Role> delegateSuscriptorRoleOptional = roleRepository.findByName("delegue");
            if (delegateSuscriptorRoleOptional.isEmpty()) {
                getLogger().error("Pas de role souscripteur délégué avec le nom = {} dans la BDD", "delegue");
                throw new Exception("Pas de role souscripteur délégué avec le nom = '%s' dans la BDD".formatted("delegue"));
            }

            // Recherche des ressources :
            final String userId = getUserId(keycloakAuthenticationToken);
            Optional<User> user = userRepository.findFirstByUid(userId);
            List<RoleAssignement> roleAssignements = roleAssignementRepository.findByUserIdAndRoleIdIn(user.get().getId(), Arrays.asList(delegateSuscriptorRoleOptional.get().getId(), 3L));
            List<Resource> resources = new ArrayList<>();
            List<Resource> finalResources = resources;

            if (!roleAssignements.isEmpty()) {
                final List<Project> collectionStream = roleAssignements.stream().map(RoleAssignement::getProject).toList();
                for (final Project project : collectionStream) {
                    resources.addAll(project.getResources());
                }
            }
            //synchroniseResourceRoleUtilisateurs(resources);
            if (!isEmpty(category)) {
                resources = finalResources
                        .stream()
                        .filter(resource -> resource.getResourceType().getCategory().equals(category))
                        .toList();
            }
            return ok(buildJSONCodeFromCollection(resources));
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }


    @Operation(summary = "Get a project resource")
    @GetMapping("/{project_id}/resources/{resource_id}")
    Set<Resource> getProjectResource(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                     @PathVariable("project_id") final Long projectId,
                                     @PathVariable("resource_id") final Long resourceId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            Predicate<Resource> resourcePredicate = withJDBCFieldEquals(Resource.class, "project", projectId);
            resourcePredicate = resourcePredicate.and(withJDBCFieldEquals(Resource.class, "id", resourceId));
            return new HashSet<>(Collections.singleton(resourceRepository.findById(resourceId).get()));
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Update a project resource")
    @PutMapping("/{project_id}/resources/{resource_id}")
    ResponseEntity<String> updateProjectResources(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                  @PathVariable("project_id") final Long projectId,
                                                  @PathVariable("resource_id") final Long resourceId,
                                                  @RequestBody final Map<String, Object> next) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            return resourceController.update(keycloakAuthenticationToken, resourceId, next);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Delete a project resource")
    @DeleteMapping("/{project_id}/resources/{resource_id}")
    void removeProjectResources(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                @PathVariable("project_id") final Long projectId,
                                @PathVariable("resource_id") final Long resourceId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            resourceRepository.deleteById(resourceId);
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Create/Update a resource object container")
    @PutMapping("/{project_id}/resources/{resource_id}/containers")
    ResponseEntity<SwiftContainer> updateProjectResourceContainer(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") Long projectId,
            @PathVariable("resource_id") Long resourceId,
            @RequestBody UpdateResourceContainerDto updateResourceContainerDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            Optional<Resource> optionalResource = resourceRepository.findById(resourceId);
            if (optionalResource.isEmpty()) {
                throw new ResponseStatusException(NOT_FOUND, "Resource not found");
            }
            objectStorageService.createContainer(optionalResource.get(), updateResourceContainerDto);
            URI location = ServletUriComponentsBuilder
                    .fromCurrentRequest()
                    .pathSegment(updateResourceContainerDto.getName())
                    .build()
                    .toUri();
            return ok().location(location).build();
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "List object containers from resource")
    @GetMapping("/{project_id}/resources/{resource_id}/containers")
    ResponseEntity<SwiftContainer[]> listProjectResourceContainer(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") final Long projectId,
            @PathVariable("resource_id") final Long resourceId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            Optional<Resource> optionalResource = resourceRepository.findById(resourceId);
            if (optionalResource.isPresent()) {
                return objectStorageService.listContainers(optionalResource.get());
            } else {
                throw new ResponseStatusException(NOT_FOUND, "Resource not found");
            }
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Get object container from resource")
    @GetMapping("/{project_id}/resources/{resource_id}/containers/{container_name}")
    ResponseEntity<SwiftContainer> getProjectResourceContainer(
            final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("project_id") Long projectId,
            @PathVariable("resource_id") Long resourceId,
            @PathVariable("container_name") String containerName) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            Optional<Resource> optionalResource =  resourceRepository.findById(resourceId);
            if (optionalResource.isPresent()) {
                return objectStorageService.getContainer(optionalResource.get(), containerName);
            } else {
                throw new ResponseStatusException(NOT_FOUND, "Resource not found");
            }
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @Operation(summary = "Delete object container from resource")
    @DeleteMapping("/{project_id}/resources/{resource_id}/containers/{container_name}")
    void deleteProjectResourceContainer(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                        @PathVariable("project_id") final Long projectId,
                                        @PathVariable("resource_id") final Long resourceId,
                                        @PathVariable("container_name") String containerName) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            businessRule.checkResourceOwnership(projectId, resourceId, keycloakAuthenticationToken.getName());
            Optional<Resource> optionalResource =  resourceRepository.findById(resourceId);
            if (optionalResource.isPresent()) {
                objectStorageService.deleteContainer(optionalResource.get(), containerName);
            } else {
                throw new ResponseStatusException(NOT_FOUND, "Resource not found");
            }
        } catch (final ResponseStatusException responseStatusException) {
            getLogger().error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            getLogger().error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    ///// Getters & Setters :

    @Autowired
    public void setObjectStorageProvider(@Qualifier("objectStorageProvider") final ObjectStorageProvider objectStorageProvider) {
        this.objectStorageProvider = objectStorageProvider;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
    @Autowired
    public void setProjectRepository(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }
    @Autowired
    public void setResourceTypeRepository(ResourceTypeRepository resourceTypeRepository) {
        this.resourceTypeRepository = resourceTypeRepository;
    }
    @Autowired
    public void setQuotaTypeRepository(QuotaTypeRepository quotaTypeRepository) {
        this.quotaTypeRepository = quotaTypeRepository;
    }
    @Autowired
    public void setRegionRepository(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }
    @Autowired
    public void setResourceRepository(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }
    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
    @Autowired
    public void setVersionedDocumentRepository(VersionedDocumentRepository versionedDocumentRepository) {
        this.versionedDocumentRepository = versionedDocumentRepository;
    }
    @Autowired
    public void setPaiRepository(PaiRepository paiRepository) {
        this.paiRepository = paiRepository;
    }
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
    @Autowired
    public void setServiceAccountRepository(ServiceAccountRepository serviceAccountRepository) {
        this.serviceAccountRepository = serviceAccountRepository;
    }
    @Autowired
    public void setResourceRegionRepository(ResourceRegionRepository resourceRegionRepository) {
        this.resourceRegionRepository = resourceRegionRepository;
    }

    @Autowired
    public void setLdapUserDAO(final DAO<LdapUser> ldapUserDAO) {
        this.ldapUserDAO = ldapUserDAO;
    }

    public DAO<LdapUser> getLdapUserDAO() {
        return ldapUserDAO;
    }






    ///// Classe(s) interne(s) :

    /**
     * <p>
     * Validateur permettant de tester que l'utilisateur LDAP
     * existe. <br />
     * </p>
     *
     * @see fr.minint.console.library.validator.Validator
     */
    private static class RSSIUserValidator extends AbstractValidator<String> {
        private final DAO<LdapUser> ldapUserDAO;

        private RSSIUserValidator(final DAO<LdapUser> ldapUserDAO) {
            this.ldapUserDAO = ldapUserDAO;
        }

        @Override
        protected String buildDefaultErrorMessage(final String fieldName) {
            return "Utilisateur RSSI avec le RIO=%s inexistant".formatted(fieldName);
        }

        @Override
        public boolean validate(final String fieldName, final String rssiUserRIO, final StringBuilder errorMsgBuffer) {
            try {
                if (isEmpty(rssiUserRIO)) {
                    return true;
                }
                boolean isOK = (this.ldapUserDAO != null);
                isOK = isOK && this.ldapUserDAO.contains(withLdapUserRIO(rssiUserRIO));
                if (!isOK) {
                    errorMsgBuffer.append(this.buildDefaultErrorMessage(rssiUserRIO));
                }
                return isOK;
            } catch (final Exception exception) {
                throw new RuntimeException(exception);
            }
        }

        public static Validator<String> createRSSIUserValidator(final DAO<LdapUser> ldapUserDAO) {
            return new RSSIUserValidator(ldapUserDAO);
        }
    }


}
