package fr.minint.console.api.project.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.StringTokenizer;

import static org.apache.commons.lang3.StringUtils.isEmpty;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "\"user\"")
public class User {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "last_name", length = -1)
    private String lastName;

    @Basic
    @Column(name = "first_name", length = -1)
    private String firstName;

    @Basic
    @Column(name = "email", length = -1)
    private String email;

    @Basic
    @Column(name = "uid", nullable = false, length = -1)
    private String uid;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Basic
    @Column(name = "enabled")
    private Boolean enabled;

    @Basic
    @Column(name = "description", length = -1)
    private String description;

    @Basic
    @Column(name = "created_by", length = -1)
    private String createdBy;

    @Basic
    @Column(name = "approuved_by", length = -1)
    private String approuvedBy;


    public User(String firstName,String lastName, String mail, String uid, boolean b) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = mail;
        this.uid = uid;
        this.enabled = b;
    }

    public void setCn(final String displayName) {
        String firstName = null;
        String lastName = null;
        if (!isEmpty(displayName)) {
            final StringTokenizer tokenizer = new StringTokenizer(displayName, " ");
            final int nbTokens = tokenizer.countTokens();
            if (nbTokens == 2) {
                this.setFirstName(tokenizer.nextToken().toLowerCase());
                this.setLastName(tokenizer.nextToken().toLowerCase());
            } else {
                String nextToken;
                for (int i = 0; i < nbTokens; i++) {
                    nextToken = tokenizer.nextToken();
                    if (i == 0) {
                        firstName = nextToken.toLowerCase();
                    } else if (i == nbTokens - 2) {
                        lastName = nextToken.toLowerCase();
                        break;
                    }
                }
                this.setFirstName(firstName);
                this.setLastName(lastName);
            }
        }
    }
 }
