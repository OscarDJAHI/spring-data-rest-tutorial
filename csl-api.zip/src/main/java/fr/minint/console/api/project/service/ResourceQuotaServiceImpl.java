package fr.minint.console.api.project.service;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;


@Service
public class ResourceQuotaServiceImpl implements ResourceQuotaService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ResourceQuotaServiceImpl.class);
    private List<String> skippedQuotas;
    private QuotaTypeRepository quotaTypeRepository;

    ///// Constructeur(s) :



    ///// Méthodes de l'interface ResourceQuotaService :

    @Override
    public boolean isSkipped(final ResourceQuota resourceQuota) {
        final Optional<QuotaType> optionalQuotaType;
        try {
            optionalQuotaType = quotaTypeRepository.findById(resourceQuota.getQuotaType().getId());
            if (optionalQuotaType.isEmpty()) {
                LOGGER.debug("Aucun type de quota n'a été trouvé avec l'id {} en base de données", resourceQuota.getQuotaType());
                return false;
            }
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return false;
        }
        return getSkippedQuotas().stream().anyMatch(optionalQuotaType.get().getName()::equals);
    }

    ///// Getters & Setters :

    @Autowired
    public void setSkippedQuotas(@Value("${console.api.project.skip-quotas}") final String skippedQuotas) {
        if (skippedQuotas != null) {
            final String[] skippedQuotasArray = skippedQuotas.split(",");
            if (skippedQuotasArray.length > 1) {
                this.skippedQuotas = Arrays.asList(skippedQuotasArray);
                return;
            }
        }
        this.skippedQuotas = List.of();
    }

    @Override
    public List<String> getSkippedQuotas() {
        return skippedQuotas;
    }


    @Autowired
    public void setQuotaTypeRepository(QuotaTypeRepository quotaTypeRepository) {
        this.quotaTypeRepository = quotaTypeRepository;
    }
}
