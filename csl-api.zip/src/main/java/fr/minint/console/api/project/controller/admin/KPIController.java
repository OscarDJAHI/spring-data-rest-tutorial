package fr.minint.console.api.project.controller.admin;

import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import static java.math.BigDecimal.ZERO;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping(path = "/admin")
public class KPIController {
    private static final Logger LOGGER = LoggerFactory.getLogger(KPIController.class);
    static final KPIRowMapper ROW_MAPPER = new KPIRowMapper();
    static final String SELECT_QUERY = "SELECT p.id AS projectId," +
            " p.name AS projectName," +
            " p.owner_id AS subscriber," +
            " r.id AS resourceId," +
            " r.name AS resourceName," +
            " rq.quota_value AS quotaValue," +
            " qt.name AS quotaType " +
            "FROM project AS p " +
            " INNER JOIN resource AS r ON (r.project = p.id)" +
            " INNER JOIN resource_quota AS rq ON (rq.resource = r.id)" +
            " INNER JOIN quota_type AS qt ON (qt.id = rq.quota_type)";

    private JdbcTemplate jdbcTemplate;

    ///// Endpoints :

    @GetMapping(path = "/kpi")
    public ResponseEntity<String> fetchKPI() {
        final JSONArray result = new JSONArray();
        try {
            final Map<Project, Map<Resource, Map<String, BigDecimal>>> projectResourceQuotasMap = new HashMap<>();
            final Map<Project, Map<String, BigDecimal>> projectTotalQuotasMap = new HashMap<>();
            Project project;
            Resource resource;
            Map<Resource, Map<String, BigDecimal>> projectResourceQuotas;
            Map<String, BigDecimal> resourceQuotas, totalQuotasMap;
            BigDecimal quotaValue;
            for (KPILine kpiLine : jdbcTemplate.query(SELECT_QUERY, ROW_MAPPER)) {

                // Récupération des clés
                project = kpiLine.toProject();
                resource = kpiLine.toResource();

                // Pour les resources :
                projectResourceQuotas = projectResourceQuotasMap.getOrDefault(project, new HashMap<>());
                resourceQuotas = projectResourceQuotas.getOrDefault(resource, new HashMap<>());
                quotaValue = resourceQuotas.getOrDefault(kpiLine.quotaName, ZERO);
                quotaValue = quotaValue.add(kpiLine.quotaValue);
                resourceQuotas.put(kpiLine.quotaName, quotaValue);
                projectResourceQuotas.put(resource, resourceQuotas);
                projectResourceQuotasMap.put(project, projectResourceQuotas);

                // Pour les totaux :
                totalQuotasMap = projectTotalQuotasMap.getOrDefault(project, new HashMap<>());
                quotaValue = totalQuotasMap.getOrDefault(kpiLine.quotaName, ZERO);
                quotaValue = quotaValue.add(kpiLine.quotaValue);
                totalQuotasMap.put(kpiLine.quotaName, quotaValue);
                projectTotalQuotasMap.put(project, totalQuotasMap);
            }
            JSONObject jsonProject, jsonQuota;
            Map<String, BigDecimal> quotasMap;
            Map<Resource, Map<String, BigDecimal>> resourceQuotasMap;
            JSONArray jsonTotalQuotas, jsonResources, jsonResourceQuotas;
            for (Project theProject : projectResourceQuotasMap.keySet()) {
                jsonProject = new JSONObject();
                jsonProject.put("projectId", theProject.getId());
                jsonProject.put("projectName", theProject.getName());
                jsonProject.put("subscriber", theProject.getOwnerId());

                // Pour les resources :
                jsonResources = new JSONArray();
                resourceQuotasMap = projectResourceQuotasMap.getOrDefault(theProject, new HashMap<>());
                JSONObject jsonResource;
                for (Resource projectResource : resourceQuotasMap.keySet()) {
                    jsonResource = new JSONObject();
                    jsonResource.put("resourceId", projectResource.getId());
                    jsonResource.put("resourceName", projectResource.getName());
                    jsonResourceQuotas = new JSONArray();
                    quotasMap = resourceQuotasMap.get(projectResource);
                    for (String quotaName : quotasMap.keySet()) {
                        jsonQuota = new JSONObject();
                        jsonQuota.put(quotaName, quotasMap.get(quotaName));
                        jsonResourceQuotas.put(jsonQuota);
                    }
                    jsonResource.put("quotas", jsonResourceQuotas);
                    jsonResources.put(jsonResource);
                }
                jsonProject.put("resources", jsonResources);

                // Pour les totaux :
                jsonTotalQuotas = new JSONArray();
                quotasMap = projectTotalQuotasMap.getOrDefault(theProject, new HashMap<>());
                for (String totalQuotaName : quotasMap.keySet()) {
                    jsonQuota = new JSONObject();
                    jsonQuota.put(totalQuotaName, quotasMap.get(totalQuotaName));
                    jsonTotalQuotas.put(jsonQuota);
                }
                jsonProject.put("quotas", jsonTotalQuotas);

                // On ajoute le projet
                result.put(jsonProject);
            }
            return ok(result.toString());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage(), exception);
        }
    }

    ///// Getters & Setters :

    @Autowired
    public void setJdbcTemplate(final JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    ///// Classes internes :

    static class KPILine {
        private Long projectId;
        private String projectName;
        private String subscriber;
        private Long resourceId;
        private String resourceName;
        private String quotaName;
        private BigDecimal quotaValue;

        ///// Méthodes générales :

        public static KPILine fromString(final String line) {
            final KPILine kpiLine = new KPILine();
            if (isEmpty(line)) {
                return kpiLine;
            }
            final StringTokenizer tokenizer = new StringTokenizer(line, ";", false);
            if (tokenizer.countTokens() < 7) {
                throw new IllegalArgumentException("Doit être au format : projectId;projectName;subscriber;resourceId;resourceName;quotaName;quotaValue");
            }
            int cursor = 0;
            String nextToken;
            while (tokenizer.hasMoreTokens()) {
                nextToken = tokenizer.nextToken();
                if (cursor == 0) {
                    kpiLine.setProjectId(Long.parseLong(nextToken));
                } else if (cursor == 1) {
                    kpiLine.setProjectName(nextToken);
                } else if (cursor == 2) {
                    kpiLine.setSubscriber(nextToken);
                } else if (cursor == 3) {
                    kpiLine.setResourceId(Long.parseLong(nextToken));
                } else if (cursor == 4) {
                    kpiLine.setResourceName(nextToken);
                } else if (cursor == 5) {
                    kpiLine.setQuotaName(nextToken);
                } else if (cursor == 6) {
                    kpiLine.setQuotaValue(new BigDecimal(nextToken));
                }
                cursor++;
            }
            return kpiLine;
        }

        public Project toProject() {
            final Project project = new Project();
            project.setId(this.projectId);
            project.setName(this.projectName);
            project.setOwnerId(this.subscriber);
            return project;
        }

        public Resource toResource() {
            final Resource resource = new Resource();
            resource.setId(this.resourceId);
            resource.setName(this.resourceName);
            return resource;
        }

        ///// Getters & Setters :

        public Long getProjectId() {
            return projectId;
        }

        public void setProjectId(final Long projectId) {
            this.projectId = projectId;
        }

        public void setProjectName(final String projectName) {
            this.projectName = projectName;
        }

        public void setSubscriber(final String subscriber) {
            this.subscriber = subscriber;
        }

        public void setQuotaName(final String quotaName) {
            this.quotaName = quotaName;
        }

        public void setQuotaValue(final Number quotaValue) {
            this.quotaValue = (quotaValue == null ? ZERO : new BigDecimal(quotaValue.toString()));
        }

        public void setResourceId(final Long resourceId) {
            this.resourceId = resourceId;
        }

        public void setResourceName(final String resourceName) {
            this.resourceName = resourceName;
        }
    }

    static class KPIRowMapper implements RowMapper<KPILine> {

        @Override
        public KPILine mapRow(final ResultSet rs, final int rowNum) throws SQLException {
            final KPILine kpiLine = new KPILine();
            kpiLine.setProjectId(rs.getLong("projectId"));
            kpiLine.setProjectName(rs.getString("projectName"));
            kpiLine.setSubscriber(rs.getString("subscriber"));
            kpiLine.setResourceId(rs.getLong("resourceId"));
            kpiLine.setResourceName(rs.getString("resourceName"));
            kpiLine.setQuotaName(rs.getString("quotaType"));
            kpiLine.setQuotaValue(rs.getBigDecimal("quotaValue"));
            return kpiLine;
        }

    }
}
