package fr.minint.console.api.project.ldap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

import javax.naming.Name;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entry(objectClasses = {
        "inetOrgPerson",
//        "organizationalPerson",
//        "person",
        "posixAccount",
        "shadowAccount"
//        "pwdPolicy",
//        "ldapPublicKey",
})
final public class Person {
    @Id
    Name dn;

    @Attribute(name = "uid")
    String uid;

    @Attribute(name = "mail")
    String mail;

    @Attribute(name = "givenName")
    String firstname;

    @Attribute(name = "sn")
    String lastname;

    public String getDn() {
        return dn.toString();
    }

    @Override
    public String toString() {
        return String.valueOf(dn);
    }
}
