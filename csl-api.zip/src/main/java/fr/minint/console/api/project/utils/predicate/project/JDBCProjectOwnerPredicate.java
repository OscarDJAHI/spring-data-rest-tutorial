package fr.minint.console.api.project.utils.predicate.project;

import fr.minint.console.api.project.model.HasProject;
import fr.minint.console.persistence.dao.sql.predicate.AbstractJDBCPredicate;

import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.isEmpty;

public class JDBCProjectOwnerPredicate<T extends HasProject> extends AbstractJDBCPredicate<T> {
    private final String ownerId;

    private JDBCProjectOwnerPredicate(final String sqlFieldPrefix, final String ownerId) {
        super(sqlFieldPrefix);
        this.ownerId = ownerId;
    }

    @Override
    public String whereClause() {
        if (!isEmpty(this.ownerId)) {
            return this.buildSQLFieldName("owner_id") + " = '" + this.ownerId + "'";
        } else {
            return this.buildSQLFieldName("owner_id") + " IS NULL";
        }
    }

    @Override
    public boolean test(final T resource) {
        boolean isOK = resource != null;
        isOK = isOK && (resource.getProjectBean() != null);
        isOK = isOK && (Objects.equals(this.ownerId, resource.getProjectBean().getOwnerId()));
        return isOK;
    }

    ///// Méthodes statiques :

    /**
     * Méthode statique permettant de construire le prédicat. <br />
     * @param sqlFieldPrefix : prefix SQL utilisé
     * @param ownerId : id
     * @return
     * @param <U>
     */
    public static <U extends HasProject> JDBCProjectOwnerPredicate<U> withProjectOwner(final String sqlFieldPrefix, final String ownerId) {
        return new JDBCProjectOwnerPredicate<>(sqlFieldPrefix, ownerId);
    }

}
