package fr.minint.console.api.project.ldap.dto;

import lombok.Data;

@Data
public class CreateUserDto {
    String rdn;
    String uid;
    String cn;
    String sn;
    String uidNumber;
    String gidNumber;
}
