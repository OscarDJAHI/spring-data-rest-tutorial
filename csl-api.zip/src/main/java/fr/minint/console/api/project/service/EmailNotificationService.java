package fr.minint.console.api.project.service;

import fr.minint.console.api.project.entities.Resource;
import fr.minint.console.api.project.entities.*;

import javax.mail.MessagingException;
import java.io.IOException;

public interface EmailNotificationService {
    void sendProjectCreationNotificationEmail(
            String userEmail,
            String userName,
            String projectName
    ) throws MessagingException, IOException;

    void sendResourceCreationNotificationEmail(
            String userEmail,
            String userName,
            String resourceName,
            String resourceTagLabel,
            String zoneLabel,
            String regionLabel,
            String dashboardUrl
    ) throws MessagingException, IOException;

    void sendResourceCreationNotificationEmail(String userEmail, String userName, Resource resource) throws MessagingException, IOException;

    boolean sendResourceRoleCreationNotification(RoleAssignement resourceRole) throws Exception;

    boolean sendResourceS3RoleCreationNotification(RoleAssignement resourceRole) throws Exception;

    boolean sendResourceRoleDeletionNotification(RoleAssignement resourceRole) throws Exception;

    boolean sendProjectRoleCreationNotification(RoleAssignement projectRole);

    boolean sendProjectRoleDeletionNotification(RoleAssignement projectRole);

    void sendServiceAccountCreatedEmail(String userEmail, String userName, String serviceAccountName) throws MessagingException, IOException;

    void sendResourceRoleUpdateEmail(
            String userName,
            String userEmail,
            String targetName,
            String action,
            String roleName,
            String resourceName
    ) throws MessagingException, IOException;

    void sendResourceS3CreationNotificationEmail(String userEmail,
                                                 String userName,
                                                 Resource resource) throws MessagingException, IOException;

    void sendWorkFlowTenantCreationNotificationEmail(String userName) throws MessagingException, IOException;

}

