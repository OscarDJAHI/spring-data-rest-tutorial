package fr.minint.console.api.project.model.document;

import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isEmpty;

public enum VersionedDocumentType {
    CGU("cgu"),
    PDF("pdf"),
    DOCX("docx");

    private final String typeName;

    ///// Constructeurs :

    VersionedDocumentType(final String typeName) {
        this.typeName = typeName;
    }

    ///// Méthode(s) :

    @Override
    public String toString() {
        return this.getTypeName();
    }


    ///// Getters & Setters :

    public String getTypeName() {
        return typeName;
    }

    ///// Méthodes statiques :

    public static Optional<VersionedDocumentType> getVersionedDocumentTypeFromName(final String name) {
        if (isEmpty(name)) {
            return Optional.empty();
        }
        for (VersionedDocumentType docType : VersionedDocumentType.values()) {
            if (!name.equalsIgnoreCase(docType.typeName)) {
                continue;
            }
            return Optional.of(docType);
        }
        return Optional.empty();
    }
}
