package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.model.OrganisationalUnit;
import fr.minint.console.api.project.repository.ldap.OrganizationalUnitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class LdapOrganizationalUnitController {
    @Autowired
    OrganizationalUnitRepository organizationalUnitRepository;

    @GetMapping("/api/ldap/organizational-units")
    List<OrganisationalUnit> list() {
        return organizationalUnitRepository.findAll();
    }
}
