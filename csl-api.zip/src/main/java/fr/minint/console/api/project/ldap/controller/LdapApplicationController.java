package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.dto.CreateApplicationDto;
import fr.minint.console.api.project.ldap.model.Application;
import fr.minint.console.api.project.ldap.model.Pers;
import fr.minint.console.api.project.ldap.service.ApplicationService;
import fr.minint.console.api.project.repository.ldap.PersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j

@RestController
@RequestMapping("/api/ldap/applications")
public class LdapApplicationController {
    @Autowired
    ApplicationService applicationService;

    @Autowired
    PersRepository persRepository;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    void create(@RequestBody CreateApplicationDto createApplicationDto) {
        applicationService.create(createApplicationDto.getOu());
    }

    @GetMapping
    List<Application> list() {
        return applicationService.list();
    }

    @PostMapping("/pers")
    Pers create() {

        var walter = new Pers();
        walter.setFullName("Walter White");
        walter.setUid("heisenberg");
        walter.setLastname("White");
        var pers = persRepository.save(walter);

        return pers;

//        return persRepository.findById(pers.getId());
    }


    @GetMapping("/pers")
    List<Pers> listPers() {
        return persRepository.findAll();
    }

}
