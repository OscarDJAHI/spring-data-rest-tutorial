package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.model.resource.ResourceRegion;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCResourceRegionDAO extends AbstractJDBCDAO<Long, ResourceRegion> {
    public static final Transcoder<ResultSet, ResourceRegion> RESULT_SET_RESOURCE_REGION_TRANSCODER = new ResultSetResourceRegionTranscoder();

    ///// Constructeurs :

    public JDBCResourceRegionDAO(final DataSource dataSource) {
        super(dataSource, "resource_region", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_RESOURCE_REGION_TRANSCODER);
    }

    ///// Méthodes

    @Override
    public String getSelectAllQuery() {
        return "SELECT id," +
                "resource AS resource_id," +
                "region AS region_id," +
                "created_at," +
                "updated_at" +
                " FROM " + this.tableName;
    }

    @Override
    protected String getInsertQuery(final ResourceRegion resourceRegion) throws Exception {
        if (resourceRegion == null) {
            throw new Exception("L'instance de ResourceRegion est nulle -> on ne peut pas créer la requête de mise à jour");
        }
        return "INSERT INTO resource_region " +
                "(resource, region, created_at, updated_at) " +
                "VALUES (%d, %d, now(), now())"
                        .formatted(resourceRegion.getResource(), resourceRegion.getRegion());
    }

    @Override
    protected String getUpdateQuery(final ResourceRegion resourceRegion) throws Exception {
        if (resourceRegion == null) {
            throw new Exception("L'instance de ResourceRegion est nulle -> on ne peut pas créer la requête d'insertion");
        }
        return "UPDATE resource_region " +
                "SET resource=%d, region=%d, updated_at=now() WHERE id=%d"
                        .formatted(resourceRegion.getResource(),
                                resourceRegion.getRegion(),
                                resourceRegion.getId());
    }

    ///// Classe(s) interne(s) :

    private static class ResultSetResourceRegionTranscoder extends AbstractResultSetTranscoder<ResourceRegion> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected ResourceRegion doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceRegion resourceRegion = new ResourceRegion();
            resourceRegion.setId(processLongValue(resultSet, "id"));
            resourceRegion.setResource(processLongValue(resultSet, "resource_id"));
            resourceRegion.setRegion(processLongValue(resultSet, "region_id"));
            return resourceRegion;
        }
    }
}
