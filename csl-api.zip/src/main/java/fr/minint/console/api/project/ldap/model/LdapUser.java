package fr.minint.console.api.project.ldap.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.bean.HasRIO;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.data.domain.Persistable;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.odm.annotations.Transient;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;
import java.util.Objects;
import java.util.StringTokenizer;

import static org.apache.commons.lang3.StringUtils.isEmpty;

// TODO: Renommer en LDAPUSer
@Entry(objectClasses = {
        "posixAccount",
        "inetOrgPerson",
})
final public class LdapUser implements Persistable<String>, HasRIO {
    public static final Long DEFAULT_UID = 90000L;
    public static final Long DEFAULT_GID = 50010L;
    static final String EXTERNAL_USER_LOGIN_SHELL = "/bin/bash";

    @Id
    Name dn;

    @Attribute(name = "cn")
    String cn;

    @Attribute(name = "sn")
    String sn;

    @Attribute(name = "uid")
    String uid;

    @Attribute(name = "uidNumber")
    String uidNumber;

    @Attribute(name = "gidNumber")
    String gidNumber;

    @Attribute(name = "userPassword")
    String password;

    @Attribute(name = "departmentNumber")
    String departmentNumber;

    @Attribute(name = "gecos")
    String gecos;

    @Attribute(name = "givenName")
    String givenName;

    @Attribute(name = "initials")
    String initials;

    @Attribute(name = "l")
    String l;

    @Attribute(name = "loginShell")
    String loginShell;

    @Attribute(name = "ou")
    String ou;

    @Attribute(name = "title")
    String title;

    @Attribute(name = "mail")
    String mail;

    @Attribute(name = "displayName")
    String displayName;

    @Attribute
    String homeDirectory;

    @JsonIgnore
    @Transient
    boolean isNew;

    ///// Constructeur(s) :

    public LdapUser(final String uid,
                    final String name,
                    final String cnValue,
                    final String email) {
        this.uid = uid;
        this.sn = name;
        this.cn = cnValue;
        this.mail = email;
    }

    public LdapUser(final String uid,
                    final String name,
                    final String cnValue) {
        this(uid, name, cnValue, null);
    }

    public LdapUser(final String uid, final String name) {
        this.uid = uid;
        this.sn = name;
    }

    public LdapUser() {
        this(null, null);
    }


    ///// Méthodes statiques :

    public static LdapUser createExternalUser(final Long uid,
                                              final String externalUserDn,
                                              final String firstname,
                                              final String lastname,
                                              final String email,
                                              final String password,
                                              final String organization) {
        final LdapUser externalLdapUser = new LdapUser();
        externalLdapUser.setId("uid=%d,%s".formatted(uid, externalUserDn));
        externalLdapUser.setUid(uid.toString());
        externalLdapUser.setMail(email);
        externalLdapUser.setSn(lastname);
        externalLdapUser.setCn(firstname + " " + lastname + " " + uid);
        externalLdapUser.setGivenName(firstname);
        externalLdapUser.setDisplayName(lastname + " " + firstname);
        externalLdapUser.setPassword(password);
        externalLdapUser.setHomeDirectory("/home/" + uid);
        externalLdapUser.setLoginShell(EXTERNAL_USER_LOGIN_SHELL);
        externalLdapUser.setUidNumber(DEFAULT_UID.toString());
        externalLdapUser.setGidNumber(DEFAULT_GID.toString());
        if (!isEmpty(organization)) {
            externalLdapUser.setOu(organization.trim());
        }
        externalLdapUser.setInitials(firstname.substring(0, 1).toUpperCase() + " " + lastname.substring(0, 1).toUpperCase());
        return externalLdapUser;
    }

    public boolean equals(final Object object) {
        if (object == this) {
            return true;
        }
        if ((object == null) || (this.getClass() != object.getClass())) {
            return false;
        }
        return Objects.equals(this.uid, ((LdapUser) object).getUid());
    }

    public int hashCode() {
        return Objects.hash(this.uid);
    }

    public String toString() {
        return "User(dn=" + this.getDn() + ", cn=" + this.getCn() + ", sn=" + this.getSn() + ", uid=" + this.getUid() + ", uidNumber=" + this.getUidNumber() + ", gidNumber=" + this.getGidNumber() + ", password=" + this.getPassword() + ", departmentNumber=" + this.getDepartmentNumber() + ", gecos=" + this.getGecos() + ", givenName=" + this.getGivenName() + ", initials=" + this.getInitials() + ", l=" + this.getL() + ", loginShell=" + this.getLoginShell() + ", ou=" + this.getOu() + ", title=" + this.getTitle() + ", mail=" + this.getMail() + ", displayName=" + this.getDisplayName() + ", homeDirectory=" + this.getHomeDirectory() + ", isNew=" + this.isNew() + ")";
    }

    ///// Interface RIO

    @Override
    public String getUserUid() {
        return this.getUid();
    }


    ///// Getter(s) & Setter(s)

    @Override
    public boolean isNew() {
        return isNew;
    }

    @JsonProperty("dn")
    public String getId() {
        return dn.toString();
    }

    @JsonProperty("dn")
    public void setId(String id) {
        dn = LdapUtils.newLdapName(id);
    }

    public Name getDn() {
        return this.dn;
    }

    public String getCn() {
        return this.cn;
    }

    public String getSn() {
        return this.sn;
    }

    public String getUid() {
        return this.uid;
    }

    public String getUidNumber() {
        return this.uidNumber;
    }

    public String getGidNumber() {
        return this.gidNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public String getDepartmentNumber() {
        return this.departmentNumber;
    }

    public String getGecos() {
        return this.gecos;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public String getInitials() {
        return this.initials;
    }

    public String getL() {
        return this.l;
    }

    public String getLoginShell() {
        return this.loginShell;
    }

    public String getOu() {
        return this.ou;
    }

    public String getTitle() {
        return this.title;
    }

    public String getMail() {
        return this.mail;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getHomeDirectory() {
        return this.homeDirectory;
    }

    public void setDn(Name dn) {
        this.dn = dn;
    }

    public void setCn(String cn) {
        this.cn = cn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setUidNumber(String uidNumber) {
        this.uidNumber = uidNumber;
    }

    public void setGidNumber(String gidNumber) {
        this.gidNumber = gidNumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setDepartmentNumber(String departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public void setGecos(String gecos) {
        this.gecos = gecos;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public void setL(String l) {
        this.l = l;
    }

    public void setLoginShell(String loginShell) {
        this.loginShell = loginShell;
    }

    public void setOu(String ou) {
        this.ou = ou;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setHomeDirectory(String homeDirectory) {
        this.homeDirectory = homeDirectory;
    }

    @JsonIgnore
    public void setNew(boolean isNew) {
        this.isNew = isNew;
    }

    public Pair<String, String> getFirstAndLastNames() {
        if (isEmpty(this.cn)) {
            return Pair.of("", "");
        }
        final StringTokenizer tokenizer = new StringTokenizer(this.cn, " ");
        String firstName = (!tokenizer.hasMoreTokens() ? "" : tokenizer.nextToken().toLowerCase());
        String lastName = (!tokenizer.hasMoreTokens() ? "" : tokenizer.nextToken().toLowerCase());
        return Pair.of(firstName, lastName);
    }
}
