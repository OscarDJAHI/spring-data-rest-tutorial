package fr.minint.console.api.project.model.resource;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.api.project.model.RoleAssignment;
import fr.minint.console.api.project.model.User;
import fr.minint.console.library.utils.ToMap;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Table
public class ResourceRole extends AbstractDAOBean<Long> implements RoleAssignment, ToMap, ToJSON {
    @Id
    private Long id;
    @JsonProperty("userId")
    private String uid;
    @JsonProperty("resourceId")
    private Long resource;
    @JsonProperty("roleId")
    private Long role;
    @JsonProperty("serviceAccountId")
    private Long serviceAccount;
    private boolean isSynchronized;

    @Transient
    private User user;
    ///// Constructeurs :

    public ResourceRole(final Long id,
                        final String uid,
                        final Long resource,
                        final Long role,
                        final Long serviceAccount,
                        final boolean isSynchronized) {
        this.id = id;
        this.uid = (uid == null ? null : uid.trim());
        this.resource = resource;
        this.role = role;
        this.serviceAccount = serviceAccount;
        this.isSynchronized = isSynchronized;
    }

    public ResourceRole(final Long id, final String uid) {
        this();
        this.id = id;
        this.uid = (uid == null ? null : uid.trim());
    }

    public ResourceRole() {
        this.id = null;
        this.uid = null;
        this.resource = null;
        this.role = null;
        this.serviceAccount = null;
        this.isSynchronized = false;
    }

    ///// Méthode(s) de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonResourceRole = new JSONObject();
        jsonResourceRole.put("id", this.id);
        jsonResourceRole.put("userId", this.uid);
        jsonResourceRole.put("resourceId", this.resource);
        jsonResourceRole.put("roleId", this.role);
        jsonResourceRole.put("serviceAccountId", this.serviceAccount);
        jsonResourceRole.put("isSynchronized", this.isSynchronized);
        jsonResourceRole.put("user", (user == null ? new JSONObject() : this.user.toJSON()));
        return jsonResourceRole;
    }

    @Override
    public Map<String, Object> toMap() {
        final Map<String, Object> map = new HashMap<>();
        map.put("id", this.id);
        map.put("userId", this.uid);
        map.put("resourceId", this.resource);
        map.put("roleId", this.role);
        map.put("serviceAccountId", this.serviceAccount);
        map.put("user", (this.user == null ? new JSONObject() : this.user.toJSON()));
        return map;
    }

    ///// Méthodes de la classe Object :

    @Override
    public boolean equals(final Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        return this.isFunctionnallyEquals((ResourceRole) object);
    }

    @Override
    public int hashCode() {
        return this.functionnalHashCode();
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(uid, resource, role, serviceAccount);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if (that == null || getClass() != that.getClass()) {
            return false;
        }
        final ResourceRole resRole = (ResourceRole) that;
        return Objects.equals(uid, resRole.uid)
                && Objects.equals(resource, resRole.resource)
                && Objects.equals(role, resRole.role)
                && Objects.equals(serviceAccount, resRole.serviceAccount);
    }



    ///// Méthodes générales :

    /**
     * Retourne un booléen montrant si l'instance doit
     * faire l'objet d'une notification par émail.<br />
     *
     * @return booléen
     */
    public boolean shouldBeNotifiedByEmail() {
        return getUid() != null && isSynchronized();
    }

    /**
     * Méthode montrant si l'instance est un compte de service. <br />
     *
     * @return booléen
     */
    public boolean isServiceAccount() {
        return (this.serviceAccount != null);
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(final String uid) {
        this.uid = uid;
    }

    public Long getResource() {
        return resource;
    }

    public void setResource(final Long resource) {
        this.resource = resource;
    }

    public Long getRole() {
        return role;
    }

    public void setRole(final Long role) {
        this.role = role;
    }

    public boolean isSynchronized() {
        return isSynchronized;
    }

    public void setSynchronized(boolean aSynchronized) {
        isSynchronized = aSynchronized;
    }

    @Deprecated
    public void setServiceAccount(final Long serviceAccount) {
        this.serviceAccount = serviceAccount;
    }

    @Deprecated
    public Long getServiceAccount() {
        return serviceAccount;
    }

    @JsonIgnore
    @Override
    public Long getServiceAccountId() {
        return this.serviceAccount;
    }

    public void setServiceAccountId(final Long serviceAccountId) {
        this.serviceAccount = serviceAccountId;
    }

    @Override
    public Long getTargetKey() {
        return resource;
    }

    @Override
    public void setTargetKey(final Long targetKey) {
        resource = targetKey;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
