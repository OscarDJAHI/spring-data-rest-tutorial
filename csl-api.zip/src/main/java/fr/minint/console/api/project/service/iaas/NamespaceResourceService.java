package fr.minint.console.api.project.service.iaas;

import fr.minint.console.api.project.client.s3.S3NamespaceClient;
import fr.minint.console.api.project.client.s3.S3UserClient;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.api.project.service.ResourceQuotaService;
import fr.minint.console.api.project.service.ResourceService;
import fr.minint.console.library.s3.S3PolicyTranscoder;
import fr.minint.console.library.transcoder.Transcoder;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.*;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.OBJECT_MAPPER;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

/**
 * Décorateur pour S3 pur !!!
 */
@Setter
public class NamespaceResourceService extends AbstractDecoratedResourceService {
    private static final Logger LOGGER = LoggerFactory.getLogger(NamespaceResourceService.class);
    private static final Transcoder<String, String> S3_ROLE_TRANSCODER = new S3PolicyTranscoder();
    final static private Double NOTIFICATION_COEFFICIENT = .7;
    private QuotaTypeRepository quotaTypeRepository;
    private RoleAssignementRepository roleAssignementRepository;
    private S3NamespaceClient s3NamespaceClient;
    private S3UserClient s3UserClient;
    private ResourceQuotaService resourceQuotaService;
    private EmailNotificationService emailNotificationService;

    ///// Constructeur(s) :

    public NamespaceResourceService(final ResourceService resourceService) {
        super(resourceService);
        if (resourceService instanceof AbstractIAASService abstractIAASService) {
            this.setResourceQuotaRepository(abstractIAASService.getResourceQuotaRepository());
            this.setResourceRegionRepository(abstractIAASService.getResourceRegionRepository());
            this.setResourceTagRepository(abstractIAASService.getResourceTagRepository());
            this.setExecutorService(abstractIAASService.getExecutorService());
            this.setPosixGroupDAO(abstractIAASService.getPosixGroupDAO());
        }
    }

    ///// Méthodes privées :

    private String mapToNamespaceServiceParameterKey(final ResourceQuota resourceQuota) {
        final QuotaType quotaType = quotaTypeRepository
                .findById(resourceQuota.getQuotaType().getId())
                .orElseThrow(() -> new RuntimeException("Type de quota non trouvé."));
        if ("object-storage".equals(quotaType.getName())) {
            return "blockSize";
        }
        throw new RuntimeException("Impossible de mapper le type de quota %s".formatted(quotaType.getName()));
    }

    private void applyNotificationQuota(final ResourceQuota resourceQuota, final Map<String, Object> parameters) {
        final QuotaType quotaType = quotaTypeRepository
                .findById(resourceQuota.getQuotaType().getId())
                .orElseThrow(() -> new RuntimeException("Type de quota non trouvé."));
        if ("object-storage".equals(quotaType.getName())) {
            parameters.put("notificationSize", BigDecimal.valueOf(NOTIFICATION_COEFFICIENT * resourceQuota.getQuotaValue()));
        }
    }

    private Map<String, Object> mapToParameters(final Set<ResourceQuota> resourceQuotas) {
        final Map<String, Object> parameters = new HashMap<>();
        return resourceQuotas.stream().reduce(parameters, (stringObjectMap, resourceQuota) -> {
            stringObjectMap.put(mapToNamespaceServiceParameterKey(resourceQuota), resourceQuota.getQuotaValue());
            applyNotificationQuota(resourceQuota, stringObjectMap); // Ajoute notificationSize de manière tacite.
            return stringObjectMap;
        }, (stringObjectMap, stringObjectMap2) -> {
            final Map<String, Object> nextMap = new HashMap<>();
            nextMap.putAll(stringObjectMap);
            nextMap.putAll(stringObjectMap2);
            return nextMap;
        });
    }

    private QuotaType quotaType(ResourceQuota resourceQuota) {
        return quotaTypeRepository
                .findById(resourceQuota.getQuotaType().getId())
                .orElseThrow(() -> {
                    LOGGER.error("Le type de quota ayant l'id {} n'a pas été trouvé", resourceQuota.getQuotaType());
                    return new ResponseStatusException(
                            INTERNAL_SERVER_ERROR,
                            "Le type de quota ayant l'id %d n'a pas été trouvé".formatted(resourceQuota.getQuotaType())
                    );
                });
    }

    private void validate(QuotaType quotaType, ResourceQuota resourceQuota) {
        if (resourceQuotaService.isSkipped(resourceQuota)) {
            LOGGER.info("Le quota %s n'est pas traiter...");
            return;
        }

        if (!quotaType.validate(resourceQuota.getQuotaValue())) {
            throw new ResponseStatusException(
                    INTERNAL_SERVER_ERROR,
                    "La valeur du quota %s n'est pas dans intervalle définit par le type de quota: [%d; %d] (%d)".formatted(
                            quotaType.getName(),
                            quotaType.getQuotaMin(),
                            quotaType.getQuotaMax(),
                            resourceQuota.getQuotaValue()
                    )
            );
        }
    }

    String fetchAreaPattern(final Resource resource) {
        if (resource == null) {
            return "";
        }
        final StringBuilder buffer = new StringBuilder();
        long cursor = 0L;
        for (ResourceRegion resourceRegion : resource.getResourceRegions()) {
            if (cursor > 0) {
                buffer.append("&");
            }
            buffer.append(resourceRegion.getRegion().getName().toLowerCase());
            cursor++;
        }
        return buffer.toString();
    }

    ///// Méthodes de l'interface ResourceService

    @Override
    public Resource create(final Resource resource) {
        if (resource.getResourceRegions()==null) {
            throw new RuntimeException("L'ensemble de régions de la ressource n'est pas instancié.");
        }
        if (isCollectionEmpty(resource.getResourceRegions())) {
            throw new RuntimeException("La ressource ne dispose d'aucune région.");
        }

        final Map<String, Object> parameters = mapToParameters((Set<ResourceQuota>) resource.getResourceQuotas());
        parameters.put("namespace", resource.getName());
        parameters.put("domain", "s3");
        parameters.put("area", fetchAreaPattern(resource));
        LOGGER.info("============");
        LOGGER.info(" Création du namespace S3 avec les paramètres : ");
        LOGGER.info(" namespace : {}", resource.getName());
        LOGGER.info(" domain : s3");
        LOGGER.info(" area : {}", fetchAreaPattern(resource));
        LOGGER.info("============");
        final ResponseEntity<String> responseEntity = this.s3NamespaceClient.create(parameters);
        if (responseEntity.getStatusCode().isError()) {
            LOGGER.error("Erreur lors de l'appel à l'API de création de namespace: {}", responseEntity.getBody());
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, responseEntity.getBody());
        }
        if (!responseEntity.hasBody()) {
            LOGGER.error("La réponse de la requête de création de namespace ne possède pas de contenu.");
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Échec de la création du namespace");
        }
        if (responseEntity.getStatusCode() != CREATED) {
            LOGGER.warn("La création du namespace semble s'être déroulée avec succès, cependant le code de retour ne semble pas exact. (attendu: 201, reçu: {})", responseEntity.getStatusCodeValue());
        }
        LOGGER.info("Namespace créé dans le service de namespace externe: {}", responseEntity.getBody());
        try {
            final Map<?, ?> map = OBJECT_MAPPER.readValue(responseEntity.getBody(), HashMap.class);
            resource.setExternalId((String) map.get("name"));
            return super.create(resource);
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    /**
     * S3 pure.
     * @param resource
     * @return
     */
    @Override
    public Long update(final Resource resource) throws Exception {
        resource.getResourceQuotas().forEach(resourceQuota -> validate(quotaType(resourceQuota), resourceQuota));
        final Map<String, Object> parameters = mapToParameters((Set<ResourceQuota>) resource.getResourceQuotas());
        parameters.put("namespace", resource.getName());
        parameters.put("domain", "s3");
        parameters.put("area", fetchAreaPattern(resource));
        try {
            s3NamespaceClient.update(parameters);
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(
                    INTERNAL_SERVER_ERROR,
                    "Une erreur s'est produite lors de la tentative de mise à jour de la resource %s".formatted(resource.getName())
            );
        }
        return super.update(resource);
    }


    @Override
    public boolean addMember(final RoleAssignement resourceRole) throws Exception {
        return super.addMember(resourceRole);
    }

    /**
     * Hypothèse :
     * -> L'utilisateur User existe dans la DB !!
     *
     * @param resource : resource
     * @param ldapUser     : utilisateur
     * @param role     : rôle à associer à l'utilisateur
     * @return paramètres de retour sous forme de Map
     * @throws Exception : En cas de problème
     */
    @Override
    public Map<String, Object> addMember(final Resource resource, final LdapUser ldapUser, final Role role) throws Exception {
        final RoleAssignement resourceRole = buildResourceRole(resource, ldapUser, role);

        // On vérifie si le lien existe déjà ou pas :
        final Map<String, Object> returnParameters = new HashMap<>();
        final Optional<RoleAssignement> resourceRoleOpt = roleAssignementRepository.findByUserUidAndRoleIdAndResourceId(ldapUser.getUid(),role.getId(), resource.getId());
        boolean isAddedInDB;
        if (resourceRoleOpt.isPresent()) {
            isAddedInDB = true;
        } else {
            isAddedInDB = this.addMember(resourceRole);
        }
        returnParameters.put("result", isAddedInDB);
        if (!isAddedInDB) {
            throw new Exception("---> ERREUR L'utilisateur n'a pas été persisté en base de données");
        }
        try {
            final String area = fetchAreaPattern(resource);
            if (isBlank(area)) {
                LOGGER.error("Pas de région (r1, r1, r1&r2, ..etc) trouvé pour la resource {}", resource);
                throw new Exception("Pas de région (r1, r1, r1&r2, ..etc) trouvé pour la resource %s".formatted(resource.toString()));
            }
            LOGGER.info("---> Utilisation de (area = {}, domain=s3)", area);
            this.s3UserClient.addMember("s3", area, ldapUser.getUid(), resource.getExternalId());
            this.s3UserClient.addMemberRole("s3", area, ldapUser.getUid(), resource.getExternalId(), S3_ROLE_TRANSCODER.transcode(role.getName()));
            final Pair<String, String> generatedKeyPair = this.s3UserClient.generateKey("s3", area, ldapUser.getUid(), resource.getExternalId());
            returnParameters.put("accessKeyId", generatedKeyPair.getLeft());
            returnParameters.put("accessKeySecret", generatedKeyPair.getRight());
            returnParameters.put("resourceId", resource.getId());
            returnParameters.put("resourceName", resource.getName());
            returnParameters.put("userId", ldapUser.getUid());

            // Envoi asynchrone de l'email :
            if (this.emailNotificationService != null &&( ldapUser.getUid() != null && roleAssignement.getIsSynchronized())) {
                executorService.submit(() -> {
                    LOGGER.debug("---> On envoie un email de notification pour la création du ResourceRole");
                    try {
                        NamespaceResourceService.this.emailNotificationService.sendResourceS3RoleCreationNotification(resourceRole);
                    } catch (final Exception exception) {
                        LOGGER.error("Erreur lors de la notification de l'email : ");
                        LOGGER.error(exception.getMessage(), exception);
                    }
                });
            }
            return returnParameters;
        } catch (final Exception exception) {
            LOGGER.error("---> Erreur lors de l'appel de l'api IAAS : {}", exception.getMessage(), exception);
            if (!this.removeMember(resourceRole)) {
                LOGGER.warn("WARNING : N'a pas pu supprimer le ResourceRole correspondant");
            }
            throw exception;
        }
    }

    @Override
    public boolean removeMember(final RoleAssignement resourceRole) throws Exception {
        final Resource resource = resourceRole.getResource();
        String uid = resourceRole.getUser().getUid();

        // TODO: A refactoriser. Mode compte de service.
        if (resourceRole.getServiceAccount() != null) {
            final Optional<ServiceAccount> foundServiceAccountOpt = serviceAccountRepository.findById(resourceRole.getServiceAccount().getId());
            if (foundServiceAccountOpt.isEmpty()) {
                throw new Exception("Pas de compte de service avec id = %d".formatted(resourceRole.getServiceAccount()));
            }
            uid = foundServiceAccountOpt.get().getUid();
        }

        try {
            this.s3UserClient.removeMember("s3", fetchAreaPattern(resource), uid, resource.getName());
        } catch (HttpServerErrorException e) {
            if (e.getStatusCode() == INTERNAL_SERVER_ERROR) {
                final String message = Objects.requireNonNull(e.getMessage());
                List<Boolean> conditions = List.of(
                        message.contains(uid),
                        message.contains("NoSuchEntity"),
                        message.contains("404 Not Found")
                );

                if (conditions.stream().allMatch(Boolean::booleanValue)) {

                    // TODO: A refactoriser. Mode compte de service.
                    if (resourceRole.getServiceAccount() != null) {
                        LOGGER.warn("L'utilisateur semble déjà être supprimé du service distant... Compte de service, opération de suppression ne se déroulera pas.");
                        return true;
                    }

                    LOGGER.warn("L'utilisateur semble déjà être supprimé du service distant... L'opération de suppression du rôle de continue.");
                    return super.removeMember(resourceRole);
                }
            }
            throw e;
        }

        // TODO: A refactoriser. Mode compte de service.
        if (resourceRole.getServiceAccount() != null) {
            return true;
        }

        return super.removeMember(resourceRole);
    }

    ///// Getters & Setters :

    public void setEmailNotificationService(final EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }

}
