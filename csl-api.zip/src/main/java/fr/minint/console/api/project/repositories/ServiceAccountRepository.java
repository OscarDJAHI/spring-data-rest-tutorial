package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.ServiceAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface ServiceAccountRepository extends JpaRepository<ServiceAccount, Long>, JpaSpecificationExecutor<ServiceAccount> {

    Optional<ServiceAccount> findByUid(String uid);
}
