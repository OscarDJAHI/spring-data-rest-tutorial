package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.History;
import fr.minint.console.api.project.model.HistoryRecord;
import fr.minint.console.api.project.repositories.HistoryRepository;
import fr.minint.console.library.validator.NotNullValidator;
import fr.minint.console.persistence.dao.DAO;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;


import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCode;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCodeFromCollection;
import static fr.minint.console.library.utils.predicate.BeanFieldPredicate.withFieldEqualTo;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static java.time.LocalDateTime.now;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/historique")
@Setter(onMethod = @__(@Autowired))
public class HistoriqueController  {
    private static final Logger LOGGER = LoggerFactory.getLogger(HistoriqueController.class);
    private static final NotNullValidator NOT_NULL_VALIDATOR = new NotNullValidator();
    @Autowired
    public  HistoryRepository historyRepository;

    ///// Définition des "endPoints"


    @GetMapping("/{id}")
    public ResponseEntity<String> getHistoriqueById(@PathVariable final Long id) {
        try {
            final Optional<History> foundHistoriqueOptional = historyRepository.findById(id);
            if (foundHistoriqueOptional.isEmpty()) {
                LOGGER.error("Historique avec id={}", id);
                return createErrorResponseEntity(NOT_FOUND, "Historique avec id=%s".formatted(id));
            }
            return ok(buildJSONCode(foundHistoriqueOptional.get()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage(), now());
        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<String> getAllHistoriques() {
        try {
            return ok(buildJSONCodeFromCollection(historyRepository.findAll()));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @PostMapping
    public ResponseEntity<String> addHistorique(@RequestBody final History historyRecord) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        if (!NOT_NULL_VALIDATOR.validate("action", historyRecord, errorMsgBuffer)) {
            LOGGER.warn("Attention : {}", errorMsgBuffer);
            LOGGER.warn("---> On ne fait donc rien !!");
            return new ResponseEntity<>("{}", OK);
        }
        try {
            return ok(buildJSONCode(historyRepository.save(historyRecord)));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateHistorique(@PathVariable final Long id, @RequestBody final History historyRecord) {
        final StringBuilder errorMessageBuilder = new StringBuilder();
        boolean isOK = NOT_NULL_VALIDATOR.validate("action", historyRecord, errorMessageBuilder);
        isOK = NOT_NULL_VALIDATOR.validate("id", id, errorMessageBuilder) && isOK;
        if (!isOK) {
            LOGGER.warn("Attention : {}", errorMessageBuilder);
            LOGGER.warn("---> On ne fait donc rien !!");
            return new ResponseEntity<>("{}", OK);
        }
        try {
            return ok(buildJSONCode(historyRepository.save(historyRecord)));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    ///// Méthode


    ///// Getters & Setters :


}


