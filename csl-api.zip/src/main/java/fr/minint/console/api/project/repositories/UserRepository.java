package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
    Optional<User> findFirstByUid(String uid);

    User findByUid(String userid);

    Iterable<User> findByFirstName(String value);

    Iterable<User> findByEmail(String value);
}
