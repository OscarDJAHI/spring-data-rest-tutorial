package fr.minint.console.api.project.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "flavor_quota")
public class FlavorQuota1 {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "flavor_quota_id_gen")
    @SequenceGenerator(name = "flavor_quota_id_gen", sequenceName = "flavor_quota_id_seq1", allocationSize = 1)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quota_type")
    private QuotaType quotaType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flavor")
    private Flavor flavor;

    @Column(name = "flavor_value")
    private Long flavorValue;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

}