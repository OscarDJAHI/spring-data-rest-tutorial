package fr.minint.console.api.project.dao.serviceAccount;

import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceDAO;
import fr.minint.console.api.project.model.ServiceAccount;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.library.bean.HasId;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.collection.CollectionUtils.isMapEmpty;
import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * DAO des comptes de service utilisant les connexions JDBC.
 * </p>
 */
public class JDBCServiceAccountDAO extends AbstractJDBCDAO<Long, ServiceAccount> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCServiceAccountDAO.class);
    private static final Transcoder<ResultSet, ServiceAccount> SERVICE_ACCOUNT_TRANSCODER = new ServiceAccountResultSetTranscoder();
    private final DAO<Resource> jdbcResourceDAO;
    private final DAO<Project> jdbcProjectDAO;

    ///// Constructeur(s) :

    public JDBCServiceAccountDAO(final DataSource dataSource) {
        super(dataSource, "service_account", "servAccount");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(SERVICE_ACCOUNT_TRANSCODER);
        this.jdbcResourceDAO = new JDBCResourceDAO(dataSource);
        this.jdbcProjectDAO = new JDBCProjectDAO(dataSource);
    }

    @Override
    public void start() throws Exception {
        this.jdbcProjectDAO.start();
        this.jdbcResourceDAO.start();
        super.start();
    }

    @Override
    public void close() throws IOException {
        super.close();
        closeDAO(this.jdbcResourceDAO);
        closeDAO(this.jdbcProjectDAO);
    }

    ///// Méthodes privées :

    private static <B extends HasId<Long>> B findById(final Collection<? extends B> beans, final Long id) {
        if (isCollectionEmpty(beans) || (id == null)) {
            return null;
        }
        return beans.stream()
                .filter(bean -> id.equals(bean.getId()))
                .findFirst()
                .orElse(null);
    }


    ///// Méthode de la classe AbstractJDBCDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT DISTINCT servAccount.id, " +
                " servAccount.project," +
                " servAccount.resource," +
                " servAccount.uid," +
                " servAccount.description," +
                " servAccount.enabled," +
                " servAccount.verified," +
                " servAccount.created_by," +
                " servAccount.created_at," +
                " servAccount.updated_at," +
                " servAccount.approved_by" +
                "   FROM " + this.tableName + " AS " + this.tableAlias +
                "    LEFT JOIN project AS proj ON (proj.id = servAccount.project)" +
                "    LEFT JOIN project_role AS projRole ON (projRole.project = proj.id)" +
                "    LEFT JOIN role AS role ON (role.id = projRole.role)" +
                "    LEFT JOIN resource AS res ON (res.id = servAccount.resource)";
    }

    @Override
    protected String getInsertQuery(final ServiceAccount serviceAccount) throws Exception {
        if (serviceAccount == null) {
            throw new Exception("L'instance de ServiceAccount est nulle => on ne peut donc pas créer la requête SQL d'insertion");
        }
        return "INSERT INTO " + this.tableName + " AS " + this.tableAlias +
                "(project, resource, uid, description, enabled, verified, created_by, approved_by, created_at, updated_at) " +
                "VALUES (%d, %d, %s, %s, %s, %s, %s, %s, now(), now())"
                        .formatted(serviceAccount.getProject(),
                                serviceAccount.getResource(),
                                escapeSQL(serviceAccount.getUid()),
                                escapeSQL(serviceAccount.getDescription()),
                                (Boolean.valueOf(serviceAccount.isEnabled()).toString()),
                                (Boolean.valueOf(serviceAccount.isVerified()).toString()),
                                escapeSQL(serviceAccount.getCreatedBy()),
                                escapeSQL(serviceAccount.getApprovedBy()));
    }

    @Override
    protected String getUpdateQuery(final ServiceAccount serviceAccount) throws Exception {
        if (serviceAccount == null) {
            throw new Exception("L'instance de ServiceAccount est nulle => on ne peut donc pas créer la requête SQL de mise à jour");
        }
        return "UPDATE " + this.tableName + " AS " + this.tableAlias +
                " SET project=%d, resource=%d, uid=%s, description=%s, enabled=%s, verified=%s, created_by=%s, approved_by=%s, updated_at=now() WHERE servAccount.id=%d"
                        .formatted(serviceAccount.getProject(),
                                serviceAccount.getResource(),
                                escapeSQL(serviceAccount.getUid()),
                                escapeSQL(serviceAccount.getDescription()),
                                (Boolean.valueOf(serviceAccount.isEnabled())).toString(),
                                (Boolean.valueOf(serviceAccount.isVerified())).toString(),
                                escapeSQL(serviceAccount.getCreatedBy()),
                                escapeSQL(serviceAccount.getApprovedBy()),
                                serviceAccount.getId());
    }

    @Override
    protected List<ServiceAccount> selectFromQuery(final String selectQuery) throws Exception {
        if (isEmpty(selectQuery)) {
            throw new Exception("SelectFromQuery ---> La requête SQL à exécuter est soit vide ou nulle");
        }
        final List<ServiceAccount> serviceAccounts = new ArrayList<>();
        final Map<ServiceAccount, Long> serviceAccountResourceMap = new HashMap<>();
        final Map<ServiceAccount, Long> serviceAccountProjectMap = new HashMap<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        ServiceAccount serviceAccount;
        try {
            connection = this.getConnection();
            //noinspection SqlSourceToSinkFlow
            preparedStatement = connection.prepareStatement(selectQuery);
            resultSet = preparedStatement.executeQuery();

            // Boucle sur le résultat :
            while (resultSet.next()) {
                serviceAccount = SERVICE_ACCOUNT_TRANSCODER.transcode(resultSet);
                if (serviceAccount.getResource() != null) {
                    serviceAccountResourceMap.remove(serviceAccount);
                    serviceAccountResourceMap.put(serviceAccount, serviceAccount.getResource());
                }
                if (serviceAccount.getProject() != null) {
                    serviceAccountProjectMap.remove(serviceAccount);
                    serviceAccountProjectMap.put(serviceAccount, serviceAccount.getProject());
                }
                serviceAccounts.add(serviceAccount);
            }
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw exception;
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }

        // Récupération des projets :
        final List<Project> projects;
        if (isMapEmpty(serviceAccountProjectMap) || isCollectionEmpty(serviceAccountProjectMap.values())) {
            projects = new ArrayList<>();
        } else {
            projects = this.jdbcProjectDAO
                    .select(withFieldInCollection(Project.class, "proj", "id", serviceAccountProjectMap.values()));
        }
        final List<Resource> resources;
        if (isMapEmpty(serviceAccountResourceMap) || isCollectionEmpty(serviceAccountResourceMap.values())) {
            resources = new ArrayList<>();
        } else {
            resources = this.jdbcResourceDAO
                    .select(withFieldInCollection(Resource.class, "res", "id", serviceAccountResourceMap.values()));
        }
        for (ServiceAccount servAccount : serviceAccounts) {
            servAccount.setProjectBean(findById(projects, serviceAccountProjectMap.get(servAccount)));
            servAccount.setResourceBean(findById(resources, serviceAccountResourceMap.get(servAccount)));
        }

        // On renvoie la liste :
        return serviceAccounts;
    }

    ///// Classe(s) interne(s) :

    private static class ServiceAccountResultSetTranscoder extends AbstractResultSetTranscoder<ServiceAccount> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected ServiceAccount doTranscode(final ResultSet resultSet) throws SQLException {
            final ServiceAccount serviceAccount = new ServiceAccount();
            serviceAccount.setId(processLongValue(resultSet, "id"));
            serviceAccount.setUid(resultSet.getString("uid"));
            serviceAccount.setProject(resultSet.getLong("project"));
            serviceAccount.setResource(resultSet.getLong("resource"));
            serviceAccount.setDescription(resultSet.getString("description"));
            serviceAccount.setEnabled(resultSet.getBoolean("enabled"));
            serviceAccount.setVerified(resultSet.getBoolean("verified"));
            serviceAccount.setApprovedBy(resultSet.getString("approved_by"));
            serviceAccount.setCreatedBy(resultSet.getString("created_by"));
            serviceAccount.setCreatedAt(processTimestampField(resultSet, "created_at"));
            serviceAccount.setUpdatedAt(processTimestampField(resultSet, "updated_at"));
            return serviceAccount;
        }
    }

}
