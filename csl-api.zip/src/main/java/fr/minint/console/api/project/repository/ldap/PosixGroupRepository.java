package fr.minint.console.api.project.repository.ldap;

import fr.minint.console.api.project.ldap.model.PosixGroup;
import org.springframework.data.ldap.repository.LdapRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PosixGroupRepository extends LdapRepository<PosixGroup> {
    Optional<PosixGroup> findByCn(String cn);
}
