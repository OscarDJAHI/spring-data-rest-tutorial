package fr.minint.console.api.project.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class UpdateServiceAccountDto {
    @NotNull
    Long id;

    @Size(min = 50)
    String password;

    @NotBlank
    String description;

    Boolean enabled;
}
