package fr.minint.console.api.project.dao.quota;

import fr.minint.console.api.project.model.flavor.FlavorQuota;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCFlavorQuotaDAO extends AbstractJDBCDAO<Long, FlavorQuota> {
    private static final Transcoder<ResultSet, FlavorQuota> FLAVOR_QUOTA_TRANSCODER = new FlavorQuotaTranscoder();

    public JDBCFlavorQuotaDAO(final DataSource dataSource) {
        super(dataSource, "flavor_quota", "flavorQuota");

        // Initialisation
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(FLAVOR_QUOTA_TRANSCODER);
    }

    ///// Méthodes de la classe AbstractJDBCDAO :

    @Override
    protected String getInsertQuery(final FlavorQuota bean) throws Exception {
        if (bean == null) {
            throw new Exception("L'instance de FlavorQuota est nulle => on ne peut donc pas construire la requête d'insertion");
        }
        return "INSERT INTO " + this.tableName + " (id, quota_type, flavor, quota_value, created_at, updated_at) " +
                "VALUES (%d, %d, %d, %d, now(), now())"
                        .formatted(bean.getId(), bean.getQuotaType(), bean.getFlavor(), bean.getQuotaValue());
    }

    @Override
    protected String getUpdateQuery(final FlavorQuota bean) throws Exception {
        if (bean == null) {
            throw new Exception("L'instance de FlavorQuota est nulle => on ne peut donc pas construire la requête de mise à jour");
        }
        return "UPDATE " + this.tableName +
                "SET quota_type=%d, flavor=%d, quota_value=%d, updated_at=now() WHERE id = %d"
                        .formatted(bean.getQuotaType(), bean.getFlavor(), bean.getQuotaValue(), bean.getId());
    }

    ///// Classe(s) interne(s) :

    private static class FlavorQuotaTranscoder extends AbstractResultSetTranscoder<FlavorQuota> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected FlavorQuota doTranscode(final ResultSet resultSet) throws SQLException {
            final FlavorQuota flavorQuota = new FlavorQuota();
            flavorQuota.setId(processLongValue(resultSet, "id"));
            flavorQuota.setQuotaType(processLongValue(resultSet, "quota_type"));
            flavorQuota.setFlavor(processLongValue(resultSet, "flavor"));
            flavorQuota.setQuotaValue(processLongValue(resultSet, "quota_value"));
            return flavorQuota;
        }
    }
}
