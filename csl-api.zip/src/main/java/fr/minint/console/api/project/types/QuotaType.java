package fr.minint.console.api.project.types;

public enum QuotaType {
    CPU("cpu"),
    RAM("ram"),
    BLOCK("block"),
    OBJECT("object"),
    OBJECT_STORAGE("object-storage");

    private final String name;

    QuotaType(String name) {
        this.name = name;
    }

    public String value() {
        return name;
    }
}
