package fr.minint.console.api.project.dto.user;

import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
public class CreateUserDto {

    @NotEmpty String name;
    @NotEmpty String email;

}
