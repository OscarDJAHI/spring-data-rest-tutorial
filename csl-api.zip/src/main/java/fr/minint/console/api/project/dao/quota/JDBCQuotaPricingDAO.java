package fr.minint.console.api.project.dao.quota;

import fr.minint.console.api.project.model.QuotaPricing;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCQuotaPricingDAO extends AbstractJDBCDAO<Long, QuotaPricing> {
    private static final Transcoder<ResultSet, QuotaPricing> RESULT_SET_QUOTA_PRICING_TRANSCODER = new ResultSetQuotaPricingTranscoder();

    public JDBCQuotaPricingDAO(final DataSource dataSource) {
        super(dataSource, "quota_pricing", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_QUOTA_PRICING_TRANSCODER);
    }

    ///// Méthode de la classe AbstractDefaultJdbcDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT id," +
                "  quota_unit," +
                "  monthly_price," +
                "  yearly_price," +
                "  quota_type" +
                " FROM quota_pricing";
    }

    @Override
    protected String getInsertQuery(final QuotaPricing quotaPricing) throws Exception {
        if (quotaPricing == null) {
            throw new Exception("L'instance QuotaPricing est nulle --> On ne peut pas construire la requête SQL d'insertion");
        }
        return "INSERT INTO quota_pricing " +
                "(quota_type, quota_unit, monthly_price, yearly_price, created_at, updated_at) " +
                "VALUES (%d, %s, %f, %f, now(), now())"
                        .formatted(quotaPricing.getQuotaType(),
                                escapeSQL(quotaPricing.getQuotaUnit()),
                                quotaPricing.getMonthlyPrice(),
                                quotaPricing.getYearlyPrice());
    }

    @Override
    protected String getUpdateQuery(final QuotaPricing quotaPricing) throws Exception {
        if (quotaPricing == null) {
            throw new Exception("L'instance QuotaPricing est nulle --> On ne peut pas construire la requête SQL de mise à jour");
        }
        return "UPDATE quota_pricing" +
                " SET quota_type=%d, quota_unit=%s, monthly_price=%f, yearly_price=%f, updated_at=now() WHERE id=%d"
                        .formatted(quotaPricing.getQuotaType(),
                                escapeSQL(quotaPricing.getQuotaUnit()),
                                quotaPricing.getMonthlyPrice(),
                                quotaPricing.getYearlyPrice(),
                                quotaPricing.getId());
    }

    ///// Classe(s) interne(s) :

    private static class ResultSetQuotaPricingTranscoder extends AbstractResultSetTranscoder<QuotaPricing> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected QuotaPricing doTranscode(final ResultSet resultSet) throws SQLException {
            final QuotaPricing quotaPricing = new QuotaPricing();
            quotaPricing.setId(processLongValue(resultSet, "id"));
            quotaPricing.setMonthlyPrice(processDoubleValue(resultSet, "monthly_price"));
            quotaPricing.setYearlyPrice(processDoubleValue(resultSet, "yearly_price"));
            quotaPricing.setQuotaType(processLongValue(resultSet, "quota_type"));
            quotaPricing.setQuotaUnit(resultSet.getString("quota_unit"));
            return quotaPricing;
        }
    }
}
