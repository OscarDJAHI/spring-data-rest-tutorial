package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.entities.RoleAssignement;
import fr.minint.console.api.project.model.resource.ResourceRole;
import fr.minint.console.api.project.service.ResourceServiceFactory;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.server.ResponseStatusException;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Setter
public class IaasDecorator extends ResourceRoleServiceDecorator {
    private static final Logger LOGGER = LoggerFactory.getLogger(IaasDecorator.class);
    private ResourceServiceFactory resourceServiceFactory;

    public IaasDecorator(final ResourceRoleService source) {
        super(source);
    }

    private void grant(final RoleAssignement resourceRole) {
        try {
            boolean hasAddMember = resourceServiceFactory.service(resourceRole).addMember(resourceRole);
            if (!hasAddMember) {
                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role assignment have failed");
            }
        } catch (HttpClientErrorException e) {
            LOGGER.error(e.getMessage());
            LOGGER.info("Service role assignment procedure has failed, the resource role will be updated as not synchronized");
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role assignation have failed");
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage(), exception);
        }
    }

    private void revoke(final RoleAssignement resourceRole) {
        try {
            boolean hasRevokedMember = resourceServiceFactory.service(resourceRole).removeMember(resourceRole);
            if (!hasRevokedMember) {
                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role revocation have failed");
            }
        } catch (final HttpClientErrorException e) {
            LOGGER.error(e.getMessage());
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                LOGGER.info("L'affectation de rôle côté IaaS semble ne plus exister, la référence côté base de données sera traitée comme si elle était encore présente");
            } else {
                LOGGER.info("Service role revocation procedure has failed, the resource role will be not updated");
                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role revocation have failed");
            }
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage(), exception);
        }
    }

    @Override
    public RoleAssignement create(RoleAssignement resourceRole) {
        if (resourceRole.getIsSynchronized()) {
            grant(resourceRole);
        }
        return super.create(resourceRole);
    }

    @Override
    public RoleAssignement update(RoleAssignement resourceRole) {
        if (resourceRole.getIsSynchronized()) {
            grant(resourceRole);
        } else {
            revoke(resourceRole);
        }
        return super.update(resourceRole);
    }

    @Override
    public void delete(RoleAssignement resourceRole) {
        revoke(resourceRole);
        super.delete(resourceRole);
    }
}
