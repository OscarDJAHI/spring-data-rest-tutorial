package fr.minint.console.api.project.ldap.dto;

import lombok.Data;

@Data
public class BastionAccess {
    String region;
    String zone;
    String uid;
}
