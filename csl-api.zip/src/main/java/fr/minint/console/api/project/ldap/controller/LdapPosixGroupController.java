package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.dto.BastionAccess;
import fr.minint.console.api.project.ldap.dto.UpdatePosixGroupDto;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.service.PosixGroupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class LdapPosixGroupController {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapPosixGroupController.class);
    private PosixGroupService posixGroupService;


    @PostMapping("/api/ldap/posix-groups")
    @ResponseStatus(HttpStatus.CREATED)
    void create(@RequestBody PosixGroup posixGroup) {
        posixGroup.setNew(true);
        posixGroupService.create(posixGroup);
    }

    @GetMapping("/api/ldap/posix-groups")
    List<PosixGroup> list() {
        return posixGroupService.list();
    }

    @GetMapping("/api/ldap/posix-groups/{cn}")
    ResponseEntity<PosixGroup> get(@PathVariable String cn) {
        return posixGroupService.get(cn).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/api/ldap/posix-groups")
    @ResponseStatus(HttpStatus.OK)
    Optional<PosixGroup> update(@RequestBody UpdatePosixGroupDto updatePosixGroupDto) {
        return posixGroupService.update(updatePosixGroupDto);
    }

    @DeleteMapping("/api/ldap/posix-groups")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void delete(@RequestBody UpdatePosixGroupDto updatePosixGroupDto) {
        posixGroupService.remove(updatePosixGroupDto);
    }


    ///// Getters & Setters :

    @Autowired
    public void setPosixGroupService(final PosixGroupService posixGroupService) {
        this.posixGroupService = posixGroupService;
    }
}
