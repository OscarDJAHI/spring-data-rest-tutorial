package fr.minint.console.api.project.dao.tag;

import fr.minint.console.api.project.model.Tag;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTagDAO extends AbstractJDBCDAO<Long, Tag> {
    private static final Transcoder<ResultSet, Tag> RESULT_SET_TAG_TRANSCODER = new ResultSetTagTranscoder();

    ///// Constructeurs :

    public JDBCTagDAO(final DataSource dataSource,
                      final String login,
                      final String password) {
        super(dataSource, login, password, "tag", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_TAG_TRANSCODER);
    }

    public JDBCTagDAO(final DataSource dataSource) {
        this(dataSource, null, null);
    }

    JDBCTagDAO() {
        this(null);
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    protected String getInsertQuery(final Tag tag) throws Exception {
        if (tag == null) {
            throw new Exception("L'objet Tag est nul !! => On ne peut pas construire la requête d'insertion");
        }
        return "INSERT INTO " +
                this.tableName +
                " (name, \"label\", color, created_at, updated_at)" +
                " VALUES (%s, %s, %s, now(), now())"
                        .formatted(escapeSQL(tag.getName()),
                                escapeSQL(tag.getLabel()),
                                escapeSQL(tag.getColor()));
    }

    @Override
    protected String getUpdateQuery(final Tag tag) throws Exception {
        if (tag == null) {
            throw new Exception("L'objet Tag est nul !! => On ne peut pas construire la requête de mise à jour !!");
        }
        return "UPDATE " +
                this.tableName +
                " SET \"name\"=%s,\"label\"=%s,color=%s,updated_at=now() WHERE id=%s"
                        .formatted(escapeSQL(tag.getName()),
                                escapeSQL(tag.getLabel()),
                                escapeSQL(tag.getColor()),
                                tag.getId());
    }

    private static class ResultSetTagTranscoder extends AbstractResultSetTranscoder<Tag> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected Tag doTranscode(final ResultSet resultSet) throws SQLException {
            if (resultSet == null) {
                return null;
            }
            final Tag tag = new Tag();
            tag.setId(processLongValue(resultSet, "id"));
            tag.setName(resultSet.getString("name"));
            tag.setLabel(resultSet.getString("label"));
            tag.setColor(resultSet.getString("color"));
            tag.setCreatedAt(processTimestampField(resultSet, "created_at"));
            tag.setUpdatedAt(processTimestampField(resultSet, "updated_at"));
            return tag;
        }

    }
}
