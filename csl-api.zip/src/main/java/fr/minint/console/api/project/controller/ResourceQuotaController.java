package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.repositories.ResourceQuotaRepository;
import fr.minint.console.api.project.entities.*;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;


@RestController
@RequestMapping("/resource-quotas")
@Setter(onMethod = @__(@Autowired))
public class ResourceQuotaController extends AbstractRestController {
    private ResourceQuotaRepository resourceQuotaRepository;

    ///// Définition des "endPoints" :

    @PostMapping
    public ResourceQuota create(
            KeycloakAuthenticationToken keycloakAuthenticationToken,
            @RequestBody ResourceQuota resourceQuota) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return resourceQuotaRepository.save(resourceQuota);
    }

    @GetMapping
    public Iterable<ResourceQuota> list(KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return resourceQuotaRepository.findAll();
    }

    @GetMapping("/{resource_quota_id}")
    public Optional<ResourceQuota> get(final KeycloakAuthenticationToken keycloakAuthenticationToken, @PathVariable("resource_quota_id") final Long id) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return resourceQuotaRepository.findById(id);
    }

    @PutMapping("/{resource_quota_id}")
    public ResourceQuota update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("resource_quota_id") Long id,
            @RequestBody ResourceQuota resourceQuota) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        if (!resourceQuotaRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource quota not found");
        }
        if (!resourceQuota.getId().equals(id)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Resource quota id is not corresponding with the request one");
        }
        return resourceQuotaRepository.save(resourceQuota);
    }

    @DeleteMapping("/{resource_quota_id}")
    public void remove(KeycloakAuthenticationToken keycloakAuthenticationToken,@PathVariable("resource_quota_id") Long id) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        if (!resourceQuotaRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource quota not found");
        }
        resourceQuotaRepository.deleteById(id);
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceQuotaRepository(ResourceQuotaRepository resourceQuotaRepository) {
        this.resourceQuotaRepository = resourceQuotaRepository;
    }
}
