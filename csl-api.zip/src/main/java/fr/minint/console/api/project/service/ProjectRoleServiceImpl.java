package fr.minint.console.api.project.service;

import fr.minint.console.api.project.ConsoleRole;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.api.project.model.Role.SOUSCRIPTEUR_ROLE_NAME;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProjectRoleServiceImpl implements ProjectRoleService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProjectRoleServiceImpl.class);
    private final RoleAssignementRepository projectRoleRepository;
    private final ProjectRepository projectRepository;
    private final RoleRepository roleRepository;
    private final LdapService ldapService;
    private final ServiceAccountRepository serviceAccountRepository;

    // DAO's

    boolean isUnique(RoleAssignement projectRole) {
        return projectRole.getServiceAccount()!=null? projectRoleRepository.findByProjectIdAndRoleIdAndServiceAccountId(
                projectRole.getProject().getId(),
                projectRole.getRole().getId(),
                projectRole.getServiceAccount().getId()
        ).isEmpty(): projectRoleRepository.findByProjectIdAndRoleIdAndUserUid(
                projectRole.getProject().getId(),
                projectRole.getRole().getId(),
                projectRole.getUser().getUid()).isEmpty();
    }

    boolean isServiceAccount(RoleAssignement projectRole) {
        return projectRole.getServiceAccount() != null;
    }

    boolean isOwner(RoleAssignement projectRole) {
        if (isServiceAccount(projectRole)) {
            return false;
        }
        final Project project = projectRepository.findById(projectRole.getProject().getId()).orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Project not found"));
        return projectRole.getRole().getLabel().equals(SOUSCRIPTEUR_ROLE_NAME);
    }

    boolean isDelegation(RoleAssignement projectRole) {
        Role role = roleRepository
                .findById(projectRole.getRole().getId())
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Role not found"));

        return role.getName().equals(ConsoleRole.DELEGUE.value());
    }

    @Override
    public RoleAssignement create(final RoleAssignement projectRole) {
        try {
            if (projectRole.getServiceAccount() != null) {
                final Optional<ServiceAccount> foundServiceAccountOpt = serviceAccountRepository.findById(projectRole.getServiceAccount().getId());
                if (foundServiceAccountOpt.isEmpty()) {
                    throw new Exception("Pas de compte de service en base de données avec l'id = %d".formatted(projectRole.getServiceAccount().getId()));
                }
                final ServiceAccount serviceAccount = foundServiceAccountOpt.get();
                if (!ldapService.userExists(serviceAccount.getUid())) {
                    LOGGER.warn("Pas de compte de service dans le répertoire LDAP");
                    throw new ResponseStatusException(NOT_FOUND, "Pas de compte de service dans le répertoire LDAP");
                }
            } else if (!ldapService.userExists(projectRole.getUser().getUid())) {
                LOGGER.warn("User not found in directory");
                throw new ResponseStatusException(NOT_FOUND, "User not found");
            }
            if (!isUnique(projectRole)) {
                throw new ResponseStatusException(HttpStatus.OK, "Role already assigned to user on project");
            }
            if (isDelegation(projectRole) && isOwner(projectRole)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can't delegate to the project owner");
            }
            return projectRoleRepository.save(projectRole);
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @Override
    public Iterable<RoleAssignement> list() {
        return projectRoleRepository.findAll();
    }

    @Override
    public RoleAssignement get(Long id) {
        Optional<RoleAssignement> optionalProjectRole = projectRoleRepository.findById(id);

        if (optionalProjectRole.isPresent()) return optionalProjectRole.get();
        throw new ResponseStatusException(NOT_FOUND, "Project not found");
    }

    @Override
    public RoleAssignement update(RoleAssignement projectRole) {
        Set<RoleAssignement> projectRoleMatchingUniqueConstrain = projectRoleRepository.findByProjectIdAndRoleIdAndUserUidAndServiceAccountId(
                projectRole.getProject().getId(),
                projectRole.getRole().getId(),
                projectRole.getUser().getUid(),
                projectRole.getServiceAccount().getId()
        );
        boolean hasProjectRoleWithSameId = projectRoleRepository.existsById(projectRole.getId());
        boolean hasExistingProjectRoleWithSameUniqueConstrain = !projectRoleMatchingUniqueConstrain.isEmpty();

        if (hasProjectRoleWithSameId && hasExistingProjectRoleWithSameUniqueConstrain) {
            boolean hasSameId = projectRoleMatchingUniqueConstrain.stream().allMatch(pr -> pr.getId().equals(projectRole.getId()));

            if (hasSameId) return projectRoleRepository.save(projectRole);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Project role update avoided. A project role similar to the one you want to update already exists");
        }
        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Are you trying to create a project role with an update call ?");
    }

    @Override
    public RoleAssignement delete(Long id) {
        final RoleAssignement projectRole = projectRoleRepository.findById(id).orElse(null);
        if (projectRole != null) {
            projectRoleRepository.deleteById(id);
            removeUserFromGroupIfItShould(projectRole);
            return projectRole;
        }
        throw new ResponseStatusException(NOT_FOUND);
    }

    private void removeUserFromGroupIfItShould(final RoleAssignement projectRole) {
        final List<RoleAssignement> userProjectRoleOccurrences = projectRoleRepository.findByUserUidAndRoleId(projectRole.getUser().getUid(), projectRole.getRole().getId());
        if (userProjectRoleOccurrences.isEmpty()) {
            Role role = roleRepository.findById(projectRole.getRole().getId()).orElseThrow();
            ldapService.removeUserFromGroup(projectRole.getUser().getUid(), role.getName());
        }
    }

    ///// Setters & Getters :

}
