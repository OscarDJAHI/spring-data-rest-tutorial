package fr.minint.console.api.project.entities;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.library.utils.json.JSONUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "role_assignement", schema = "public", catalog = "ConsoleAdapation")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class RoleAssignement {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "is_synchronized")
    private Boolean isSynchronized;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @OneToOne
    @JoinColumn(name = "service_account", referencedColumnName = "id")
    @JsonBackReference("parent-service-account-role")
    private ServiceAccount serviceAccount;

    @ManyToOne
    @JoinColumn(name = "resource", referencedColumnName = "id")
    @JsonBackReference("parent-service-account-resource")
    private Resource resource;

    @ManyToOne
    @JoinColumn(name = "role", referencedColumnName = "id")
    private Role role;

    @ManyToOne
    @JoinColumn(name = "\"user\"", referencedColumnName = "id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "project", referencedColumnName = "id")
    @JsonBackReference("parent-project-role")
    private Project project;

    public RoleAssignement(ServiceAccount serviceAccount, Resource resource, Project project, Role role, Boolean isSynchronized) {
        this.serviceAccount = serviceAccount;
        this.resource = resource;
        this.project = project;
        this.role = role;
        this.isSynchronized = isSynchronized;
    }


    public Map<String, Object> toMap() throws JsonProcessingException {
        final Map<String, Object> map = new HashMap<>();
        map.put("id", this.id);
        map.put("userId", this.user.getUid());
        map.put("resourceId", this.resource);
        map.put("roleId", this.role);
        map.put("serviceAccountId", this.serviceAccount);
        map.put("user", (this.user == null ? new JSONObject() : JSONUtils.buildJSONObject(this.user)));
        return map;
    }
}
