package fr.minint.console.api.project.email.service;

import fr.minint.console.api.project.email.configuration.EmailConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.IContext;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.IOException;
import java.util.Objects;

@Slf4j
@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    EmailConfiguration emailConfiguration;

    @Autowired
    JavaMailSender emailSender;

    @Autowired
    TemplateEngine templateEngine;

    @Override
    public void sendMessage(String to, String subject, String content) {
        SimpleMailMessage message = new SimpleMailMessage();

        message.setFrom(emailConfiguration.getNoReply());
        message.setTo(to);
        message.setSubject(subject);
        message.setText(content);
        emailSender.send(message);
    }

    @Override
    public void sendTemplatedMessage(String to, String subject, String template) throws MessagingException {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper message = new MimeMessageHelper(mimeMessage, false, emailConfiguration.getEncoding());

        message.setFrom(emailConfiguration.getNoReply());
        message.setTo(to);
        message.setSubject(subject);
        message.setText(template, true);
        emailSender.send(mimeMessage);
    }

    @Override
    public void sendThymeleafTemplatedMessage(String to, String subject, String template, IContext context) throws IOException, MessagingException {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper message = new MimeMessageHelper(mimeMessage, false, emailConfiguration.getEncoding());
        String html = templateEngine.process(template, context);

        message.setFrom(emailConfiguration.getNoReply());
        message.setTo(to);
        message.setSubject(subject);
        message.setText(html, true);
        emailSender.send(mimeMessage);
    }

    @Override
    public void sendThymeleafTemplatedMessageWithCc(String to,String cc, String subject, String template, IContext context) throws IOException, MessagingException {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper message = new MimeMessageHelper(mimeMessage, false, emailConfiguration.getEncoding());
        String html = templateEngine.process(template, context);

        message.setFrom(emailConfiguration.getNoReply());
        message.setTo(to);
        message.setCc(cc);
        message.setSubject(subject);
        message.setText(html, true);
        emailSender.send(mimeMessage);
    }

    @Override
    public void sendThymeleafTemplatedMessageWithAttachment(final String to,
                                                            final String subject,
                                                            final String template,
                                                            final IContext context,
                                                            final String fileToAttach) throws IOException, MessagingException {
        final String body = templateEngine.process(template, context);
//        String attachment = templateEngine.process(fileToAttach, context);

        final MimeMessagePreparator preparator = mimeMessage -> {
            mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            mimeMessage.setFrom(new InternetAddress(emailConfiguration.getNoReply()));
            mimeMessage.setSubject(subject);
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setText(body, true);
            // helper.addAttachment(
            //         "%s.osrc".formatted(((Resource) context.getVariable("tenant")).getName()),
            //         new ByteArrayDataSource(attachment.getBytes(StandardCharsets.UTF_8), "application/octet-stream")
            // );
        };

        try {
            emailSender.send(preparator);
        } catch (MailException ex) {
            log.error(ex.getMessage(), ex);
        }
    }

    @Override
    public void sendMailWithAttachment(String to, String subject, String body, String fileToAttach) {
        MimeMessagePreparator preparator = mimeMessage -> {
            mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            mimeMessage.setFrom(new InternetAddress(emailConfiguration.getNoReply()));
            mimeMessage.setSubject(subject);
            mimeMessage.setText(body);

            FileSystemResource file = new FileSystemResource(new File(fileToAttach));
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.addAttachment(Objects.requireNonNull(file.getFilename()), file);
        };

        try {
            emailSender.send(preparator);
        } catch (MailException ex) {
            // simply log it and go on...
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void sendMailWithInlineResources(String to, String subject, String fileToAttach) {
        MimeMessagePreparator preparator = mimeMessage -> {
            mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            mimeMessage.setFrom(new InternetAddress(emailConfiguration.getNoReply()));
            mimeMessage.setSubject(subject);

            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

            helper.setText("<html><body><img src='cid:identifier1234'></body></html>", true);

            FileSystemResource res = new FileSystemResource(new File(fileToAttach));
            helper.addInline("identifier1234", res);
        };

        try {
            emailSender.send(preparator);
        } catch (MailException ex) {
            // simply log it and go on...
            System.err.println(ex.getMessage());
        }
    }
}
