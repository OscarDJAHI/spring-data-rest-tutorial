package fr.minint.console.api.project.ldap.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;

@Data
@Entry(objectClasses = {"organizationalUnit"})
final public class OrganisationalUnit {
    @Id
    private Name dn;

    @Attribute(name = "ou")
    private String ou;

    @JsonProperty("dn")
    public String getId() {
        return dn.toString();
    }

    @JsonProperty("dn")
    public void setId(String id) {
        dn = LdapUtils.newLdapName(id);
    }
}
