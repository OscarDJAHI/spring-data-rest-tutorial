package fr.minint.console.api.project.entities;

import com.fasterxml.jackson.annotation.*;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property ="id")
public class Project {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", nullable = false, length = -1)
    private String name;

    @Basic
    @Column(name = "label", nullable = false, length = -1)
    private String label;
    @Basic
    @Column(name = "description", length = -1)
    private String description;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;
    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Basic
    @Column(name = "enabled")
    private Boolean enabled;

    @ManyToOne
    @JoinColumn(name = "pai", referencedColumnName = "id")
    private Pai pai;

    @ManyToOne
    @JoinColumn(name = "cgu_id", referencedColumnName = "id")
    @JsonBackReference("parent-versionned-document")
    private VersionedDocument versionedDocument;

    @JsonManagedReference("parent-resource-project")
    @OneToMany(mappedBy = "project")
    private Collection<Resource> resources;

    @OneToMany(mappedBy = "project")
    @JsonManagedReference("parent-project-role")
    private Collection<RoleAssignement> roleAssignements;
}
