package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.QuotaType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface QuotaTypeRepository extends JpaRepository<QuotaType, Long>, JpaSpecificationExecutor<QuotaType> {
}
