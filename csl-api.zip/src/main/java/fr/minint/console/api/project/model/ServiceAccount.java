package fr.minint.console.api.project.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceRegion;
import fr.minint.console.library.bean.HasRIO;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONObject;

@Table
public class ServiceAccount extends AbstractDAOBean<Long> implements ToJSON, HasProject, HasRIO {
    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceAccount.class);

    @Id
    private Long id;

    @JsonProperty("projectId")
    private Long project;

    @JsonProperty("resourceId")
    private Long resource;

    private String uid;
    private String description;
    private boolean enabled;
    private boolean verified;
    private String createdBy;
    private String approvedBy;
    private Instant createdAt;
    private Instant updatedAt;

    @Transient
    private Project projectBean;

    @Transient
    private Resource resourceBean;

    ///// Constructeurs :

    public ServiceAccount(final Long id,
                          final Long project,
                          final Long resource,
                          final String uid,
                          final String description,
                          final boolean enabled,
                          final boolean verified) {
        this.id = id;
        this.project = project;
        this.resource = resource;
        this.uid = uid;
        this.description = description;
        this.enabled = enabled;
        this.verified = verified;
    }


    public ServiceAccount(final Long id, final String uid) {
        this.id = id;
        this.uid = uid;
    }

    public ServiceAccount() {
        this(null, null, null, null, null, true, true);
    }

    ///// Implémentation des méthodes d'AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.uid);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.uid, ((ServiceAccount) that).uid);
    }

    ///// Implémentation de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        try {
            final JSONObject jsonResource = new JSONObject();
            jsonResource.put("id", this.id);
            jsonResource.put("enabled", this.enabled);
            jsonResource.put("projectId", this.project);
            jsonResource.put("resourceId", this.resource);
            jsonResource.put("verified", this.verified);
            jsonResource.put("approved_by", this.approvedBy);
            jsonResource.put("created_by", this.createdBy);
            jsonResource.put("description", this.description);
            jsonResource.put("uid", this.uid);
            jsonResource.put("project", buildJSONObject(this.projectBean));
            final Resource resourceBean = this.getResourceBean();
            if (resourceBean != null) {
                jsonResource.put("resource", buildJSONObject(resourceBean));
            }
            if (resourceBean != null && resourceBean.getResourceTypeBean() != null) {
                jsonResource.put("resourceType", buildJSONObject(resourceBean.getResourceTypeBean()));
            }
            if (resourceBean != null && !isCollectionEmpty(resourceBean.getRegions())) {
                final JSONArray jsonResourceRegions = new JSONArray();
                for (Region area : resourceBean.getRegions()) {
                    jsonResourceRegions.put(new ResourceRegion(null, resourceBean.getId(), area.getId()).toJSON());
                }
                jsonResource.put("regions", jsonResourceRegions);
            }
            return jsonResource;
        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error("ERREUR FATALE : {}", jsonProcessingException.getMessage());
            throw new RuntimeException(jsonProcessingException);
        }
    }

    ///// Méthodes de l'interface HasRIO :

    @Override
    public String getUserUid() {
        return this.getUid();
    }

    ////// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public Long getProject() {
        return project;
    }

    public void setProject(final Long project) {
        this.project = project;
    }

    public Long getResource() {
        return resource;
    }

    public void setResource(final Long resource) {
        this.resource = resource;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(final String uid) {
        this.uid = uid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(final boolean verified) {
        this.verified = verified;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(final String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(final Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Project getProjectBean() {
        return projectBean;
    }

    public void setProjectBean(final Project projectBean) {
        this.projectBean = projectBean;
        this.project = (projectBean == null ? null : projectBean.getId());
    }

    public Resource getResourceBean() {
        return resourceBean;
    }

    public void setResourceBean(final Resource resourceBean) {
        this.resourceBean = resourceBean;
        this.resource = (resourceBean == null ? null : resourceBean.getId());
    }

}
