package fr.minint.console.api.project.model.project;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.utils.json.ToJSON;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class ProjectTag implements ToJSON {
    @Id
    private Long id;
    @JsonProperty("projectId")
    private Long project;
    @JsonProperty("tagId")
    private Long tag;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    ///// Méthode de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonTag = new JSONObject();
        jsonTag.put("id", this.getId());
        jsonTag.put("projectId", this.getProject());
        jsonTag.put("tagId", this.getTag());
        jsonTag.put("createdAt", this.getCreatedAt());
        jsonTag.put("updatedAt", this.getUpdatedAt());
        return jsonTag;
    }
}
