package fr.minint.console.api.project.ldap.model;

import org.springframework.ldap.core.AttributesMapper;

import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;

final public class PersonAttributeMapper implements AttributesMapper<Person> {
    @Override
    public Person mapFromAttributes(Attributes attributes) throws NamingException {
        Person person = new Person();

        person.setDn((Name) attributes.get("dn").get());
        person.setUid((String) attributes.get("uid").get());
        person.setMail((String) attributes.get("mail").get());
        person.setFirstname((String) attributes.get("givenName").get());
        person.setLastname((String) attributes.get("sn").get());

        return person;
    }
}
