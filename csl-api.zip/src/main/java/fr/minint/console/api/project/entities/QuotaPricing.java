package fr.minint.console.api.project.entities;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "quota_pricing", schema = "public", catalog = "ConsoleAdapation")
public class QuotaPricing {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "quota_unit", length = -1)
    private String quotaUnit;

    @Basic
    @Column(name = "monthly_price", precision = 0)
    private Float monthlyPrice;

    @Basic
    @Column(name = "yearly_price", precision = 0)
    private Float yearlyPrice;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @ManyToOne
    @JoinColumn(name = "quota_type", referencedColumnName = "id")
    private QuotaType quotaType;

    public QuotaPricing(final Long id,
                        final String quotaUnit,
                        final Float monthlyPrice,
                        final Float yearlyPrice,
                        final QuotaType quotaType) {
        this.id = id;
        this.setQuotaUnit(quotaUnit);
        this.setMonthlyPrice(monthlyPrice);
        this.setYearlyPrice(yearlyPrice);
        this.setQuotaType(quotaType);
    }

    public QuotaPricing(final String quotaUnit, final Float monthlyPrice, final Float yearlyPrice, final QuotaType quotaType) {
        this.id = null;
        this.setQuotaUnit(quotaUnit);
        this.setMonthlyPrice(monthlyPrice);
        this.setYearlyPrice(yearlyPrice);
        this.setQuotaType(quotaType);
    }
}
