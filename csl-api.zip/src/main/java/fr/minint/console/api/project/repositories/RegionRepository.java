package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Region;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Set;

public interface RegionRepository extends JpaRepository<Region, Long>, JpaSpecificationExecutor<Region> {

    List<Region> findByIdIn(List<Long> s3AreaIds);
}
