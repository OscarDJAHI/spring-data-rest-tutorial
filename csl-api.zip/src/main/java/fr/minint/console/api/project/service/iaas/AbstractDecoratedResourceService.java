package fr.minint.console.api.project.service.iaas;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.service.ResourceService;

import java.util.List;

public abstract class AbstractDecoratedResourceService extends AbstractIAASService {
    private ResourceService wrappee;

    public AbstractDecoratedResourceService(ResourceService resourceService) {
        this.wrappee = resourceService;
    }

    @Override
    public Resource create(Resource resource) throws Exception {
        return wrappee.create(resource);
    }

    @Override
    public Resource get(Long resourceId) throws Exception {
        return wrappee.get(resourceId);
    }

    @Override
    public List<Resource> list() throws Exception {
        return wrappee.list();
    }

    @Override
    public Long update(Resource resource) throws Exception {
        return wrappee.update(resource);
    }

    @Override
    public void delete(Resource resource) throws Exception {
        wrappee.delete(resource);
    }

    @Override
    public boolean addMember(RoleAssignement resourceRole) throws Exception {
        return wrappee.addMember(resourceRole);
    }

    @Override
    public boolean removeMember(RoleAssignement resourceRole) throws Exception {
        return wrappee.removeMember(resourceRole);
    }
}
