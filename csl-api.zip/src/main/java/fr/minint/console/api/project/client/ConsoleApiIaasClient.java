package fr.minint.console.api.project.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.ActionResponse;
import fr.minint.console.api.project.service.EcsUsage;
import fr.minint.console.api.project.utils.RAMUnit;
import lombok.Setter;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.openstack4j.model.identity.v3.Domain;
import org.openstack4j.model.identity.v3.Project;
import org.openstack4j.model.identity.v3.Role;
import org.openstack4j.model.identity.v3.User;
import org.openstack4j.openstack.identity.v3.domain.KeystoneDomain;
import org.openstack4j.openstack.identity.v3.domain.KeystoneProject;
import org.openstack4j.openstack.identity.v3.domain.KeystoneRole;
import org.openstack4j.openstack.identity.v3.domain.KeystoneUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.*;

import static fr.minint.console.api.project.utils.RAMUnit.MEGA;
import static fr.minint.console.api.project.utils.RAMUnit.convertTo;
import static fr.minint.console.api.project.utils.RestUtils.createHttpHeaders;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONObjectFromMap;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.Objects.requireNonNull;
import static org.springframework.http.HttpMethod.PUT;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
@Setter(onMethod = @__(@Autowired))
public class ConsoleApiIaasClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConsoleApiIaasClient.class);
    private static final BigDecimal NOTIFICATION_PERCENTAGE = new BigDecimal("0.7");
    private static final String S3_OBJECT_STORAGE_QUOTA_TYPE_NAME = "object-storage";
    private static final String SWIFT_OBJECT_STORAGE_QUOTA_TYPE_NAME = "object";
    private Environment env;
    private RestTemplate restTemplate;
    private StatusRepository statusRepository;
    private ZoneRepository zoneRepository;
    private QuotaTypeRepository quotaTypeRepository;
    private ResourceTypeRepository resourceTypeRepository;
    private TagRepository tagRepository;
    private RegionRepository regionRepository;

    // DAO's
    private ResourceRepository resourceRepository;

    public Status getStatus(Long statusId) {
        return statusRepository.findById(statusId).orElseThrow();
    }

    public Region getRegion(final Long areaId) {
        try {
            final Optional<Region> foundRegionOpt = regionRepository.findById(areaId);
            if (foundRegionOpt.isEmpty()) {
                throw new NoSuchElementException("Pas de région trouvée dans la base de données avec id = %d".formatted(areaId));
            }
            return foundRegionOpt.get();
        } catch (final Exception exception) {
            throw new RuntimeException(exception.getMessage(), exception);
        }
//        return regionRepository.findById(areaId).orElseThrow();
    }

    public Zone getZone(Long zoneId) {
        return zoneRepository.findById(zoneId).orElseThrow();
    }

    private QuotaType getQuotaType(Long quotaTypeId) {
        return quotaTypeRepository.findById(quotaTypeId).orElseThrow();
    }

    private Resource getResource(final Long resourceId) throws Exception {
        final Optional<Resource> foundResourceOptional = resourceRepository.findById(resourceId);
        if (foundResourceOptional.isEmpty()) {
            throw new Exception("Pas de ressource trouvée pour id = %d".formatted(resourceId));
        }
        return foundResourceOptional.get();
    }

    public List<String> generateOpenStackTags(Resource resource) {
        return resource.getResourceTags().stream()
                .map(resourceTag ->
                        tagRepository.findById(resourceTag.getTag().getId())
                                .orElseThrow(() -> new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to map tag id"))
                                .getName()
                ).toList();
    }

    public HttpHeaders getHeaders() {
        return createHttpHeaders(APPLICATION_JSON);
    }

    public HttpHeaders getHeaders(KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal) {
        HttpHeaders headers = getHeaders();
        headers.setBearerAuth(keycloakPrincipal.getKeycloakSecurityContext().getTokenString());
        return headers;
    }

    public Project getOpenstackProject(Region region, String projectId) {
        String baseUrl = env.getProperty("console.api.iaas.url").trim();
        String url = "%s/openstack/projects/%s?provider=%s".formatted(baseUrl, projectId, region.getName());
        final ResponseEntity<KeystoneProject> response = this.restTemplate.getForEntity(url, KeystoneProject.class);
        if (response.getStatusCode().is2xxSuccessful()) {
            return response.getBody();
        }
        return null;
    }

    public Project getOpenstackProject(final Resource resource) {
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
        return getOpenstackProject(region, resource.getExternalId());
    }

    public boolean openstackProjectExists(Resource resource) {
        return getOpenstackProject(resource) != null;
    }

    public Project createOpenstackProject(Resource resource) {
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
        Zone zone = resource.getZone();
        Boolean enabled = resource.getEnabled();
        List<String> tags = generateOpenStackTags(resource);
        return createOpenstackProject(
                resource.getName(),
                resource.getDescription(),
                enabled,
                region.getName(),
                zone.getName(),
                tags
        );
    }

    public Project createOpenstackProject(String name,
                                          String description,
                                          Boolean enabled,
                                          String region,
                                          String zone,
                                          List<String> tags) {
        final String url = "%s/projects?provider=%s".formatted(env.getProperty("console.api.iaas.url").trim(), region);
        final Map<String, Object> map = new HashMap<>();
        map.put("name", name);
        map.put("description", description);
        map.put("enabled", enabled);
        map.put("region", region);
        map.put("zone", zone);
        map.put("tags", tags);
        map.put("domain", env.getProperty("console.api.iaas.openstack.user.domain.name"));
        LOGGER.debug(url);
        final ResponseEntity<KeystoneProject> response = this.restTemplate.postForEntity(
                url,
                new HttpEntity<>(map, getHeaders()),
                KeystoneProject.class);
        if (response.getStatusCode() == HttpStatus.CREATED) {
            return response.getBody();
        }
        LOGGER.debug("IaaS tenant creation failure with status code: %s".formatted(response.getStatusCode()));
        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Fail to create tenant");
    }

    public boolean statusIdToBoolean(Status status) {
        return status.getName().equals("enabled") || (status.getName().equals("disabled") ? false : null);
    }

    public Project updateOpenstackProject(Resource resource) {
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
        Zone zone = resource.getZone();
        Boolean enabled = resource.getEnabled();
        List<String> tags = generateOpenStackTags(resource);
        return updateOpenstackProject(
                resource.getExternalId(),
                resource.getName(),
                resource.getDescription(),
                enabled,
                region.getName(),
                zone.getName(),
                tags
        );
    }

    public Project updateOpenstackProject(
            String id,
            String name,
            String description,
            Boolean enabled,
            String region,
            String zone,
            List<String> tags
    ) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/projects?provider=%s".formatted(baseUrl, region);
        HttpHeaders headers = getHeaders();
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("name", name);
        map.put("description", description);
        map.put("enabled", enabled);
        map.put("region", region);
        map.put("zone", zone);
        map.put("tags", tags);
        map.put("domain", env.getProperty("console.api.iaas.openstack.user.domain.name"));

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(map, headers);

        ResponseEntity<KeystoneProject> response = this.restTemplate.exchange(
                url,
                PUT,
                entity,
                KeystoneProject.class
        );

        LOGGER.debug("{} {}: {}", PUT, url, response.getStatusCode());

        if (response.hasBody()) {
            return response.getBody();
        }

        return null;
    }

    public Project disableOpenstackProject(Resource resource) {
        return enableOpenstackProject(resource, false);
    }

    public Project enableOpenstackProject(Resource resource) {
        return enableOpenstackProject(resource, true);
    }

    public Project enableOpenstackProject(Resource resource, boolean enabled) {
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
        Zone zone = resource.getZone();
        List<String> tags = generateOpenStackTags(resource);

        return updateOpenstackProject(
                resource.getExternalId(),
                resource.getName(),
                resource.getDescription(),
                enabled,
                region.getName(),
                zone.getName(),
                tags
        );
    }

    public Long getOpenstackUsedQuota(Resource resource, QuotaType quotaType) {
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();

        final String url = "%s/projects/%s/quotas/%s/limits?provider=%s".formatted(
                requireNonNull(env.getProperty("console.api.iaas.url")).trim(),
                resource.getExternalId(),
                findIaaSQuotaApiToUse(quotaType.getName()),
                region.getName()
        );
        final ResponseEntity<Map> httpLimitsResponse = restTemplate.getForEntity(url, Map.class);
        if (httpLimitsResponse.getStatusCode() == NO_CONTENT) {
            return 0L;
        }
        final Map<?, ?> limits = httpLimitsResponse.getBody();
        final Map<String, Integer> absoluteLimits = (Map<String, Integer>) limits.get("absolute");
        if (absoluteLimits != null) {
            final String openstackLimitsName = translateToOpenstackLimitsName(quotaType.getName());
            final Long openstackLimitsValue = absoluteLimits.get(openstackLimitsName).longValue();
            LOGGER.debug("QuotaType.name: %s, OpenstackLimits.name: %s, OpenstackLimits.value: %s".formatted(quotaType.getName(), openstackLimitsName, openstackLimitsValue));
            return absoluteLimits.get(translateToOpenstackLimitsName(quotaType.getName())).longValue();
        }
        final Map<String, String> metadata = (Map<String, String>) limits.get("metadata");
        if (metadata != null) {
            return Long.parseLong(metadata.get(translateToOpenstackLimitsName(quotaType.getName()))) / 1000000000L; // TODO: Add better unit conversion handling
        }
        return null;
    }

    public Map<String, Object> getOpenstackQuota(final ResourceQuota resourceQuota) throws Exception {
        final Resource resource = resourceQuota.getResource();
        final QuotaType quotaType = resourceQuota.getQuotaType();
        final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();

        final String url = "%s/projects/%s/quotas/%s?provider=%s".formatted(
                requireNonNull(env.getProperty("console.api.iaas.url")).trim(),
                resource.getExternalId(),
                findIaaSQuotaApiToUse(quotaType.getName()),
                region.getName()
        );

        //noinspection rawtypes
        final ResponseEntity<Map> responseEntity = restTemplate.getForEntity(url, Map.class);
        if (responseEntity.getStatusCode() == NO_CONTENT) {
            return new HashMap<>();
        }
        return (Map<String, Object>) responseEntity.getBody();
    }

    public EcsUsage getEcsQuota(final ResourceQuota resourceQuota, final String domain, final String area) throws Exception {
        final QuotaType quotaType = getQuotaType(resourceQuota.getQuotaType().getId());
        if (quotaType == null) {
            throw new RuntimeException("Type de quota non trouvé");
        }

        // TODO: Faire confiance à l'algorithme de sélection des quota à update et tester le comportement dans un test adapté
        List<String> objectStorageQuotaTypeNames = List.of(S3_OBJECT_STORAGE_QUOTA_TYPE_NAME, SWIFT_OBJECT_STORAGE_QUOTA_TYPE_NAME);
        if (objectStorageQuotaTypeNames.stream().noneMatch(quotaTypeName -> quotaTypeName.equals(quotaType.getName()))) {
            throw new RuntimeException("La mise à jour de quota ECS ne s'applique qu'au type de quota %s, %s ne fait pas partie des types de quota supportés".formatted(objectStorageQuotaTypeNames, quotaType.getName()));
        }
        final Resource resource = resourceQuota.getResource();
        if (resource == null) {
            throw new RuntimeException("Resource non trouvée");
        }
        final String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        final String url = "%s/ecs/namespaces/%s/quotas?domain=%s&area=%s".formatted(baseUrl, resource.getExternalId(), URLEncoder.encode(domain, UTF_8), URLEncoder.encode(area, UTF_8));
        final ResponseEntity<EcsUsage> responseEntity = restTemplate.getForEntity(url, EcsUsage.class);
        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
            LOGGER.debug("{} {}", responseEntity.getStatusCode().value(), responseEntity.getStatusCode().getReasonPhrase());
            throw new RuntimeException("Echec de la récupération l'utilisation du namespace ECS: %s".formatted(resource.getExternalId()));
        }
        if (!responseEntity.hasBody()) {
            throw new RuntimeException("Aucune donnée n'a été remontée lors de l'appel à l'utilisation du namespace ECS: %s".formatted(resource.getExternalId()));
        }
        return responseEntity.getBody();
    }

    public void updateEcsQuota(final ResourceQuota resourceQuota) throws Exception {
        final QuotaType quotaType = resourceQuota.getQuotaType();
        if (quotaType == null) {
            LOGGER.error("Type de quota non trouvé");
            throw new Exception("Type de quota non trouvé");
        }
        // TODO: Faire confiance à l'algorithme de sélection des quota à update et tester le comportement dans un test adapté
        final List<String> objectStorageQuotaTypeNames = List.of(S3_OBJECT_STORAGE_QUOTA_TYPE_NAME, SWIFT_OBJECT_STORAGE_QUOTA_TYPE_NAME);
        if (objectStorageQuotaTypeNames.stream().noneMatch(quotaTypeName -> quotaTypeName.equals(quotaType.getName()))) {
            final String errorMessage = "La mise à jour de quota ECS ne s'applique qu'au type de quota %s, %s ne fait pas partie des types de quota supportés".formatted(objectStorageQuotaTypeNames, quotaType.getName());
            LOGGER.error(errorMessage);
            throw new Exception(errorMessage);
        }

        final Resource resource = resourceQuota.getResource();
        if (resource == null) {
            LOGGER.error("Resource non trouvée pour id = {}", resourceQuota.getResource());
            throw new Exception("Resource non trouvée pour id = %d".formatted(resourceQuota.getResource()));
        }
        final Region region =resource.getResourceRegions().stream().findFirst().get().getRegion();

        if (region ==null) {
            LOGGER.error("Région non trouvée pour la resource id = {}", resource.getId());
            throw new Exception("Région non trouvée pour la resource id = %d".formatted(resource.getId()));
        }

        final String namespace = resource.getExternalId();
        final String blockSize = String.valueOf(resourceQuota.getQuotaValue());
        final String notificationSize = NOTIFICATION_PERCENTAGE.multiply(new BigDecimal(resourceQuota.getQuotaValue())).toString();

        final HashMap<String, String> payload = new HashMap<>();
        payload.put("namespace", namespace);
        payload.put("blockSize", blockSize);
        payload.put("notificationSize", notificationSize);
        payload.put("replicationGroup", Objects.requireNonNull(
                env.getProperty("console.api.iaas.default.replication-group"),
                "Aucun groupe de réplication par défaut n'a été trouvé dans la configuration"
        ));
        final Optional<ResourceType> resourceTypeOpt = resourceTypeRepository.findById(resource.getResourceType().getId());
        if (resourceTypeOpt.isEmpty()) {
            LOGGER.error("Pas de type de resource pour l'id = {}", resource.getResourceType().getId());
            throw new Exception("Pas de type de resource");
        }
        final ResourceType resourceType = resourceTypeOpt.get();
        String domain;
        if ("s3".equalsIgnoreCase(resourceType.getCategory())) {
            domain = "s3";
        } else {
            domain = "iaas";
        }
        payload.put("domain", domain);
        payload.put("area", region.getName());
        LOGGER.debug("namespace: {}", namespace);
        LOGGER.debug("blockSize: {}", blockSize);
        LOGGER.debug("notificationSize: {}", notificationSize);
        LOGGER.info("Mise à jour du namespace {} (blockSize: {}}, notificationSize: {}}) en cours...", namespace, blockSize, notificationSize);

        final ResponseEntity<String> responseEntity = restTemplate
                .exchange("%s/ecs/namespaces".formatted(requireNonNull(env.getProperty("console.api.iaas.url")).trim()),
                        PUT,
                        new HttpEntity<Map<String, String>>(payload),
                        String.class);
        if (responseEntity.getStatusCode() == OK) {
            LOGGER.info("Namespace {} mis à jour", namespace);
        } else if (responseEntity.getStatusCode() == NO_CONTENT) {
            LOGGER.info("Pas de misà jour car ECS bouchonné probablement");
        } else if (responseEntity.getStatusCode().value() >= BAD_REQUEST.value()) {
            LOGGER.error("Echec de la mise à jour du namespace {}", namespace);
            throw new Exception(responseEntity.getStatusCode().getReasonPhrase());
        }
    }

    public void updateOpenstackQuota(final ResourceQuota resourceQuota) throws Exception {
        final QuotaType quotaType = resourceQuota.getQuotaType();
        final Resource resource = resourceQuota.getResource();
        final String openstackQuotaName = translateToOpenstackQuotaName(quotaType.getName());
        Map<String, Object> requestBody = getOpenstackQuota(resourceQuota);
        switch (openstackQuotaName) {
            case "cores" -> requestBody.put("cores", resourceQuota.getQuotaValue());
            case "ram" -> requestBody.put("ram", convertTo(resourceQuota.getQuotaValue(), RAMUnit.fromUnit(quotaType.getQuotaUnit()), MEGA).longValue());
            case "gigabytes" -> requestBody.put("gigabytes", resourceQuota.getQuotaValue());
            case "X-Account-Meta-Quota-Bytes" -> {
                Map<String, Object> metadata = new HashMap<>();
                metadata.put("X-Account-Meta-Quota-Bytes", resourceQuota.getQuotaValue());
                metadata = convertConsoleObjectQuotaToOpenstackSwiftAccountMetaQuotaBytes(metadata);
                metadata.put("X-Account-Meta-Quota-Bytes", String.valueOf(metadata.get("X-Account-Meta-Quota-Bytes")));
                requestBody = metadata;
            }
            default -> LOGGER.warn("Quota field %s not supported".formatted(openstackQuotaName));
        }
        try {
            LOGGER.debug(buildJSONObjectFromMap(requestBody).toString());
        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error(jsonProcessingException.getMessage(), jsonProcessingException);
        }

        // Appel REST
        final Region region =resource.getResourceRegions().stream().findFirst().get().getRegion();

        final String url = "%s/projects/%s/quotas/%s?provider=%s".formatted(
                requireNonNull(env.getProperty("console.api.iaas.url")).trim(),
                resource.getExternalId(),
                findIaaSQuotaApiToUse(quotaType.getName()),
                region.getName());
        LOGGER.debug("updateOpenstackQuota : Appel de {}", url);
        this.restTemplate.exchange(url, PUT, new HttpEntity<>(requestBody, getHeaders()), Object.class);
    }


    private static String findIaaSQuotaApiToUse(final String quotaName) {
        String api = null;
        if (Objects.equals(quotaName, "cpu") || Objects.equals(quotaName, "ram")) {
            api = "compute";
        }
        if (Objects.equals(quotaName, "disk")) {
            api = "block-storage";
        }
        if (Objects.equals(quotaName, "object")) {
            api = "object-storage";
        }
        return api;
    }

    private static String translateToOpenstackQuotaName(final String quotaName) {
        Map<String, String> map = new HashMap<>();
        map.put("cpu", "cores");
        map.put("ram", "ram");
        map.put("disk", "gigabytes");
        map.put("object", "X-Account-Meta-Quota-Bytes");
        return map.get(quotaName);
    }

    private static String translateToOpenstackLimitsName(final String quotaName) {
        Map<String, String> map = new HashMap<>();
        map.put("cpu", "totalCoresUsed");
        map.put("ram", "totalRAMUsed");
        map.put("disk", "totalGigabytesUsed");
        map.put("object", "X-Account-Bytes-Used");
        return map.get(quotaName);
    }

    public List<? extends Domain> searchOpenstackDomainByName(Region region, String domainName) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/openstack/domains?provider=%s&name=%s".formatted(baseUrl, region.getName(), domainName);
        ResponseEntity<KeystoneDomain[]> responseEntity = this.restTemplate.getForEntity(url, KeystoneDomain[].class);
        KeystoneDomain[] domainArray = responseEntity.getBody();

        assert domainArray != null;

        return Arrays.asList(domainArray);
    }

    public List<? extends User> searchOpenstackUserByNameAndDomainId(
            Region region,
            String username,
            String domainId
    ) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/openstack/users?provider=%s&name=%s&domain_id=%s".formatted(
                baseUrl,
                region.getName(),
                username,
                domainId
        );
        ResponseEntity<KeystoneUser[]> responseEntity = this.restTemplate.getForEntity(url, KeystoneUser[].class);
        User[] users = responseEntity.getBody();

        assert users != null;

        return List.of(users);
    }

    public List<? extends Role> searchOpenstackRoleByName(Region region, String roleName) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/openstack/roles?provider=%s&name=%s".formatted(baseUrl, region.getName(), roleName);
        ResponseEntity<KeystoneRole[]> responseEntity = this.restTemplate.getForEntity(url, KeystoneRole[].class);
        KeystoneRole[] roleArray = responseEntity.getBody();

        assert roleArray != null;

        return Arrays.asList(roleArray);
    }

    public void grantUserSwiftOperator(Region region, Project project, User user) {
        String configKey = "console.api.iaas.openstack.user.role.swiftoperator";
        String openstackRoleName = env.getProperty(configKey);

        LOGGER.debug("configKey: {}", configKey);
        LOGGER.debug("openstackRoleName: {}", openstackRoleName);

        if (openstackRoleName == null) {
            LOGGER.info("Aucune valeur pour la clé de configuration: {}", configKey);
            LOGGER.info("Annulation de la procedure d'ajout du role swiftoperator pour l'utilisateur {} sur le projet {}", user.getName(), project.getName());

            return;
        }

        try {
            String openstackRoleId = searchOpenstackRoleByName(region, openstackRoleName)
                    .stream()
                    .findFirst()
                    .orElseThrow()
                    .getId();

            LOGGER.info("Ajout du role {} à l'utilisateur {} sur le projet {}", openstackRoleName, user.getName(), project.getName());

            grantProjectUserRole(region, project.getId(), user.getId(), openstackRoleId);
        } catch (NoSuchElementException e) {
            LOGGER.warn("Le rôle OpenStack {} n'a pas été trouvé", openstackRoleName);
        }
    }

    public void revokeUserSwiftOperator(Region region, Project project, User user) {
        String configKey = "console.api.iaas.openstack.user.role.swiftoperator";
        String openstackRoleName = env.getProperty(configKey);

        LOGGER.debug("configKey: {}", configKey);
        LOGGER.debug("openstackRoleName: {}", openstackRoleName);

        if (openstackRoleName == null) {
            LOGGER.info("Aucune valeur pour la clé de configuration: {}", configKey);
            LOGGER.info("Annulation de la procedure d'ajout du role swiftoperator pour l'utilisateur {} sur le projet {}", user.getName(), project.getName());

            return;
        }

        try {
            String openstackRoleId = searchOpenstackRoleByName(region, openstackRoleName)
                    .stream()
                    .findFirst()
                    .orElseThrow()
                    .getId();

            LOGGER.info("Retrait du role {} à l'utilisateur {} sur le projet {}", openstackRoleName, user.getName(), project.getName());

            revokeProjectUserRole(region, project.getId(), user.getId(), openstackRoleId);
        } catch (NoSuchElementException e) {
            LOGGER.warn("Le rôle OpenStack {} n'a pas été trouvé", openstackRoleName);
        }
    }

    public void grantProjectUserRole(Region region, String projectId, String userId, String roleId) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/openstack/projects/%s/users/%s/roles/%s?provider=%s".formatted(baseUrl, projectId, userId, roleId, region.getName());
        HttpHeaders headers = getHeaders();
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(null, headers);

        restTemplate.exchange(url, PUT, entity, ActionResponse.class);
    }

    public void revokeProjectUserRole(Region region, String projectId, String userId, String roleId) {
        String baseUrl = requireNonNull(env.getProperty("console.api.iaas.url")).trim();
        String url = "%s/openstack/projects/%s/users/%s/roles/%s?provider=%s".formatted(baseUrl, projectId, userId, roleId, region.getName());
        HttpHeaders headers = getHeaders();
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(null, headers);

        this.restTemplate.exchange(url, HttpMethod.DELETE, entity, ActionResponse.class);
    }

    public Map<String, Object> convertConsoleObjectQuotaToOpenstackSwiftAccountMetaQuotaBytes(Map<String, Object> quotaMapping) {
        Long accountMetaQuotaBytes = (Long) quotaMapping.get("X-Account-Meta-Quota-Bytes");

        if (accountMetaQuotaBytes != null) {
            quotaMapping.put("X-Account-Meta-Quota-Bytes", accountMetaQuotaBytes * 1000000000L);
        }
        return quotaMapping;
    }

    ///// Getters & Setters :

    public ResourceTypeRepository getResourceTypeRepository() {
        return resourceTypeRepository;
    }


}
