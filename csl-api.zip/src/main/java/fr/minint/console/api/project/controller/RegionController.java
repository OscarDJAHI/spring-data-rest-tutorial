package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.Region;
import fr.minint.console.api.project.repositories.RegionRepository;
import lombok.Setter;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;


@RestController
@RequestMapping("/regions")
@Setter(onMethod = @__(@Autowired))
public class RegionController extends AbstractRestController {
    private RegionRepository regionRepository;

    ///// Définition des "endPoints" :

    @GetMapping
    public Iterable<Region> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return regionRepository.findAll();
    }

    @GetMapping("/{region_id}")
    public Optional<Region> get(final KeycloakAuthenticationToken keycloakAuthenticationToken, @PathVariable("region_id") final Long id) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return regionRepository.findById(id);
    }

    ///// Getters & Setters :

    @Autowired
    public void setRegionRepository(final RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }
}
