package fr.minint.console.api.project.utils.predicate.resource;

import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.sql.predicate.AbstractJDBCPredicate;
import fr.minint.console.persistence.dao.sql.predicate.JDBCPredicate;

import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * Prédicat JDBC permettant de tester si un utilisateur a un rôle
 * attaché à la resource. <br />
 * Ce prédicat permet de tester si un utilisateur possède le rôle de Concepteur.
 * </p>
 */
public class JDBCUserHasResourceRolePredicate extends AbstractJDBCPredicate<Resource> {
    private final HasRolePredicate hasRolePredicate;

    private JDBCUserHasResourceRolePredicate(final String sqlPrefix, final String userUid, final Role role) {
        super(sqlPrefix);
        this.hasRolePredicate = new HasRolePredicate(userUid, role);
    }

    ///// Méthode(s) de la classe AbstractJDBCPredicate :

    @Override
    public boolean test(final Resource resource) {
        return this.hasRolePredicate.test(resource);
    }

    @Override
    public String whereClause() {
        final StringBuilder buffer = new StringBuilder();
        final String userUid = this.hasRolePredicate.getUserUid();
        if (isEmpty(userUid)) {
            buffer.append(this.buildSQLFieldName("uid")).append(" IS NULL ");
        } else {
            buffer.append(this.buildSQLFieldName("uid")).append(" = '").append(userUid).append("' ");
        }
        final Role role = this.hasRolePredicate.getRole();
        if (role == null || role.getId() == null) {
            buffer.append("AND ").append(this.buildSQLFieldName("id")).append(" IS NULL");
        } else {
            buffer.append("AND ").append(this.buildSQLFieldName("id")).append(" = ").append(role.getId());
        }
        return buffer.toString();
    }

    ///// Méthode(s) statique(s) :

    public static JDBCPredicate<Resource> withUserHavingResourceRole(final String userUid, final Role role) {
        return withUserHavingResourceRole("resRole", userUid, role);
    }

    public static JDBCPredicate<Resource> withUserHavingResourceRole(final String sqlPrefix, final String userUid, final Role role) {
        return new JDBCUserHasResourceRolePredicate(sqlPrefix, userUid, role);
    }
}
