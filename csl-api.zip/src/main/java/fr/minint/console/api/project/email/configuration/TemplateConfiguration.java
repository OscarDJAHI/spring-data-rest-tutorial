package fr.minint.console.api.project.email.configuration;

import lombok.Data;

@Data
public class TemplateConfiguration {
    String name;
    String template;
}
