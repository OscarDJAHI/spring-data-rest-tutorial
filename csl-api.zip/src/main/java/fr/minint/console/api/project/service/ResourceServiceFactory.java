package fr.minint.console.api.project.service;

import fr.minint.console.api.project.client.s3.S3NamespaceClient;
import fr.minint.console.api.project.client.s3.S3UserClient;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.iaas.AbstractIAASService;
import fr.minint.console.api.project.service.iaas.NamespaceResourceService;
import fr.minint.console.api.project.service.iaas.TenantService;
import fr.minint.console.api.project.service.persistence.DefaultBDDResourceService;
import fr.minint.console.api.project.types.Category;
import fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.concurrent.ExecutorService;

import static fr.minint.console.api.project.types.ResourceType.NAMESPACE;
import static fr.minint.console.api.project.types.ResourceType.TENANT;
import static java.util.Locale.ROOT;

@Service
@Setter(onMethod = @__(@Autowired))
public class ResourceServiceFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(ResourceServiceFactory.class);
    private TenantService tenantService;
    private DefaultBDDResourceService defaultBDDResourceService;
    private QuotaTypeRepository quotaTypeRepository;
    private S3NamespaceClient s3NamespaceClient;
    private S3UserClient s3UserClient;
    private ResourceQuotaService resourceQuotaService;
    private ExecutorService executorService;
    private EmailNotificationService emailNotificationService;

    // Définition des DAO's :

    private boolean s3NamespaceFeatureEnabled;
    private boolean iaasTenantFeatureEnabled;
    private ResourceTypeRepository resourceTypeRepository;

    public ResourceService withNamespaceServiceFeatures(final ResourceService resourceService) {
        final NamespaceResourceService namespaceResourceService = new NamespaceResourceService(resourceService);
        namespaceResourceService.setQuotaTypeRepository(quotaTypeRepository);
        namespaceResourceService.setS3NamespaceClient(this.s3NamespaceClient);
        namespaceResourceService.setS3UserClient(this.s3UserClient);
        namespaceResourceService.setResourceQuotaService(resourceQuotaService);
        namespaceResourceService.setEmailNotificationService(emailNotificationService);
        namespaceResourceService.setExecutorService(this.executorService);
        if (resourceService instanceof AbstractIAASService abstractIAASService) {
            namespaceResourceService.setPosixGroupDAO(abstractIAASService.getPosixGroupDAO());
        }
        return namespaceResourceService;
    }

    public ResourceService service(final Resource resource) throws Exception {
        final Optional<ResourceType> foundResourceTypeOpt = resourceTypeRepository.findById(resource.getResourceType().getId());
        if (foundResourceTypeOpt.isEmpty()) {
            throw new Exception("Type de resource non trouvé en base de données");
        }
        final ResourceType resourceType = foundResourceTypeOpt.get();

        LOGGER.debug("La catégorie de la ressource est: '{}'", resourceType.getCategory());
        ResourceService resourceService = this.defaultBDDResourceService;
        switch (Category.valueOf(resourceType.getCategory().toUpperCase(ROOT))) {
            case IAAS -> {
                if (resourceType.getName().equals(TENANT.value())) {
                    if (iaasTenantFeatureEnabled) {
                        return tenantService;
                    }
                    return resourceService;
                }
            }
            case S3 -> {
                if (resourceType.getName().equals(NAMESPACE.value())) {
                    LOGGER.info("--> On retourne le service correspondant à S3");
                    if (s3NamespaceFeatureEnabled)  {
                        LOGGER.info("S3 service : il n'est pas bouchonné");
                        resourceService = this.withNamespaceServiceFeatures(resourceService);
                    } else {
                        LOGGER.info("S3 service : Attention il n'est pas BOUCHONNÉ !!");
                    }
                    return resourceService;
                }
            }
        }
        LOGGER.warn("Tentative d'utilisation du service '{}' de la catégorie {} non implémenté ou non géré",
                    resourceType.getName(),
                    resourceType.getCategory());
        throw new RuntimeException("Impossible de trouver un service de ressource adéquat pour la ressource passée en paramètre");
    }

    public ResourceService service(final RoleAssignement resourceRole) throws Exception {
        return service(defaultBDDResourceService.get(resourceRole.getResource().getId()));
    }



    ////// Getters & Setters :

    @Autowired
    public void setS3NamespaceFeatureEnabled(@Value("${console.api.iaas.feature.s3.namespace.enabled:false}") final Boolean s3NamespaceFeatureEnabled) {
        this.s3NamespaceFeatureEnabled = s3NamespaceFeatureEnabled;
    }

    public boolean isS3NamespaceFeatureEnabled() {
        return s3NamespaceFeatureEnabled;
    }

    @Autowired
    public void setIaasTenantFeatureEnabled(@Value("${console.api.iaas.feature.os.tenant.enabled:false}") final Boolean iaasTenantFeatureEnabled) {
        this.iaasTenantFeatureEnabled = iaasTenantFeatureEnabled;
    }

    public boolean isIaasTenantFeatureEnabled() {
        return iaasTenantFeatureEnabled;
    }

    @Autowired
    public void setEmailNotificationService(final EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }


}
