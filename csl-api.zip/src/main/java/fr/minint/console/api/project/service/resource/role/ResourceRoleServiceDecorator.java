package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.entities.RoleAssignement;

import java.util.List;
import java.util.Optional;

public class ResourceRoleServiceDecorator implements ResourceRoleService {
    protected ResourceRoleService wrapped;

    public ResourceRoleServiceDecorator(ResourceRoleService source) {
        this.wrapped = source;
    }

    @Override
    public RoleAssignement create(RoleAssignement resourceRole) {
        return wrapped.create(resourceRole);
    }

    @Override
    public Optional<RoleAssignement> get(Long id) {
        return wrapped.get(id);
    }

    @Override
    public List<RoleAssignement> list() {
        return wrapped.list();
    }

    @Override
    public RoleAssignement update(RoleAssignement resourceRole) {
        return wrapped.update(resourceRole);
    }

    @Override
    public void delete(RoleAssignement resourceRole) {
        wrapped.delete(resourceRole);
    }

    @Override
    public void delete(Long id) {
        wrapped.delete(id);
    }
}
