package fr.minint.console.api.project.dao.document;

import fr.minint.console.api.project.model.document.VersionedDocument;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.apache.commons.lang3.StringUtils.isEmpty;

// TODO : A Implémenter !!
public class JDBCVersionedDocumentDAO extends AbstractJDBCDAO<Long, VersionedDocument> {
    private static final ResultSetVersionedDocumentTranscoder RESULT_DOC_TRANSCODER = new ResultSetVersionedDocumentTranscoder();

    ///// Constructeur(s) :

    public JDBCVersionedDocumentDAO(final DataSource dataSource) {
        super(dataSource, "versioned_document", "doc");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_DOC_TRANSCODER);
    }

    ///// Méthode(s) générale(s) :

    @Override
    protected String getInsertQuery(final VersionedDocument versionedDocument) throws Exception {
        if (versionedDocument == null) {
            throw new Exception("Ne peut pas construire la requête d'insertion car le bean est null!");
        }
        return "INSERT INTO versioned_document (doc_path, doc_type_name, version_number, created_at, updated_at) " +
                "VALUES (%s, %s, %d, now(), now())"
                        .formatted(escapeSQL(versionedDocument.getDocPath()),
                                escapeSQL(versionedDocument.getDocTypeName()),
                                versionedDocument.getVersionNumber());
    }

    @Override
    protected String getUpdateQuery(final VersionedDocument versionedDocument) throws Exception {
        if (versionedDocument == null) {
            throw new Exception("Ne peut pas construire la requête d'insertion car le bean est null!");
        }
        return "UPDATE versioned_document " +
                "SET doc_path=%s, doc_type_name=%s, version_number=%d, created_at=now(), updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(versionedDocument.getDocPath()),
                                escapeSQL(versionedDocument.getDocTypeName()),
                                versionedDocument.getVersionNumber(),
                                versionedDocument.getId());
    }

    @Override
    public String getDeleteAllQuery() {
        return super.getDeleteAllQuery();
    }

    ///// Classe(s) interne(s) :

    public static class ResultSetVersionedDocumentTranscoder extends AbstractResultSetTranscoder<VersionedDocument> {
        private final String sqlFieldPrefix;

        ///// Constructeur(s) :

        public ResultSetVersionedDocumentTranscoder(final String sqlFieldPrefix) {
            this.sqlFieldPrefix = (sqlFieldPrefix == null ? null : sqlFieldPrefix.trim());
        }

        public ResultSetVersionedDocumentTranscoder() {
            this(null);
        }

        ///// Méthodes privées :

        private String getFieldName(final String fieldName) {
            if (isEmpty(sqlFieldPrefix)) {
                return fieldName;
            } else {
                return this.sqlFieldPrefix + "_" + fieldName;
            }
        }

        ///// Méthodes de la classe AbstractResultSetTranscoder :

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, getFieldName("id")) == null);
            return isNull;
        }

        @Override
        protected VersionedDocument doTranscode(final ResultSet resultSet) throws SQLException {
            final VersionedDocument versionedDocument = new VersionedDocument();
            versionedDocument.setId(processLongValue(resultSet, this.getFieldName("id")));
            versionedDocument.setDocPath(resultSet.getString(this.getFieldName("doc_path")));
            versionedDocument.setDocTypeName(resultSet.getString(this.getFieldName("doc_type_name")));
            versionedDocument.setVersionNumber(processIntValue(resultSet, this.getFieldName("version_number")));
            return versionedDocument;
        }
    }
}
