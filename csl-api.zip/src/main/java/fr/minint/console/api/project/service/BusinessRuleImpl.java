package fr.minint.console.api.project.service;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.Optional;
import java.util.function.Predicate;

import static fr.minint.console.api.project.ConsoleRole.DELEGUE;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.springframework.http.HttpStatus.FORBIDDEN;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class BusinessRuleImpl implements BusinessRule {
    private ProjectRepository projectRepository;
    private ResourceRepository resourceRepository;
    private RoleRepository roleRepository;
    private RoleAssignementRepository roleAssignementRepository;


    ///// Méthodes de l'interface BusinessRule :

    @Override
    public boolean isProjectOwnerOrManager(final Long projectId, final String uid) throws Exception {
        final Optional<Role> foundManagerRoleOpt = roleRepository.findByName(DELEGUE.value());
        if (foundManagerRoleOpt.isEmpty()) {
            throw new Exception("Le Role '%s' n'a pas été trouvé en base de données".formatted(DELEGUE.value()));
        }
        Predicate<Project> predicate = withJDBCFieldEquals(Project.class, "proj_role", "uid", uid);
        predicate = predicate.and(withJDBCFieldEquals(Project.class, "proj_role", "role", foundManagerRoleOpt.get().getId()));
        predicate = predicate.or(withJDBCFieldEquals(Project.class, "owner_id", uid));
        predicate = predicate.and(withJDBCFieldEquals(Project.class, "id", projectId));
        return roleAssignementRepository.findByProjectIdAndUserUidAndRoleIdIn(projectId, uid, Arrays.asList(foundManagerRoleOpt.get().getId(), 0L)).isPresent();
    }

    @Override
    public void checkResourceOwnership(final Long projectId,
                                       final Long resourceId,
                                       final String uid) throws Exception {
        if (projectRepository.existsById(projectId)) {
            throw new Exception("Pas de projet trouvé avec l'id = %d".formatted(projectId));
        }
        if (!isProjectOwnerOrManager(projectId, uid)) {
            throw new ResponseStatusException(FORBIDDEN, "Vous n'êtes ni un souscripteur, ni un souscripteur délégué");
        }
        if (resourceRepository.existsById(resourceId)) {
            throw new Exception("Pas de ressource trouvée avec id = %d".formatted(resourceId));
        }
        Predicate<Resource> predicate = withJDBCFieldEquals(Resource.class, "id", resourceId);
        predicate = predicate.and(withJDBCFieldEquals(Resource.class, "project", projectId));
        if (resourceRepository.existsByIdAndProjectId(resourceId, projectId)) {
            throw new ResponseStatusException(FORBIDDEN, "La Ressource (id = %d) n'appartient au project (id = %d)".formatted(resourceId, projectId));
        }
    }


    ///// Getters & Setters :


    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
}
