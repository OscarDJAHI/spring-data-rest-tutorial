package fr.minint.console.api.project.entities;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collection;

import static java.time.Instant.now;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tag {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", length = -1)
    private String name;

    @Basic
    @Column(name = "label", length = -1)
    private String label;

    @Basic
    @Column(name = "color", length = -1)
    private String color;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    public Tag(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Tag(String name, String label, String color) {
        this.name = name;
        this.label = label;
        this.color = color;
    }

    public static Tag createTag(final String name, final String label, final String color) {
        final Tag createdTag = new Tag();
        createdTag.setName(name);
        createdTag.setLabel(label);
        createdTag.setColor(color);
        createdTag.setCreatedAt(Timestamp.from(Instant.now()));
        return createdTag;
    }
}
