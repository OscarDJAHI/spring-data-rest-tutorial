package fr.minint.console.api.project.ldap;

import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.persistence.dao.ldap.DefaultLdapRepositoryDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.ldap.repository.LdapRepository;

import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * DAO permettant de manipuler les groupes POSIX. <br />
 * </p>
 *
 * @see DefaultLdapRepositoryDAO
 */
public class PosixGroupDAO extends DefaultLdapRepositoryDAO<PosixGroup> {
    private static final Logger LOGGER = LoggerFactory.getLogger(PosixGroupDAO.class);

    public PosixGroupDAO(final LdapRepository<PosixGroup> ldapRepository) {
        super(ldapRepository);
    }

    ///// Méthodes de la classe DefaultLdapRepositoryDAO :

    @Override
    public PosixGroup save(final PosixGroup posixGroup) throws Exception {
        try {
            return super.save(posixGroup);
        } catch (final Exception exception) {
            final String errorMessage = exception.getMessage();
            if (!isEmpty(errorMessage) && errorMessage.contains("already exists")) {
                LOGGER.info("Paramètre(s) POSIX du groupe déjà existant => on ne fait donc rien !!");
                return posixGroup;
            }
            LOGGER.error(exception.getMessage(), exception);
            throw exception;
        }
    }
}
