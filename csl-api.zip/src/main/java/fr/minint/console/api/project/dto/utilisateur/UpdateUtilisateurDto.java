package fr.minint.console.api.project.dto.utilisateur;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class UpdateUtilisateurDto {

    @NotNull Long id;
    @NotEmpty String nom;
    @NotEmpty String prenom;
    @NotEmpty String email;
    @NotEmpty String rio;
    @NotEmpty boolean isAccountService;
}
