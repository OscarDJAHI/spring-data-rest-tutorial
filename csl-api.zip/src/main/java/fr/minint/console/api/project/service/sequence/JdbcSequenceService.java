package fr.minint.console.api.project.service.sequence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * <p>
 * Ce type service permet de récupérer la valeur actuelle ainsi que la nouvelle
 * d'une séquence SQL. <br />
 * </p>
 */
public class JdbcSequenceService implements SequenceService {
    private static final Logger LOGGER = LoggerFactory.getLogger(JdbcSequenceService.class);
    private final String sequenceName;
    private final JdbcTemplate jdbcTemplate;

    public JdbcSequenceService(final String sequenceName,
                               final JdbcTemplate jdbcTemplate) {
        this.sequenceName = sequenceName;
        this.jdbcTemplate = jdbcTemplate;
    }

    ///// Méthodes générales :

    private Long executeSequenceQuery(final String queryTemplate) {
        final String query = queryTemplate.formatted(this.sequenceName);
        LOGGER.debug("--> Sequence {} : execution de la requête {}", this.sequenceName, query);
        return this.jdbcTemplate.queryForObject(query, Long.class);
    }

    @Override
    public Long getCurrentValue() {
        return executeSequenceQuery("SELECT currval('%s')");
    }

    @Override
    public void setCurrentValue(final Long value) {
        final String query = "ALTER SEQUENCE %s RESTART WITH %d".formatted(this.sequenceName, value);
        LOGGER.debug("--> Sequence {} : execution de la requête {}", this.sequenceName, query);
        this.jdbcTemplate.update(query);
    }

    @Override
    public Long getNextValue() {
        return executeSequenceQuery("SELECT nextval('%s')");
    }

}
