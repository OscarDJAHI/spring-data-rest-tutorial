package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.library.exception.BadRequestException;
import fr.minint.console.library.validator.NotNullValidator;
import lombok.Setter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.*;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static java.util.stream.Collectors.toSet;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.ResponseEntity.ok;


/**
 * <p>
 * Contrôleur exposant toutes les APIs gérant les comptes de service
 * </p>
 */
@RestController
@Setter(onMethod = @__(@Autowired))
public class ServiceAccountController extends AbstractRestController {
    public static final NotNullValidator NOT_NULL_VALIDATOR = new NotNullValidator();
    private RoleAssignementRepository roleAssignementRepository;
    private RoleRepository roleRepository;

    private static Set<Long> getRoleIds(final Collection<? extends RoleAssignement> roleAssignments, final Long serviceAccountId) {
        if (isCollectionEmpty(roleAssignments) || (serviceAccountId == null)) {
            return new HashSet<>();
        }
        return roleAssignments
                .stream()
                .filter(roleAssignment -> serviceAccountId.equals(roleAssignment.getServiceAccount().getId()))
                .map(RoleAssignement::getRole).map(Role::getId).collect(toSet());
    }

    ///// Définition des "endPoints" :

    /**
     * Endpoint permettant de lister les comptes de services. <br />
     *
     * @param keycloakAuthenticationToken : token d'authentification
     * @param projectId                   : identifiant du projet
     * @return liste des comptes de service sous format JSON
     */
    @GetMapping(path = "/projects/{project_id}/service-accounts")
    public ResponseEntity<String> listServiceAccounts(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                      @PathVariable("project_id") final Long projectId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final StringBuilder errorMsgBuffer = new StringBuilder();
            final boolean isOk = NOT_NULL_VALIDATOR.validate("projectId", projectId, errorMsgBuffer);
            if (!isOk) {
                throw new BadRequestException(errorMsgBuffer.toString());
            }
            final List<Role> allRoles = roleRepository.findAll();
            if (isCollectionEmpty(allRoles)) {
                throw new Exception("Pas de rôle initialisé dans la table Role de la base de données");
            }
            final Optional<Role> delegueRoleOptional = allRoles
                    .stream()
                    .filter(role -> "delegue".equals(role.getName()))
                    .findFirst();
            if (delegueRoleOptional.isEmpty()) {
                throw new Exception("Pas de rôle 'delegue' trouvé dans la table Role de la base de données");
            }
            final Optional<Role> concepteurRoleOptional = allRoles
                    .stream()
                    .filter(role -> "concepteur".equals(role.getName()))
                    .findFirst();
            if (concepteurRoleOptional.isEmpty()) {
                throw new Exception("Pas de rôle 'concepteur' trouvé dans la table Role de la base de données");
            }

            final String userUid = getUserId(keycloakAuthenticationToken);
            final List<RoleAssignement> roleAssignements = roleAssignementRepository.findByProjectIdAndRoleIdIn(projectId, Arrays.asList(delegueRoleOptional.get().getId(), 0L));
            final List<ServiceAccount> serviceAccounts = roleAssignements.stream().filter(roleAssignement -> roleAssignement.getServiceAccount()!=null).map(RoleAssignement::getServiceAccount).toList();
            final JSONArray jsonServiceAccounts = new JSONArray();
            JSONObject jsonServiceAccount;
            Set<Role> roles;
            for (ServiceAccount serviceAccount : serviceAccounts) {
                jsonServiceAccount = new JSONObject();
                jsonServiceAccount.put("id", serviceAccount.getId());
                jsonServiceAccount.put("uid", serviceAccount.getUid());
                jsonServiceAccount.put("description", serviceAccount.getDescription());
                jsonServiceAccount.put("verified", serviceAccount.getVerified());
                jsonServiceAccount.put("enabled", serviceAccount.getEnabled());
                jsonServiceAccount.put("created_by", serviceAccount.getCreatedBy());
                jsonServiceAccount.put("approved_by", serviceAccount.getApprovedBy());

                // Ajout des termes liés à la ressource :
                final Resource resource = serviceAccount.getRoleAssignement().getResource();
                jsonServiceAccount.put("resourceId", resource.getId());
                 jsonServiceAccount.put("resource", buildJSONObject(resource));
                jsonServiceAccount.put("regions", (resource == null ? EMPTY_JSON_ARRAY : buildJSONArrayFromCollection(resource.getResourceRegions().stream().map(ResourceRegion::getRegion).collect(toSet()))));
                jsonServiceAccount.put("resourceType", (resource == null ? EMPTY_JSON_OBJECT : buildJSONObject(resource.getResourceType())));

                // Ajout des termes liés au projet :
                final Project project = serviceAccount.getRoleAssignement().getProject();
                jsonServiceAccount.put("projectId", project.getId());
                jsonServiceAccount.put("project", buildJSONObject(project));

                // Ajout des roles du projet et/ou de la ressource correspondant à l'utilisateur :
                roles = new HashSet<>();
                if (!roleAssignements.isEmpty()) {
                    roles.addAll(allRoles.stream().filter(role -> getRoleIds(roleAssignements, serviceAccount.getId()).contains(role.getId())).collect(toSet()));
                }


                // Si pas de roles → ce qui n'est pas normal !!!
                final Role concepteurRole = concepteurRoleOptional.get();
                if (isCollectionEmpty(roles)) {
                    this.getLogger()
                            .warn("Dû à un problème de cohérence de données dans la BDD, " +
                                    "le rôle de concepteur (id = {}) a été ajouté automatiquement " +
                                    "à la resource {}, au projet {} et au compte de service (uid = {}, id = {})", concepteurRole.getId(), serviceAccount.getRoleAssignement().getResource(), serviceAccount.getRoleAssignement().getProject(), serviceAccount.getUid(), serviceAccount.getId());
                    roleAssignementRepository
                            .save(new RoleAssignement(serviceAccount,serviceAccount.getRoleAssignement().getResource(),serviceAccount.getRoleAssignement().getProject(), concepteurRole,  true));
                    roles.add(concepteurRole);

                }
                jsonServiceAccount.put("roles", buildJSONArrayFromCollection(roles));

                // Ajout du compte de service
                jsonServiceAccounts.put(jsonServiceAccount);
            }
            return ok(jsonServiceAccounts.toString());
        } catch (final BadRequestException badRequestException) {
            this.getLogger().error(badRequestException.getMessage(), badRequestException);
            return createErrorResponseEntity(BAD_REQUEST, badRequestException.getMessage());
        } catch (final Exception exception) {
            this.getLogger().error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }
    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }

    ///// Getters & Setters :



}
