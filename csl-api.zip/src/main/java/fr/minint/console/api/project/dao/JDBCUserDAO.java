package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.model.User;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCUserDAO extends AbstractJDBCDAO<Long, User> {

    ///// Constructeur(s) :

    public JDBCUserDAO(final DataSource dataSource) {
        super(dataSource, "\"user\"", "usr");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(new UserResultSetTranscoder());
    }

    private static String printBooleanValue(final Boolean boolValue) {
        if (boolValue == null) {
            return "false";
        }
        return (boolValue ? "true" : "false");
    }

    ///// Méthode(s) de la classe AbstractJDBCDAO :

    @Override
    protected String getInsertQuery(final User user) throws Exception {
        return "INSERT INTO \"user\" " +
                ("(first_name, last_name, rio, is_service_account, created_at, updated_at, email)" +
                        " SELECT %s, %s, %s, %b, now(), NULL, %s WHERE NOT EXISTS ( SELECT * from \"user\" WHERE rio=%s)")
                        .formatted(escapeSQL(user.getFirstName()),
                                escapeSQL(user.getLastName()),
                                escapeSQL(user.getRio()),
                                user.getIsServiceAccount(),
                                escapeSQL(user.getEmail()),
                                escapeSQL(user.getRio()));
    }

    @Override
    protected String getUpdateQuery(final User user) throws Exception {
        return "UPDATE \"user\" " +
                "SET rio=%s, first_name=%s, last_name=%s, email=%s, is_service_account=%s, updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(user.getRio()),
                                escapeSQL(user.getFirstName()),
                                escapeSQL(user.getLastName()),
                                escapeSQL(user.getEmail()),
                                printBooleanValue(user.getIsServiceAccount()),
                                user.getId());
    }

    ///// Classe(s) interne(s) :

    private static class UserResultSetTranscoder extends AbstractResultSetTranscoder<User> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected User doTranscode(final ResultSet resultSet) throws SQLException {
            final User user = new User();
            user.setId(processLongValue(resultSet, "id"));
            user.setRio(resultSet.getString("rio"));
            user.setFirstName(resultSet.getString("first_name"));
            user.setLastName(resultSet.getString("last_name"));
            user.setEmail(resultSet.getString("email"));
            user.setIsServiceAccount(resultSet.getBoolean("is_service_account"));
            return user;
        }
    }
}
