package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.BastionAccessService;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.api.project.service.LdapService;
import fr.minint.console.api.project.service.ResourceServiceFactory;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;

@Service
@Setter(onMethod = @__(@Autowired))
public class ResourceRoleServiceFactory {
    private ResourceServiceFactory resourceServiceFactory;
    private BastionAccessService bastionAccessService;
    private LdapService ldapService;
    private EmailNotificationService emailNotificationService;
    private RoleAssignementRepository resourceRoleRepository;
    private RegionRepository regionRepository;
    private ZoneRepository zoneRepository;
    private RoleRepository roleRepository;
    private ExecutorService executorService;

    // DAO's

    public ResourceRoleService withEmail(final ResourceRoleService resourceRoleService) {
        final EmailDecorator emailDecorator = new EmailDecorator(resourceRoleService);
        emailDecorator.setEmailNotificationService(emailNotificationService);
        emailDecorator.setExecutorService(executorService);
        return emailDecorator;
    }

    public ResourceRoleService withIaas(final ResourceRoleService resourceRoleService) {
        final IaasDecorator iaasDecorator = new IaasDecorator(resourceRoleService);
        iaasDecorator.setResourceServiceFactory(resourceServiceFactory);
        return iaasDecorator;
    }

    public ResourceRoleService withLdap(final ResourceRoleService resourceRoleService) {
        final LdapDecorator ldapDecorator = new LdapDecorator(resourceRoleService);
        ldapDecorator.setBastionAccessService(bastionAccessService);
        ldapDecorator.setLdapService(ldapService);
        ldapDecorator.setRegionRepository(regionRepository);
        ldapDecorator.setResourceRoleRepository(resourceRoleRepository);
        ldapDecorator.setRoleRepository(roleRepository);
        ldapDecorator.setZoneRepository(zoneRepository);
        return ldapDecorator;
    }

    ///// Getters & Setters :

    public ExecutorService getExecutorService() {
        return executorService;
    }


}
