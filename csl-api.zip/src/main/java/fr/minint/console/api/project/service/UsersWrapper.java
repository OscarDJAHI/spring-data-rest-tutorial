package fr.minint.console.api.project.service;

import lombok.Data;
import org.openstack4j.openstack.identity.v3.domain.KeystoneUser;

import java.util.ArrayList;
import java.util.List;

@Data
public class UsersWrapper {

    List<? extends KeystoneUser> users = new ArrayList<>();

}
