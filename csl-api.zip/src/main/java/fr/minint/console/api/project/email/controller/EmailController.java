package fr.minint.console.api.project.email.controller;

import fr.minint.console.api.project.email.configuration.EmailConfiguration;
import fr.minint.console.api.project.email.dto.CreateEmailDto;
import fr.minint.console.api.project.email.service.EmailServiceImpl;
import fr.minint.console.api.project.model.User;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.context.Context;

import javax.mail.MessagingException;
import java.io.IOException;

@Slf4j

@RestController
@RequestMapping("/emails")
public class EmailController {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailController.class);
    private EmailServiceImpl emailServiceImpl;
    private EmailConfiguration emailConfiguration;


    @PostMapping("/tests/raw-template")
    public void sendTestHtmlEmail(@RequestBody CreateEmailDto createEmailDto) {
        try {
            emailServiceImpl.sendTemplatedMessage(
                    createEmailDto.getTo(),
                    createEmailDto.getSubject(),
                    emailConfiguration.getTemplates().get(0).getTemplate()
            );
        } catch (final MessagingException messagingException) {
            LOGGER.error(messagingException.getMessage(), messagingException);
        }
    }

    @PostMapping("/tests/thymeleaf-template")
    public void sendTestThymeleafTemplatedHtmlEmail(@RequestBody CreateEmailDto createEmailDto) {
        try {
            Context context = new Context();
            final User user = new User();
            user.setLastName("radeauda");
            user.setEmail("daniel.radeau-econocom@interieur.gouv.fr");
            context.setVariable("user", user);
            context.setVariable("tenant_name", "project-0-tenant-0");
            context.setVariable("dashboard_url", "https://dashboard.pi-bas.cloudmi.minint.fr");
            context.setVariable("console_url", "http://localhost:8081");
            context.setVariable("region", "R1");
            emailServiceImpl.sendThymeleafTemplatedMessage(
                    createEmailDto.getTo(),
                    createEmailDto.getSubject(),
                    "tenant-created-notification.html",
                    context
            );
        } catch (MessagingException | IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    ///// Getters & Setters :

    @Autowired
    public void setEmailServiceImpl(final EmailServiceImpl emailServiceImpl) {
        this.emailServiceImpl = emailServiceImpl;
    }

    @Autowired
    public void setEmailConfiguration(final EmailConfiguration emailConfiguration) {
        this.emailConfiguration = emailConfiguration;
    }
}
