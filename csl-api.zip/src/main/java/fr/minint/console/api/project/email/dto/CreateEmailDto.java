package fr.minint.console.api.project.email.dto;

import lombok.Data;

@Data
public class CreateEmailDto {

    String to;
    String subject;

}
