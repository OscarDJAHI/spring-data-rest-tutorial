package fr.minint.console.api.project.service;

import fr.minint.console.api.project.controller.UserController;
import fr.minint.console.api.project.email.service.EmailService;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repositories.*;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.*;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.StringUtils.isNumeric;

@Service
@Getter
@Setter(onMethod = @__(@Autowired))
public class EmailNotificationServiceImpl implements EmailNotificationService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailNotificationServiceImpl.class);
    private static final String SPACE = " ";
    private static final String EMPTY_STRING = "";
    private ProjectRepository projectRepository;
    private RegionRepository regionRepository;
    private ZoneRepository zoneRepository;
    private EmailService emailService;
    private UserController userController;
    private RoleRepository roleRepository;
    private TagRepository tagRepository;
    private Environment environment;

    /// DAO :
    private ResourceRepository resourceRepository;

    public static String formatNameWithoutRIO(final String name) {
        if (name == null) {
            return EMPTY_STRING;
        }
        final StringTokenizer tokenizer = new StringTokenizer(name, SPACE, false);
        final StringBuilder buffer = new StringBuilder();
        int cursor = 0;
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            if (!isNumeric(token)) {
                if (cursor > 0) {
                    buffer.append(SPACE);
                }
                buffer.append(token);
                cursor++;
            }
        }
        return buffer.toString().trim();
    }

    private Context initContext() {
        final Context ctx = new Context();
        ctx.setVariable("consoleUrl", environment.getProperty("console.api.email.console-url"));
        return ctx;
    }

    @Override
    public void sendProjectCreationNotificationEmail(final String userEmail,
                                                     final String userName,
                                                     final String projectName) throws MessagingException, IOException {
        final Context ctx = initContext();
        ctx.setVariable("userName", formatNameWithoutRIO(userName));
        ctx.setVariable("userEmail", userEmail);
        ctx.setVariable("projectName", projectName);
        emailService.sendThymeleafTemplatedMessage(userEmail,
                "[Console Cloud π] Création de projet: %s".formatted(projectName),
                "project-created-notification.html",
                ctx);
    }

    @Override
    public void sendResourceCreationNotificationEmail(final String userEmail,
                                                      final String userName,
                                                      final String resourceName,
                                                      final String resourceTagLabel,
                                                      final String zoneLabel,
                                                      final String regionLabel,
                                                      final String dashboardUrl) throws MessagingException, IOException {
        final Context ctx = initContext();
        ctx.setVariable("userName", formatNameWithoutRIO(userName));
        ctx.setVariable("userEmail", userEmail);
        ctx.setVariable("resourceName", resourceName);
        ctx.setVariable("resourceTagLabel", resourceTagLabel);
        ctx.setVariable("zoneLabel", zoneLabel);
        ctx.setVariable("regionLabel", regionLabel);
        ctx.setVariable("dashboardUrl", dashboardUrl);
        emailService.sendThymeleafTemplatedMessage(userEmail,
                "[Console Cloud π] Création de ressource: %s".formatted(resourceName),
                "tenant-created-notification.html",
                ctx);
    }

    @Override
    public void sendResourceCreationNotificationEmail(final String userEmail, final String userName, final Resource resource) throws MessagingException, IOException {
        final Region iaasArea;
        if (!resource.getResourceRegions().isEmpty()) {
            iaasArea = resource.getResourceRegions().stream().findFirst().get().getRegion();
        } else {
            iaasArea = null;
        }
        final Zone zone;
        if (resource.getZone() != null) {
            zone = zoneRepository.findById(resource.getZone().getId()).orElse(null);
        } else {
            zone = null;
        }
        final List<Tag> tags = new ArrayList<>();
        final List<Long> tagIds = resource.getResourceTags().stream().map(resourceTag -> resourceTag.getTag().getId()).collect(toList());
        for (Tag foundTag : tagRepository.findAllById(tagIds)) {
            tags.add(foundTag);
        }
        if (tags.isEmpty()) {
            throw new RuntimeException("Project tags is empty");
        }
        sendResourceCreationNotificationEmail(
                userEmail,
                userName,
                resource.getName(),
                tags.get(0).getLabel(),
                (zone == null ? "" : zone.getLabel()),
                (iaasArea == null ? "" : iaasArea.getLabel()),
                (iaasArea == null ? "" : this.getDashboardUrlByRegionName(iaasArea.getName()))
        );
    }

    @Override
    public boolean sendResourceRoleCreationNotification(RoleAssignement resourceRole) throws Exception {
        final Map<String, String> params = new HashMap<>();
        params.put("uid", resourceRole.getUser().getUid());
        final List<LdapUser> persons = (List<LdapUser>) userController.search(params);
        final LdapUser person = persons.get(0);
        final Optional<Resource> resourceOpt = resourceRepository.findById(resourceRole.getId());
        if (resourceOpt.isEmpty()) {
            LOGGER.warn("No resource found");
            return false;
        }

        final Role consoleRole = roleRepository.findById(resourceRole.getRole().getId()).orElse(null);
        if (consoleRole == null) {
            LOGGER.warn("No role found");
            return false;
        }
        final Resource resource = resourceOpt.get();

        final Long iaasAreaId = resource.getResourceRegions().stream().findFirst().get().getRegion().getId();
        final Region iaasArea;
        if (iaasAreaId != null) {
            iaasArea = regionRepository.findById(iaasAreaId).orElse(null);
        } else {
            iaasArea = null;
        }
        final Zone zone;
        if (resource.getZone() != null) {
            zone = zoneRepository.findById(resource.getZone().getId()).orElse(null);
        } else {
            zone = null;
        }

        final Context ctx = initContext();
        ctx.setVariable("user", person);
        ctx.setVariable("tenant", (resource.getName() == null ? "" : resource.getName()));
        ctx.setVariable("role", consoleRole);
        ctx.setVariable("zoneLabel", (zone == null ? "" : zone.getLabel()));
        ctx.setVariable("regionLabel", (iaasArea == null ? "" : iaasArea.getLabel()));
        ctx.setVariable("dashboardUrl", (iaasArea == null ? "" : getDashboardUrlByRegionName(iaasArea.getName())));
        try {
            emailService.sendThymeleafTemplatedMessageWithAttachment(
                    person.getMail(),
                    "[Console Cloud π] Ajout de rôle OpenStack sur %s".formatted(resource.getName()),
                    "you-are-granted-notification.html",
                    ctx,
                    "user.osrc.txt"
            );
            return true;
        } catch (IOException | MessagingException | MailAuthenticationException e) {
            LOGGER.error("Notification system exception", e);
        }
        return false;
    }

    @Override
    public boolean sendResourceRoleDeletionNotification(final RoleAssignement resourceRole) throws Exception {
        final Map<String, String> params = new HashMap<>();
        params.put("uid", resourceRole.getUser().getUid());
        final List<LdapUser> persons = (List<LdapUser>) userController.search(params);
        final LdapUser person = persons.get(0);

        final Optional<Resource> foundResourceOpt = resourceRepository.findById(resourceRole.getResource().getId());
        if (foundResourceOpt.isEmpty()) {
            LOGGER.warn("Pas de ressource trouvée dans la base de données avec id = %d".formatted(resourceRole.getResource()));
            return false;
        }
        final Resource resource = foundResourceOpt.get();
        Role consoleRole = roleRepository.findById(resourceRole.getRole().getId()).orElse(null);

        if (consoleRole == null) {
            LOGGER.warn("No role found");
            return false;
        }
        final Region iaasArea;
        if (!resource.getResourceRegions().isEmpty()) {
            iaasArea = regionRepository.findById(resource.getResourceRegions().stream().findFirst().get().getId()).orElse(null);
        } else {
            iaasArea = null;
        }

        final Zone zone;
        if (resource.getZone() != null) {
            zone = zoneRepository.findById(resource.getZone().getId()).orElse(null);
        } else {
            zone = null;
        }

        final Context ctx = initContext();
        ctx.setVariable("user", person);
        ctx.setVariable("tenant", resource);
        ctx.setVariable("role", consoleRole);
        ctx.setVariable("zoneLabel", (zone == null ? "" : zone.getLabel()));
        ctx.setVariable("regionLabel", (iaasArea == null ? "" : iaasArea.getLabel()));
        ctx.setVariable("dashboardUrl", (iaasArea == null ? "" : getDashboardUrlByRegionName(iaasArea.getName())));
        try {
            emailService.sendThymeleafTemplatedMessage(
                    person.getMail(),
                    "[Console Cloud π] Retrait de rôle OpenStack sur %s".formatted(resource.getName()),
                    "you-are-revoked-notification.html",
                    ctx
            );
            return true;
        } catch (IOException | MessagingException | MailAuthenticationException e) {
            LOGGER.error("Notification system exception", e);
        }
        return false;
    }

    @Override
    public boolean sendProjectRoleCreationNotification(final RoleAssignement projectRole) {
        final Map<String, String> params = new HashMap<>();
        params.put("uid", projectRole.getUser().getUid());
        final List<LdapUser> persons = (List<LdapUser>) userController.search(params);
        final LdapUser person = persons.get(0);
        final Optional<Project> projectRepositoryOpt = projectRepository.findById(projectRole.getProject().getId());
        if (projectRepositoryOpt.isEmpty()) {
            LOGGER.warn("No resource found");
            return false;
        }
        final Project project = projectRepositoryOpt.get();

        final Optional<Role> roleRepositoryOpt = roleRepository.findById(projectRole.getRole().getId());
        if (roleRepositoryOpt.isEmpty()) {
            LOGGER.warn("No role found");
            return false;
        }
        final Role consoleRole = roleRepositoryOpt.get();

        final Context ctx = initContext();
        ctx.setVariable("user", person);
        ctx.setVariable("project", project);
        ctx.setVariable("role", consoleRole);
        try {
            emailService.sendThymeleafTemplatedMessage(
                    person.getMail(),
                    "[Console Cloud π] Ajout de rôle Console Cloud π sur %s".formatted(project.getName()),
                    "project-user-granted-notification.html",
                    ctx
            );
            return true;
        } catch (final IOException | MessagingException | MailAuthenticationException exception) {
            LOGGER.error("Notification system exception", exception);
        }
        return false;
    }

    @Override
    public boolean sendProjectRoleDeletionNotification(final RoleAssignement projectRole) {
        Map<String, String> params = new HashMap<>();
        params.put("uid", projectRole.getUser().getUid());
        List<LdapUser> persons = (List<LdapUser>) userController.search(params);
        LdapUser person = persons.get(0);
        final Optional<Project> foundProjectOpt = projectRepository.findById(projectRole.getProject().getId());
        if (foundProjectOpt.isEmpty()) {
            LOGGER.warn("No resource found");
            return false;
        }
        final Project project = foundProjectOpt.get();

        final Optional<Role> foundConsoleRoleOpt = roleRepository.findById(projectRole.getRole().getId());
        if (foundConsoleRoleOpt.isEmpty()) {
            LOGGER.warn("No role found");
            return false;
        }
        final Role consoleRole = foundConsoleRoleOpt.get();

        final Context ctx = initContext();
        ctx.setVariable("user", person);
        ctx.setVariable("project", project);
        ctx.setVariable("role", consoleRole);
        try {
            emailService.sendThymeleafTemplatedMessage(
                    person.getMail(),
                    "[Console Cloud π] Retrait de rôle Console Cloud π sur %s".formatted(project.getName()),
                    "project-user-revoked-notification.html",
                    ctx
            );
            return true;
        } catch (final IOException | MessagingException | MailAuthenticationException exception) {
            LOGGER.error("Notification system exception", exception);
        }
        return false;
    }

    @Override
    public void sendServiceAccountCreatedEmail(final String userEmail,
                                               final String userName,
                                               final String serviceAccountName) throws MessagingException, IOException {
        final Context ctx = initContext();
        ctx.setVariable("userName", userName);
        ctx.setVariable("serviceAccountName", serviceAccountName);
        try {
            emailService.sendThymeleafTemplatedMessage(userEmail,
                    "[Console Cloud π] Création du compte de service %s".formatted(serviceAccountName),
                    "service-account-created-email.html",
                    ctx);
        } catch (final IOException | MessagingException exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw exception;
        }
    }

    @Override
    public void sendResourceRoleUpdateEmail(final String userName,
                                            final String userEmail,
                                            final String targetName,
                                            final String action,
                                            final String roleName,
                                            final String resourceName) throws MessagingException, IOException {
        final Context ctx = initContext();
        ctx.setVariable("userName", formatNameWithoutRIO(userName));
        ctx.setVariable("userEmail", userEmail);
        ctx.setVariable("targetName", targetName);
        ctx.setVariable("action", action);
        ctx.setVariable("roleName", roleName);
        ctx.setVariable("resourceName", resourceName);
        try {
            emailService.sendThymeleafTemplatedMessage(
                    userEmail,
                    "[Console Cloud π] Mise à jour du compte de service %s".formatted(targetName),
                    "service-account-updated-email.html",
                    ctx
            );
        } catch (final IOException | MessagingException exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw exception;
        }
    }

    @Override
    public void sendWorkFlowTenantCreationNotificationEmail(final String userName) throws MessagingException, IOException {
        final Context ctx = initContext();
        ctx.setVariable("userName", formatNameWithoutRIO(userName));
        ctx.setVariable("toEmail", this.getAlertEmail(false));
        ctx.setVariable("ccEmail", this.getAlertEmail(true));
        emailService.sendThymeleafTemplatedMessage(
                this.getAlertEmail(false),
                "[Console Cloud π] Dépassement du quotas de creation de tenant par  %s".formatted(userName),
                "depassement-quotas-creation-tenant.html",
                ctx
        );
    }

    @Override
    public void sendResourceS3CreationNotificationEmail(final String userEmail,
                                                        final String userName,
                                                        final Resource resource) throws MessagingException, IOException {
        if (resource == null) {
            LOGGER.info("Pas de ressource pour l'envoi de l'email S3");
            return;
        }
        final String label;
        if (!resource.getResourceRegions().isEmpty()) {
            final Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
            label = (region == null ? "Region avec id = %d".formatted(region.getId()) : region.getLabel());
        } else if (!isCollectionEmpty(resource.getResourceRegions())) {
            final StringBuilder builder = new StringBuilder();
            int index = 0;
            for (ResourceRegion resourceRegion : resource.getResourceRegions()) {
                if (index > 0) {
                    builder.append(" ");
                }
                builder.append(resourceRegion.getRegion().getLabel());
                index++;
            }
            label = builder.toString();
        } else {
            label = "";
        }

        final List<Region> regions =resource.getResourceRegions().stream().map(ResourceRegion::getRegion).toList();
        final Context ctx = initContext();
        ctx.setVariable("userName", formatNameWithoutRIO(userName));
        ctx.setVariable("userEmail", userEmail);
        ctx.setVariable("resourceName", resource.getName());
        ctx.setVariable("regionLabel", label);
        ctx.setVariable("regions", regions);
        try {
            emailService.sendThymeleafTemplatedMessage(userEmail,
                    "[Console Cloud π] Création d'un namespace': %s".formatted(resource.getName()),
                    "s3-created-notification.html",
                    ctx);
        } catch (final IOException | MessagingException exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw exception;
        }
    }

    @Override
    public boolean sendResourceS3RoleCreationNotification(final RoleAssignement resourceRole) throws Exception {
        final Map<String, String> params = new HashMap<>();
        params.put("uid", resourceRole.getUser().getUid());

        final List<LdapUser> persons = (List<LdapUser>) userController.search(params);
        final LdapUser person = persons.get(0);
        if (person == null) {
            LOGGER.warn("Pas d'utilisateur trouvé avec uid = {}", resourceRole.getUser().getUid());
        }

        final Optional<Resource> foundResourceOpt = resourceRepository.findById(resourceRole.getResource().getId());
        if (foundResourceOpt.isEmpty()) {
            LOGGER.warn("Pas de ressource trouvée avec id = {}", resourceRole.getResource());
            return false;
        }
        final Resource resource = foundResourceOpt.get();

        final Role consoleRole = roleRepository.findById(resourceRole.getRole().getId()).orElse(null);
        if (consoleRole == null) {
            LOGGER.warn("Pas de rôle trouvée");
            return false;
        }

        final Long iaasAreaId = resource.getResourceRegions().stream().findFirst().get().getRegion().getId();
        final Region iaasArea;
        if (iaasAreaId != null) {
            iaasArea = regionRepository.findById(iaasAreaId).orElse(null);
            if (iaasArea == null) {
                LOGGER.warn("Pas de région IAAS trouvée");
            }
        } else {
            LOGGER.warn("L'id de la région IAAS est nul => On doit donc se trouver dans le cas S3");
            iaasArea = null;
        }

        final List<Region> regions = resource.getResourceRegions().stream().map(ResourceRegion::getRegion).toList();
        final Context ctx = initContext();
        ctx.setVariable("user", person);
        ctx.setVariable("s3", resource);
        ctx.setVariable("role", consoleRole);
        ctx.setVariable("regionLabel", (iaasArea == null ? "" : iaasArea.getLabel()));
        ctx.setVariable("regions", regions);

        LOGGER.info("regions: {}", regions);

        try {
            emailService.sendThymeleafTemplatedMessageWithAttachment(person.getMail(),
                    "[Console Cloud π] Ajout de rôle stockage S3 sur %s".formatted(resource.getName()),
                    "you-are-granted-notification-member-s3.html",
                    ctx,
                    "user.osrc.txt");
            return true;
        } catch (final IOException | MessagingException | MailAuthenticationException exception) {
            LOGGER.error("Erreur lors de l'envoi de l'email de notification : %s".formatted(exception.getMessage()), exception);
            throw exception;
        }
    }

    //// Getters & Setters :

    public String getDashboardUrlByRegionName(final String regionName) {
        return this.environment.getProperty("console.api.email.openstack.dashboard." + regionName + ".url");
    }

    public String getAlertEmail(final boolean withCc) {
        return this.environment.getProperty("console.api.project.workflow.email.alert-ssi-pi" + (!withCc ? "" : "-cc"));
    }
    @Autowired
    public void setProjectRepository(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }
    @Autowired
    public void setRegionRepository(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }
    @Autowired
    public void setZoneRepository(ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }

    @Autowired
    public void setEmailService(final EmailService emailService) {
        this.emailService = emailService;
    }

    @Autowired
    public void setUserController(final UserController userController) {
        this.userController = userController;
    }

    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
    @Autowired
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }
    @Autowired
    public void setResourceRepository(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }
    @Autowired
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
}
