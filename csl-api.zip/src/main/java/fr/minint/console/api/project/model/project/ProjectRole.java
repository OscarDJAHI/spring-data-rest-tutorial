package fr.minint.console.api.project.model.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.api.project.model.RoleAssignment;
import fr.minint.console.api.project.model.User;
import fr.minint.console.library.bean.HasRIO;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table
public class ProjectRole extends AbstractDAOBean<Long> implements RoleAssignment, ToJSON, HasRIO {
    @Id
    private Long id;
    @JsonProperty("userId")
    private String uid;
    @JsonProperty("projectId")
    private Long project;
    @JsonProperty("roleId")
    private Long role;
    @JsonProperty("serviceAccountId")
    private Long serviceAccount;
    private boolean isSynchronized;

    @Transient
    private User user;

    @Transient
    private String roleName;


    ///// Constructeur(s) :

    public ProjectRole(final Long id,
                       final String uid,
                       final Long project,
                       final Long role,
                       final Long serviceAccount,
                       final Boolean isSynchronized) {
        this.id = id;
        this.uid = uid;
        this.project = project;
        this.role = role;
        this.serviceAccount = serviceAccount;
        this.isSynchronized = (isSynchronized != null && isSynchronized);
    }

    public ProjectRole(final String uid, final Long project, final Long role) {
        this(null, uid, project, role, null, true);
    }

    public ProjectRole() {
        this(null, null, null);
    }

    ///// Interface ToJSON

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonProjectRole = new JSONObject();
        jsonProjectRole.put("id", getJSONValueOrNull(this.id));
        jsonProjectRole.put("userId", getJSONValueOrNull(this.uid));
        jsonProjectRole.put("projectId", getJSONValueOrNull(this.project));
        jsonProjectRole.put("roleId", getJSONValueOrNull(this.role));
        jsonProjectRole.put("serviceAccountId", getJSONValueOrNull(this.serviceAccount));
        jsonProjectRole.put("isSynchronized", this.isSynchronized);
        jsonProjectRole.put("user", (user == null ? new JSONObject() : user.toJSON()));
        return jsonProjectRole;
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        if (this.serviceAccount != null) {
            return Objects.hash(this.project, this.role, this.serviceAccount);
        } else {
            return Objects.hash(this.project, this.role, this.uid);
        }
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        ProjectRole theProjectRole = (ProjectRole) that;
        boolean isOK = Objects.equals(this.project, theProjectRole.project);
        isOK = isOK && Objects.equals(this.role, theProjectRole.role);
        if (this.serviceAccount != null) {
            isOK = isOK && Objects.equals(this.serviceAccount, theProjectRole.serviceAccount);
        } else {
            isOK = isOK && Objects.equals(this.uid, theProjectRole.uid);
        }
        return isOK;
    }

    @Override
    public String getUserUid() {
        return this.getUid();
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(final String uid) {
        this.uid = uid;
    }

    public Long getProject() {
        return project;
    }

    public void setProject(final Long project) {
        this.project = project;
    }

    public Long getRole() {
        return role;
    }

    public void setRole(final Long role) {
        this.role = role;
    }

    @Deprecated
    public Long getServiceAccount() {
        return serviceAccount;
    }

    @Deprecated
    public void setServiceAccount(final Long serviceAccount) {
        this.serviceAccount = serviceAccount;
    }

    @JsonIgnore
    @Override
    public Long getServiceAccountId() {
        return this.serviceAccount;
    }

    public void setServiceAccountId(final Long serviceAccount) {
        this.serviceAccount = serviceAccount;
    }

    public boolean isServiceAccount() {
        return (this.serviceAccount != null);
    }

    public void setSynchronized(boolean isSynchronized) {
        this.isSynchronized = isSynchronized;
    }

    public boolean isSynchronized() {
        return isSynchronized;
    }

    public void setSynchronized(final Boolean isSynchronized) {
        this.isSynchronized = (isSynchronized != null && isSynchronized);
    }

    @Override
    public Long getTargetKey() {
        return project;
    }

    @Override
    public void setTargetKey(final Long targetKey) {
        project = targetKey;
    }

    public User getUser() {
        return user;
    }

    public void setUser(final User user) {
        this.user = user;
        this.uid = (user == null ? null : user.getRio());
    }

    public void setRoleName(final String roleName) {
        this.roleName = roleName;
    }

    public String getRoleName() {
        return roleName;
    }
}
