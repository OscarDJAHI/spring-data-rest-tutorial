package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.entities.RoleAssignement;
import fr.minint.console.api.project.model.resource.ResourceRole;
import fr.minint.console.api.project.service.EmailNotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;
import java.util.concurrent.ExecutorService;

@SuppressWarnings("OptionalIsPresent")
public class EmailDecorator extends ResourceRoleServiceDecorator {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailDecorator.class);
    private EmailNotificationService emailNotificationService;
    private ExecutorService executorService;

    public EmailDecorator(final ResourceRoleService source) {
        super(source);
    }

    @Override
    public void delete(RoleAssignement resourceRole) {
        super.delete(resourceRole);
        this.executorService.submit(() -> {
            try {
                emailNotificationService.sendResourceRoleDeletionNotification(resourceRole);
            } catch (final Exception exception) {
                LOGGER.error("Erreur de l'envoi de l'email de notification de suppression de rôle : %s".formatted(exception.getMessage()), exception);
            }
        });
    }

    @Override
    public void delete(Long id) {
        final Optional<RoleAssignement> resourceRole = super.get(id);
        if (resourceRole.isPresent()) {
            this.delete(resourceRole.get());
        }
    }

    ///// Getters & Setters :

    public void setEmailNotificationService(final EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }

    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }
}
