package fr.minint.console.api.project.service;

import fr.minint.console.api.project.entities.*;
import org.springframework.stereotype.Service;

@Service
public class BastionAccessService {
    private String baseName;

    public BastionAccessService() {
        this.baseName = "bastion";
    }

    public BastionAccessService(String baseName) {
        this.baseName = baseName;
    }

    public String getBastionAccessPosixGroupName(Region region, Zone zone) {
        return "%s-%s-%s".formatted(baseName, region.getName(), zone.getName());
    }
}
