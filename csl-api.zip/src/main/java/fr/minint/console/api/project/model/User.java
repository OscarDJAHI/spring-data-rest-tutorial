package fr.minint.console.api.project.model;

import fr.minint.console.library.bean.HasRIO;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;
import java.util.StringTokenizer;

import static java.time.Instant.now;
import static org.apache.commons.lang3.StringUtils.isEmpty;


@Table
public class User extends AbstractDAOBean<Long> implements HasRIO, ToJSON {
    @Id
    private Long id;
    private String rio;
    private String lastName;
    private String firstName;
    private String email;
    private Boolean isServiceAccount;
    private Instant createdAt;
    private Instant updatedAt;

    public User(final Long id,
                final String rio,
                final String lastName,
                final String firstName,
                final String email,
                final Boolean isServiceAccount,
                final Instant createdAt,
                final Instant updatedAt) {
        this.id = id;
        this.rio = rio;
        this.lastName = lastName;
        this.firstName = firstName;
        this.email = email;
        this.isServiceAccount = (isServiceAccount != null && isServiceAccount);
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public User(final Long id, String rio, String firstName, String lastName, String email, final Boolean isServiceAccount) {
        this(id, rio, lastName, firstName, email, isServiceAccount, now(), now());
    }

    public User(final String rio, final String firstName, final String lastName, final String email, final Boolean isServiceAccount) {
        this(null, rio, firstName, lastName, email, isServiceAccount);
    }

    public User(final String rio, final String firstName, final String lastName, final String email) {
        this(rio, firstName, lastName, email, false);
    }

    public User() {
        this(null, null, null, null, false);
    }

    /////

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonUtilisateur = new JSONObject();
        jsonUtilisateur.put("id", getJSONValueOrNull(this.id));
        jsonUtilisateur.put("rio", getJSONValueOrNull(this.rio));
        jsonUtilisateur.put("lastName", getJSONValueOrNull(this.lastName));
        jsonUtilisateur.put("firstName", getJSONValueOrNull(this.firstName));
        jsonUtilisateur.put("email", getJSONValueOrNull(this.email));
        jsonUtilisateur.put("createdAt", getJSONValueOrNull(this.createdAt));
        jsonUtilisateur.put("updatedAt", getJSONValueOrNull(this.updatedAt));
        jsonUtilisateur.put("isServiceAccount", (this.isServiceAccount != null && this.isServiceAccount));
        return jsonUtilisateur;
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.rio);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.getRio(), ((User) that).getRio());
    }

    ///// Interface RIO :

    @Override
    public String getUserUid() {
        return this.getRio();
    }

    ///// Getters & Setters :

    public void setId(final Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setRio(final String rio) {
        this.rio = rio;
    }

    public String getRio() {
        return this.rio;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setEmail(final String email) {
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    public void setIsServiceAccount(final Boolean isServiceAccount) {
        this.isServiceAccount = (isServiceAccount != null && isServiceAccount);
    }

    public Boolean getIsServiceAccount() {
        return this.isServiceAccount;
    }

    public Instant getCreatedAt() {
        return this.createdAt;
    }

    public void setCreatedAt(final Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return this.updatedAt;
    }

    public void setUpdatedAt(final Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setCn(final String displayName) {
        String firstName = null;
        String lastName = null;
        if (!isEmpty(displayName)) {
            final StringTokenizer tokenizer = new StringTokenizer(displayName, " ");
            final int nbTokens = tokenizer.countTokens();
            if (nbTokens == 2) {
                this.setFirstName(tokenizer.nextToken().toLowerCase());
                this.setLastName(tokenizer.nextToken().toLowerCase());
            } else {
                String nextToken;
                for (int i = 0; i < nbTokens; i++) {
                    nextToken = tokenizer.nextToken();
                    if (i == 0) {
                        firstName = nextToken.toLowerCase();
                    } else if (i == nbTokens - 2) {
                        lastName = nextToken.toLowerCase();
                        break;
                    }
                }
                this.setFirstName(firstName);
                this.setLastName(lastName);
            }
        }
    }
}
