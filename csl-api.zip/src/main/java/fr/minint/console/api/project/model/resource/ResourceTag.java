package fr.minint.console.api.project.model.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.json.JSONObject;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table
public class ResourceTag extends AbstractDAOBean<Long> implements ToJSON {

    @Id
    private Long id;

    @JsonProperty("tagId")
    private Long tag;

    @JsonProperty("resourceId")
    private Long resource;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    ///// Constructeurs :

    public ResourceTag(final Long id,
                       final Long resourceId,
                       final Long tagId) {
        this.id = id;
        this.resource = resourceId;
        this.tag = tagId;
    }


    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.tag, this.resource);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final ResourceTag tag = (ResourceTag) that;
        boolean areOK = Objects.equals(this.tag, tag.tag);
        areOK = areOK && Objects.equals(this.resource, tag.resource);
        return areOK;
    }

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonTag = new JSONObject();
        jsonTag.put("id", this.getId());
        jsonTag.put("tagId", this.getTag());
        jsonTag.put("resourceId", this.getResource());
        jsonTag.put("createdAt", this.getCreatedAt());
        jsonTag.put("updatedAt", this.getUpdatedAt());
        return jsonTag;
    }
}
