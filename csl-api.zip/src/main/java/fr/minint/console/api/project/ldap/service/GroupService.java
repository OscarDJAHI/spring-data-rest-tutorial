package fr.minint.console.api.project.ldap.service;

import fr.minint.console.api.project.ldap.model.Group;

import java.util.List;
import java.util.Optional;

public interface GroupService {
    List<Group> list();

    Optional<Group> get(String cn);

    Optional<Group> update(Group group);

    void addToSubscriberGroup(String userUid);

    void addToDesignerGroup(String userUid);

    void addToManagerGroup(String uid);

    void addToGroup(String userUid, String groupCn);
}
