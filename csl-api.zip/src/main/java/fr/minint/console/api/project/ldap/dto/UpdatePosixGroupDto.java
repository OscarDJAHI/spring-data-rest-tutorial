package fr.minint.console.api.project.ldap.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.ldap.support.LdapUtils;

import javax.naming.Name;
import java.util.Set;

@Data
public class UpdatePosixGroupDto {
    Name dn;
    String cn;
    String gidNumber;
    Set<String> members;

    @JsonProperty("dn")
    public void setId(String id) {
        this.dn = LdapUtils.newLdapName(id);
    }

    @JsonProperty("dn")
    public String getId() {
        return dn.toString();
    }
}
