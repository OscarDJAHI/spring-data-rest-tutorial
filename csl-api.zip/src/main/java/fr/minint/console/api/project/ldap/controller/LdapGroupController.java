package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.model.Group;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.GroupService;
import fr.minint.console.api.project.ldap.service.LdapGroupService;
import fr.minint.console.api.project.ldap.service.UserService;
import fr.minint.console.persistence.dao.DAO;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
public class LdapGroupController {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapGroupController.class);
    static final Logger ERROR_LDAP_EMAIL_LOGGER = LoggerFactory.getLogger("errorLdapLogger");
    private LdapGroupService ldapGroupService;
    private GroupService groupService;
    private UserService userService;

    // Définition des DAO's :
    private DAO<PosixGroup> posixGroupDAO;

    ///// Méthodes privées :

    private void addToPosixGroups(final String userUid) throws Exception {
        if (isEmpty(userUid)) {
            return;
        }
        final Set<PosixGroup> posixGroupsToSave = new HashSet<>();
        for (PosixGroup posixGroup : this.posixGroupDAO.selectAll()) {
            posixGroup.addMember(userUid);
            posixGroupsToSave.add(posixGroup);
        }

        // Sauvegarde des groupes POSIX :
        this.posixGroupDAO.save(posixGroupsToSave);
    }


    ///// Définition des "end-points"

    @GetMapping("/api/ldap/groups")
    @ResponseStatus(OK)
    public List<Group> list() {
        return ldapGroupService.list();
    }

    @GetMapping("/api/ldap/groups/{cn}")
    public Optional<Group> get(@PathVariable String cn) {
        return ldapGroupService.get(cn);
    }

    @PutMapping("/api/ldap/groups")
    @ResponseStatus(OK)
    public Optional<Group> update(@RequestBody Group updateGroup) {
        return ldapGroupService.update(updateGroup);
    }

    @PutMapping("/api/ldap/groups/subscribers/add/{userUid}")
    public void addSubscriber(@PathVariable() String userUid) {
        groupService.addToSubscriberGroup(userUid);
    }

    @PutMapping("/api/ldap/groups/subscribers/add/byMail")
    public ResponseEntity<String> addSubscriberFromEmail(@RequestBody final String userEmail) {
        if (isEmpty(userEmail)) {
            throw new ResponseStatusException(BAD_REQUEST, "Email vide passé en paramètre");
        }
        final Optional<LdapUser> foundUser = this.userService.findLDAPUserByEmail(userEmail);
        if (foundUser.isEmpty()) {
            throw new ResponseStatusException(BAD_REQUEST, "Pas d'utilisateur trouvé avec cet email");
        }
        final LdapUser ldapUser = foundUser.get();
        this.addSubscriber(ldapUser.getUid());
        return ok("Utilisateur ajouté");
    }

    @PutMapping("/api/ldap/groups/subscribers/add/byMail/fromList")
    public ResponseEntity<String> addSubscriberFromEmailList(@RequestBody final List<String> emails) {
        if (emails == null || emails.isEmpty()) {
            LOGGER.error("La liste des emails passée en paramètre est soit vide soit nulle");
            throw new ResponseStatusException(BAD_REQUEST, "La liste des emails passée en paramètre est soit vide soit nulle");
        }
        final JSONArray addedEmails = new JSONArray();
        final JSONArray errorEmails = new JSONArray();
        ResponseEntity<String> httpResponse;
        for (String email : new HashSet<>(emails)) {
            if (isEmpty(email)) {
                continue;
            }
            try {
                httpResponse = this.addSubscriberFromEmail(email);
            } catch (final ResponseStatusException responseStatusException) {
                LOGGER.error(responseStatusException.getReason(), responseStatusException);
                ERROR_LDAP_EMAIL_LOGGER.info(email);
                errorEmails.put(email);
                continue;
            }
            if (httpResponse.getStatusCode() != OK) {
                LOGGER.error("Erreur lors de l'ajout du souscripteur LDAP : {}", httpResponse.getBody());
                ERROR_LDAP_EMAIL_LOGGER.info(email);
                errorEmails.put(email);
            } else {
                addedEmails.put(email);
            }
        }

        // Création de la réponse :
        final JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("emailsAdded", addedEmails);
        jsonResponse.put("emailsInError", errorEmails);
        return ok(jsonResponse.toString());
    }

    @PutMapping("/api/ldap/groups/editors/add/{userUid}")
    public void addDesigner(@PathVariable() final String userUid) {
        if (isEmpty(userUid) || isBlank(userUid)) {
            LOGGER.info("Pas de paramètre userUid => on ne fait rien");
            return;
        }
        try {
            this.addToPosixGroups(userUid);
            groupService.addToDesignerGroup(userUid);
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @PutMapping("/api/ldap/groups/managers/add/{userUid}")
    public void addManager(@PathVariable() final String userUid) {
        if (isEmpty(userUid) || isBlank(userUid)) {
            LOGGER.info("Pas de paramètre userUid => on ne fait rien");
            return;
        }
        try {
            this.addToPosixGroups(userUid);
            groupService.addToManagerGroup(userUid);
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    ///// Getters & Setters :

    @Autowired
    public void setLdapGroupService(final LdapGroupService ldapGroupService) {
        this.ldapGroupService = ldapGroupService;
    }

    @Autowired
    public void setGroupService(final GroupService groupService) {
        this.groupService = groupService;
    }

    @Autowired
    public void setUserService(final UserService userService) {
        this.userService = userService;
    }

    @Autowired
    public void setPosixGroupDAO(@Qualifier("posixGroupDAO") final DAO<PosixGroup> posixGroupDAO) {
        this.posixGroupDAO = posixGroupDAO;
    }

    public DAO<PosixGroup> getPosixGroupDAO() {
        return posixGroupDAO;
    }
}
