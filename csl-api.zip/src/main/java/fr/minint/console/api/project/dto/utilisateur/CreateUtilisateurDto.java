package fr.minint.console.api.project.dto.utilisateur;

import lombok.*;

import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateUtilisateurDto {

    @NotEmpty String nom;
    @NotEmpty String prenom;
    @NotEmpty String email;
    @NotEmpty String rio;
    @NotEmpty boolean isAccountService;

}
