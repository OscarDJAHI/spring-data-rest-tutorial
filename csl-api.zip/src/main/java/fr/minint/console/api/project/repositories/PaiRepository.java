package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Pai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface PaiRepository extends JpaRepository<Pai, Long>, JpaSpecificationExecutor<Pai> {
}
