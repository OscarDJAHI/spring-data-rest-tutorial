package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.model.Person;
import fr.minint.console.api.project.repository.ldap.PersonRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@Slf4j

@RestController
@RequestMapping("/api/ldap")
public class LdapController {

    @Autowired
    PersonRepository personRepository;

    @GetMapping("/search")
    Iterable<Person> search(@PathParam("uid") String uid) {
        return personRepository.findAll(query()
                        .base("ou=users")
//                 .searchScope(SearchScope.ONELEVEL)
//                .timeLimit(5000)
//                .where("objectclass").is("person")
                        .where("objectclass").is("inetOrgPerson")
                // .where("uid").like(uid)
        );
    }


}
