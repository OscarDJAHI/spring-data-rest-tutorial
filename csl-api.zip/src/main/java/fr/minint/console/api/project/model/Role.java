package fr.minint.console.api.project.model;

import fr.minint.console.library.bean.HasId;
import fr.minint.console.library.bean.HasName;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table
public class Role extends AbstractDAOBean<Long> implements HasId<Long>, HasName, ToJSON {
    public static final String RSSI_ROLE_NAME = "rssi";
    public static final String DELEGUE_ROLE_NAME = "delegue";
    public static final String SOUSCRIPTEUR_ROLE_NAME = "souscripteur";
    @Id
    private Long id;
    private String name;
    private String label;
    private String color;
    private String description;
    private boolean enabled;
    private String ldapGroupRdn;

    ///// Constructeur(s) :

    public Role(final Long id,
                final String name,
                final String label,
                final String color,
                final String description,
                final boolean enabled,
                final String ldapGroupRdn) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.color = color;
        this.description = description;
        this.enabled = enabled;
        this.ldapGroupRdn = ldapGroupRdn;
    }

    public Role(final Long id, final String name) {
        this.id = id;
        this.name = name;
    }

    public Role() {
        this(null, null);
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.name);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.name, ((Role) that).name);
    }

    ///// Méthode(s)

    public String toString() {
        return "Role[id = %d, name = '%s']"
                .formatted(this.id, this.name);
    }

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", this.getId());
        jsonObject.put("name", this.getName());
        jsonObject.put("label", this.getLabel());
        jsonObject.put("color", this.getColor());
        jsonObject.put("description", this.getDescription());
        jsonObject.put("enabled", this.isEnabled());
        jsonObject.put("ldap_group_rnd", this.getLdapGroupRdn());
        return jsonObject;
    }

    ///// Getters & Setters :


    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }

    public String getLdapGroupRdn() {
        return ldapGroupRdn;
    }

    public void setLdapGroupRdn(final String ldapGroupRdn) {
        this.ldapGroupRdn = ldapGroupRdn;
    }
}
