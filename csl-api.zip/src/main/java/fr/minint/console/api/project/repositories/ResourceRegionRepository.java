package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.ResourceRegion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Collection;
import java.util.List;

public interface ResourceRegionRepository extends JpaRepository<ResourceRegion, Long>, JpaSpecificationExecutor<ResourceRegion> {
    Collection<ResourceRegion> findByRegionIdIn(List<Long> s3AreaIds);
}
