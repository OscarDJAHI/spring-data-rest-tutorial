package fr.minint.console.api.project.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.bytebuddy.asm.Advice;

import javax.persistence.*;
import java.sql.Timestamp;

import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class History {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private long id;

    @Basic
    @Column(name = "action",  length = -1)
    private String action;

    @Basic
    @Column(name = "ancienne_valeur", length = -1)
    private String ancienneValeur;

    @Basic
    @Column(name = "nouvelle_valeur",  length = -1)
    private String nouvelleValeur;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_by",  length = -1)
    private String updatedBy;

    @Basic
    @Column(name = "modified_table",  length = -1)
    private String modifiedTable;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    public History(long id, String action, String ancienneValeur, String nouvelleValeur, String modifiedTable, String updatedBy) {
        this.id = id;
        this.action = action;
        this.ancienneValeur = ancienneValeur;
        this.nouvelleValeur = nouvelleValeur;
        this.modifiedTable = modifiedTable;
        this.updatedBy = updatedBy;
        this.modifiedTable = modifiedTable;
    }


    public History(String action, String ancienneValeur, String name, String table, String userId) {
         this.action = action;
         this.ancienneValeur = ancienneValeur;
         this.nouvelleValeur = name;
         this.updatedBy = userId;
         this.modifiedTable = table;

    }
}
