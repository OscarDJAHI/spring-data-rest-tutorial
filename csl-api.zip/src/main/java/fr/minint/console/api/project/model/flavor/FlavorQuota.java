package fr.minint.console.api.project.model.flavor;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Table
public class FlavorQuota extends AbstractDAOBean<Long> implements ToJSON, Copyable<FlavorQuota> {
    @Id
    private Long id;
    private Long quotaValue;

    @JsonProperty("quotaTypeId")
    private Long quotaType;
    @JsonProperty("flavorId")
    private Long flavor;

    // Champs transient :

    @Transient
    private QuotaType quotaTypeBean;

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.quotaType, this.flavor);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final FlavorQuota flavorQuota = (FlavorQuota) that;
        boolean areEquals = Objects.equals(this.quotaType, flavorQuota.quotaType);
        areEquals = areEquals && Objects.equals(this.flavor, flavorQuota.flavor);
        return areEquals;
    }

    ///// Méthodes de l'interface ToJSON

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonQuotaValue = new JSONObject();
        jsonQuotaValue.put("id", this.id);
        jsonQuotaValue.put("quotaValue", this.quotaValue);
        jsonQuotaValue.put("quotaTypeId", this.quotaType);
        jsonQuotaValue.put("flavorId", this.flavor);
        return jsonQuotaValue;
    }

    @Override
    public FlavorQuota copy() {
        final FlavorQuota flavorQuota = new FlavorQuota();
        flavorQuota.setId(this.id);
        flavorQuota.setQuotaType(this.quotaType);
        flavorQuota.setQuotaValue(this.quotaValue);
        flavorQuota.setFlavor(this.flavor);
        return flavorQuota;
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public Long getQuotaValue() {
        return quotaValue;
    }

    public void setQuotaValue(final Long quotaValue) {
        this.quotaValue = quotaValue;
    }

    public Long getQuotaType() {
        return quotaType;
    }

    public void setQuotaType(final Long quotaType) {
        this.quotaType = quotaType;
    }

    public Long getFlavor() {
        return flavor;
    }

    public void setFlavor(final Long flavor) {
        this.flavor = flavor;
    }

    @Transient
    public QuotaType getQuotaTypeBean() {
        return quotaTypeBean;
    }

    @Transient
    public void setQuotaTypeBean(final QuotaType quotaTypeBean) {
        this.quotaTypeBean = quotaTypeBean;
        this.quotaType = (quotaTypeBean == null ? null : quotaTypeBean.getId());
    }
}
