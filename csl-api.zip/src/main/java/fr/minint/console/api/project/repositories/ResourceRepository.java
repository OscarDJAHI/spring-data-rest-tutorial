package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Resource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Long>, JpaSpecificationExecutor<Resource> {
    List<Resource> findByProjectIdAndResourceTypeId(Long projectId, Long resourceTypeId);

    List<Resource> findAllByProject(Long projectId);


    Boolean existsByNameAndResourceTypeId(String resourceName, Long ResourceTypeId);

    boolean existsByIdAndProjectId(Long resourceId, Long projectId);
}
