package fr.minint.console.api.project.utils;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import static java.util.Collections.singletonList;

public class RestUtils {

    public RestUtils() {
        // EMPTY
    }


    public static HttpHeaders createHttpHeaders(final MediaType mediaType) {
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);
        headers.setAccept(singletonList(mediaType));
        return headers;
    }
}
