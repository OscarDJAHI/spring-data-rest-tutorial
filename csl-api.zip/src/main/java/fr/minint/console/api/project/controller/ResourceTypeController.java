package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.ResourceType;
import fr.minint.console.api.project.repositories.ResourceTypeRepository;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("/resource-types")
@Setter(onMethod = @__(@Autowired))
public class ResourceTypeController {
    private ResourceTypeRepository resourceTypeRepository;

    @Autowired
    private void setResourceTypeRepository(ResourceTypeRepository resourceTypeRepository) {
        this.resourceTypeRepository = resourceTypeRepository;
    }

    @ExceptionHandler(ResponseStatusException.class)
    Map<String, String> handleHttpExceptions(ResponseStatusException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("code", Integer.toString(ex.getStatus().value()));
        errors.put("status", ex.getStatus().getReasonPhrase());
        errors.put("reason", ex.getReason());
        return errors;
    }

    @GetMapping
    public Iterable<ResourceType> list() {
        return resourceTypeRepository.findAll();
    }

    @GetMapping("/{resource_type_id}")
    public ResourceType get(@PathVariable("resource_type_id") Long id) {
        Optional<ResourceType> optionalResourceType = resourceTypeRepository.findById(id);

        if (optionalResourceType.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Resource type not found");
        }
        return optionalResourceType.get();
    }
}
