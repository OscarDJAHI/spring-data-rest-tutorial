package fr.minint.console.api.project.service;


import fr.minint.console.api.project.entities.*;

import java.util.List;

public interface ResourceQuotaService {
    List<String> getSkippedQuotas();
    boolean isSkipped(ResourceQuota resourceQuota);
}
