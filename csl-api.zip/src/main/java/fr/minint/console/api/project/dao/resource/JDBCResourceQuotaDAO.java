package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.dao.quota.JDBCQuotaTypeDAO.ResultSetQuotaTypeTranscoder;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.resource.ResourceQuota;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;

public class JDBCResourceQuotaDAO extends AbstractJDBCDAO<Long, ResourceQuota> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCResourceQuotaDAO.class);
    private static final Transcoder<ResultSet, ResourceQuota> RESULT_SET_RESOURCE_QUOTA_TRANSCODER = new ResultSetResourceQuotaTranscoder();
    private static final Transcoder<ResultSet, QuotaType> RESULT_SET_QUOTA_TYPE_TRANSCODER = new ResultSetQuotaTypeTranscoder();

    ///// Constructeurs :

    public JDBCResourceQuotaDAO(final DataSource dataSource) {
        super(dataSource, "resource_quota", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_RESOURCE_QUOTA_TRANSCODER);
    }

    ///// Définition des requêtes SQL :

    @Override
    public String getSelectAllQuery() {
        return "SELECT resQuota.id AS res_quota_id," +
                "   resQuota.quota_type AS res_quota_type_id," +
                "   resQuota.resource AS res_quota_resource_id," +
                "   resQuota.quota_value AS res_quota_value," +
                "   resQuota.created_at AS res_quota_created_at," +
                "   resQuota.updated_at AS res_quota_updated_at," +
                "   quotaType.id AS quota_type_id," +
                "   quotaType.\"name\" AS quota_type_name," +
                "   quotaType.\"label\" AS quota_type_label," +
                "   quotaType.quota_icon AS quota_type_icon," +
                "   quotaType.quota_min AS quota_type_min," +
                "   quotaType.quota_max AS quota_type_max," +
                "   quotaType.quota_default AS quota_type_default," +
                "   quotaType.quota_unit AS quota_type_unit," +
                "   quotaType.resource_type AS quota_type_resource_type_id," +
                "   quotaType.priority AS quota_type_priority, " +
                "   quotaPricing.id AS quota_pricing_id, " +
                "   quotaPricing.quota_unit AS quota_pricing_quota_unit, " +
                "   quotaPricing.monthly_price AS quota_pricing_monthly_price, " +
                "   quotaPricing.yearly_price AS quota_pricing_yearly_price " +
                " FROM " + this.tableName + " AS resQuota  " +
                "  LEFT JOIN quota_type AS quotaType ON (quotaType.id = resQuota.quota_type)" +
                "  LEFT JOIN quota_pricing AS quotaPricing ON (quotaPricing.quota_type = quotaType.id)";
    }

    @Override
    protected String getInsertQuery(final ResourceQuota resourceQuota) throws Exception {
        if (resourceQuota == null) {
            throw new Exception("L'instance de ResourceQuota est nulle --> On ne peut pas créer la requête d'insertion");
        }
        return "INSERT INTO resource_quota " +
                "(quota_type, resource, quota_value, created_at, updated_at) " +
                " VALUES (%d, %d, %d, now(), now())"
                        .formatted(resourceQuota.getQuotaType(),
                                resourceQuota.getResource(),
                                resourceQuota.getQuotaValue());
    }

    @Override
    protected String getUpdateQuery(final ResourceQuota resourceQuota) throws Exception {
        if (resourceQuota == null) {
            throw new Exception("L'instance de ResourceQuota est nulle --> On ne peut pas créer la requête de mise à jour");
        }
        return "UPDATE resource_quota " +
                "SET quota_type=%d, resource=%d, quota_value=%d, updated_at=now() WHERE id=%d"
                        .formatted(resourceQuota.getQuotaType(),
                                resourceQuota.getResource(),
                                resourceQuota.getQuotaValue(),
                                resourceQuota.getId());
    }

    ///// Méthodes de l'interface DAO :

    @Override
    protected List<ResourceQuota> selectFromQuery(final String selectQuery) throws Exception {
        final Set<ResourceQuota> resourceQuotas = new HashSet<>();
        final Connection connection = this.getConnection();
        PreparedStatement preparedStatement = null;
        ResourceQuota resourceQuota;
        try {
            //noinspection SqlSourceToSinkFlow
            preparedStatement = connection.prepareStatement(selectQuery);
            final ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                resourceQuota = RESULT_SET_RESOURCE_QUOTA_TRANSCODER.transcode(resultSet);
                resourceQuotas.remove(resourceQuota);
                resourceQuota.setQuotaTypeBean(RESULT_SET_QUOTA_TYPE_TRANSCODER.transcode(resultSet));
                resourceQuotas.add(resourceQuota);
            }
            return new ArrayList<>(resourceQuotas);
        } finally {
            closeQuietly(preparedStatement, LOGGER);
            closeQuietly(connection, LOGGER);
        }
    }

    ///// Classe(s) statique(s) :

    private static class ResultSetResourceQuotaTranscoder extends AbstractResultSetTranscoder<ResourceQuota> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "res_quota_id") == null);
            return isNull;
        }

        @Override
        protected ResourceQuota doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceQuota resourceQuota = new ResourceQuota();
            resourceQuota.setId(processLongValue(resultSet, "res_quota_id"));
            resourceQuota.setResource(processLongValue(resultSet, "res_quota_resource_id"));
            resourceQuota.setQuotaValue(processLongValue(resultSet, "res_quota_value"));
            return resourceQuota;
        }
    }

}
