package fr.minint.console.api.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.data.jdbc.repository.config.EnableJdbcAuditing;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import org.springframework.data.ldap.repository.config.EnableLdapRepositories;

@SpringBootApplication(exclude = LiquibaseAutoConfiguration.class)
@EnableJdbcRepositories(basePackages = {"fr.minint.console.api.project.repository.jdbc"})
@EnableLdapRepositories(basePackages = {"fr.minint.console.api.project.repository.ldap"})
@EnableJdbcAuditing
public class ConsoleApiProjectApplication {

    public static void main(final String[] args) {
        SpringApplication.run(ConsoleApiProjectApplication.class, args);
    }

}
