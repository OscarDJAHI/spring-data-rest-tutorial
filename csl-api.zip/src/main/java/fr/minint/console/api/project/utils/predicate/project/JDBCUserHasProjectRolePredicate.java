package fr.minint.console.api.project.utils.predicate.project;

import fr.minint.console.api.project.model.HasProject;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.persistence.dao.sql.predicate.AbstractJDBCPredicate;

import java.util.function.Predicate;

import static fr.minint.console.library.utils.predicate.BeanFieldPredicate.withFieldEqualTo;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * Prédicat permettant de tester si un utilisateur
 * possède un rôle au niveau du projet. <br />
 * Ce prédicat est, par exemple, utilisé afin de tester si un utilisateur est souscripteur délégué. <br />
 * </p>
 */
public class JDBCUserHasProjectRolePredicate<B extends HasProject> extends AbstractJDBCPredicate<B> {
    private final Role role;
    private final String userUid;

    ///// Constructeurs :

    private JDBCUserHasProjectRolePredicate(final String sqlPrefix, final String userUid, final Role role) {
        super(sqlPrefix);
        this.role = role;
        this.userUid = userUid;
    }

    ///// Méthodes des interfaces JDBCPredicate et Predicate :

    @Override
    public String whereClause() {
        final StringBuilder buffer = new StringBuilder();
        if (isEmpty(userUid)) {
            buffer.append(this.buildSQLFieldName("uid")).append(" IS NULL ");
        } else {
            buffer.append(this.buildSQLFieldName("uid")).append(" = '").append(userUid).append("' ");
        }
        if (role == null || role.getId() == null) {
            buffer.append("AND ").append(buildSQLFieldName("role")).append(" IS NULL");
        } else {
            buffer.append("AND ").append(buildSQLFieldName("role")).append(" = ").append(role.getId());
        }
        return buffer.toString();
    }

    @Override
    public boolean test(final B resource) {
        if (resource == null) {
            return false;
        }
        final Project project = resource.getProjectBean();
        if (project == null) {
            return false;
        }
        Predicate<ProjectRole> projRolePredicate = withFieldEqualTo(ProjectRole.class, "uid", userUid);
        projRolePredicate = projRolePredicate.and(withFieldEqualTo(ProjectRole.class, "role", (role == null ? null : role.getId())));
        return project
                .getProjectRoles()
                .stream()
                .anyMatch(projRolePredicate);
    }

    ///// Méthodes statiques :

    public static <U extends HasProject> JDBCUserHasProjectRolePredicate<U> withUserHavingProjectRole(final String sqlPrefix, final String uid, final Role role) {
        return new JDBCUserHasProjectRolePredicate<>(sqlPrefix, uid, role);
    }

    public static <U extends HasProject> JDBCUserHasProjectRolePredicate<U> withUserHavingProjectRole(final String uid, final Role role) {
        return withUserHavingProjectRole("projRole", uid, role);
    }


}
