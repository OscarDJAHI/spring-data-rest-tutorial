package fr.minint.console.api.project.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.minint.console.api.project.types.Category;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Collection;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static java.util.Collections.singleton;

@Table
public class ResourceType extends AbstractDAOBean<Long> implements Copyable<ResourceType> {
    @Id
    private Long id;
    private String name;
    private String label;
    private String category;
    private String color;
    private Set<QuotaType> quotaTypes;

    ///// Constructeur(s) :

    public ResourceType(final Long id,
                        final String name,
                        final String label,
                        final String category,
                        final String color,
                        final Set<QuotaType> quotaTypes) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.category = category;
        this.color = color;
        this.setQuotaTypes(quotaTypes);
    }

    public ResourceType(final Long id,
                        final String name,
                        final String label,
                        final String category) {
        this(id, name, label, category, null, new HashSet<>());
    }

    public ResourceType() {
        this(null, null, null, null);
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.name, ((ResourceType) that).name);
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.name);
    }

    @Override
    public ResourceType copy() {
        final ResourceType copiedResourceType = new ResourceType();
        copiedResourceType.setId(this.id);
        copiedResourceType.setName(this.name);
        copiedResourceType.setLabel(this.label);
        copiedResourceType.setCategory(this.category);
        copiedResourceType.setColor(this.color);
        copiedResourceType.setQuotaTypes(this.getQuotaTypes());
        return copiedResourceType;
    }

    ///// Méthode(s) générale(s) :

    public void addQuotaType(final QuotaType quotaType) {
        this.addQuotaTypes(singleton(quotaType));
    }

    public void addQuotaTypes(final Collection<? extends QuotaType> quotaTypes) {
        if (isCollectionEmpty(quotaTypes)) {
            return;
        }
        if (this.quotaTypes == null) {
            this.quotaTypes = new HashSet<>();
        }
        final Set<QuotaType> newQuotaTypes = Copyable.copy(quotaTypes);
        QuotaType copiedQuotaType;
        for (QuotaType newQuotaType : quotaTypes) {
            if (newQuotaType == null) {
                continue;
            }
            for (QuotaType quotaType : quotaTypes) {
                if (!newQuotaType.equals(quotaType)) {
                    continue;
                }
                newQuotaTypes.remove(quotaType);
                copiedQuotaType = Copyable.copy(newQuotaType);
                copiedQuotaType.setResourceType(this.id);
                newQuotaTypes.add(copiedQuotaType);
            }
        }
        this.quotaTypes = newQuotaTypes;
    }

    ///// Getters & Setters  :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
        if (this.quotaTypes == null) {
            this.quotaTypes = new HashSet<>();
        }
        for (QuotaType quotaType : this.quotaTypes) {
            quotaType.setResourceType(id);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(final String category) {
        this.category = category;
    }

    @JsonIgnore
    public Category getCategoryEnum() {
        return Category.fromName(this.category);
    }

    public String getColor() {
        return color;
    }

    public void setColor(final String color) {
        this.color = color;
    }

    public Set<QuotaType> getQuotaTypes() {
        if (quotaTypes == null) {
            this.quotaTypes = new HashSet<>();
        }
        return Copyable.copy(quotaTypes);
    }

    public void setQuotaTypes(final Set<QuotaType> quotaTypes) {
        this.quotaTypes = new HashSet<>();
        if (isCollectionEmpty(quotaTypes)) {
            return;
        }
        for (QuotaType quotaType : Copyable.copy(quotaTypes)) {
            quotaType.setResourceType(this.getId());
            this.quotaTypes.add(quotaType);
        }
    }


}
