package fr.minint.console.api.project.entities;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "quota_type", schema = "public", catalog = "ConsoleAdapation")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QuotaType {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", length = -1)
    private String name;

    @Basic
    @Column(name = "label", length = -1)
    private String label;

    @Basic
    @Column(name = "quota_icon", length = -1)
    private String quotaIcon;

    @Basic
    @Column(name = "quota_min")
    private Long quotaMin;

    @Basic
    @Column(name = "quota_max")
    private Long quotaMax;

    @Basic
    @Column(name = "quota_default")
    private Long quotaDefault;

    @Basic
    @Column(name = "quota_unit", length = -1)
    private String quotaUnit;

    @Basic
    @Column(name = "priority")
    private Long priority;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;



    public Boolean validate(final Long value) {
        return this.quotaMin <= value && value <= this.quotaMax;
    }
}
