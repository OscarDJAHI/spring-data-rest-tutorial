package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.controller.validator.project.ProjectRoleValidator;
import fr.minint.console.api.project.dto.resource.CreateResourceRoleDto;
import fr.minint.console.api.project.dto.resource.UpdateResourceRoleDto;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.UserService;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.*;
import fr.minint.console.api.project.service.iaas.NamespaceResourceService;
import fr.minint.console.api.project.service.iaas.TenantService;
import fr.minint.console.api.project.service.persistence.DefaultBDDResourceService;
import fr.minint.console.api.project.service.resource.role.ResourceRoleService;
import fr.minint.console.api.project.service.resource.role.ResourceRoleServiceFactory;
import fr.minint.console.api.project.types.Category;
import fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils;
import fr.minint.console.persistence.dao.DAO;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.concurrent.ExecutorService;

import static fr.minint.console.api.project.dao.ldap.LdapUserDAO.LdapUserRIOPredicate.withLdapUserRIO;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONArrayFromListOfMap;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONObject;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.springframework.http.HttpStatus.*;

@RestController
@RequestMapping(path = "/resource-roles", produces = MediaType.APPLICATION_JSON_VALUE)
@Setter(onMethod = @__(@Autowired))
public class ResourceRoleController extends AbstractRestController {
    private UserRepository userRepository;
    private ResourceServiceFactory resourceServiceFactory;
    private EmailNotificationService emailNotificationService;
    private ResourceRoleService resourceRoleService;
    private ResourceRoleServiceFactory resourceRoleServiceFactory;
    private UserService ldapUserService;
    private ResourceTypeRepository resourceTypeRepository;
    private ExecutorService executorService;
    private ProjectRepository projectRepository;
    private RoleRepository roleRepository;
    private ResourceRepository resourceRepository;
    private ServiceAccountRepository serviceAccountRepository;
    private RoleAssignementRepository roleAssignementRepository;

    private DAO<LdapUser> userDAO;


    private void tryToSendResourceRoleUpdateEmail(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                                  final UpdateResourceRoleDto updateResourceRoleDto) throws Exception {
        final KeycloakPrincipal<KeycloakSecurityContext> keycloakPrincipal = AuthenticationTokenUtils.getKeycloakPrincipal(keycloakAuthenticationToken);
        boolean isServiceAccountAssignment = (updateResourceRoleDto.getUserId() == null)
                && (updateResourceRoleDto.getServiceAccountId() != null);
        ServiceAccount serviceAccount = null;
        if (isServiceAccountAssignment) {
            serviceAccount = serviceAccountRepository.findById(updateResourceRoleDto.getServiceAccountId()).get();
        }

        boolean hasServiceAccount = serviceAccount != null;
        final Optional<Role> roleOptional = roleRepository.findById(updateResourceRoleDto.getRoleId());
        if (roleOptional.isEmpty()) {
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Role not found");
        }
        final Optional<Resource> resourceOptional = resourceRepository.findById(updateResourceRoleDto.getResourceId());
        if (resourceOptional.isEmpty()) {
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource not found");
        }

        // Envoi de l'email :
        final ServiceAccount theEmailServiceAccount = serviceAccount;
        this.executorService.submit(() -> {
            try {
                emailNotificationService.sendResourceRoleUpdateEmail(
                        keycloakPrincipal.getName(),
                        keycloakPrincipal.getKeycloakSecurityContext().getToken().getEmail(),
                        (hasServiceAccount ? theEmailServiceAccount.getUid() : updateResourceRoleDto.getUserId()),
                        (updateResourceRoleDto.isSynchronized() ? "gagné" : "perdu"),
                        roleOptional.get().getName(),
                        resourceOptional.get().getName()
                );
            } catch (final Exception exception) {
                DEFAULT_LOGGER.error("Failed to send resource role update email : %s".formatted(exception.getMessage()), exception);
            }
        });
    }

    private void checkRoleAssignmentAlreadyExists(RoleAssignement resourceRole) {
        final List<RoleAssignement> resourcRoles = roleAssignementRepository.findByResourceIdAndRoleId(
                resourceRole.getResource().getId(),
                resourceRole.getRole().getId());
        final List<RoleAssignement> foundRoleAssignements = resourcRoles.stream().filter(roleAssignement -> roleAssignement.getUser() != null ?
                roleAssignement.getUser().getId() == resourceRole.getUser().getId()
                : roleAssignement.getServiceAccount().getId() == resourceRole.getServiceAccount().getId()).toList();
         if (!foundRoleAssignements.isEmpty()) {
            throw new ResponseStatusException(FORBIDDEN, "Role assignment already exists");
        }
    }

    private void tryNotifyRoleAssignmentToTargetUser(final RoleAssignement resourceRole) throws Exception {
        final Optional<Resource> foundResourceOpt = resourceRepository.findById(resourceRole.getResource().getId());
        if (foundResourceOpt.isEmpty()) {
            throw new Exception("Pas de resource trouvée avec l'id = %d".formatted(resourceRole.getResource()));
        }
        final ResourceType resourceType = resourceTypeRepository.findById(foundResourceOpt.get().getResourceType().getId()).orElseThrow();
        if (!(resourceRole.getUser().getUid() != null && resourceRole.getIsSynchronized())) {
            DEFAULT_LOGGER.info("Pas de notification email demandée => on ne fait rien");
            return;
        }
        this.executorService.submit(() -> {
            try {
                switch (Category.valueOf(resourceType.getCategory().toUpperCase(Locale.ROOT))) {
                    case S3 -> emailNotificationService.sendResourceS3RoleCreationNotification(resourceRole);
                    case IAAS -> emailNotificationService.sendResourceRoleCreationNotification(resourceRole);
                }
            } catch (final Exception exception) {
                ResourceRoleController.this.getLogger().error(exception.getMessage(), exception);
            }
        });
    }

    /**
     * returnParameters.put("accessKeyId", generatedKeyPair.getLeft());
     * returnParameters.put("accessKeySecret", generatedKeyPair.getRight());
     *
     * @return réponse HTTP
     */
    Map<String, Object> addS3Member(final Map<String, Object> requestBody) {
        final StringBuilder errorMessageBuilder = new StringBuilder();
        boolean isOk = NOT_NULL_VALIDATOR.validate("requestBody", requestBody, errorMessageBuilder);
        isOk = REQUEST_BODY_VALIDATOR.validate("resourceId", requestBody, errorMessageBuilder) && isOk;
        isOk = REQUEST_BODY_VALIDATOR.validate("userId", requestBody, errorMessageBuilder) && isOk;
        isOk = REQUEST_BODY_VALIDATOR.validate("roleId", requestBody, errorMessageBuilder) && isOk;
        if (!isOk) {
            DEFAULT_LOGGER.error("ERREUR : {}", errorMessageBuilder);
            throw new ResponseStatusException(BAD_REQUEST, errorMessageBuilder.toString());
        }
        final Long namespaceId = (Long) requestBody.get("resourceId");
        final String memberLdapUid = (String) requestBody.get("userId");
        final Long roleId = (Long) requestBody.get("roleId");
        try {

            // Récupération du namespace :
            final Optional<Resource> resourceOptional = resourceRepository.findById(namespaceId);
            if (resourceOptional.isEmpty()) {
                throw new Exception("Pas de namespace trouvé avec id=%s".formatted(namespaceId));
            }
            final Resource namespaceResource = resourceOptional.get();
            DEFAULT_LOGGER.debug("---> Namespace trouvé : {}", namespaceResource);

            // Utilisateur :
            final Optional<LdapUser> ldapMemberOptional = ldapUserService.findLDAPUserByUid(memberLdapUid);
            if (ldapMemberOptional.isEmpty()) {
                throw new Exception("Pas d'utilisateur trouvé dans le LDAP avec uid=%s".formatted(memberLdapUid));
            }
            final LdapUser ldapMember = ldapMemberOptional.get();
            DEFAULT_LOGGER.debug("---> Utilisateur LDAP trouvé : {}", ldapMember);

            // Role
            final Optional<Role> roleOpt = roleRepository.findById(roleId);
            if (roleOpt.isEmpty()) {
                throw new Exception("Pas de rôle trouvé dans la base avec id=%s".formatted(roleId));
            }

            // Ajout du membre :
            final ResourceService namespaceService = this.resourceServiceFactory.service(namespaceResource);
            return namespaceService.addMember(namespaceResource, ldapMember, roleOpt.get());
        } catch (final ResponseStatusException responseStatusException) {
            DEFAULT_LOGGER.error("ERREUR : {}", responseStatusException.getReason());
            throw responseStatusException;
        } catch (final Exception exception) {
            DEFAULT_LOGGER.error("ERREUR : %s".formatted(exception.getMessage()), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage(), exception);
        }
    }

    ////// Définition des endpoints :
    // TODO : Refactorer en utilisant resourceServiceFactory
    @PostMapping()
    public ResponseEntity<String> create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                         @RequestBody final List<CreateResourceRoleDto> createResourceRoleDtoList) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final String userId = getUserId(keycloakAuthenticationToken);
            final List<Map<String, Object>> resultMaps = new ArrayList<>();
            RoleAssignement resourceRole;
            Long resourceId;
            StringBuilder errorMsgBuffer;
            String resourceName;
            boolean isOK;
            Map<String, Object> jsonResource  ;
            Optional<RoleAssignement> existingResourceRoles;
            Optional<Resource> resourceOptional;
            for (CreateResourceRoleDto createResourceRoleDto : createResourceRoleDtoList) {
                resourceId = createResourceRoleDto.getResourceId();
                errorMsgBuffer = new StringBuilder();
                existingResourceRoles = roleAssignementRepository.findByUserUidAndRoleIdAndResourceId(createResourceRoleDto.getUserId(),createResourceRoleDto.getRoleId(),resourceId);
                resourceOptional = resourceRepository.findById(resourceId);
                if (resourceOptional.isPresent()) {
                    resourceName = (resourceOptional.get().getName() == null ? "" : resourceOptional.get().getName());
                } else {
                    resourceName = "";
                }
                if (!existingResourceRoles.isEmpty()) {
                    final RoleAssignement existingResourceRole = existingResourceRoles.stream().findFirst().get();
                    DEFAULT_LOGGER.error("Member déjà ajouté à la ressource avec l'id = {}", existingResourceRole.getId());
                    jsonResource = existingResourceRole.toMap();
                    jsonResource.put("userId", existingResourceRole.getUser().getId());
                    jsonResource.put("resourceId", existingResourceRole.getResource().getId());
                    jsonResource.put("roleId", existingResourceRole.getRole().getId());
                    jsonResource.put("serviceAccountId",existingResourceRole.getServiceAccount().getId());
                   // jsonResource.put("user", (this.user == null ? new JSONObject() : this.user.toJSON()));

                    jsonResource.put("alreadyExists", true);
                    jsonResource.put("userAlreadyAdded", createResourceRoleDto.getUserId());
                    jsonResource.put("resourceName", resourceName);
                    resultMaps.add(jsonResource);
                    continue;
                }
                isOK = new ProjectRoleValidator(roleAssignementRepository, resourceRepository, roleRepository,projectRepository)
                        .validate("userId", Pair.of(userId, resourceId), errorMsgBuffer);
                if (!isOK) {
                    DEFAULT_LOGGER.error("ERREUR : {}", errorMsgBuffer);
                    return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
                }

                if (createResourceRoleDto.isS3()) {
                    DEFAULT_LOGGER.debug("==> Création en mode S3");
                    final Map<String, Object> parameters = createResourceRoleDto.toMap();
                    // TODO: A refactoriser. Substitution de mode compte de service en mode user pour fonctionner avec addS3Member().
                    if (createResourceRoleDto.isServiceAccount()) {
                        final Optional<ServiceAccount> serviceAccount = serviceAccountRepository.findById(createResourceRoleDto.getServiceAccountId());
                        parameters.put("serviceAccountId", null);
                        parameters.put("userId", serviceAccount.get().getUid());
                    }
                    DEFAULT_LOGGER.debug("avec les paramètres");
                    for (String paramName : parameters.keySet()) {
                        DEFAULT_LOGGER.debug("  {} = {}", paramName, parameters.get(paramName));
                    }
                    final Map<String, Object> result = this.addS3Member(parameters);
                    result.put("alreadyExists", false);
                    result.put("newUserAdded", createResourceRoleDto.getUserId());
                    resultMaps.add(result);
                } else {
                    DEFAULT_LOGGER.debug("==> Création en mode Tenant ou normal");
                    final RoleAssignement newResourceRole = new RoleAssignement();
                    User userRole = null;
                    Optional<User> userOpt= userRepository.findFirstByUid(createResourceRoleDto.getUserId());
                    if(userOpt.isEmpty()){
                        final Optional<LdapUser> existingLdapUser = userDAO.selectFirst(withLdapUserRIO(createResourceRoleDto.getUserId()));
                        if(existingLdapUser.isPresent()){
                            final LdapUser ldapUser = existingLdapUser.get();
                            User newUser = new User(
                                    ldapUser.getFirstAndLastNames().getLeft(),
                                    ldapUser.getFirstAndLastNames().getLeft(),
                                    ldapUser.getMail(),
                                    ldapUser.getUid(),
                                    true
                            );
                            userRole = userRepository.save(newUser);
                        }
                    }else{
                        userRole = userOpt.get();
                    }
                    newResourceRole.setUser(userRole);
                    final Resource resource = resourceRepository.findById(resourceId).get();
                    newResourceRole.setResource(resource);
                    newResourceRole.setRole(roleRepository.findById(createResourceRoleDto.getRoleId()).get());
                    newResourceRole.setServiceAccount(createResourceRoleDto.getServiceAccountId()==null?null: serviceAccountRepository.findById(createResourceRoleDto.getServiceAccountId()).get());
                    newResourceRole.setIsSynchronized(createResourceRoleDto.isSynchronized());
                    newResourceRole.setProject(resource.getProject());
                    if (!((newResourceRole.getUser().getUid() == null) == (newResourceRole.getServiceAccount() != null))) {
                        throw new ResponseStatusException(BAD_REQUEST, "The field uid and serviceAccountId are mutually exclusive");
                    }
                    checkRoleAssignmentAlreadyExists(newResourceRole);
                    if (!newResourceRole.getIsSynchronized()) {
                        DEFAULT_LOGGER.info("Skipping add member to resource service...");
                    } else {
                        try {
                            boolean hasAddMember = resourceServiceFactory.service(newResourceRole).addMember(newResourceRole);
                            if (!hasAddMember) {
                                throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role assignment have failed");
                            }
                        } catch (final HttpClientErrorException e) {
                            DEFAULT_LOGGER.error("ERREUR : {}", e.getMessage());
                            DEFAULT_LOGGER.info("Service role assignment procedure has failed, the resource role will be created but not synchronized");
                            newResourceRole.setIsSynchronized(false);
                        }
                    }
                    resourceRole = roleAssignementRepository.save(newResourceRole);
                    jsonResource= newResourceRole.toMap();
                    jsonResource.put("alreadyExists", false);
                    jsonResource.put("newUserAdded", createResourceRoleDto.getUserId());
                    jsonResource.put("resourceName", resourceName);
                    resultMaps.add(jsonResource);
                    tryNotifyRoleAssignmentToTargetUser(resourceRole);
                }
            }
            return new ResponseEntity<>(buildJSONArrayFromListOfMap(resultMaps).toString(), CREATED);
        } catch (final Exception exception) {
            DEFAULT_LOGGER.error("ERREUR : %s".formatted(exception.getMessage()), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }


    @GetMapping()
    public Iterable<RoleAssignement> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return roleAssignementRepository.findAll();
    }

    @GetMapping("/{resource_role_id}")
    public Optional<RoleAssignement> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                      @PathVariable("resource_role_id") final Long resourceRoleId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return roleAssignementRepository.findById(resourceRoleId);
    }

    @PutMapping("/{resource_role_id}")
    public ResponseEntity<RoleAssignement> update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                               @PathVariable("resource_role_id") final Long resourceRoleId,
                                               @RequestBody final UpdateResourceRoleDto updateResourceRoleDto) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            if (!resourceRoleId.equals(updateResourceRoleDto.getId())) {
                throw new ResponseStatusException(FORBIDDEN, "Resource role to update not corresponding with query parameter one");
            }
            if (!roleAssignementRepository.existsById(resourceRoleId)) {
                throw new ResponseStatusException(NOT_FOUND, "Resource role not found");
            }
            final RoleAssignement resourceRole = new RoleAssignement();
            resourceRole.setResource(resourceRepository.findById(updateResourceRoleDto.getResourceId()).get());
            resourceRole.setRole(roleRepository.findById(updateResourceRoleDto.getRoleId()).get());
            resourceRole.setUser(userRepository.findFirstByUid(updateResourceRoleDto.getUserId()).get());
            resourceRole.setServiceAccount(serviceAccountRepository.findById(updateResourceRoleDto.getServiceAccountId()).get());
            resourceRole.setIsSynchronized(updateResourceRoleDto.isSynchronized());
            final ResourceService resourceService = resourceServiceFactory.service(resourceRole);
            if (resourceRole.getIsSynchronized()) {
                try {
                    String uid = resourceRole.getUser().getUid();
                    if (resourceRole.getIsSynchronized()) {
                        uid = serviceAccountRepository.findByUid(resourceRole.getServiceAccount().getUid()).get().getUid();
                    }
//                    final Resource foundResource = resourceRepository.findById(resourceRole.getResource()).orElseThrow();
                    final Optional<Resource> foundResourceOpt = resourceRepository.findById(resourceRole.getResource().getId());
                    if (foundResourceOpt.isEmpty()) {
                        throw new Exception("Pas de resource trouvée avec l'id = %d".formatted(resourceRole.getResource()));
                    }
                    final boolean hasAddMember = (boolean) resourceService.addMember(
                            foundResourceOpt.get(),
                            ldapUserService.findLDAPUserByUid(uid).orElseThrow(),
                            resourceRole.getRole()).get("result");
                    if (!hasAddMember) {
                        throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role assignment have failed");
                    }
                } catch (final HttpClientErrorException httpClientErrorException) {
                    DEFAULT_LOGGER.info("Service role assignment procedure has failed, the resource role will be updated as not synchronized");
                    DEFAULT_LOGGER.error(httpClientErrorException.getMessage(), httpClientErrorException);
                    throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role assignation have failed");
                } catch (final Exception exception) {
                    DEFAULT_LOGGER.error(exception.getMessage(), exception);
                    throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
                }
            } else if (resourceService instanceof DefaultBDDResourceService) {
                DEFAULT_LOGGER.info("---> Utilisation de DefaultBDDResourceService => on ne fait qu'une mise à jour en base de données");
                resourceRole.setIsSynchronized(false);
            } else {
                try {
                    if (!resourceService.removeMember(resourceRole)) {
                        DEFAULT_LOGGER.error("Resource service role revocation have failed");
                        throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role revocation have failed");
                    }
                } catch (final HttpClientErrorException httpClientErrorException) {
                    DEFAULT_LOGGER.error(httpClientErrorException.getMessage(), httpClientErrorException);
                    DEFAULT_LOGGER.info("Service role revocation procedure has failed, the resource role will be not updated");
                    throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "Resource service role revocation have failed");
                }
            }
            tryToSendResourceRoleUpdateEmail(keycloakAuthenticationToken, updateResourceRoleDto);
            return ResponseEntity.ok(roleAssignementRepository.save(resourceRole));
        } catch (final ResponseStatusException responseStatusException) {
            DEFAULT_LOGGER.error(responseStatusException.getReason(), responseStatusException);
            throw responseStatusException;
        } catch (final Exception exception) {
            DEFAULT_LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage(), exception);
        }
    }

    @DeleteMapping("/{resource_role_id}")
    public void delete(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                       @PathVariable("resource_role_id") final Long resourceRoleId) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final RoleAssignement resourceRole = roleAssignementRepository.findById(resourceRoleId).orElseThrow(() -> new ResponseStatusException(NOT_FOUND, "Resource rôle non trouvé"));
            final ResourceService resourceService = this.resourceServiceFactory.service(resourceRole);
            ResourceRoleService source = resourceRoleService;
            if (resourceService instanceof NamespaceResourceService) {
                source = resourceRoleServiceFactory.withLdap(source);
                source = resourceRoleServiceFactory.withEmail(source);
                source.delete(resourceRoleId);
                resourceService.removeMember(resourceRole);
            } else if (resourceService instanceof TenantService) {
                source = resourceRoleServiceFactory.withIaas(source);
                source = resourceRoleServiceFactory.withLdap(source);
                source = resourceRoleServiceFactory.withEmail(source);
                source.delete(resourceRoleId);
            } else {
                source.delete(resourceRoleId);
            }
        } catch (final Exception exception) {
            DEFAULT_LOGGER.error(exception.getMessage(), exception);
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    ///// Getters & Setters :

    RoleRepository getRoleRepository() {
        return roleRepository;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Autowired
    public void setResourceTypeRepository(ResourceTypeRepository resourceTypeRepository) {
        this.resourceTypeRepository = resourceTypeRepository;
    }
    @Autowired
    public void setProjectRepository(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }
    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
    @Autowired
    public void setResourceRepository(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }
    @Autowired
    public void setServiceAccountRepository(ServiceAccountRepository serviceAccountRepository) {
        this.serviceAccountRepository = serviceAccountRepository;
    }
    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
    @Autowired
    public void setUserDAO(DAO<LdapUser> userDAO) {
        this.userDAO = userDAO;
    }
}
