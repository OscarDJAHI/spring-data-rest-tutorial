package fr.minint.console.api.project.ldap.dto;

import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Data
public class CreateExternalUserDto {
    @NotBlank
    String firstname;

    @NotBlank
    String lastname;

    @Email
    @NotBlank
    String email;

    @NotBlank
    String password;

    String organization;
}
