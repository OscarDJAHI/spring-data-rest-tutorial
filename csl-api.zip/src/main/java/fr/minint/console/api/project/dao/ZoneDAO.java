package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.model.Zone;
import fr.minint.console.persistence.dao.jpa.data.DefaultCrudRepositoryDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.repository.CrudRepository;

public class ZoneDAO extends DefaultCrudRepositoryDAO<Long, Zone> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ZoneDAO.class);

    public ZoneDAO(final CrudRepository<Zone, Long> crudRepository) {
        super(crudRepository);
    }

    @Override
    public void close() {
        LOGGER.info("---> Fermeture de l'instance de ZoneDAO");
    }
}
