package fr.minint.console.api.project.ldap.model;

import lombok.Data;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

import javax.naming.Name;

@Entry(base = "ou=people", objectClasses = "inetOrgPerson")
@Data
final public class Pers {
    private @Id
    Name id;
    //    private @DnAttribute(value = "uid", index = 3) String uid;
    private @Attribute(name = "uid")
    String uid;
    private @Attribute(name = "cn")
    String fullName;
    private @Attribute(name = "sn")
    String lastname;
    private String userPassword;
}
