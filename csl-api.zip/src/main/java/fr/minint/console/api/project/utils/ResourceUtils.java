package fr.minint.console.api.project.utils;

import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.resource.Resource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ResourceUtils {

    public static Map<String, Boolean> validate(Iterable<QuotaType> quotaTypes, Resource resource) {
        List<QuotaType> quotaTypeList = StreamSupport
                .stream(quotaTypes.spliterator(), false)
                .collect(Collectors.toList());

        return resource.getResourceQuotas().stream().reduce(
                new HashMap<>(),
                (map, resourceQuota) -> {
                    quotaTypeList.stream()
                            .filter(qt -> resourceQuota.getQuotaType().equals(qt.getId()))
                            .findFirst()
                            .ifPresent(quotaType -> map.put(
                                    quotaType.getName(),
                                    quotaType.validate(resourceQuota.getQuotaValue())
                            ));

                    return map;
                },
                (map1, map2) -> {
                    map1.putAll(map2);

                    return map1;
                }
        );
    }

    public static boolean isValid(Iterable<QuotaType> quotaTypes, Resource resource) {
        return validate(quotaTypes, resource).values().stream().anyMatch(value -> value);
    }

}
