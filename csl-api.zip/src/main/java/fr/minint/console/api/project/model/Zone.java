package fr.minint.console.api.project.model;

import fr.minint.console.library.bean.HasId;
import fr.minint.console.library.bean.HasName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Zone implements HasId<Long>, HasName {
    @Id
    Long id;
    String name;
    String label;
    String color;

    public Zone(long id, String name, String label) {
        this.id = id;
        this.name = name;
        this.label = label;
    }
}
