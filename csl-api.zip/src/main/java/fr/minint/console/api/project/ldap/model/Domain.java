package fr.minint.console.api.project.ldap.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entry(objectClasses = {
        "gosaDepartment",
        "organizationalUnit",
        "top"
})
final public class Domain {
    @Id
    String dn;

    @Attribute(name = "description")
    String description;

    @Attribute(name = "ou")
    String ou;

    @Attribute(name = "o")
    String o;
}
