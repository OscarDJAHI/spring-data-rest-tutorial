package fr.minint.console.api.project.configuration;

import fr.minint.console.api.project.ObjectStorageProvider;
import fr.minint.console.api.project.service.sequence.JdbcSequenceService;
import fr.minint.console.api.project.service.sequence.SequenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

@Configuration
public class ConsoleApiProjectConfiguration {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConsoleApiProjectConfiguration.class);

    @Bean
    public RestTemplate restTemplate(final RestTemplateBuilder builder) {
        // Do any additional configuration here
        return builder.build();
    }

    @Bean(name = "extUserRIOSeqService")
    public SequenceService getExtUserRioSequence(final JdbcTemplate jdbcTemplate) {
        return new JdbcSequenceService("ext_users_rio_seq", jdbcTemplate);
    }

    @Bean(name = "extUserUidNumberSeqService")
    public SequenceService getExtUserUidNumberSequenceService(final JdbcTemplate jdbcTemplate) {
        return new JdbcSequenceService("ext_users_uid_number_seq", jdbcTemplate);
    }

    @Bean("objectStorageProvider")
    public ObjectStorageProvider getObjectStorageProvider(@Value("${console.api.project.object-storage-provider:ecs}") final String objectStorageProviderName) {
        try {
            ObjectStorageProvider objectStorageProvider = ObjectStorageProvider.valueOf(objectStorageProviderName.toUpperCase(Locale.ROOT).trim());
            LOGGER.info("Utilisation du fournisseur de stockage objet: {}", objectStorageProvider.value());
            return objectStorageProvider;
        } catch (final IllegalArgumentException illegalArgumentException) {
            LOGGER.warn("Le fournisseur de stockage objet {} n'est pas supporté", objectStorageProviderName);
        } catch (final NullPointerException nullPointerException) {
            LOGGER.warn("Le fournisseur de stockage objet n'est à priori pas renseigné", nullPointerException);
        }
        LOGGER.info("Utilisation du fournisseur de stockage objet ECS par défaut");
        return ObjectStorageProvider.ECS;
    }

    @Bean("apiProjectExecutorService")
    public ExecutorService buildExecutorService() {
        return new ThreadPoolExecutor(2, 15, 70, MILLISECONDS, new LinkedBlockingQueue<>());
    }
}
