package fr.minint.console.api.project.ldap.model;

import lombok.Data;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

import javax.naming.Name;

@Data
@Entry(base = "ou=applications", objectClasses = {"organizationalUnit", "top"})
final public class Application {
    @Id
    private Name dn;

    private @Attribute(name = "ou")
    String name;
//    private @Attribute(name = "ou") @DnAttribute(value = "ou", index = 0) String name;
//    private @Attribute(name = "ou") @DnAttribute("ou") String ou;
//    private @DnAttribute(value = "ou", index = 1) String ou;
//    @Attribute(name = "ou", readonly = true)
//    private String name;


//    @Transient
//    @JsonIgnore
//    @DnAttribute(value = "ou", index = 0)
//    private String ou;

    public String getDn() {
        return dn.toString();
    }

    @Override
    public String toString() {
        return name;
    }

}
