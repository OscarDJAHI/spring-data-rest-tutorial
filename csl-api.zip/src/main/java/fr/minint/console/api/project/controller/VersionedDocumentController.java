package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.VersionedDocument;
import fr.minint.console.api.project.repositories.VersionedDocumentRepository;
import fr.minint.console.library.validator.NotNullValidator;
import lombok.Setter;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.util.Optional;

import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCodeFromCollection;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCode;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.time.LocalDateTime.now;
import static org.apache.commons.io.FileUtils.readFileToString;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/documents")
@Setter(onMethod = @__(@Autowired))
public class VersionedDocumentController  {
    private static final Logger LOGGER = LoggerFactory.getLogger(VersionedDocumentController.class);
    private static final NotNullValidator NOT_NULL_VALIDATOR = new NotNullValidator();
    private VersionedDocumentRepository versionedDocumentRepository;


    ///// Définition des "endPoints"

    @GetMapping("/latest/{typeName}")
    public ResponseEntity<String> getLatestDocumentByType(@PathVariable final String typeName) {
        final Optional<VersionedDocument> docTypeOpt = versionedDocumentRepository.findByDocTypeName(typeName);
        if (docTypeOpt.isEmpty()) {
            LOGGER.error("ERREUR : pas de type de document avec le nom {}", typeName);
            return createErrorResponseEntity(NOT_FOUND, "ERREUR : pas de type de document avec le nom %s".formatted(typeName));
        }
        try {
            final Optional<VersionedDocument> versionedDocumentOptional
                    = versionedDocumentRepository.findFirstByDocTypeNameOrderByVersionNumberDesc(typeName);
            if (versionedDocumentOptional.isEmpty()) {
                LOGGER.error("Pas de document versionné avec type = {}", typeName);
                return createErrorResponseEntity(NOT_FOUND, "Pas de document versionné avec type = %s".formatted(typeName));
            }
            return ok(buildJSONCode(versionedDocumentOptional.get()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage(), now());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @GetMapping("/latest/{typeName}/content")
    public ResponseEntity<String> getLatestDocumentContentByType(@PathVariable final String typeName) {
        final Optional<VersionedDocument> docTypeOpt = versionedDocumentRepository.findByDocTypeName(typeName);
        if (docTypeOpt.isEmpty()) {
            LOGGER.error("ERREUR : pas de type de document avec le nom {}", typeName);
            return createErrorResponseEntity(NOT_FOUND, "ERREUR : pas de type de document avec le nom %s".formatted(typeName));
        }
        try {
            final Optional<VersionedDocument> versionedDocumentOptional
                    = versionedDocumentRepository.findFirstByDocTypeNameOrderByVersionNumberDesc(typeName);
            if (versionedDocumentOptional.isEmpty()) {
                LOGGER.error("Pas de document versionné avec type = {}", typeName);
                return createErrorResponseEntity(NOT_FOUND, "Pas de document versionné avec type = %s".formatted(typeName));
            }

            // Récupération du contenu :
            final VersionedDocument versionedDocument = versionedDocumentOptional.get();
            final File docFile = new File(versionedDocument.getDocPath());
            if (!docFile.exists()) {
                LOGGER.error("ERREUR : Le fichier {} n'existe pas", docFile.getAbsolutePath());
                return createErrorResponseEntity(NOT_FOUND, "Le fichier %s n'existe pas".formatted(docFile.getAbsolutePath()));
            }

            // Envoi du résultat :
            final JSONObject jsonResult = new JSONObject();
            jsonResult.put("version", versionedDocument.getVersionNumber());
            jsonResult.put("content", readFileToString(docFile, UTF_8));
            return ok(jsonResult.toString());
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage(), now());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage(), now());
        }
    }

    @GetMapping("/{typeName}/{version}")
    public ResponseEntity<String> getDocumentPathByTypeAndVersion(@PathVariable final String typeName,
                                                                  @PathVariable final int version) {
        try {
            final Optional<VersionedDocument> foundDocOptional = versionedDocumentRepository.findFirstByDocTypeNameAndVersionNumber(typeName,version);
            if (foundDocOptional.isEmpty()) {
                LOGGER.error("Document avec type={} et version={}", typeName, version);
                return createErrorResponseEntity(NOT_FOUND, "Document avec type=%s et version=%s".formatted(typeName, version));
            }
            return ok(buildJSONCode(foundDocOptional.get()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage(), now());
        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getDocumentById(@PathVariable final Long id) {
        try {
            final Optional<VersionedDocument> foundDocOptional = versionedDocumentRepository.findById(id);
            if (foundDocOptional.isEmpty()) {
                LOGGER.error("Document avec id={}", id);
                return createErrorResponseEntity(NOT_FOUND, "Document avec id=%s".formatted(id));
            }
            return ok(buildJSONCode(foundDocOptional.get()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage(), now());
        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<String> getAllDocuments() {
        try {
            return ok(buildJSONCodeFromCollection(versionedDocumentRepository.findAll()));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @PostMapping
    public ResponseEntity<String> addDocument(@RequestBody final VersionedDocument document) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        if (!NOT_NULL_VALIDATOR.validate("document", document, errorMsgBuffer)) {
            LOGGER.warn("Attention : {}", errorMsgBuffer);
            LOGGER.warn("---> On ne fait donc rien !!");
            return new ResponseEntity<>("{}", OK);
        }
        try {
            return ok(buildJSONCode(versionedDocumentRepository.save(document)));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateDocument(@PathVariable final Long id, @RequestBody final VersionedDocument document) {
        final StringBuilder errorMessageBuilder = new StringBuilder();
        boolean isOK = NOT_NULL_VALIDATOR.validate("document", document, errorMessageBuilder);
        isOK = NOT_NULL_VALIDATOR.validate("id", id, errorMessageBuilder) && isOK;
        if (!isOK) {
            LOGGER.warn("Attention : {}", errorMessageBuilder);
            LOGGER.warn("---> On ne fait donc rien !!");
            return new ResponseEntity<>("{}", OK);
        }
        try {
            return ok(buildJSONCode(versionedDocumentRepository.save(document)));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    ///// Méthode



    ///// Getters & Setters :

    @Autowired
    public void setVersionedDocumentRepository(VersionedDocumentRepository versionedDocumentRepository) {
        this.versionedDocumentRepository = versionedDocumentRepository;
    }
}


