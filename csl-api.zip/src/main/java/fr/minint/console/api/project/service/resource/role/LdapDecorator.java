package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.BastionAccessService;
import fr.minint.console.api.project.service.LdapService;
import fr.minint.console.persistence.dao.DAO;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;

@Slf4j
@Setter
public class LdapDecorator extends ResourceRoleServiceDecorator {
    private RoleAssignementRepository resourceRoleRepository;
    private RoleRepository roleRepository;
    private ZoneRepository zoneRepository;
    private RegionRepository regionRepository;
    private LdapService ldapService;
    private BastionAccessService bastionAccessService;
    private DAO<Resource> resourceDAO;

    public LdapDecorator(ResourceRoleService source) {
        super(source);
    }

    private Resource fetchResource(final Long resourceId) throws Exception {
        final Optional<Resource> foundResourceOpt = resourceDAO.selectFirst(withJDBCFieldEquals(Resource.class, "id", resourceId));
        if (foundResourceOpt.isEmpty()) {
            throw new Exception("Pas de ressource trouvée avec id = %d".formatted(resourceId));
        }
        return foundResourceOpt.get();
    }

    private void removeUnnecessaryGroup(final RoleAssignement resourceRoleToDelete) {
        final List<RoleAssignement> resourceRoleAssignments = resourceRoleRepository.findByUserUidAndRoleId(
                resourceRoleToDelete.getUser().getUid(),
                resourceRoleToDelete.getRole().getId()
        );
        if (resourceRoleAssignments.size() == 1) {
            boolean isSame = resourceRoleAssignments.get(0).getId().equals(resourceRoleToDelete.getId());
            if (isSame) {
                removeUserConsoleRoleGroup(resourceRoleToDelete);
            }
        }
    }

    private void removeUnnecessaryBastionAccesses(RoleAssignement resourceRole) {
        List<RoleAssignement> userResourceRoleAssignments = resourceRoleRepository.findByUserUid(resourceRole.getUser().getUid());
        Map<String, List<RoleAssignement>> countMap = new HashMap<>();

        log.debug(
                "List des assignations de l'utilisateur {}: {}",
                resourceRole.getUser().getUid(),
                userResourceRoleAssignments
        );

        userResourceRoleAssignments.forEach(resourceRole1 -> {
            try {
                final Resource resource = resourceRole1.getResource();
                Region region = resource.getResourceRegions().stream().findFirst().get().getRegion();
                if (region != null) {
                    region = regionRepository.findById(region.getId()).orElse(null);
                } else {
                    region = null;
                }
                final Zone zone;
                if (resource.getZone() !=  null) {
                    zone = zoneRepository.findById(resource.getZone().getId()).orElse(null);
                } else {
                    zone = null;
                }
                if (region == null || zone == null) {
                    log.info("iaasArea == null ou zone == null => on ne fait rien !!");
                    return;
                }
                final String key = "%s-%s".formatted(region.getName(), zone.getName());
                if (countMap.containsKey(key)) {
                    List<RoleAssignement> next = new ArrayList<>(List.copyOf(countMap.get(key)));
                    next.add(resourceRole1);
                    countMap.put(key, next);
                } else {
                    countMap.put(key, List.of(resourceRole1));
                }
            } catch (final Exception exception) {
                log.error(exception.getMessage(), exception);
            }
        });

        log.debug("Totaux des assignations de rôles sur ressources: {}", countMap);

        countMap.entrySet().stream()
                .filter(entry -> entry.getValue().size() == 1)
                .toList()
                .forEach(entry -> {
                    entry.getValue().forEach(resourceRole1 -> {
                        try {
                            if (resourceRole1.getId().equals(resourceRole.getId())) {
                                removeUserBastionAccessPosixGroup(resourceRole1);
                            }
                        } catch (final Exception exception) {
                            log.error(exception.getMessage(), exception);
                        }
                    });
                });
    }

    private void removeUserConsoleRoleGroup(RoleAssignement resourceRole) {
        final Role role = roleRepository.findById(resourceRole.getRole().getId()).orElseThrow();
        log.debug("L'utilisateur {} va perdre le groupe {}", resourceRole.getUser().getUid(), role.getName());
        ldapService.removeUserFromGroup(resourceRole.getUser().getUid(), role.getName());
    }

    private void removeUserBastionAccessPosixGroup(final RoleAssignement resourceRole) throws Exception {
        final Long resourceId = resourceRole.getResource().getId();
        Resource resource = fetchResource(resourceId);
        Region region = regionRepository.findById(resource.getResourceRegions().stream().findFirst().get().getRegion().getId()).orElseThrow();
        Zone zone = zoneRepository.findById(resource.getZone().getId()).orElseThrow();
        String bastionAccessPosixGroupName = bastionAccessService.getBastionAccessPosixGroupName(region, zone);
        log.debug("L'utilisateur {} va perdre le groupe {}", resourceRole.getUser().getUid(), bastionAccessPosixGroupName);
        ldapService.removeUserFromPosixGroup(resourceRole.getUser().getUid(), bastionAccessPosixGroupName);
    }


    @Override
    public void delete(RoleAssignement resourceRole) {
        removeUnnecessaryBastionAccesses(resourceRole);
        removeUnnecessaryGroup(resourceRole);
        super.delete(resourceRole);
    }

    @Override
    public void delete(Long id) {
        super.get(id).ifPresent(this::delete);
    }
}
