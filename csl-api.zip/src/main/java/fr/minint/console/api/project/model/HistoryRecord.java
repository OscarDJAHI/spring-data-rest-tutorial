package fr.minint.console.api.project.model;

import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

@Table
public class HistoryRecord extends AbstractDAOBean<Long> implements ToJSON {

    @Id
    private Long id;
    private String action;
    private String ancienneValeur;
    private String nouvelleValeur;
    private String modifiedTable;
    private String updatedBy;
    @CreatedDate
    private Instant createdAt;

    @CreatedDate
    private Instant updatedAt;

    ///// Constructeurs :

    public HistoryRecord(final Long id,
                         final String action,
                         final String ancienneValeur,
                         final String nouvelleValeur,
                         final String modifiedTable,
                         final String updatedBy,
                         final Instant createdAt,
                         final Instant updatedAt) {
        this.id = id;
        this.action = action;
        this.ancienneValeur = ancienneValeur;
        this.nouvelleValeur = nouvelleValeur;
        this.modifiedTable = modifiedTable;
        this.updatedBy = updatedBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public HistoryRecord(final Long id,
                         final String action,
                         final String ancienneValeur,
                         final String nouvelleValeur,
                         final String modifiedTable,
                         final String updatedBy) {
        this(id, action, ancienneValeur, nouvelleValeur, modifiedTable, updatedBy, null, null);
    }

    public HistoryRecord() {
        this(null, null, null, null, null, null, null, null);
    }

    ///// Méthode de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", this.id);
        jsonObject.put("action", this.getAction());
        jsonObject.put("nouvelleValeur", this.getNouvelleValeur());
        jsonObject.put("ancienneValeur", this.getAncienneValeur());
        jsonObject.put("updatedBy", this.getUpdatedBy());
        jsonObject.put("modifiedTable", this.getModifiedTable());
        jsonObject.put("createdAt", this.getCreatedAt());
        return jsonObject;
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.action,
                this.ancienneValeur,
                this.nouvelleValeur,
                this.modifiedTable,
                this.updatedBy,
                this.createdAt,
                this.updatedAt);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final HistoryRecord history = (HistoryRecord) that;
        boolean areEquals = Objects.equals(this.action, history.action);
        areEquals = areEquals && Objects.equals(this.ancienneValeur, history.ancienneValeur);
        areEquals = areEquals && Objects.equals(this.nouvelleValeur, history.nouvelleValeur);
        areEquals = areEquals && Objects.equals(this.modifiedTable, history.modifiedTable);
        areEquals = areEquals && Objects.equals(this.updatedBy, history.updatedBy);
        areEquals = areEquals && Objects.equals(this.createdAt, history.createdAt);
        areEquals = areEquals && Objects.equals(this.updatedAt, history.updatedAt);
        return areEquals;
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAncienneValeur() {
        return ancienneValeur;
    }

    public void setAncienneValeur(String ancienneValeur) {
        this.ancienneValeur = ancienneValeur;
    }

    public String getNouvelleValeur() {
        return nouvelleValeur;
    }

    public void setNouvelleValeur(String nouvelleValeur) {
        this.nouvelleValeur = nouvelleValeur;
    }

    public String getModifiedTable() {
        return modifiedTable;
    }

    public void setModifiedTable(String modifiedTable) {
        this.modifiedTable = modifiedTable;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }
}
