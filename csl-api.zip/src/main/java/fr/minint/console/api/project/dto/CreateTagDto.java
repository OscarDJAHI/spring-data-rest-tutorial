package fr.minint.console.api.project.dto;

import lombok.Data;

@Data
public class CreateTagDto {
    protected String name;
    protected String label;
    protected String color;
}
