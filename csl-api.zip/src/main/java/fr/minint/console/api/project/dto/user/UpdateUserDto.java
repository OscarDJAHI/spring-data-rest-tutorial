package fr.minint.console.api.project.dto.user;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class UpdateUserDto {

    @NotNull Long id;
    @NotEmpty String name;
    @NotEmpty String email;

}
