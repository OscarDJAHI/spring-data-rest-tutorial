package fr.minint.console.api.project.controller.validator.resource;

import fr.minint.console.api.project.repositories.ResourceRepository;
import fr.minint.console.library.validator.Validator;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;

/**
 * <p>
 * Validateur permettant de vérifier qu'une ressource donnée par son identifiant
 * n'existe pas dans la couche de persistance. <br />
 * </p>
 *
 * @see Validator
 */
public class NotExistingResourceValidator implements Validator<Pair<String, Long>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NotExistingResourceValidator.class);
    private ResourceRepository resourceRepository;
    public NotExistingResourceValidator(final ResourceRepository resourceDAO) {
        this.resourceRepository = resourceDAO;
    }

    ///// Méthode(s) privée(s) :

    private static void appendErrorMessage(final StringBuilder errorMsgBuffer, final String errorMessage) {
        if (!errorMsgBuffer.isEmpty()) {
            errorMsgBuffer.append(",");
        }
        errorMsgBuffer.append(errorMessage);
    }

    @Override
    public boolean validate(final String fieldName,
                            final Pair<String, Long> fieldValue,
                            final StringBuilder errorMsgBuffer) {
        try {
            if(resourceRepository.existsByNameAndResourceTypeId( fieldValue.getLeft(),  fieldValue.getRight())){
                 appendErrorMessage(errorMsgBuffer, "Votre ressource n'a pas pu être crée car le nom existe déjà");
                return false;
            }
            return true;
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            appendErrorMessage(errorMsgBuffer, exception.getMessage());
            return false;
        }
    }
}
