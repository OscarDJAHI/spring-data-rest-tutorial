package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.dto.user.CreateUserDto;
import fr.minint.console.api.project.dto.user.UpdateUserDto;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import fr.minint.console.persistence.dao.DAO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.*;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

@Deprecated
@RestController
@RequestMapping("/users")
public class UserController extends AbstractRestController {
    private UserRepository userRepository;
    private UserLdapRepository userLdapRepository;
    private ProjectRepository projectRepository;
    private RoleRepository roleRepository;

    // Définition des DAO's :
    private DAO<User> userDAO;
    private RoleAssignementRepository roleAssignementRepository;

    ///// Définition des "endPoints" :

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    User create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                @Valid @RequestBody final CreateUserDto createUserDto) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        final User user = new User();
        user.setLastName(createUserDto.getName());
        user.setEmail(createUserDto.getEmail());
        return userRepository.save(user);
    }

    @Operation(
            summary = "List users",
            description = """
                    List users from database by key pattern or not.
                    Returns all users when no matched key are found or not key existing key is set.
                    Currently not support multi query params.
                    Filters must be specified one by one.
                    Precedence filtering is name, email.
                    """
    )
    @Parameters({
            @Parameter(name = "queryParams", examples = {
                    @ExampleObject(
                            name = "all",
                            value = "{}"
                    ),
                    @ExampleObject(
                            name = "with name pattern",
                            value = "{ \"name\": \"tat\" }"
                    ),
                    @ExampleObject(
                            name = "with email pattern",
                            value = "{ \"email\": \"@tot\" }"
                    )
            }),
    })
    @GetMapping
    Iterable<User> list(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                        @RequestParam() final Map<String, String> queryParams) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        if (queryParams.containsKey("name")) {
            String value = queryParams.get("name");
            return userRepository.findByFirstName(value);
        }
        if (queryParams.containsKey("email")) {
            String value = queryParams.get("email");
            return userRepository.findByEmail(value);
        }
        return userRepository.findAll();
    }

    @GetMapping("/{user_id}")
    Optional<User> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                       @PathVariable("user_id") final Long userId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return userRepository.findById(userId);
    }

    @PutMapping("/{user_id}")
    @ResponseStatus(code = HttpStatus.OK)
    User update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                @PathVariable("user_id") final Long userId,
                @Valid @RequestBody final UpdateUserDto updateUserDto) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        Optional<User> optional = userRepository.findById(userId);
        if (optional.isPresent()) {
            User user = optional.get();
            user.setLastName(updateUserDto.getName());
            user.setEmail(updateUserDto.getEmail());
            return userRepository.save(user);
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
    }

    @DeleteMapping("/{user_id}")
    void remove(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                @PathVariable("user_id") final Long id) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        userRepository.deleteById(id);
    }

    @GetMapping("/search")
    public Iterable<LdapUser> search(
            KeycloakAuthenticationToken keycloakAuthenticationToken,
            @RequestParam Map<String, String> allParams
    ) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return search(allParams);
    }

    public Iterable<LdapUser> search(@RequestParam Map<String, String> allParams) {
        LdapQuery query = null;
        if (allParams.containsKey("uid")) {
            String uid = allParams.get("uid");
            query = query()
                    .where("objectclass").is("inetOrgPerson")
                    .and("uid").like(uid);
        } else if (allParams.containsKey("mail")) {
            String mail = allParams.get("mail");
            query = query()
                    .where("objectclass").is("inetOrgPerson")
                    .and("mail").like(mail);
        } else {
            query = query()
                    .where("objectclass").is("inetOrgPerson");
        }

        return userLdapRepository.findAll(query);
    }

    @GetMapping("/{user_id}/projects")
    Set<Project> getUserProjectSet(
            KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("user_id") final String userId
    ) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        Set<Project> projects = new HashSet<>();
        Role role = roleRepository.findByName("delegue").orElseThrow();
        projects.addAll(roleAssignementRepository.findByUserUidAndRoleIdIn(userId, Arrays.asList(role.getId(), 0L)).stream().map(RoleAssignement::getProject).toList());
        return projects;
    }

    @GetMapping("/{user_id}/projects/{project_id}")
    Optional<Project> getUserProject(
            KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("user_id") final String userId,
            @PathVariable("project_id") final Long projectId
    ) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        Role role = roleRepository.findByName("delegue").orElseThrow();
        return Optional.ofNullable(roleAssignementRepository.findByUserUidAndProjectId(userId, projectId).get().getProject());
    }

    ///// Getters & Setters :

    @Autowired
    public void setUserRepository(final UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setUserLdapRepository(final UserLdapRepository userLdapRepository) {
        this.userLdapRepository = userLdapRepository;
    }

    @Autowired
    public void setProjectRepository(final ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Autowired
    public void setRoleRepository(final RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }


    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
}
