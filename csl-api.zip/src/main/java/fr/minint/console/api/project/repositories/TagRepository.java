package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Tag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Collection;
import java.util.Set;

public interface TagRepository extends JpaRepository<Tag, Long>, JpaSpecificationExecutor<Tag> {
    Collection<? extends Tag> findByIdIn(Set<Long> tagIds);
}
