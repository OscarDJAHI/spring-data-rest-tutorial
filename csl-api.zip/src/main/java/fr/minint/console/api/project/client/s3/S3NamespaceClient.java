package fr.minint.console.api.project.client.s3;

import fr.minint.console.api.project.client.AbstractRestTemplateClient;
import fr.minint.console.library.validator.NotNullValidator;
import fr.minint.console.library.validator.Validator;
import fr.minint.console.library.validator.rest.RequestBodyValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.Objects;

@Service
public class S3NamespaceClient extends AbstractRestTemplateClient {
    private static final Validator<Map<String, Object>> MAP_VALIDATOR = new RequestBodyValidator();
    private static final Validator<Object> NOT_NULL_VALIDATOR = new NotNullValidator();

    public ResponseEntity<String> create(final Map<String, Object> parameters) {
        return this.restTemplate.postForEntity("%s/ecs/namespaces".formatted(getBaseUrl()), parameters, String.class);
    }

    ///// Méthodes générales :

    public ResponseEntity<String> list() {
        String baseUrl = Objects.requireNonNull(environment.getProperty("console.api.iaas.url")).trim();
        return this.restTemplate.getForEntity("%s/ecs/namespaces".formatted(baseUrl), String.class);
    }

    public ResponseEntity<String> get(String namespace) {
        String baseUrl = Objects.requireNonNull(environment.getProperty("console.api.iaas.url")).trim();
        return this.restTemplate.getForEntity("%s/ecs/namespaces/%s".formatted(baseUrl, namespace), String.class);
    }

    public void update(final Map<String, Object> parameters) throws Exception {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOk = NOT_NULL_VALIDATOR.validate("parameters", parameters, errorMsgBuffer);
        isOk = MAP_VALIDATOR.validate("domain", parameters, errorMsgBuffer) && isOk;
        isOk = MAP_VALIDATOR.validate("area", parameters, errorMsgBuffer) && isOk;
        if (!isOk) {
            LOGGER.error("ERREUR : {}", errorMsgBuffer);
            throw new Exception("ERREUR : %s".formatted(errorMsgBuffer));
        }
        final String baseUrl = Objects.requireNonNull(environment.getProperty("console.api.iaas.url")).trim();
        LOGGER.info("----> Création/Maj d'un namespace S3 : {}", baseUrl);
        LOGGER.info("----> avec les paramètres : {}", parameters);
        this.restTemplate.put("%s/ecs/namespaces".formatted(baseUrl), parameters);
    }

    public void delete(final Map<String, Object> parameters) {
        String baseUrl = Objects.requireNonNull(environment.getProperty("console.api.iaas.url")).trim();
        this.restTemplate.delete("%s/ecs/namespaces".formatted(baseUrl), parameters);
    }

    ///// Getters & Setters :

    @Autowired
    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    @Autowired
    @Override
    public void setRestTemplate(final RestTemplate restTemplate) {
        super.setRestTemplate(restTemplate);
    }


}
