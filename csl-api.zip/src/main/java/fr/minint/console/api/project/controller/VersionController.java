package fr.minint.console.api.project.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Slf4j

@RestController
public class VersionController {
    @Autowired
    Environment env;

    @GetMapping("/version")
    Map<String, String> getVersion() {
        Map<String, String> map = new HashMap<>();

        map.put("version", env.getProperty("console.api.project.version"));

        return map;
    }
}
