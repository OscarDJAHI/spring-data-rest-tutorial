package fr.minint.console.api.project.utils.predicate.resource;

import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.api.project.model.resource.Resource;

import java.util.Objects;
import java.util.function.Predicate;

/**
 * <p>
 * Prédicat permettant de tester les resources en fonction
 * de leur catégorie.<br />
 * </p>
 *
 * @see Predicate
 * @see Resource
 */
public class ResourceTypeCategoryPredicate implements Predicate<Resource> {
    private final String categoryName;

    public ResourceTypeCategoryPredicate(final String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public boolean test(final Resource resource) {
        if (resource == null) {
            return false;
        }
        final ResourceType resourceType = resource.getResourceTypeBean();
        boolean isOK = (resourceType != null);
        isOK = isOK && Objects.equals(categoryName, resourceType.getCategory());
        return isOK;
    }

    public static Predicate<Resource> withCategory(final String categoryName) {
        return new ResourceTypeCategoryPredicate(categoryName);
    }
}
