package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.dao.quota.JDBCQuotaTypeDAO;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.collection.CollectionUtils.diff;
import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCNotNullFieldPredicate.withNotNullJDBCField;
import static java.util.stream.Collectors.toSet;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * <p>
 * DAO permettant de gérer la persistance des instances ResourceType à l'aide
 * de connexion JDBC. <br />
 * </p>
 *
 * @see AbstractJDBCDAO
 * @see JDBCQuotaTypeDAO
 */
public class JDBCResourceTypeDAO extends AbstractJDBCDAO<Long, ResourceType> {
    private static final Transcoder<ResultSet, ResourceType> RESULT_SET_RESOURCE_TYPE_TRANSCODER = new ResultSetResourceTypeTranscoder();
    private final JDBCQuotaTypeDAO quotaTypeDAO;

    ///// Constructeur(s) :

    public JDBCResourceTypeDAO(final DataSource dataSource) {
        super(dataSource, "resource_type", "resType");
        this.quotaTypeDAO = new JDBCQuotaTypeDAO(dataSource);
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_RESOURCE_TYPE_TRANSCODER);
    }

    ///// Méthodes de la classe AbstractJDBCDAO :

    @Override
    public void start() throws Exception {
        this.quotaTypeDAO.start();
        super.start();
    }

    @Override
    public void close() throws IOException {
        super.close();
        this.quotaTypeDAO.close();
    }

    @Override
    public String getSelectAllQuery() {
        return "SELECT resType.id, " +
                "resType.\"name\", " +
                "resType.\"label\", " +
                "resType.category, " +
                "resType.color, " +
                "resType.created_at, " +
                "resType.updated_at " +
                "FROM " + this.tableName + " AS resType";
    }

    @Override
    protected String getInsertQuery(final ResourceType resourceType) throws Exception {
        if (resourceType == null) {
            throw new Exception("L'instance ResourceType est nulle => on ne peut pas créer la requête SQL d'insertion");
        }
        return "INSERT INTO resource_type " +
                "(\"name\", \"label\", category, color, created_at, updated_at) " +
                "VALUES (%s, %s, %s, %s, now(), now())"
                        .formatted(escapeSQL(resourceType.getName()),
                                escapeSQL(resourceType.getLabel()),
                                escapeSQL(resourceType.getCategory()),
                                escapeSQL(resourceType.getColor()));
    }

    @Override
    protected String getUpdateQuery(final ResourceType resourceType) throws Exception {
        if (resourceType == null) {
            throw new Exception("L'instance ResourceType est nulle => on ne peut pas créer la requête SQL de mis à jour");
        }
        return "UPDATE resource_type " +
                "SET \"name\"=%s, \"label\"=%s, category=%s, color=%s, updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(resourceType.getName()),
                                escapeSQL(resourceType.getLabel()),
                                escapeSQL(resourceType.getCategory()),
                                escapeSQL(resourceType.getColor()),
                                resourceType.getId());
    }

    @Override
    protected List<ResourceType> selectFromQuery(final String selectQuery) throws Exception {
        if (isEmpty(selectQuery)) {
            throw new Exception("La requête SQL est nulle => On ne peut donc pas sélectionner les instances");
        }
        final List<ResourceType> foundResourceTypes = super.selectFromQuery(selectQuery);
        final Map<Long, Set<QuotaType>> quotaTypeMap = new HashMap<>();
        final Set<Long> resourceTypeIds = foundResourceTypes
                .stream()
                .map(ResourceType::getId)
                .filter(Objects::nonNull)
                .collect(toSet());
        List<QuotaType> quotaTypes;
        if (isCollectionEmpty(resourceTypeIds)) {
            quotaTypes = new ArrayList<>();
        } else {
            quotaTypes = this.quotaTypeDAO.select(withFieldInCollection(QuotaType.class, "resource_type", resourceTypeIds));
        }
        for (QuotaType quotaType : quotaTypes) {
            if (!quotaTypeMap.containsKey(quotaType.getResourceType())) {
                quotaTypeMap.put(quotaType.getResourceType(), new HashSet<>());
            }
            quotaTypeMap.get(quotaType.getResourceType()).add(quotaType);
        }
        Long resourceId;
        for (ResourceType foundResourceType : foundResourceTypes) {
            resourceId = foundResourceType.getId();
            if (!quotaTypeMap.containsKey(resourceId)) {
                continue;
            }
            foundResourceType.setQuotaTypes(quotaTypeMap.get(resourceId));
        }
        return foundResourceTypes;
    }

    @Override
    public ResourceType save(final ResourceType resourceType) throws Exception {
        if (resourceType == null) {
            return null;
        }

        // Sauvegarde primaire de l'instance :
        final ResourceType savedResourceType = super.save(resourceType);

        // Sauvegarde des types de ressources :
        final Set<QuotaType> initQuotaTypes = resourceType.getQuotaTypes();
        if (isCollectionEmpty(initQuotaTypes)) {
            return savedResourceType;
        }
        final List<QuotaType> allQuotaType = this.quotaTypeDAO.selectAll();
        QuotaType copiedQuotaType;
        for (QuotaType quotaType : allQuotaType) {
            copiedQuotaType = quotaType.copy();
            if (initQuotaTypes.contains(copiedQuotaType)) {
                savedResourceType.addQuotaType(copiedQuotaType);
            }
        }
        savedResourceType.addQuotaTypes(this.quotaTypeDAO.save(diff(initQuotaTypes, allQuotaType)));
        return savedResourceType;
    }

    @Override
    public void delete(final Predicate<ResourceType> predicate) throws Exception {
        final List<ResourceType> resourceTypes = this.select(predicate);
        if (isCollectionEmpty(resourceTypes)) {
            return;
        }

        // On supprime les types de quotas :
        final Set<Long> resourcesTypeIds = resourceTypes.stream().map(ResourceType::getId).filter(Objects::nonNull).collect(toSet());
        if (!isCollectionEmpty(resourcesTypeIds)) {
            this.quotaTypeDAO.delete(withFieldInCollection(QuotaType.class, "resource_type", resourcesTypeIds));
        }

        // On supprime les types de ressources :
        super.delete(predicate);
    }

    @Override
    public void deleteAll() throws Exception {

        // On supprime les types de quota
        this.quotaTypeDAO.delete(withNotNullJDBCField(QuotaType.class, "resource_type"));

        // On supprime les types
        super.deleteAll();
    }

    ///// Classe(s) privée(s) :

    private static class ResultSetResourceTypeTranscoder extends AbstractResultSetTranscoder<ResourceType> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected ResourceType doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceType resourceType = new ResourceType();
            resourceType.setId(processLongValue(resultSet, "id"));
            resourceType.setName(resultSet.getString("name"));
            resourceType.setLabel(resultSet.getString("label"));
            resourceType.setCategory(resultSet.getString("category"));
            resourceType.setColor(resultSet.getString("color"));
            return resourceType;
        }
    }
}
