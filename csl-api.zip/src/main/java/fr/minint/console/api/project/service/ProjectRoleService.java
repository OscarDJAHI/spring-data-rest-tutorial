package fr.minint.console.api.project.service;

import fr.minint.console.api.project.entities.RoleAssignement;

public interface ProjectRoleService {
    RoleAssignement create(RoleAssignement projectRole);

    Iterable<RoleAssignement> list();

    RoleAssignement get(Long id);

    RoleAssignement update(RoleAssignement projectRole);

    RoleAssignement delete(Long id);
}
