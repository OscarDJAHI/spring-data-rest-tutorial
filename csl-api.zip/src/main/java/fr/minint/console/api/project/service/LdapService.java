package fr.minint.console.api.project.service;

import fr.minint.console.api.project.ldap.model.Group;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.model.LdapUser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class LdapService {
    private final Environment env;
    private final RestTemplate restTemplate;

    boolean userExists(final String uid) {
        final String authenticationApiUrl = env.getProperty("console.api.ldap.url");
        final String authenticationApiUserRoute = env.getProperty("console.api.ldap.resource.user.route");
        final String url = "%s/%s/%s".formatted(authenticationApiUrl, authenticationApiUserRoute, uid);

        try {
            ResponseEntity<LdapUser> response = restTemplate.getForEntity(url, LdapUser.class);

            if (response.hasBody()) {
                LdapUser ldapUser = response.getBody();

                if (ldapUser != null)
                    return ldapUser.getUid().equals(uid);
            }
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return false;
    }

    public LdapUser getUser(final String uid) {
        final String authenticationApiUrl = env.getProperty("console.api.ldap.url");
        final String authenticationApiUserRoute = env.getProperty("console.api.ldap.resource.user.route");
        final String url = "%s/%s/%s".formatted(authenticationApiUrl, authenticationApiUserRoute, uid);

        try {
            ResponseEntity<LdapUser> response = restTemplate.getForEntity(url, LdapUser.class);

            if (response.hasBody()) {
                return response.getBody();
            }
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return null;
    }

    public Group getGroup(final String cn) {
        final String baseUrl = env.getProperty("console.api.ldap.url");
        final String path = "/api/ldap/groups";
        final String url = "%s/%s/%s".formatted(baseUrl, path, cn);

        try {
            ResponseEntity<Group> response = restTemplate.getForEntity(url, Group.class);

            if (response.hasBody()) {
                return response.getBody();
            }
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return null;
    }

    public Group updateGroup(final Group group) {
        final String baseUrl = env.getProperty("console.api.ldap.url");
        final String path = "/api/ldap/groups";
        final String url = "%s/%s".formatted(baseUrl, path);

        try {
            restTemplate.put(url, group);
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return getGroup(group.getCn());
    }

    public PosixGroup getPosixGroup(String cn) {
        final String baseUrl = env.getProperty("console.api.ldap.url");
        final String path = "/api/ldap/posix-groups";
        final String url = "%s/%s/%s".formatted(baseUrl, path, cn);

        try {
            ResponseEntity<PosixGroup> response = restTemplate.getForEntity(url, PosixGroup.class);

            if (response.hasBody()) {
                return response.getBody();
            }
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return null;
    }

    public PosixGroup updatePosixGroup(final PosixGroup posixGroup) {
        final String baseUrl = env.getProperty("console.api.ldap.url");
        final String path = "/api/ldap/posix-groups";
        final String url = "%s/%s".formatted(baseUrl, path);

        log.debug("PosixGroup before update: {}", posixGroup);

        try {
            restTemplate.put(url, posixGroup);
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("%d - %s".formatted(e.getStatusCode().value(), e.getStatusCode().getReasonPhrase()));
        }

        return getPosixGroup(posixGroup.getCn());
    }

    public void removeUserFromGroup(String uid, String groupCn) {
        LdapUser ldapUser = getUser(uid);
        Group group = getGroup(groupCn);

        if (ldapUser == null) throw new ResponseStatusException(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "L'utilisateur à retirer du groupe n'a pas été trouvé"
        );

        if (group == null) throw new ResponseStatusException(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Le groupe de l'utilisateur n'a pas été trouvé"
        );

        group.setMembers(
                group.getMembers().stream()
                        .filter(s -> !s.contains(Objects.requireNonNull(ldapUser.getId())))
                        .collect(Collectors.toSet())
        );

        updateGroup(group);
    }

    public void removeUserFromPosixGroup(String uid, String posixGroupCn) {
        LdapUser ldapUser = getUser(uid);
        PosixGroup posixGroup = getPosixGroup(posixGroupCn);

        if (ldapUser == null) throw new ResponseStatusException(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "L'utilisateur à retirer du groupe posix n'a pas été trouvé"
        );

        if (posixGroup == null) throw new ResponseStatusException(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Le groupe posix de l'utilisateur n'a pas été trouvé"
        );

        posixGroup.setMembers(
                posixGroup.getMembers().stream()
                        .filter(s -> !s.contains(Objects.requireNonNull(ldapUser.getUid())))
                        .collect(Collectors.toSet())
        );

        updatePosixGroup(posixGroup);
    }
}
