package fr.minint.console.api.project.ldap.service;

import fr.minint.console.api.project.ldap.dto.UpdatePosixGroupDto;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repository.ldap.PosixGroupRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@Deprecated
@Service
public class PosixGroupService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PosixGroupService.class);
    private PosixGroupRepository posixGroupRepository;
    private UserService userService;

    public void create(final PosixGroup posixGroup) {
        posixGroupRepository.save(posixGroup);
    }

    public List<PosixGroup> list() {
        return posixGroupRepository.findAll();
    }

    public Optional<PosixGroup> get(final String cn) {
        return posixGroupRepository.findByCn(cn);
    }

    public Optional<PosixGroup> update(UpdatePosixGroupDto updatePosixGroupDto) {
        final PosixGroup posixGroup = new PosixGroup();
        posixGroup.setDn(updatePosixGroupDto.getDn());
        posixGroup.setCn(updatePosixGroupDto.getCn());
        posixGroup.setGidNumber(updatePosixGroupDto.getGidNumber());
        posixGroup.setMembers(updatePosixGroupDto.getMembers());
        posixGroupRepository.save(posixGroup);
        return posixGroupRepository.findById(updatePosixGroupDto.getDn());
    }

    public void remove(final UpdatePosixGroupDto updatePosixGroupDto) {
        final PosixGroup posixGroup = new PosixGroup();
        posixGroup.setDn(updatePosixGroupDto.getDn());
        posixGroupRepository.delete(posixGroup);
    }

    public void grantBastionAccess(final String uid, final String region, final String zone) {
        final Optional<LdapUser> optionalUser = userService.get(uid);
        if (optionalUser.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "No user with this uid");
        }
        final LdapUser ldapUser = optionalUser.get();
        final String suffix = "%s-%s".formatted(region, zone);
        final List<PosixGroup> posixGroups = list().stream().filter(Objects::nonNull).toList();
        final List<PosixGroup> filteredPosixGroups = posixGroups.stream().filter(posixGroup -> posixGroup.getCn().contains(suffix)).toList();
        if (filteredPosixGroups.size() > 1) {
            LOGGER.debug("Matched posix group count :" + filteredPosixGroups.size());
            filteredPosixGroups.forEach(posixGroup -> LOGGER.debug("Matched posix group: " + posixGroup.getCn()));
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, "More than one posix group matched");
        }
        if (filteredPosixGroups.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "No posix group found for theses parameters");
        }
        final PosixGroup posixGroup = filteredPosixGroups.get(0);
        boolean isAlreadyInPosixGroup = posixGroup.getMembers().stream().anyMatch(member -> member.equals(ldapUser.getUid()));
        if (isAlreadyInPosixGroup) {
            LOGGER.info("L'utilisateur est déjà dans le groupe posix => Rien à faire donc !!!!");
            return;
        }
        posixGroup.getMembers().add(uid);
        posixGroupRepository.save(posixGroup);
    }

    ///// Getters & Setters :

    @Autowired
    public void setPosixGroupRepository(final PosixGroupRepository posixGroupRepository) {
        this.posixGroupRepository = posixGroupRepository;
    }

    @Autowired
    public void setUserService(final UserService userService) {
        this.userService = userService;
    }
}
