package fr.minint.console.api.project.service;

import org.openstack4j.model.identity.v3.Project;

public interface Tenant extends Project {
}
