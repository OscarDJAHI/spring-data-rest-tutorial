package fr.minint.console.api.project.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table
public class QuotaPricing extends AbstractDAOBean<Long> implements Copyable<QuotaPricing>, ToJSON {
    @Id
    private Long id;
    private String quotaUnit;
    private Double monthlyPrice;
    private Double yearlyPrice;

    @JsonProperty("quotaTypeId")
    private Long quotaType;

    ///// Constructeurs :

    public QuotaPricing(final Long id,
                        final String quotaUnit,
                        final Number monthlyPrice,
                        final Number yearlyPrice,
                        final Long quotaType) {
        this.id = id;
        this.setQuotaUnit(quotaUnit);
        this.setMonthlyPrice(monthlyPrice);
        this.setYearlyPrice(yearlyPrice);
        this.setQuotaType(quotaType);
    }

    public QuotaPricing(final String quotaUnit, final Number monthlyPrice, final Number yearlyPrice, final Long quotaType) {
        this.id = null;
        this.setQuotaUnit(quotaUnit);
        this.setMonthlyPrice(monthlyPrice);
        this.setYearlyPrice(yearlyPrice);
        this.setQuotaType(quotaType);
    }

    public QuotaPricing() {
        this(null, null, null, null, null);
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.quotaUnit,
                this.monthlyPrice,
                this.yearlyPrice,
                this.quotaType);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final QuotaPricing pricing = (QuotaPricing) that;
        boolean areEquals = Objects.equals(this.quotaUnit, pricing.quotaUnit);
        areEquals = areEquals && Objects.equals(this.monthlyPrice, pricing.monthlyPrice);
        areEquals = areEquals && Objects.equals(this.yearlyPrice, pricing.yearlyPrice);
        areEquals = areEquals && Objects.equals(this.quotaType, pricing.quotaType);
        return areEquals;
    }

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonQuotaPricing = new JSONObject();
        jsonQuotaPricing.put("id", getJSONValueOrNull(this.id));
        jsonQuotaPricing.put("quotaUnit", getJSONValueOrNull(this.quotaUnit));
        jsonQuotaPricing.put("monthlyPrice", getJSONValueOrNull(this.monthlyPrice));
        jsonQuotaPricing.put("yearlyPrice", getJSONValueOrNull(this.yearlyPrice));
        jsonQuotaPricing.put("quotaTypeId", getJSONValueOrNull(this.quotaType));
        return jsonQuotaPricing;
    }

    @Override
    public QuotaPricing copy() {
        try {
            return ((QuotaPricing) this.clone());
        } catch (final CloneNotSupportedException cloneNotSupportedException) {
            // Cela ne devrait pas arriver, car l'instance implémente l'interface Cloneable
            throw new RuntimeException(cloneNotSupportedException);
        }
    }

    ///// Getters & Setters :

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getQuotaUnit() {
        return quotaUnit;
    }

    public void setQuotaUnit(final String quotaUnit) {
        this.quotaUnit = quotaUnit;
    }

    public Double getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(final Number monthlyPrice) {
        this.monthlyPrice = (monthlyPrice == null ? 0d : monthlyPrice.doubleValue());
    }

    public Double getYearlyPrice() {
        return yearlyPrice;
    }

    public void setYearlyPrice(final Number yearlyPrice) {
        this.yearlyPrice = (yearlyPrice == null ? 0d : yearlyPrice.doubleValue());
    }

    public Long getQuotaType() {
        return quotaType;
    }

    public void setQuotaType(final Long quotaType) {
        this.quotaType = quotaType;
    }
}
