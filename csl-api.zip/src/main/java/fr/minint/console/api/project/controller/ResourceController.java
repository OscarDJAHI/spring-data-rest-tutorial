package fr.minint.console.api.project.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.api.project.ConsoleRole;
import fr.minint.console.api.project.controller.validator.project.ProjectRoleValidator;
import fr.minint.console.api.project.controller.validator.resource.NotExistingResourceValidator;
import fr.minint.console.api.project.controller.validator.resource.NumberCreatedResourceValidator;
import fr.minint.console.api.project.dto.resource.CreateResourceDto;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.api.project.service.ResourceService;
import fr.minint.console.api.project.service.ResourceServiceFactory;
import fr.minint.console.api.project.types.Category;
import fr.minint.console.library.validator.NotNullValidator;
import fr.minint.console.library.validator.rest.RequestBodyValidator;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.convert.DurationStyle;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.function.Function;
import java.util.function.Predicate;

import static fr.minint.console.api.project.types.Category.IAAS;
import static fr.minint.console.api.project.types.Category.S3;
import static fr.minint.console.api.project.utils.RequestBodyUtils.getCollectionFromRequestBody;
import static fr.minint.console.api.project.utils.TokenUtil.getFirstname;
import static fr.minint.console.library.utils.NumberUtils.convertToLong;
import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.*;
import static fr.minint.console.library.utils.keycloak.AuthenticationTokenUtils.getUserId;
import static fr.minint.console.library.utils.predicate.BeanFieldPredicate.withFieldEqualTo;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static java.util.stream.Collectors.toSet;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/resources")
@Setter(onMethod = @__(@Autowired))
public class ResourceController extends AbstractRestController {
    public static final RequestBodyValidator REQUEST_BODY_VALIDATOR = new RequestBodyValidator();
    private static final Logger LOGGER = LoggerFactory.getLogger(ResourceController.class);
    private static final NotNullValidator NOT_NULL_VALIDATOR = new NotNullValidator();
    private ResourceServiceFactory resourceServiceFactory;
    private ResourceTypeRepository resourceTypeRepository;
    private ProjectRepository projectRepository;
    private RoleRepository roleRepository;
    private ResourceRepository resourceRepository;
    private QuotaTypeRepository quotaTypeRepository;
    private ExecutorService executorService;
    private EmailNotificationService emailNotificationService;
    private transient Function<Long, URI> uriBuilder;

    // Liste des DAO's :

    //
    private int nbMaxCreatedTenants;
    private Duration nbMaxCreatedTenantsDuration;
    private HistoryRepository historyRepository;
    private RegionRepository regionRepository;
    private TagRepository tagRepository;
    private ResourceRegionRepository resourceRegionRepository;
    private RoleAssignementRepository roleAssignementRepository;
    private ZoneRepository zoneRepository;
    private ServiceAccountRepository serviceAccountRepository;
    private UserRepository userRepository;
    private ResourceTagRepository resourceTagRepository;


    //// Constructeurs :

    public ResourceController() {
        this.uriBuilder = new DefaultURIBuilder();
    }

    ///// Méthodes générales :

    private void hasS3FeatureAccess(final KeycloakAuthenticationToken keycloakAuthenticationToken, final Long resourceTypeId) throws Exception {
        final Optional<ResourceType> resourceTypeOptional = resourceTypeRepository.findById(resourceTypeId);
        if (resourceTypeOptional.isPresent()) {
            if (isS3Allowed(keycloakAuthenticationToken, resourceTypeOptional.get())) {
                return;
            }
            this.getSsiLogger().info("L'utilisateur {} a tenté d'accéder aux fonctionnalités de S3 sans qu'il ait les permissions", keycloakAuthenticationToken.getName());
            throw new ResponseStatusException(FORBIDDEN, "Vous n'êtes pas autorisé à utiliser les fonctionnalités S3");
        } else {
            final String errorMessage = "Le type de resource (id = %d) n'a pas été trouvé".formatted(resourceTypeId);
            LOGGER.error(errorMessage);
            throw new Exception(errorMessage);
        }
    }

    private void hasS3FeatureAccess(final KeycloakAuthenticationToken keycloakAuthenticationToken, final Resource resource) {
        final Optional<ResourceType> resourceTypeOptional = resourceTypeRepository.findById(resource.getResourceType().getId());
        if (resourceTypeOptional.isPresent()) {
            if (isS3Allowed(keycloakAuthenticationToken, resourceTypeOptional.get())) {
                return;
            }
            throw new ResponseStatusException(FORBIDDEN, "Vous n'êtes pas autorisé à utiliser les fonctionnalités S3");
        }
    }

    private boolean isS3Allowed(final KeycloakAuthenticationToken keycloakAuthenticationToken, final ResourceType resourceType) {
        if (!resourceType.getCategory().equals(S3.value())) {
            return true;
        }
        if (hasTokenRole(keycloakAuthenticationToken, ConsoleRole.S3)) {
            return true;
        }
        return false;
    }


    private Map<String, Tag> fetchTagsByName(final Predicate<Tag> tagPredicate) throws Exception {
        final Map<String, Tag> tagMap = new HashMap<>();
        for (Tag tag : tagRepository.findAll()) {
            tagMap.put(tag.getName(), tag);
        }
        return tagMap;
    }

    @ResponseStatus(BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }

    ///// Endpoints :

    /**
     * //
     * //    final long tokens = Long.parseLong(environment.getProperty("console.api.project.workflow.tokens"));
     * //    final long capacity = Long.parseLong(environment.getProperty("console.api.project.workflow.capacity"));
     * <p>
     * //    final long tokens = Long.parseLong(environment.getProperty("console.api.project.workflow.tenants.max"));
     * //    final long capacity = Long.parseLong(environment.getProperty("console.api.project.workflow.tenants.duration"));
     *
     * @param keycloakAuthenticationToken
     * @param createResourceDto
     * @return
     * @throws MessagingException
     * @throws IOException
     */
    @PostMapping
    public ResponseEntity<String> create(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                         @RequestBody final CreateResourceDto createResourceDto) throws MessagingException, IOException {

        try {
            // Vérification :
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            hasS3FeatureAccess(keycloakAuthenticationToken, createResourceDto.getResourceTypeId());
            final StringBuilder errorMsgBuffer = new StringBuilder();
            boolean isOK = new NotExistingResourceValidator(this.resourceRepository)
                    .validate("resourceName", Pair.of(createResourceDto.getName(), createResourceDto.getResourceTypeId()), errorMsgBuffer);
            isOK = new NumberCreatedResourceValidator(historyRepository, nbMaxCreatedTenants, nbMaxCreatedTenantsDuration, emailNotificationService)
                    .validate("nbCreatedResource", keycloakAuthenticationToken, errorMsgBuffer) && isOK;
            if (!isOK) {
                LOGGER.error("ERREUR : {}", errorMsgBuffer);
                return createErrorResponseEntity(INTERNAL_SERVER_ERROR, errorMsgBuffer.toString());
            }

            final Map<String, Object> createResourceActionResult = ActionResultFactory.create("Création de ressource");
            final Map<String, Object> getResourceActionResult = ActionResultFactory.create("Récupération de ressource");
            final Map<String, Object> updateQuotasActionResult = ActionResultFactory.create("Mise à jour des quotas de la ressource");
            final List<Map<String, Object>> results = new ArrayList<>();
            results.add(createResourceActionResult);
            results.add(getResourceActionResult);
            results.add(updateQuotasActionResult);
            Long resourceId = null;
            Resource savedResource = null;
            List<Region> foundAreas = new ArrayList<>();
            Set<Long> tagIds;
            try {

                // Création de la resource (projet, tenant, ..etc)
                final Resource resourceToCreate = new Resource();

                // Récupération du type de la ressource :
                final Long resourceTypeId = createResourceDto.getResourceTypeId();
                final Optional<ResourceType> foundResourceTypeOpt = resourceTypeRepository.findById(resourceTypeId);
                if (foundResourceTypeOpt.isEmpty()) {
                    LOGGER.error("Le type de ressource avec id = {} n'a pas été trouvé dans la base de données", resourceTypeId);
                    throw new Exception("Le type de ressource avec id = %d n'a pas été trouvé dans la base de données".formatted(resourceTypeId));
                }
                final ResourceType resourceType = foundResourceTypeOpt.get();

                // On crée les tags par défauts (région, zone, etc...) :
                if (S3.equals(resourceType.getCategory())) {
                     if (!isCollectionEmpty(createResourceDto.getS3AreaIds())) {
                        foundAreas = regionRepository.findByIdIn(createResourceDto.getS3AreaIds());
                    }
                 } else {
                    final Optional<Region> foundIAASAreaOpt = regionRepository.findById(createResourceDto.getIAASAreaId());
                    if (foundIAASAreaOpt.isEmpty()) {
                        throw new Exception("La région pour IAAS avec id = %d n'est pas dans la base de données".formatted(createResourceDto.getIAASAreaId()));
                    } else {
                          foundAreas.add(foundIAASAreaOpt.get());
                     }

                }


                resourceToCreate.setName(createResourceDto.getName());
                resourceToCreate.setDescription(createResourceDto.getDescription());
                resourceToCreate.setExternalId(createResourceDto.getExternalId());
                resourceToCreate.setResourceType(resourceTypeRepository.findById(resourceTypeId).get());
                resourceToCreate.setEnabled(true);
                resourceToCreate.setProject(projectRepository.findById(createResourceDto.getProjectId()).get());
//                resourceToCreate.setResourceQuotas(createResourceDto.getQuotas());
//                resourceToCreate.setResourceRoles(createResourceDto.getRoles());

                resourceToCreate.setZone(zoneRepository.findById(createResourceDto.getZoneId()).get());
                savedResource = resourceServiceFactory.service(resourceToCreate).create(resourceToCreate);
                // resource Regions
                for (final Region region : foundAreas) {
                    ResourceRegion resourceRegion = new ResourceRegion();
                    resourceRegion.setRegion(region);
                    resourceRegion.setResource(savedResource);
                    final ResourceRegion saved = resourceRegionRepository.save(resourceRegion);
                    savedResource.setResourceRegions(Collections.singleton(saved));
                }

                // resource Tag
                ResourceTag resourceTag = new ResourceTag();
                //resourceTag.setResource(savedResource);
                // A modifier
                resourceTag.setTag(tagRepository.findById(1L).get());
                final ResourceTag savedTag = resourceTagRepository.save(resourceTag);
                savedResource.setResourceTags(Collections.singleton(savedTag));
                resourceId = savedResource.getId();
                LOGGER.info("Ressource créée avec succès");
                historyRepository.save(new History("create-tenant", "", createResourceDto.getName(), "resource", getUserId(keycloakAuthenticationToken)));
                ActionResultFactory.success(createResourceActionResult, "Ressource créée avec succès", resourceId);
            } catch (final Exception exception) {
                if (exception.getMessage()!=null && exception.getMessage().contains("it is not permitted to have two projects with the same name in the same domain")) {
                    ActionResultFactory.error(createResourceActionResult, "Il n'est pas possible de créer deux tenants/projets Openstack avec le même nom dans le même domaine: %s".formatted(createResourceDto.getName()));
                } else {
                    ActionResultFactory.error(createResourceActionResult, "Echec de la création de la ressource");
                }
                LOGGER.error("Echec de la création de la ressource : {}", exception.getMessage(), exception);
            }
            if (resourceId == null) {
                return ok(buildJSONArrayFromListOfMap(results).toString());
            }

            // Envoi de l'email :
            final Resource theEmailResource = savedResource;
            this.executorService.submit(() -> {
                try {
                    final AccessToken accessToken = keycloakAuthenticationToken
                            .getAccount()
                            .getKeycloakSecurityContext()
                            .getToken();
                    final Optional<ResourceType> resourceTypeOptional = resourceTypeRepository.findById(theEmailResource.getResourceType().getId());
                    if (resourceTypeOptional.isEmpty()) {
                        throw new Exception("Resource Type avec id = %d".formatted(theEmailResource.getResourceType()));
                    }
                    final Category category = Category.fromName(resourceTypeOptional.get().getCategory());
                    if (category == null) {
                        throw new Exception("Pas de catégorie trouvée avec id = %s"
                                .formatted(resourceTypeOptional.get().getCategory()));
                    }
                    if (S3.equals(category)) {
                        emailNotificationService.sendResourceS3CreationNotificationEmail(accessToken.getEmail(), getFirstname(accessToken), theEmailResource);
                    } else if (IAAS.equals(category)) {
                        emailNotificationService.sendResourceCreationNotificationEmail(accessToken.getEmail(), getFirstname(accessToken), theEmailResource);
                    }
                } catch (final SendFailedException sendFailedException) {
                    LOGGER.warn("L'email de notification n'a pas pu être envoyé, probablement une erreur serveur smtp ?");
                    LOGGER.error(sendFailedException.getMessage(), sendFailedException);
                } catch (final Exception exception) {
                    LOGGER.error("Echec de l'envoi du mail de notification");
                    LOGGER.error(exception.getMessage(), exception);
                }
            });
            return ok()
                    .location(this.uriBuilder.apply(savedResource.getId()))
                    .body(buildJSONArrayFromListOfMap(results).toString());

        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error("Pb de transcodification de la réponse en JSON : {}", jsonProcessingException.getMessage());
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Pb interne de transcodification JSON");
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error("ERREUR : %s".formatted(responseStatusException.getMessage()), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage());
        } catch (final Exception exception) {
            LOGGER.error("ERREUR : %s".formatted(exception.getMessage()), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Erreur interne au serveur");
        }

    }

    @GetMapping
    public ResponseEntity<String> list(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                       @RequestParam(required = false) final String category) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        try {
            final Optional<Role> delegueRoles = roleRepository.findByName("delegue");
            if (delegueRoles.isEmpty()) {
                throw new Exception("Pas de role avec le nom = 'delegue'");
            }

            final String userUid = getUserId(keycloakAuthenticationToken);

            final List<Object> resources = new ArrayList<>();
            for (RoleAssignement roleAssignement :roleAssignementRepository.findByUserUidAndRoleIdIn(userUid, Arrays.asList(delegueRoles.get().getId(), 3L) )) {
                if (roleAssignement.getResource()!=null && roleAssignement.getResource().getResourceType().getCategory().equals(category)) {
                    continue;
                }
                if(roleAssignement.getResource()!=null)
                resources.add(roleAssignement.getResource());
                else if(roleAssignement.getProject().getResources()!=null){
                    resources.addAll(roleAssignement.getProject().getResources());
                }
            }
            return ok(buildJSONCodeFromCollection(resources));
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Erreur interne au serveur");
        }
    }

    @GetMapping("/{resource_id}")
    public ResponseEntity<String> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                      @PathVariable("resource_id") final Long id) throws MessagingException, IOException {

        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        try {
            // Définition du prédicat :
            final Optional<Role> delegueRoles = roleRepository.findByName("delegue");
            if (delegueRoles.isEmpty()) {
                throw new Exception("Pas de role avec le nom = 'delegue'");
            }

            final String userUid = getUserId(keycloakAuthenticationToken);
            final Optional<RoleAssignement> foundResourceOptional = roleAssignementRepository.findByUserUidAndResourceIdAndRoleIdIn(userUid, id, Arrays.asList(delegueRoles.get().getId(), 3L));
            if (foundResourceOptional.isEmpty()) {
                throw new ResponseStatusException(NOT_FOUND, "Resource non trouvée");
            }
            return ok(buildJSONCode(foundResourceOptional.get()));
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error(responseStatusException.getMessage(), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getReason());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Problème interne au serveur");
        }
    }

    @PutMapping("/{resource_id}")
    public ResponseEntity<String> update(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                         @PathVariable("resource_id") final Long id,
                                         @RequestBody final Map<String, Object> requestBody) {
        final String userId = getUserId(keycloakAuthenticationToken);
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOK = new ProjectRoleValidator(projectRepository, resourceRepository, roleRepository).validate("userId", Pair.of(userId, id), errorMsgBuffer);
        isOK = NOT_NULL_VALIDATOR.validate("id", id, errorMsgBuffer) && isOK;
        isOK = REQUEST_BODY_VALIDATOR.validate("id", requestBody, errorMsgBuffer) && isOK;
        isOK = REQUEST_BODY_VALIDATOR.validate("resourceTypeId", requestBody, errorMsgBuffer) && isOK;
        if (!isOK) {
            LOGGER.error("ERREUR : {}", errorMsgBuffer);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, errorMsgBuffer.toString());
        }
        final Long resourceTypeId = convertToLong(requestBody.get("resourceTypeId"));
        final Long resourceId = convertToLong(requestBody.get("id"));
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            hasS3FeatureAccess(keycloakAuthenticationToken, resourceTypeId);
            final Optional<Resource> existingResourceOpt = resourceRepository.findById(id);
            if (existingResourceOpt.isEmpty()) {
                return createErrorResponseEntity(NOT_FOUND, "Resource avec l'id = %d n'existe pas".formatted(id));
            }
            if (!resourceId.equals(id)) {
                return createErrorResponseEntity(BAD_REQUEST, "Resource id is not corresponding with the request one");
            }

            final Resource existingResource = existingResourceOpt.get();
            existingResource.setDescription((!requestBody.containsKey("description")) ? null : requestBody.get("description").toString());
            existingResource.setEnabled((!requestBody.containsKey("statusId") ? false : true));

            // Mise à jour des ResourceQuotas :
            JSONObject jsonQuota;
            ResourceQuota resourceQuota;
            final List<ResourceQuota> resourceQuotas = new ArrayList<>();
            for (Object quota : getCollectionFromRequestBody(requestBody, "quotas")) {
                resourceQuota = new ResourceQuota();
                jsonQuota = buildJSONObject(quota);
                resourceQuota.setResource(resourceRepository.findById(getJSONLongValue(jsonQuota, "resourceId")).get());
                resourceQuota.setQuotaType(quotaTypeRepository.findById(getJSONLongValue(jsonQuota, "quotaTypeId")).get());
                resourceQuota.setQuotaValue(getJSONLongValue(jsonQuota, "quotaValue"));
                resourceQuotas.add(resourceQuota);
            }
            existingResource.setResourceQuotas(resourceQuotas);

            // Mise à jour des ResourceRoles :
            final List<RoleAssignement> resourceRoles = new ArrayList<>();
            JSONObject jsonResourceRole;
            RoleAssignement resourceRole;
            for (Object role : getCollectionFromRequestBody(requestBody, "roles")) {
                jsonResourceRole = buildJSONObject(role);
                resourceRole = new RoleAssignement();
                resourceRole.setUser(userRepository.findByUid(getJSONStringValue(jsonResourceRole, "userid")));
                resourceRole.setResource(resourceRepository.findById(getJSONLongValue(jsonResourceRole, "resourceId")).get());
                resourceRole.setRole(roleRepository.findById(getJSONLongValue(jsonResourceRole, "roleId")).get());
                resourceRole.setServiceAccount(serviceAccountRepository.findById(getJSONLongValue(jsonResourceRole, "serviceAccountId")).get());
                resourceRole.setIsSynchronized(getJSONBooleanValue(jsonResourceRole, "isSynchronized", true));
                resourceRoles.add(resourceRole);
            }

            // MaJ des ResourceTags :
            JSONObject jsonResourceTag;
            ResourceTag resourceTag;
            final List<ResourceTag> resourceTags = new ArrayList<>();
            for (Object resTag : getCollectionFromRequestBody(requestBody, "tags")) {
                jsonResourceTag = buildJSONObject(resTag);
                resourceTag = new ResourceTag();
                resourceTag.setTag(tagRepository.findById(getJSONLongValue(jsonResourceTag, "tagId")).get());
                //resourceTag.setResource(resourceRepository.findById(getJSONLongValue(jsonResourceTag, "resourceId")).get());
                resourceTags.add(resourceTag);
            }
            existingResource.setResourceTags(resourceTags);
            final ResourceService resourceService = this.resourceServiceFactory.service(existingResource);
            final Resource updatedResource = resourceService.get(resourceService.update(existingResource));
            return ok(buildJSONObject(updatedResource).toString());
        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error("ERREUR : %s".formatted(jsonProcessingException.getMessage()), jsonProcessingException);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "ERREUR : Transcodification JSON de Jackson");
        } catch (final ResponseStatusException responseStatusException) {
            LOGGER.error("ERREUR : %s".formatted(responseStatusException.getMessage()), responseStatusException);
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getMessage());
        } catch (final Exception exception) {
            LOGGER.error("ERREUR : %s".formatted(exception.getMessage()), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Erreur interne lors de la mise à jour d'une ressource");
        }
    }

    @DeleteMapping("/{resource_id}")
    public ResponseEntity<String> remove(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                                         @PathVariable("resource_id") final Long id) {
        try {
            this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
            final Optional<Resource> foundResourceOpt = resourceRepository.findById(id);
            if (foundResourceOpt.isEmpty()) {
                throw new ResponseStatusException(NOT_FOUND, "Resource not found");
            }
            final Resource foundResource = foundResourceOpt.get();
            hasS3FeatureAccess(keycloakAuthenticationToken, foundResource);
            resourceRepository.deleteById(id);
            return ok("Resource (id = %d) supprimée".formatted(id));
        } catch (final ResponseStatusException responseStatusException) {
            this.getLogger().error("ERREUR : %s".formatted(responseStatusException.getReason()));
            return createErrorResponseEntity(responseStatusException.getStatus(), responseStatusException.getReason());
        } catch (final Exception exception) {
            this.getLogger().error("ERREUR : %s".formatted(exception.getMessage()));
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, "Erreur interne lors de la suppression de la ressource (id = %d)".formatted(id));
        }
    }

    ///// Getters & Setters :

    @Autowired
    public void setNbMaxCreatedTenants(@Value("${console.api.project.workflow.tenants.max}") final int nbMaxCreatedTenants) {
        this.nbMaxCreatedTenants = nbMaxCreatedTenants;
    }

    int getNbMaxCreatedTenants() {
        return nbMaxCreatedTenants;
    }

    @Autowired
    public void setNbMaxCreatedTenantsDuration(@Value("${console.api.project.workflow.tenants.duration}") final String duration) {
        this.nbMaxCreatedTenantsDuration = DurationStyle.detectAndParse(duration);
    }

    Duration getNbMaxCreatedTenantsDuration() {
        return nbMaxCreatedTenantsDuration;
    }


    // DAOs :



    @Autowired
    public void setResourceServiceFactory(final ResourceServiceFactory resourceServiceFactory) {
        this.resourceServiceFactory = resourceServiceFactory;
    }

    @Autowired
    public void setEmailNotificationService(final EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }

    public void setUriBuilder(final Function<Long, URI> uriBuilder) {
        this.uriBuilder = uriBuilder;
    }

    @Autowired
    public void setExecutorService(final ExecutorService executorService) {
        this.executorService = executorService;
    }

    public ExecutorService getExecutorService() {
        return executorService;
    }

    @Autowired
    public void setRegionRepository(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }

    @Autowired
    public void setTagRepository(TagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    @Autowired
    public void setResourceRegionRepository(ResourceRegionRepository resourceRegionRepository) {
        this.resourceRegionRepository = resourceRegionRepository;
    }

    @Autowired
    public void setRoleAssignementRepository(RoleAssignementRepository roleAssignementRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
    }
    @Autowired
    public void setServiceAccountRepository(ServiceAccountRepository serviceAccountRepository) {
        this.serviceAccountRepository = serviceAccountRepository;
    }
    @Autowired
    public void setResourceTypeRepository(ResourceTypeRepository resourceTypeRepository) {
        this.resourceTypeRepository = resourceTypeRepository;
    }
    @Autowired
    public void setProjectRepository(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }
    @Autowired
    public void setRoleRepository(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
    @Autowired
    public void setResourceRepository(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }
    @Autowired
    public void setQuotaTypeRepository(QuotaTypeRepository quotaTypeRepository) {
        this.quotaTypeRepository = quotaTypeRepository;
    }
    @Autowired
    public void setZoneRepository(ZoneRepository zoneRepository) {
        this.zoneRepository = zoneRepository;
    }

    public ServiceAccountRepository getServiceAccountRepository() {
        return serviceAccountRepository;
    }
    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    @Autowired
    public void setHistoryRepository(HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
    }



///// Classes internes :

    private static class DefaultURIBuilder implements Function<Long, URI> {

        @Override
        public URI apply(final Long resourceId) {
            return ServletUriComponentsBuilder.fromCurrentRequest()
                    .path("/{resourceId}")
                    .buildAndExpand(resourceId)
                    .toUri();
        }
    }

    private static class ActionResultFactory {

        static Map<String, Object> create(final String name) {
            final Map<String, Object> result = new HashMap<>();
            result.put("name", name);
            result.put("status", "idle");
            result.put("value", null);
            result.put("message", "Procédure pas encore exécutée");
            return result;
        }

        static void success(final Map<String, Object> actionResult, String message, Object value) {
            ActionResultFactory.success(actionResult, message);
            actionResult.put("value", value);
        }

        static void success(final Map<String, Object> actionResult, String message) {
            actionResult.put("status", "success");
            actionResult.put("message", message);
        }

        static void error(final Map<String, Object> actionResult, String message) {
            actionResult.put("status", "error");
            actionResult.put("message", message);
        }
    }


}
