package fr.minint.console.api.project.entities;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property ="id")
public class Resource {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", length = -1)
    private String name;

    @Basic
    @Column(name = "description", length = -1)
    private String description;

    @Basic
    @Column(name = "external_id", length = -1)
    private String externalId;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Basic
    @Column(name = "enabled")
    private Boolean enabled;

    @ManyToOne
    @JoinColumn(name = "resource_type", referencedColumnName = "id")
    private ResourceType resourceType;

    @ManyToOne
    @JoinColumn(name = "zone", referencedColumnName = "id")
    private Zone zone;

    @JsonBackReference("parent-resource-project")
    @ManyToOne
    @JoinColumn(name = "project", referencedColumnName = "id")
    private Project project;

    @JsonManagedReference("parent-resource-resource-quota")
    @OneToMany(mappedBy = "resource")
    private Collection<ResourceQuota> resourceQuotas;

    @JsonManagedReference("parent-resource-resource-region")
    @OneToMany(mappedBy = "resource")
    private Collection<ResourceRegion> resourceRegions;

    @JsonManagedReference("parent-resource-resource-tags")
    @OneToMany(mappedBy = "resource")
    private Collection<ResourceTag> resourceTags;

    @OneToMany(mappedBy = "resource")
    @JsonManagedReference("parent-service-account-resource")
    private Set<RoleAssignement> roleAssignements = new LinkedHashSet<>();

}
