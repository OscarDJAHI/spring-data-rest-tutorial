package fr.minint.console.api.project.controller;

 import fr.minint.console.api.project.entities.Pai;
 import fr.minint.console.api.project.repositories.PaiRepository;
 import lombok.Setter;
 import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/pais")
@Setter(onMethod = @__(@Autowired))
public class PaiController extends AbstractRestController {
    private PaiRepository paiRepository;

    ///// Définition des "endPoints" :

    @GetMapping
    public Iterable<Pai> list(final KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return paiRepository.findAll();
    }

    @GetMapping("/{pai_id}")
    public Optional<Pai> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
                             @PathVariable("pai_id") final Long paiId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return paiRepository.findById(paiId);
    }

    ///// Getters & Setters :

    @Autowired
    public void setPaiRepository(final PaiRepository paiRepository) {
        this.paiRepository = paiRepository;
    }
}
