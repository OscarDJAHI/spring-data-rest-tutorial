package fr.minint.console.api.project.configuration.rest.template;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        String token = RequestContext.getContext().getToken();

        request.getHeaders().add(RequestContext.REQUEST_HEADER_NAME, token);

        return execution.execute(request, body);
    }

}