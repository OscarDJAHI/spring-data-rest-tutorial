package fr.minint.console.api.project.types;

import static org.apache.commons.lang3.StringUtils.isEmpty;

public enum Category {
    IAAS("iaas"),
    S3("s3");

    private final String name;

    Category(final String name) {
        this.name = name;
    }

    ///// Méthodes statiques :

    /**
     * Retourne la catégortie en fonction de son nom indépendamment
     * de sa casse. <br />
     *
     * @param catName : nom de la catégorie
     * @return catégorie correspondante
     */
    public static Category fromName(final String catName) {
        if (isEmpty(catName)) {
            return null;
        }
        for (Category category : Category.values()) {
            if (!category.name.equalsIgnoreCase(catName.trim())) {
                continue;
            }
            return category;
        }
        return null;
    }

    public String value() {
        return name;
    }
}
