package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.entities.QuotaPricing;
import fr.minint.console.api.project.entities.QuotaType;
import fr.minint.console.api.project.repositories.QuotaTypeRepository;
import lombok.Setter;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Optional;

import static fr.minint.console.library.utils.json.JSONUtils.buildJSONCode;
import static fr.minint.console.library.utils.response.ResponseEntityUtils.createErrorResponseEntity;
import static org.springframework.http.HttpStatus.*;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/quota-types")
@Setter(onMethod = @__(@Autowired))
public class QuotaTypeController extends AbstractRestController {
    private QuotaTypeRepository quotaTypeRepository;

    ///// Méthodes statiques :

    private static QuotaPricing createNullQuotaPricing() {
        return new QuotaPricing(null, "", 0f, 0f, null);
    }

    ///// Définition des "end-points" :

    @GetMapping
    public ResponseEntity<String> list() {
        try {
            final JSONArray jsonQuotaTypes = new JSONArray();
            for (QuotaType quotaType : quotaTypeRepository.findAll()) {

               jsonQuotaTypes.put(buildJSONCode(quotaType));

            }
            return ok(jsonQuotaTypes.toString());
        } catch (final Exception exception) {
            this.logger.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }

    @GetMapping("/{quota_type_id}")
    public ResponseEntity<String> get(@PathVariable("quota_type_id") final Long id) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        final boolean isOK = NOT_NULL_VALIDATOR.validate("id", id, errorMsgBuffer);
        if (!isOK) {
            this.logger.error(errorMsgBuffer.toString());
            return createErrorResponseEntity(BAD_REQUEST, errorMsgBuffer.toString());
        }
        try {
            final Optional<QuotaType> foundQuotaTypeOptional = quotaTypeRepository.findById( id);
            if (foundQuotaTypeOptional.isEmpty()) {
                final String errorMessage = "Pas de quota-type trouvé avec l'id = %d".formatted(id);
                this.logger.error(errorMessage);
                return createErrorResponseEntity(NOT_FOUND, errorMessage);
            }
            final QuotaType foundQuotaType = foundQuotaTypeOptional.get();

            return ok(buildJSONCode(foundQuotaType));
        } catch (final Exception exception) {
            this.logger.error(exception.getMessage(), exception);
            return createErrorResponseEntity(INTERNAL_SERVER_ERROR, exception.getMessage());
        }
    }
    @Autowired
    public void setQuotaTypeRepository(QuotaTypeRepository quotaTypeRepository) {
        this.quotaTypeRepository = quotaTypeRepository;
    }

    ///// Getters & Setters :


}
