package fr.minint.console.api.project.utils.predicate.resource;

import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.resource.Resource;

import java.util.function.Predicate;

/**
 * <p>
 * Prédicat permettant de tester si un utilisateur (via son uid)
 * possède un rôle sur la ressource. <br />
 * </p>
 */
public class HasRolePredicate implements Predicate<Resource> {
    private final Role role;
    private final String userUid;

    public HasRolePredicate(final String userUid, final Role role) {
        this.role = role;
        this.userUid = userUid;
    }

    @Override
    public boolean test(final Resource resource) {
        if (resource == null) {
            return false;
        }
        return resource.hasUserWithRole(this.userUid, this.role);
    }

    public static Predicate<Resource> withRole(final String userUid, final Role role) {
        return new HasRolePredicate(userUid, role);
    }

    ///// Getters & Setters :

    public Role getRole() {
        return role;
    }

    public String getUserUid() {
        return userUid;
    }
}
