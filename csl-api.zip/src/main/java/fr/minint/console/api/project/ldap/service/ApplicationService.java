package fr.minint.console.api.project.ldap.service;

import fr.minint.console.api.project.ldap.model.Application;
import fr.minint.console.api.project.repository.ldap.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.support.LdapNameBuilder;
import org.springframework.stereotype.Service;

import javax.naming.Name;
import java.util.List;

@Service
public class ApplicationService {
    @Autowired
    ContextSource contextSource;

    @Autowired
    LdapTemplate ldapTemplate;

    @Autowired
    ApplicationRepository applicationRepository;

    public List<String> search(String name) {
        return ldapTemplate.search(
                "ou=applications",
                "ou=" + name,
                (AttributesMapper<String>) attrs -> (String) attrs
                        .get("cn")
                        .get());
    }

    public List<Application> list() {
        return applicationRepository.findAll();
    }

    public void create(final String name) {
        Name dn = LdapNameBuilder.newInstance()
                .add("ou", "applications")
                .add("ou", name)
                .build();
        DirContextAdapter context = new DirContextAdapter(dn);

        context.setAttributeValues("objectclass", new String[]{"organizationalUnit", "top"}); // "gosaDepartment"
        context.setAttributeValue("ou", name);

        ldapTemplate.bind(context);
    }

    public void modify(final String name) {
        Name dn = LdapNameBuilder.newInstance()
                .add("ou", "applications")
                .add("ou", name)
                .build();
        DirContextAdapter context = new DirContextAdapter(dn);

        context.setAttributeValues("objectclass", new String[]{"gosaDepartment", "organizationalUnit", "top"});
        context.setAttributeValue("ou", name);

        ldapTemplate.modifyAttributes(context);
    }

}
