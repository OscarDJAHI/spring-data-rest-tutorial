package fr.minint.console.api.project.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "resource_quota", schema = "public", catalog = "ConsoleAdapation")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property ="id")
public class ResourceQuota {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @JsonBackReference("parent-resource-resource-quota")
    @ManyToOne
    @JoinColumn(name = "resource", referencedColumnName = "id")
    private Resource resource;

    @ManyToOne
    @JoinColumn(name = "quota_type", referencedColumnName = "id")
    private QuotaType quotaType;

    @Column(name = "quota_value")
    private Long quotaValue;

}
