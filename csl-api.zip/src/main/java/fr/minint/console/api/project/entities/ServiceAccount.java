package fr.minint.console.api.project.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties({"roleAssignements"})
public class ServiceAccount {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "uid", length = -1)
    private String uid;

    @Basic
    @Column(name = "description", length = -1)
    private String description;

    @Basic
    @Column(name = "enabled")
    private Boolean enabled;

    @Basic
    @Column(name = "verified")
    private Boolean verified;

    @Basic
    @Column(name = "created_by", length = -1)
    private String createdBy;

    @Basic
    @Column(name = "approved_by", length = -1)
    private String approvedBy;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @OneToOne(mappedBy = "serviceAccount")
    @JsonBackReference("parent-service-account-role")
    private RoleAssignement roleAssignement;

    public ServiceAccount(String uid, String description, Boolean enabled, Boolean verified, String approvedBy, String createdBy) {
        this.uid = uid;
        this.description = description;
        this.enabled = enabled;
        this.verified = verified;
        this.approvedBy = approvedBy;
        this.createdBy = createdBy;
    }
}
