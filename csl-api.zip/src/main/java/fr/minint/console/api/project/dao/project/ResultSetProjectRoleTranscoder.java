package fr.minint.console.api.project.dao.project;

import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.apache.commons.lang3.StringUtils.isEmpty;

class ResultSetProjectRoleTranscoder extends AbstractResultSetTranscoder<ProjectRole> {
    private final String sqlFieldPrefix;

    ///// Constructeur(s) :

    public ResultSetProjectRoleTranscoder(final String sqlFieldPrefix) {
        this.sqlFieldPrefix = (sqlFieldPrefix == null ? null : sqlFieldPrefix.trim());
    }

    public ResultSetProjectRoleTranscoder() {
        this(null);
    }

    ///// Méthodes privées :

    private String getFieldName(final String fieldName) {
        if (isEmpty(sqlFieldPrefix)) {
            return fieldName;
        } else {
            return this.sqlFieldPrefix + "_" + fieldName;
        }
    }

    ///// Méthodes de la classe AbstractResultSetTranscoder :

    @Override
    protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
        boolean isNull = (resultSet == null);
        isNull = isNull || (processLongValue(resultSet, getFieldName("id")) == null);
        return isNull;
    }

    @Override
    protected ProjectRole doTranscode(final ResultSet resultSet) throws SQLException {
        final ProjectRole projectRole = new ProjectRole();
        projectRole.setId(processLongValue(resultSet, this.getFieldName("id")));
        projectRole.setProject(processLongValue(resultSet, this.getFieldName("project")));
        projectRole.setRole(processLongValue(resultSet, this.getFieldName("role")));
        projectRole.setUid(resultSet.getString(this.getFieldName("uid")));
        projectRole.setServiceAccount(processLongValue(resultSet, this.getFieldName("service_account")));
        projectRole.setSynchronized(resultSet.getBoolean(this.getFieldName("is_synchronized")));
        if (hasResultSetField(resultSet, this.getFieldName("name"))) {
            projectRole.setRoleName(resultSet.getString(this.getFieldName("name")));
        }

        return projectRole;
    }
}
