package fr.minint.console.api.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static java.util.Optional.empty;

/**
 * Interface représentant les services généraux. <br />
 * @param <T> : Type des objets gérés
 */
public interface GeneralService<T> {

    List<T> list();

    T update(final T tag);

    T save(final T bean);

    void delete(final T bean);

    ///// Méthodes par défaut :

    /**
     * Fonction permettant de retourner la liste des tags
     * vérifiant un prédicat passé en paramètre. <br />
     *
     * @param predicate : prédicat
     * @return liste des tags vérifiant le prédicat
     */
    default List<T> find(final Predicate<T> predicate) {
        final List<T> foundTags = new ArrayList<>();
        for (T bean : this.list()) {
            if (predicate.test(bean)) {
                foundTags.add(bean);
            }
        }
        return foundTags;
    }

    /**
     * Méthode permettant de trouver le premier élément correspondant
     * au prédicat passé en paramètre. <br />
     * @param predicate : prédicat
     * @return premier élément
     */
    default Optional<T> findFirst(final Predicate<T> predicate) {
        if (predicate == null) {
            return empty();
        }
        final List<T> foundBeans = this.find(predicate);
        if (foundBeans == null || foundBeans.isEmpty()) {
            return empty();
        }
        return Optional.of(foundBeans.get(0));
    }
}
