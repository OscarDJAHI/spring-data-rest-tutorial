package fr.minint.console.api.project.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "resource_type", schema = "public", catalog = "ConsoleAdapation")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property ="id")
public class ResourceType {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", length = -1)
    private String name;

    @Basic
    @Column(name = "label", length = -1)
    private String label;

    @Basic
    @Column(name = "category", length = -1)
    private String category;

    @Basic
    @Column(name = "color", length = -1)
    private String color;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;


    public ResourceType(long id, String name, String label, String category) {
        this.id =id;
        this.name =name;
        this.label =label;
        this.category =category;
    }
    public ResourceType copy() {
        final ResourceType copiedResourceType = new ResourceType();
        copiedResourceType.setId(this.id);
        copiedResourceType.setName(this.name);
        copiedResourceType.setLabel(this.label);
        copiedResourceType.setCategory(this.category);
        copiedResourceType.setColor(this.color);
        return copiedResourceType;
    }
}
