package fr.minint.console.api.project.service;

import fr.minint.console.api.project.dto.resource.UpdateResourceContainerDto;
import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import lombok.extern.slf4j.Slf4j;
import org.openstack4j.model.storage.object.SwiftContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;

@Slf4j
@Service
public class ObjectStorageServiceImpl implements ObjectStorageService {
    private Environment environment;
    private RestTemplate restTemplate;
    private RegionRepository regionRepository;
    private ResourceTypeRepository resourceTypeRepository;

    @Autowired
    private void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    @Autowired
    private void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Autowired
    private void setRegionRepository(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
    }

    @Autowired
    private void setResourceTypeRepository(ResourceTypeRepository resourceTypeRepository) {
        this.resourceTypeRepository = resourceTypeRepository;
    }

    /**
     * Gets base url from configuration.
     *
     * @return Base url string.
     */
    private String getBaseUrl() {
        return environment.getProperty("console.api.iaas.url");
    }

    /**
     * Finds resource region.
     *
     * @param resource A resource.
     * @return An optional region.
     */
    private Optional<Region> findRegion(Resource resource) {
        return regionRepository.findById(resource.getResourceRegions().stream().findFirst().get().getRegion().getId());
    }

    /**
     * Finds resource type.
     *
     * @param resource A resource.
     * @return An optional resource type.
     */
    private Optional<ResourceType> findResourceType(Resource resource) {
        return resourceTypeRepository.findById(resource.getResourceType().getId());
    }

    /**
     * Returns true if the resource type of the resource is "tenant", false otherwise.
     *
     * If resource type cannot be determined throws an INTERNAL_SERVER_ERROR.
     *
     * @param resource
     * @return
     */
    private boolean isTenant(Resource resource) {
        final String TENANT_RESOURCE_TYPE_NAME = "tenant";
        final Optional<ResourceType> optionalResourceType = findResourceType(resource);

        if (optionalResourceType.isPresent()) {
            return optionalResourceType.get().getName().equals(TENANT_RESOURCE_TYPE_NAME);
        } else {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Not resource type found for this resource");
        }
    }

    /**
     * Gets resource region.
     *
     * @param resource A resource.
     * @return The resource region.
     */
    private Region getRegion(Resource resource) {
        final Optional<Region> region = findRegion(resource);

        if (region.isPresent()) {
            return region.get();
        } else {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Resource region not found");
        }
    }

    /**
     * Checks the resource is a tenant or throws an exception.
     *
     * @param resource A resource.
     */
    private void checkIsTenant(Resource resource) {
        if (!isTenant(resource)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Object storage containers feature is only supported by tenants resources");
        }
    }

    private URI getUri(Resource resource, String containerName) {
        String path = containerName != null
                ? "/projects/{projectId}/object-storage/containers/{containerName}"
                : "/projects/{projectId}/object-storage/containers";

        return UriComponentsBuilder
                .fromHttpUrl(getBaseUrl())
                .path(path)
                .queryParam("provider", getRegion(resource).getName())
                .build(resource.getExternalId(), containerName);
    }

    private URI getUri(Resource resource) {
        return getUri(resource, null);
    }

    @Override
    public void createContainer(Resource resource, UpdateResourceContainerDto updateResourceContainerDto) {
        checkIsTenant(resource);
        restTemplate.put(getUri(resource).toString(), updateResourceContainerDto);
    }

    @Override
    public ResponseEntity<SwiftContainer[]> listContainers(Resource resource) {
        checkIsTenant(resource);
        log.debug("URI: " + getUri(resource));

        ResponseEntity<SwiftContainerImpl[]> responseEntity = restTemplate
                .getForEntity(getUri(resource).toString(), SwiftContainerImpl[].class);
        SwiftContainer[] containers = responseEntity.getBody();

        if (!responseEntity.hasBody() || containers == null) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "No containers in response body");
        }

        return ResponseEntity.ok(containers);
    }

    @Override
    public ResponseEntity<SwiftContainer> getContainer(Resource resource, String containerName) {
        checkIsTenant(resource);
        ResponseEntity<SwiftContainerImpl> responseEntity = restTemplate.getForEntity(getUri(resource, containerName).toString(), SwiftContainerImpl.class);

        if (responseEntity.hasBody()) {
            return ResponseEntity.ok(responseEntity.getBody());
        } else {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "No container in response body");
        }
    }

    @Override
    public void deleteContainer(Resource resource, String containerName) {
        checkIsTenant(resource);
        restTemplate.delete(getUri(resource, containerName).toString());
    }
}
