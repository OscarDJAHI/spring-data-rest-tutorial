package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.model.resource.ResourceTag;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCResourceTagDAO extends AbstractJDBCDAO<Long, ResourceTag> {
    private static final Transcoder<ResultSet, ResourceTag> RESOURCE_TAG_TRANSCODER = new ResultSetResourceTagTranscoder();

    ///// Constructeur(s) :

    public JDBCResourceTagDAO(final DataSource dataSource, String login, String password) {
        super(dataSource, login, password, "resource_tag", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESOURCE_TAG_TRANSCODER);
    }

    public JDBCResourceTagDAO(final DataSource dataSource) {
        this(dataSource, null, null);
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT id," +
                "resource AS resource_id," +
                "tag AS tag_id," +
                "created_at," +
                "updated_at " +
                " FROM " + this.tableName;
    }

    @Override
    protected String getInsertQuery(final ResourceTag resourceTag) throws Exception {
        if (resourceTag == null) {
            throw new Exception("L'objet resourceTag est nul -> on ne peut pas construire la requête");
        }
        return "INSERT INTO " +
                this.tableName +
                " (resource, tag, created_at, updated_at) " +
                "VALUES (%d, %d, now(), now())"
                        .formatted(resourceTag.getResource(), resourceTag.getTag());
    }

    @Override
    protected String getUpdateQuery(final ResourceTag resourceTag) throws Exception {
        if (resourceTag == null) {
            throw new Exception("L'objet resourceTag est nul -> on ne peut pas construire la requête de mise à jour");
        }
        if (resourceTag.getId() == null) {
            throw new Exception("L'id de l'entité resourceTag est nul -> on ne peut pas construire la requête de mise à jour");
        }
        return "UPDATE " +
                this.tableName +
                " SET resource = %d, tag = %d, updated_at = now() WHERE id = %d"
                        .formatted(resourceTag.getResource(),
                                resourceTag.getTag(),
                                resourceTag.getId());
    }

    ///// Classe(s) interne(s) :

    private static class ResultSetResourceTagTranscoder extends AbstractResultSetTranscoder<ResourceTag> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected ResourceTag doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceTag resourceTag = new ResourceTag();
            resourceTag.setId(processLongValue(resultSet, "id"));
            resourceTag.setResource(processLongValue(resultSet, "resource_id"));
            resourceTag.setTag(processLongValue(resultSet, "tag_id"));
            resourceTag.setCreatedAt(processTimestampField(resultSet, "created_at"));
            resourceTag.setUpdatedAt(processTimestampField(resultSet, "updated_at"));
            return resourceTag;
        }
    }
}
