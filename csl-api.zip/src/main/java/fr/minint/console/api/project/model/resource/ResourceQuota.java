package fr.minint.console.api.project.model.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.library.bean.Copyable;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.*;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table
public class ResourceQuota extends AbstractDAOBean<Long> implements ToJSON, Copyable<ResourceQuota> {
    @Id
    private Long id;
    private Long quotaValue;
    @JsonProperty("quotaTypeId")
    private Long quotaType;
    @JsonProperty("resourceId")
    private Long resource;

    // Champs transient :

    @Transient
    private QuotaType quotaTypeBean;

    ///// Constructeurs :

    public ResourceQuota(final Long id, final Long quotaValue, final Long quotaType, final Long resourceId) {
        this.id = id;
        this.quotaValue = quotaValue;
        this.quotaType = quotaType;
        this.resource = resourceId;
        this.quotaTypeBean = null;
    }

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonQuota = new JSONObject();
        jsonQuota.put("id", this.getId());
        jsonQuota.put("quotaValue", this.getQuotaValue());
        jsonQuota.put("quotaTypeId", this.getQuotaType());
        jsonQuota.put("resourceId", this.getResource());
        return jsonQuota;
    }

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.quotaType, this.quotaValue, this.resource);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final ResourceQuota resourceQuota = (ResourceQuota) that;
        boolean areEquals = Objects.equals(quotaType, resourceQuota.quotaType);
        areEquals = areEquals && Objects.equals(quotaValue, resourceQuota.quotaValue);
        areEquals = areEquals && Objects.equals(resource, resourceQuota.resource);
        return areEquals;
    }

    @Override
    public ResourceQuota copy() {
        final ResourceQuota copiedResourceQuota = new ResourceQuota();
        copiedResourceQuota.setId(this.id);
        copiedResourceQuota.setResource(this.resource);
        copiedResourceQuota.setQuotaType(this.quotaType);
        copiedResourceQuota.setQuotaValue(this.quotaValue);
        return copiedResourceQuota;
    }

    ///// Getters & Setters :

    public void setQuotaTypeBean(final QuotaType quotaTypeBean) {
        this.quotaTypeBean = quotaTypeBean;
        this.quotaType = (quotaTypeBean == null ? null : quotaTypeBean.getId());
    }

    public QuotaType getQuotaTypeBean() {
        return this.quotaTypeBean;
    }

    public void setQuotaType(final Long quotaTypeId) {
        this.quotaType = quotaTypeId;
    }

}
