package fr.minint.console.api.project.model;

import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.Objects;

import static java.time.Instant.now;

@Getter
@Setter
@Builder
@Table
public class Tag extends AbstractDAOBean<Long>  {
    @Id
    private Long id;
    private String name;
    private String label;
    private String color;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    ///// Constructeurs :

    public Tag(final Long id, final String name, final String label, final String color, final Instant createdAt, final Instant updatedAt) {
        this.id = id;
        this.setName(name);
        this.label = label;
        this.color = color;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Tag(final Long id, final String name) {
        this(id, name, null, null, null, null);
    }

    public Tag() {
        this(null, null, null, null, null, null);
    }

    ///// Méthodes de la classe AbstractDAOBean :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.name);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final Tag tag = (Tag) that;
        return Objects.equals(this.name, tag.name);
    }

    ///// Méthode(s) statique(s) :

    public static Tag createTag(final String name, final String label, final String color) {
        final Tag createdTag = new Tag();
        createdTag.setName(name);
        createdTag.setLabel(label);
        createdTag.setColor(color);
        createdTag.setCreatedAt(now());
        return createdTag;
    }

    ///// Getters & Setters :

    public String getColor() {
        return (color == null ? "" : color);
    }

    public void setName(final String name) {
        this.name = (name == null ? null : name.trim().toLowerCase());
    }
}
