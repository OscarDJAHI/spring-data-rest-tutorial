package fr.minint.console.api.project.utils.predicate.tag;

import fr.minint.console.api.project.model.Tag;

import java.util.function.Predicate;

public class TagNamePredicate implements Predicate<Tag> {
    private final String tagName;

    public TagNamePredicate(final String tagName) {
        this.tagName = (tagName == null ? null : tagName.trim());
    }

    @Override
    public boolean test(final Tag tag) {
        boolean isOK = (tag != null);
        isOK = isOK && (this.tagName.equalsIgnoreCase(tag.getName()));
        return isOK;
    }
}
