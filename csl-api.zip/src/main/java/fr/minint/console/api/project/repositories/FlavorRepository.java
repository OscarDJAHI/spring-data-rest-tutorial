package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.Flavor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface FlavorRepository extends JpaRepository<Flavor, Long>, JpaSpecificationExecutor<Flavor> {
}
