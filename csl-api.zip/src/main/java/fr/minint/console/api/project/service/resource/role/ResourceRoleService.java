package fr.minint.console.api.project.service.resource.role;

import fr.minint.console.api.project.entities.*;

import java.util.List;
import java.util.Optional;

public interface ResourceRoleService {
    RoleAssignement create(RoleAssignement resourceRole);
    Optional<RoleAssignement> get(Long id);
    List<RoleAssignement> list();
    RoleAssignement update(RoleAssignement resourceRole);
    void delete(RoleAssignement resourceRole);
    void delete(Long id);
}
