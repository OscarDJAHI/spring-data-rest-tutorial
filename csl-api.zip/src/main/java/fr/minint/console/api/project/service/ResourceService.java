package fr.minint.console.api.project.service;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.entities.*;

import java.util.List;
import java.util.Map;

// TODO : Remplacer l'usage de cette interface par l'utilisation d'un DAO<Resource>.
@Deprecated
public interface ResourceService {
    Resource create(Resource resource) throws Exception;
    Resource get(Long resourceId) throws Exception;
    List<Resource> list() throws Exception;
    Long update(Resource resource) throws Exception;
    void delete(Resource resource) throws Exception;
    boolean addMember(RoleAssignement resourceRole) throws Exception;
    Map<String, Object> addMember(final Resource resource, final LdapUser ldapUser, final Role role) throws Exception;
    boolean removeMember(RoleAssignement resourceRole) throws Exception;
}
