package fr.minint.console.api.project.client.s3;

import fr.minint.console.api.project.client.AbstractRestTemplateClient;
import fr.minint.console.library.validator.string.NotBlankStringValidator;
import fr.minint.console.library.validator.Validator;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;

import static fr.minint.console.library.utils.rest.RESTUtils.*;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
public class S3UserClient extends AbstractRestTemplateClient {
    private static final Validator<Object> NOT_BLANK_VALIDATOR = new NotBlankStringValidator();

    /**
     * @param userId      : id de l'utilisateur
     * @param namespaceId : id du namespace
     * @return id user des ECS S3
     * @throws Exception : En cas de problème lors de l'appel
     */
    public String addMember(final String domain, final String area, final String userId, final String namespaceId) throws Exception {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOk = NOT_BLANK_VALIDATOR.validate("domain", domain, errorMsgBuffer);
        isOk = NOT_BLANK_VALIDATOR.validate("area", area, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("userId", userId, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("namespaceId", namespaceId, errorMsgBuffer) && isOk;
        if (!isOk) {
            LOGGER.error("ERREUR : {}", errorMsgBuffer);
            throw new Exception("ERREUR : %s".formatted(errorMsgBuffer.toString()));
        }

        final HttpHeaders headers = createHttpHeaders(APPLICATION_JSON);
        final String theUrl = "%s/ecs/user/%s/add/%s".formatted(this.getBaseUrl(), userId, namespaceId);
        final Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("domain", domain);
        requestBody.put("area", area);
        printInfoMessages(LOGGER, theUrl, headers, requestBody);
        final ResponseEntity<String> httpResponse = callRESTQuery(this.restTemplate, theUrl, POST, headers, requestBody, LOGGER);
        if (httpResponse.getStatusCode().isError()) {
            LOGGER.error("Réponse en erreur : {}", httpResponse.getStatusCode());
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, httpResponse.getBody());
        }
        final JSONObject jsonResponse = new JSONObject(httpResponse.getBody());
        if (!jsonResponse.has("userId")) {
            throw new Exception("Il manque le paramètre 'userId' dans la réponse JSON");
        }
        return jsonResponse.getString("userId");
    }

    /**
     * Méthode permettant d'appeler la couche IAAS pour la génération de clé d'un
     * utilisateur S3. <br />
     *
     * @param userId      : id de l'utilisateur
     * @param namespaceId : id du namespace
     * @return la clé S3 sous la forme d'une paire de chaînes de caractères.
     * @throws Exception : En cas de problème lors du processus
     * @see Pair
     */
    public Pair<String, String> generateKey(final String domain,
                                            final String area,
                                            final String userId,
                                            final String namespaceId) throws Exception {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOk = NOT_BLANK_VALIDATOR.validate("userId", userId, errorMsgBuffer);
        isOk = NOT_BLANK_VALIDATOR.validate("namespace", namespaceId, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("domain", domain, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("area", area, errorMsgBuffer) && isOk;
        if (!isOk) {
            LOGGER.error("Erreur lors de l'appel à IAAS pour la génération de la clé : {}", errorMsgBuffer);
            throw new ResponseStatusException(BAD_REQUEST, errorMsgBuffer.toString());
        }
        final String theUrl = "%s/ecs/user/%s/generate/key".formatted(this.getBaseUrl(), userId);
        final HttpHeaders headers = createHttpHeaders(APPLICATION_JSON);
        final Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("namespace", namespaceId);
        requestBody.put("domain", domain);
        requestBody.put("area", area);
        printInfoMessages(LOGGER, theUrl, headers, requestBody);
        final ResponseEntity<String> httpResponse = callRESTQuery(this.restTemplate, theUrl, POST, headers, requestBody, LOGGER);
        if (httpResponse.getStatusCode().isError()) {
            LOGGER.error("Réponse en erreur : {}", httpResponse.getBody());
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, httpResponse.getBody());
        }
        final JSONObject jsonResponse = new JSONObject(httpResponse.getBody());
        if (!jsonResponse.has("accessKeySecret")) {
            throw new Exception("Il manque le paramètre 'accessKeySecret' dans la réponse JSON");
        }
        if (!jsonResponse.has("accessKeyId")) {
            throw new Exception("Il manque le paramètre 'accessKeyId' dans la réponse JSON");
        }
        return Pair.of(jsonResponse.getString("accessKeyId"), jsonResponse.getString("accessKeySecret"));
    }

    /**
     * @param userId      : id de l'utilisateur
     * @param namespaceId : id du namespace
     * @param ecsPolicyArn    : nom du rôle
     */
    public void addMemberRole(final String domain,
                              final String areaPattern,
                              final String userId,
                              final String namespaceId,
                              final String ecsPolicyArn) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOk = NOT_BLANK_VALIDATOR.validate("userId", userId, errorMsgBuffer);
        isOk = NOT_BLANK_VALIDATOR.validate("namespaceId", namespaceId, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("ecsPolicyArn", ecsPolicyArn, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("area", areaPattern, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("domain", domain, errorMsgBuffer) && isOk;
        if (!isOk) {
            LOGGER.error("Erreur lors de l'appel à IAAS pour l'ajout du rôle S3 : {}", errorMsgBuffer);
            throw new ResponseStatusException(BAD_REQUEST, errorMsgBuffer.toString());
        }

        // Appel à IAAS :
        final String theUrl = "%s/ecs/user/%s/add/role".formatted(this.getBaseUrl(), userId);
        final HttpHeaders httpHeaders = createHttpHeaders(APPLICATION_JSON);
        final Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("namespace", namespaceId);
        requestBody.put("role", ecsPolicyArn);
        requestBody.put("domain", domain);
        requestBody.put("area", areaPattern);
        printInfoMessages(LOGGER, theUrl, httpHeaders, requestBody);
        final ResponseEntity<String> httpResponse = callRESTQuery(this.restTemplate, theUrl, POST, httpHeaders, requestBody, LOGGER);
        if (httpResponse.getStatusCode().isError()) {
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, httpResponse.getBody());
        }
    }


    public void removeMember(final String domain,
                             final String areaPattern,
                             final String uid,
                             final String namespaceName) {
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isOk = NOT_BLANK_VALIDATOR.validate("domain", domain, errorMsgBuffer);
        isOk = NOT_BLANK_VALIDATOR.validate("area", areaPattern, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("uid", uid, errorMsgBuffer) && isOk;
        isOk = NOT_BLANK_VALIDATOR.validate("namespaceName", namespaceName, errorMsgBuffer) && isOk;
        if (!isOk) {
            LOGGER.error("Erreur lors de la suppression d'un membre dans un namespace S3: {}", errorMsgBuffer);
            throw new ResponseStatusException(BAD_REQUEST, errorMsgBuffer.toString());
        }
        final String url = "%s/ecs/user/%s/remove/%s".formatted(this.getBaseUrl(), uid, namespaceName);
        final Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("domain", domain);
        requestBody.put("area", areaPattern);
        final HttpHeaders httpHeaders = createHttpHeaders(APPLICATION_JSON);
        printInfoMessages(LOGGER, url, httpHeaders, requestBody);
        final ResponseEntity<String> responseEntity = callRESTQuery(this.restTemplate, url, POST, httpHeaders, requestBody, LOGGER);
        if (responseEntity.getStatusCode().isError()) {
            throw new ResponseStatusException(INTERNAL_SERVER_ERROR, responseEntity.getBody());
        }
    }

    ///// Getters & Setters :

    @Autowired
    @Override
    public void setRestTemplate(final RestTemplate restTemplate) {
        super.setRestTemplate(restTemplate);
    }

    @Autowired
    @Override
    public void setEnvironment(final Environment environment) {
        super.setEnvironment(environment);
    }
}
