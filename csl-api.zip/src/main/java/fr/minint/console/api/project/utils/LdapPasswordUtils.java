package fr.minint.console.api.project.utils;

import org.apache.commons.codec.digest.Sha2Crypt;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class LdapPasswordUtils {
    public static String hashWithSha512(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-512");
        byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
        byte[] encodedHash = Base64.getEncoder().encode(hash);

        return "{SHA512}" + new String(encodedHash);
    }

    public static String hashWithSha256(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
        byte[] encodedHash = Base64.getEncoder().encode(hash);

        return "{SHA256}" + new String(encodedHash);
    }

    public static String hashWithSha(String originalString) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA");
        byte[] hash = md.digest(originalString.getBytes(StandardCharsets.UTF_8));
        byte[] encodedHash = Base64.getEncoder().encode(hash);

        return "{SHA}" + new String(encodedHash);
    }

    public static String hashWithSaltedSha256(final String password) {
        if (password == null) {
            return "";
        }
        return "{CRYPT}%s".formatted(Sha2Crypt.sha256Crypt(password.getBytes()));
    }

    public static String hashWithSaltedSha256(String password, String salt) {
        return "{CRYPT}%s".formatted(Sha2Crypt.sha256Crypt(password.getBytes(), salt));
    }

    public static String hashWithSaltedSha512(String password) {
        return "{CRYPT}%s".formatted(Sha2Crypt.sha512Crypt(password.getBytes()));
    }

    public static String hashWithSaltedSha512(String password, String salt) {
        return "{CRYPT}%s".formatted(Sha2Crypt.sha512Crypt(password.getBytes(), salt));
    }
}
