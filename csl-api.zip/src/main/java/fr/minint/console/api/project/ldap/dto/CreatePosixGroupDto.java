package fr.minint.console.api.project.ldap.dto;

import lombok.Data;

@Data
public class CreatePosixGroupDto {
    String cn;
    String gidNumber;
}
