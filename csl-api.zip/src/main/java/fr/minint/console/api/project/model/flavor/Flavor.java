package fr.minint.console.api.project.model.flavor;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Flavor {
    @Id
    Long id;
    String name;
    String external_id;

    @JsonProperty("zoneId")
    Long zone;

    Set<FlavorQuota> quotas;
}
