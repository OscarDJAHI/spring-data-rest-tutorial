package fr.minint.console.api.project.model.project;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.model.Pai;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.User;
import fr.minint.console.api.project.model.document.VersionedDocument;
import fr.minint.console.api.project.model.document.VersionedDocumentType;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.annotation.*;
import org.springframework.data.relational.core.mapping.Table;

import java.time.Instant;
import java.util.*;
import java.util.function.Predicate;

import static fr.minint.console.api.project.model.Role.RSSI_ROLE_NAME;
import static fr.minint.console.api.project.model.document.VersionedDocumentType.CGU;
import static fr.minint.console.library.comparator.DefaultComparator.createDefaultComparator;
import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.*;
import static fr.minint.console.library.utils.predicate.BeanFieldPredicate.withFieldEqualTo;
import static java.util.stream.Collectors.toSet;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Table
public class Project extends AbstractDAOBean<Long> implements ToJSON {
    private static final Logger LOGGER = LoggerFactory.getLogger(Project.class);
    @Id
    private Long id;
    private String name;
    private String label;
    private String description;
    @CreatedBy
    private String ownerId;
    @CreatedDate
    private Instant createdAt;
    @LastModifiedDate
    private Instant updatedAt;

    @JsonProperty("statusId")
    private Long status;
    @JsonProperty("paiId")
    private Long pai;

    @Transient
    private Set<ProjectRole> projectRoles;

    @Transient
    private TreeSet<VersionedDocument> projectDocuments;

    @Transient
    private Pai projectPai;


    ///// Constructeurs :

    public Project(final Long id, final String name, final String ownerId) {
        this.id = id;
        this.name = name;
        this.ownerId = ownerId;
        this.label = name;
    }

    public Project(final Long id, final String ownerId) {
        this(id, null, ownerId);
    }

    public Project() {
        this(null, null, null);
    }

    ///// Méthodes de la classe AbstractBean :

    @Override
    protected int functionnalHashCode() {
        return (name == null ? 0 : Objects.hashCode(this.name.trim()));
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this.getClass() != that.getClass()) {
            return false;
        }
        return Objects.equals(this.getName(), ((Project) that).getName());
    }

    @Override
    public JSONObject toJSON() {
        try {
            final JSONObject jsonProject = new JSONObject();
            jsonProject.put("id", convertIntoSimpleJSONValue(this.getId()));
            jsonProject.put("name", convertIntoSimpleJSONValue(this.getName()));
            jsonProject.put("label", convertIntoSimpleJSONValue(this.getLabel()));
            jsonProject.put("description", convertIntoSimpleJSONValue(this.getDescription()));
            jsonProject.put("ownerId", convertIntoSimpleJSONValue(this.getOwnerId()));
            jsonProject.put("createdAt", convertIntoSimpleJSONValue(this.getCreatedAt()));
            jsonProject.put("updatedAt", convertIntoSimpleJSONValue(this.getUpdatedAt()));
            jsonProject.put("statusId", convertIntoSimpleJSONValue(this.getStatus()));
            jsonProject.put("paiId", convertIntoSimpleJSONValue(this.getPai()));
            jsonProject.put("cguId", convertIntoSimpleJSONValue(this.getCguId()));
            jsonProject.put("docs", buildJSONArrayFromCollection(this.getProjectDocuments()));
            jsonProject.put("pai", buildJSONObject(this.getProjectPai()));
            jsonProject.put("roles", buildJSONArrayFromCollection(this.getProjectRoles()));
            final Optional<ProjectRole> rssiProjectRole = this.getRssiProjectRole();
            if (rssiProjectRole.isEmpty() || rssiProjectRole.get().getUser() == null) {
                jsonProject.put("rssiUser", new JSONObject());
            } else {
                jsonProject.put("rssiUser", rssiProjectRole.get().getUser().toJSON());

            }
            return jsonProject;
        } catch (final JsonProcessingException jsonProcessingException) {
            LOGGER.error("ERREUR FATALE : {}", jsonProcessingException.getMessage());
            throw new RuntimeException(jsonProcessingException);
        }
    }

    ///// Méthodes générales :

    public void clearDocuments(final VersionedDocumentType documentType) {
        if (documentType == null) {
            return;
        }
        final Set<VersionedDocument> docToDelete = this.getProjectDocuments()
                .stream()
                .filter(doc -> documentType == doc.getDocType())
                .collect(toSet());
        this.getProjectDocuments().removeAll(docToDelete);
    }

    public void addDocument(final VersionedDocument document) {
        if (document == null) {
            return;
        }
        this.getProjectDocuments().add(document);
    }

    /**
     * Méthode permettant de tester si un projet possède un utilisateur donné
     * avec un rôle donné. <br />
     *
     * @param userUid uid de l'utilisateur
     * @param role    : role
     * @return booléen montrant le résultat.
     */
    public boolean hasUserWithRole(final String userUid, final Role role) {
        if (StringUtils.isEmpty(userUid) || role == null) {
            return false;
        }
        Predicate<ProjectRole> predicate = withFieldEqualTo(ProjectRole.class, "uid", userUid);
        predicate = predicate.and(withFieldEqualTo(ProjectRole.class, "role", role.getId()));
        return this.getProjectRoles().stream().anyMatch(predicate);
    }

    /**
     * Cette méthode permet d'ajouter un rôle à un utilisateur. <br />
     *
     * @param userUid : uid de l'utilisateur
     * @param role    : role à ajouter
     */
    public void addRoleToUser(final String userUid, final Role role) {
        if (isEmpty(userUid) || role == null) {
            return;
        }
        final ProjectRole projectRole = new ProjectRole(userUid, this.getId(), role.getId());
        projectRole.setRoleName(role.getName());
        this.getProjectRoles().add(projectRole);
    }

    public void addRoleToUser(final User user, final Role role) {
        if (user == null || isEmpty(user.getRio()) || role == null) {
            return;
        }
        final ProjectRole projectRole = new ProjectRole(user.getRio(), this.getId(), role.getId());
        projectRole.setRoleName(role.getName());
        projectRole.setUser(user);
        this.getProjectRoles().add(projectRole);
    }

    public void removeRoleToUser(final Predicate<Pair<String, Role>> pairPredicate) {
        if (pairPredicate == null) {
            return;
        }
        final Set<ProjectRole> projectRolesToDelete = new HashSet<>();
        for (ProjectRole projectRole : this.getProjectRoles()) {
            if (!pairPredicate.test(Pair.of(projectRole.getUid(), new Role(projectRole.getRole(), projectRole.getRoleName())))) {
                continue;
            }
            projectRolesToDelete.add(projectRole);
        }
        if (!isCollectionEmpty(this.projectRoles) && !isCollectionEmpty(projectRolesToDelete)) {
            this.projectRoles.removeAll(projectRolesToDelete);
        }
    }

    /**
     * Méthode permettant de supprimer tous les rôles attachés
     * au projet. <br />
     */
    public void clearRoles() {
        this.getProjectRoles().clear();
    }


    ///// Getters & Setters :

    public void setId(final Long projectId) {
        this.id = projectId;
        for (ProjectRole projectRole : this.getProjectRoles()) {
            projectRole.setProject(projectId);
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return (name == null ? null : name.trim());
    }

    public Set<ProjectRole> getProjectRoles() {
        if (projectRoles == null) {
            this.projectRoles = new HashSet<>();
        }
        return projectRoles;
    }

    public void setProjectRoles(final Collection<ProjectRole> projectRoles) {
        this.projectRoles = new HashSet<>();
        if (isCollectionEmpty(projectRoles)) {
            return;
        }
        for (ProjectRole projectRole : projectRoles) {
            if (projectRole == null) {
                continue;
            }
            projectRole.setProject(this.getId());
            this.projectRoles.add(projectRole);
        }
    }

    public TreeSet<VersionedDocument> getProjectDocuments() {
        if (this.projectDocuments == null) {
            this.projectDocuments = new TreeSet<>();
        }
        return projectDocuments;
    }

    public void setProjectDocuments(final Collection<? extends VersionedDocument> projectDocuments) {
        this.projectDocuments = (isCollectionEmpty(projectDocuments) ? new TreeSet<>() : new TreeSet<>(projectDocuments));
    }

    public Pai getProjectPai() {
        return this.projectPai;
    }

    public void setPai(final Pai projectPai) {
        this.projectPai = projectPai;
        this.pai = (projectPai == null ? null : projectPai.getId());
    }

    public void setPai(final Long paiId) {
        this.pai = paiId;
    }

    public Integer getCGUVersion() {
        return this.getProjectDocuments()
                .stream()
                .filter(doc -> doc.getDocType() == CGU)
                .max(createDefaultComparator())
                .map(VersionedDocument::getVersionNumber)
                .orElse(null);
    }

    public Long getCguId() {
        return this.getProjectDocuments()
                .stream()
                .filter(doc -> CGU == doc.getDocType())
                .max(createDefaultComparator())
                .map(VersionedDocument::getId)
                .orElse(null);
    }

    public String getRssi() {
        final Optional<ProjectRole> rssiProjRoleOptional = getRssiProjectRole();
        if (rssiProjRoleOptional.isEmpty()) {
            return "";
        } else {
            return rssiProjRoleOptional.get().getUid();
        }
    }

    private Optional<ProjectRole> getRssiProjectRole() {
        return this
                .getProjectRoles()
                .stream()
                .filter(projRole -> RSSI_ROLE_NAME.equals(projRole.getRoleName()))
                .findFirst();
    }

    public String getLabel() {
        return this.label;
    }

    public String getDescription() {
        return this.description;
    }

    public String getOwnerId() {
        return this.ownerId;
    }

    public Instant getCreatedAt() {
        return this.createdAt;
    }

    public Instant getUpdatedAt() {
        return this.updatedAt;
    }

    public Long getStatus() {
        return this.status;
    }

    public Long getPai() {
        return this.pai;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public void setOwnerId(final String ownerId) {
        this.ownerId = ownerId;
    }

    public void setCreatedAt(final Instant createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(final Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    @JsonProperty("statusId")
    public void setStatus(Long status) {
        this.status = status;
    }

    public void setProjectPai(Pai projectPai) {
        this.projectPai = projectPai;
    }


    ///// Classe(s) interne(s) :

    public static class HasUserWithRolePredicate implements Predicate<Project> {
        private final String uid;
        private final Role role;

        private HasUserWithRolePredicate(final String uid,
                                         final Role role) {
            this.uid = uid;
            this.role = role;
        }

        @Override
        public boolean test(final Project project) {
            if (project == null) {
                return false;
            }
            return project.hasUserWithRole(uid, role);
        }

        public static Predicate<Project> hasProjectWithUserWithRole(final LdapUser ldapUser, final Role role) {
            return hasProjectWithUserWithRole(ldapUser.getUid(), role);
        }

        public static Predicate<Project> hasProjectWithUserWithRole(final String uid, final Role role) {
            return new HasUserWithRolePredicate(uid, role);
        }

    }

}