package fr.minint.console.api.project.dao.project;

import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;

import javax.sql.DataSource;
import java.sql.ResultSet;

public class JDBCProjectRoleDAO extends AbstractJDBCDAO<Long, ProjectRole> {
    private static final Transcoder<ResultSet, ProjectRole> RESULT_SET_PROJECT_ROLE_TRANSCODER = new ResultSetProjectRoleTranscoder();

    ///// Constructeur(s) :

    public JDBCProjectRoleDAO(final DataSource dataSource) {
        super(dataSource, "project_role", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_PROJECT_ROLE_TRANSCODER);
    }

    ///// Définition des requêtes SQL :

    @Override
    public String getSelectAllQuery() {
        return "SELECT id," +
                "project," +
                "\"role\"," +
                "uid," +
                "service_account," +
                "is_synchronized," +
                "created_at," +
                "updated_at" +
                " FROM " + this.tableName;
    }

    @Override
    protected String getInsertQuery(final ProjectRole projectRole) throws Exception {
        if (projectRole == null) {
            throw new Exception("L'instance ProjectRole est nulle --> On ne peut pas construire la requête d'insertion");
        }
        return "INSERT INTO project_role " +
                "(project, \"role\", uid, service_account, is_synchronized, created_at, updated_at) " +
                "VALUES (%d, %d, %s, %d, %s, now(), now())"
                        .formatted(projectRole.getProject(),
                                projectRole.getRole(),
                                escapeSQL(projectRole.getUid()),
                                projectRole.getServiceAccount(),
                                (projectRole.isSynchronized() ? "true" : "false"));
    }

    @Override
    protected String getUpdateQuery(final ProjectRole projectRole) throws Exception {
        if (projectRole == null) {
            throw new Exception("L'instance ProjectRole est nulle --> On ne peut pas construire la requête de mise à jour");
        }
        return "UPDATE project_role " +
                "SET project=%d, \"role\"=%d, uid=%s, service_account=%d, is_synchronized=%s, updated_at=now() WHERE id=%d"
                        .formatted(projectRole.getProject(),
                                projectRole.getRole(),
                                escapeSQL(projectRole.getUid()),
                                projectRole.getServiceAccount(),
                                (projectRole.isSynchronized() ? "true" : "false"),
                                projectRole.getId());
    }

}
