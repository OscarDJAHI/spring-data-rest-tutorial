package fr.minint.console.api.project.ldap.dto;

import lombok.Data;

@Data
public class CreateServiceAccountDto {
    String category;
    String name;
    String password;
}
