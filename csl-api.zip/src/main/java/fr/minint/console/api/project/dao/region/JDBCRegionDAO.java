package fr.minint.console.api.project.dao.region;

import fr.minint.console.api.project.model.Region;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCRegionDAO extends AbstractJDBCDAO<Long, Region> {
    private static final Transcoder<ResultSet, Region> RESULT_SET_AREA_TRANSCODER = new ResultSetAreaTranscoder();

    ///// Constructeurs :

    public JDBCRegionDAO(final DataSource dataSource) {
        super(dataSource, "region", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_AREA_TRANSCODER);
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    protected String getInsertQuery(final Region area) {
        return "INSERT INTO region" +
                " (name, \"label\", color, created_at, updated_at) " +
                " VALUES (%s, %s, %s, now(), now())"
                        .formatted(escapeSQL(area.getName()),
                                escapeSQL(area.getLabel()),
                                escapeSQL(area.getColor()));
    }

    @Override
    protected String getUpdateQuery(final Region area) throws Exception {
        if (area == null) {
            throw new Exception("La région est nulle -> on ne peut donc pas créer la requête de mise à jour !!");
        }
        return "UPDATE region " +
                "SET \"name\"=%s, \"label\"=%s, color=%s, updated_at=now() WHERE id = %d"
                        .formatted(escapeSQL(area.getName()), escapeSQL(area.getLabel()), escapeSQL(area.getColor()), area.getId());
    }

    ///// Classe(s) interne(s) :

    private static class ResultSetAreaTranscoder extends AbstractResultSetTranscoder<Region> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected Region doTranscode(final ResultSet resultSet) throws SQLException {
            final Region area = new Region();
            area.setId(processLongValue(resultSet, "id"));
            area.setName(resultSet.getString("name"));
            area.setLabel(resultSet.getString("label"));
            area.setColor(resultSet.getString("color"));
            return area;
        }
    }
}
