package fr.minint.console.api.project.model;

import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.util.Objects;

@Table
public class Pai extends AbstractDAOBean<Long> implements ToJSON {
    @Id
    private Long id;
    private String code;
    private String name;
    private String description;

    ///// Constructeur(s) :

    public Pai(final Long id, final String code, final String name, final String description) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.description = description;
    }

    public Pai(final String name, final String code, final String description) {
        this(null, code, name, description);
    }

    public Pai() {
        this(null, null, null, null);
    }

    ///// Méthodes de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        final JSONObject jsonPAI = new JSONObject();
        jsonPAI.put("id", id);
        jsonPAI.put("code", code);
        jsonPAI.put("name", name);
        jsonPAI.put("description", description);
        return jsonPAI;
    }

    ///// Méthode(s) de la classe AbstractDAOBean

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.code, this.name, this.description);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        final Pai pai = (Pai) that;
        boolean areEquals = Objects.equals(this.code, pai.code);
        areEquals = areEquals && Objects.equals(this.name, pai.name);
        areEquals = areEquals && Objects.equals(this.description, pai.description);
        return areEquals;
    }

    ///// Getters & Setters :

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(final Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }
}
