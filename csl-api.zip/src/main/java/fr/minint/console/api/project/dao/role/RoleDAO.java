package fr.minint.console.api.project.dao.role;

import fr.minint.console.api.project.model.Role;
import fr.minint.console.persistence.dao.jpa.data.DefaultCrudRepositoryDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.repository.CrudRepository;

public class RoleDAO extends DefaultCrudRepositoryDAO<Long, Role> {
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleDAO.class);

    public RoleDAO(final CrudRepository<Role, Long> crudRepository) {
        super(crudRepository);
    }

    @Override
    public void close() {
        LOGGER.info("---> Fermeture de l'instance de RoleDAO");
    }
}
