package fr.minint.console.api.project.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

@Data
@EqualsAndHashCode(callSuper = true)
public class TagDto extends CreateTagDto {
    @NotNull
    private Long id;
}
