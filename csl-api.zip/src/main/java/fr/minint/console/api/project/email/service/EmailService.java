package fr.minint.console.api.project.email.service;

import org.thymeleaf.context.IContext;

import javax.mail.MessagingException;
import java.io.IOException;

public interface EmailService {

    void sendMessage(String to, String subject, String content);

    void sendTemplatedMessage(String to, String subject, String template) throws MessagingException;

    void sendThymeleafTemplatedMessage(
            String to,
            String subject,
            String template,
            IContext context
    ) throws IOException, MessagingException;

    void sendThymeleafTemplatedMessageWithCc(String to,
                                             String cc,
                                             String subject,
                                             String template,
                                             IContext context) throws IOException, MessagingException;

    void sendThymeleafTemplatedMessageWithAttachment(
            String to,
            String subject,
            String template,
            IContext context,
            String fileToAttach
    ) throws IOException, MessagingException;

    void sendMailWithAttachment(String to, String subject, String body, String fileToAttach);

    void sendMailWithInlineResources(String to, String subject, String fileToAttach);
}
