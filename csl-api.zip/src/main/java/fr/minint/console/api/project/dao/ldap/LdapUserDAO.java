package fr.minint.console.api.project.dao.ldap;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import fr.minint.console.persistence.dao.ldap.DefaultLdapRepositoryDAO;

import java.util.*;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.collection.SetUtils.newSet;
import static java.util.Collections.singleton;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.ldap.query.LdapQueryBuilder.query;

public class LdapUserDAO extends DefaultLdapRepositoryDAO<LdapUser> {

    public LdapUserDAO(final UserLdapRepository ldapRepository) {
        super(ldapRepository);
    }

    private List<LdapUser> foundLdapUsersFromRios(final Collection<String> ldapUserRios) {
        final Set<LdapUser> foundLdapUsers = new HashSet<>();
        Set<LdapUser> foundLdapUserCollection;
        for (String ldapUserRio : ldapUserRios) {
            foundLdapUserCollection = newSet(ldapRepository.findAll(query().where("uid").is(ldapUserRio)));
            if (isCollectionEmpty(foundLdapUserCollection)) {
                continue;
            }
            foundLdapUsers.addAll(foundLdapUserCollection);
        }
        return new ArrayList<>(foundLdapUsers);
    }

    ///// Méthodes de l'interface DAO :

    @Override
    public List<LdapUser> select(final Predicate<LdapUser> predicate) throws Exception {
        if (predicate instanceof LdapUserRIOInCollectionPredicate rioInCollectionPredicate) {
            return foundLdapUsersFromRios(rioInCollectionPredicate.getLdapUserRios());
        } else if (predicate instanceof LdapUserRIOPredicate rioPredicate) {
            return foundLdapUsersFromRios(singleton(rioPredicate.getLdapUserRio()));
        }
        return super.select(predicate);
    }

    ///// Classe(s) interne(s) :

    /**
     * <p>
     * Prédicat permettant de filtrer ou tester les instances de LdapUser
     * possédant une valeur donnée de RIO.<br />
     * </p>
     *
     * @see Predicate
     */
    public static class LdapUserRIOPredicate implements Predicate<LdapUser> {
        private final String ldapUserRio;

        private LdapUserRIOPredicate(final String ldapUserRio) {
            this.ldapUserRio = ldapUserRio;
        }

        @Override
        public boolean test(final LdapUser ldapUser) {
            if (ldapUser == null) {
                return false;
            }
            return Objects.equals(this.ldapUserRio, (ldapUser.getUid() == null ? null : ldapUser.getUid().trim()));
        }

        ///// Méthode(s) statique(s) :

        public static Predicate<LdapUser> withLdapUserRIO(final String rio) {
            return new LdapUserRIOPredicate((rio == null ? null : rio.trim()));
        }

        ///// Getters & Setters :

        public String getLdapUserRio() {
            return ldapUserRio;
        }
    }

    public static class LdapUserRIOInCollectionPredicate implements Predicate<LdapUser> {
        private final Set<String> ldapUserRios;

        public LdapUserRIOInCollectionPredicate(final Collection<String> ldapUserRios) {
            this.ldapUserRios = (ldapUserRios == null ? new HashSet<>() : new HashSet<>(ldapUserRios));
        }

        @Override
        public boolean test(final LdapUser ldapUser) {
            boolean isOk = ldapUser != null;
            isOk = isOk && (!isEmpty(ldapUser.getUid()));
            isOk = isOk && (ldapUserRios.contains(ldapUser.getUid()));
            return isOk;
        }

        public static Predicate<LdapUser> withLdapUserRIOInCollection(final Collection<String> rios) {
            return new LdapUserRIOInCollectionPredicate(rios);
        }

        public Set<String> getLdapUserRios() {
            return ldapUserRios;
        }
    }
}
