package fr.minint.console.api.project.model;

import fr.minint.console.api.project.model.project.Project;

/**
 * <p>
 * Interface représentant tous les objects possédant
 * une instance Project. <br />
 * </p>
 *
 * @see Project
 */
public interface HasProject {

    /**
     * Retourne l'instance de Project associée à l'instance
     * courante.
     *
     * @return instance de Project
     */
    Project getProjectBean();
}
