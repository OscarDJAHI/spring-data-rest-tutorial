package fr.minint.console.api.project.dto.resource;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.library.utils.ToMap;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Deprecated
@Data
public class CreateResourceDto implements ToMap {

    @NotBlank()
    @Size(max = 64)
    @Pattern(regexp = "^[a-z][a-z0-9-]+$", message = "Must begin by lower case characters and contain only lower case characters, numbers and hyphens")
    private String name;

    @Size(max = 4000, message = "Description must be lesser than 4000 characters")
    private String description;

    private String externalId;

    @NotNull
    private Long resourceTypeId;

    @NotNull
    private Long zoneId;

    @NotNull
    private Long regionId;

    @NotNull
    private Long statusId;

    @NotNull
    private Long projectId;

    @NotNull
    private Set<ResourceQuota> quotas;

    @NotNull
    private Set<RoleAssignement> roles;

    @NotNull
    private Set<ResourceTag> tags;

    @NotNull
    private Set<ResourceRegion> regions;

    ///// Méthodes générales :

    /**
     * Ajout d'un tag
     *
     * @param tag : Tag à ajouter
     */
    public void addTag(final Tag tag) {
        if (this.tags == null) {
            this.tags = new HashSet<>();
        }
        final ResourceTag resourceTag = new ResourceTag();
        resourceTag.setTag(tag);
        this.tags.add(resourceTag);
    }

    public void addArea(final Region area) {
        if (this.regions == null) {
            this.regions = new HashSet<>();
        }
        if (area == null) {
            return;
        }
        final ResourceRegion resourceArea = new ResourceRegion();
        resourceArea.setRegion(area);
        this.regions.add(resourceArea);
    }

    @Override
    public Map<String, Object> toMap() {
        throw new RuntimeException("A Implémenter !!");
    }

    ///// Getters & Setters :

    public Long getIAASAreaId() {
        return this.regionId;
    }

    public List<Long> getS3AreaIds() {
        return this.getRegions()
                .stream()
                .map(ResourceRegion::getRegion).map(Region::getId)
                .collect(Collectors.toList());
    }

    public Set<ResourceRegion> getRegions() {
        if (regions == null) {
            this.regions = new HashSet<>();
        }
        return regions;
    }

    public Set<ResourceTag> getTags() {
        if (tags == null) {
            this.tags = new HashSet<>();
        }
        return tags;
    }

    public Set<ResourceQuota> getQuotas() {
        if (quotas == null) {
            this.quotas = new HashSet<>();
        }
        return quotas;
    }

    public Set<RoleAssignement> getRoles() {
        if (this.roles == null) {
            this.roles = new HashSet<>();
        }
        return roles;
    }
}
