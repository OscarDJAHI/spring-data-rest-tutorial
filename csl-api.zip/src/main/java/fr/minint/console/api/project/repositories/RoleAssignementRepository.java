package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface RoleAssignementRepository extends JpaRepository<RoleAssignement, Long>, JpaSpecificationExecutor<RoleAssignement> {
    Optional<RoleAssignement> findByRoleIdAndProjectId(Long roleId, Long projectId);
    Optional<RoleAssignement> findByRoleIdAndProjectIdAndUserId(Long roleId, Long projectId, Long userID);
    List<RoleAssignement> findByUserIdAndRoleIdIn(Long userId, Collection<Long> roles);
    List<RoleAssignement> findByUserUidAndRoleIdIn(String userId, Collection<Long> roles);
    List<RoleAssignement> findAllByProjectIdAndResourceIdNotNull(Long projectId);

    List<RoleAssignement> findAllByProjectIdAndResourceId(Long projectId, Long resourceId);

    List<RoleAssignement> findByProjectIdAndRoleIdIn(Long projectId, List<Long> roleIds);

    List<RoleAssignement> findByResourceIdAndRoleId(Long resource, Long role);

    Optional<RoleAssignement> findByUserUidAndRoleIdAndResourceId(String uid, Long id, Long id1);

    Optional<RoleAssignement> findByUserUidAndResourceIdAndRoleIdIn(String userUid, Long resourceId, Collection<Long> roleIds);

    RoleAssignement deleteByProjectId(Long projectId);

    Set<RoleAssignement> findByProjectIdAndRoleIdAndUserUidAndServiceAccountId(Long project_id, Long role_id, String user_uid, Long serviceAccount_id);

    List<RoleAssignement> findByUserUidAndRoleId(String uid, Long roleId);

    List<RoleAssignement> findByUserUid(String userUid);

    Optional<RoleAssignement> findByUserUidAndProjectId(String userId, Long projectId);

    Optional<RoleAssignement> findByProjectIdAndUserUidAndRoleIdIn(Long projectId, String uid, List<Long> list);

    List<RoleAssignement> findAllByProjectIdAndResourceIdAndServiceAccountNotNull(Long projectId, Long resourceId);

    List<RoleAssignement> findByProjectIdAndRoleIdAndServiceAccountId(Long projectId, Long roleId, Long serviceAccountId);

    List<RoleAssignement> findByProjectIdAndRoleIdAndUserUid(Long project, Long role, String uid);
}
