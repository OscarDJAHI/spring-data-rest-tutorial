package fr.minint.console.api.project.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import static java.util.Objects.requireNonNull;

public abstract class AbstractRestTemplateClient {
    protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestTemplateClient.class);
    static final String CONSOLE_API_IAAS_URL = "console.api.iaas.url";
    protected RestTemplate restTemplate;
    protected Environment environment;

    ///// Getters & Setters :

    protected String getBaseUrl() {
        return requireNonNull(environment.getProperty(CONSOLE_API_IAAS_URL)).trim();
    }

    protected void setRestTemplate(final RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    protected void setEnvironment(final Environment environment) {
        this.environment = environment;
    }
}
