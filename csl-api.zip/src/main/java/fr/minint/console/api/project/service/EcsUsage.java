package fr.minint.console.api.project.service;

import lombok.Data;

@Data
public class EcsUsage {
    private Long totalQuota;
    private Double usedQuota;
}
