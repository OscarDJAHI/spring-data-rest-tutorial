package fr.minint.console.api.project.repository.ldap;

import fr.minint.console.api.project.ldap.model.LdapUser;
import org.springframework.data.ldap.repository.LdapRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserLdapRepository extends LdapRepository<LdapUser> {
    Optional<LdapUser> findByUid(String uid);
    Optional<LdapUser> findByMail(String email);
}
