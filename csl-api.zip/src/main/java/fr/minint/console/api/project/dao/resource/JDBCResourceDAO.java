package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.dao.region.JDBCRegionDAO;
import fr.minint.console.api.project.dao.tag.JDBCTagDAO;
import fr.minint.console.api.project.model.Region;
import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.api.project.model.Tag;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.api.project.model.resource.*;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.collection.CollectionUtils.diff;
import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONObject;
import static fr.minint.console.library.utils.predicate.EqualsPredicate.areEqualsPredicate;
import static fr.minint.console.persistence.dao.sql.JDBCUtils.isConnectionClosed;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.util.stream.Collectors.toSet;

/**
 * <p>
 * DAO utilisant une connexion JDBC afin d'interagir avec la base de données.<br />
 * </p>
 */
@SuppressWarnings("SqlSourceToSinkFlow")

public class JDBCResourceDAO extends AbstractJDBCDAO<Long, Resource> {
    static final Logger LOGGER = LoggerFactory.getLogger(JDBCResourceDAO.class);
    static final Transcoder<ResultSet, Resource> RESOURCE_TRANSCODER = new ResourceTranscoder();
    static final Transcoder<ResultSet, ResourceType> RESOURCE_TYPE_TRANSCODER = new ResourceTypeTranscoder();
    static final Transcoder<ResultSet, Project> PROJECT_TRANSCODER = new ProjectTranscoder();
    static final Transcoder<ResultSet, ProjectRole> PROJECT_ROLE_TRANSCODER = new ProjectRoleTranscoder();
    static final Transcoder<ResultSet, ResourceRole> RESOURCE_ROLE_TRANSCODER = new ResourceRoleTranscoder();
    static final Transcoder<ResultSet, ResourceQuota> RESOURCE_QUOTA_TRANSCODER = new ResourceQuotaTranscoder();
    static final Transcoder<ResultSet, ResourceTag> RESOURCE_TAG_TRANSCODER = new ResourceTagTranscoder();
    static final Transcoder<ResultSet, Set<Region>> RESOURCE_AREA_TRANSCODER = new AreaTranscoder();
    private final DAO<ResourceTag> resourceTagDAO;
    private final DAO<ResourceRole> resourceRoleDAO;
    private final DAO<ResourceRegion> resourceRegionDAO;
    private final DAO<ResourceQuota> resourceQuotaDAO;
    private final DAO<ResourceType> resourceTypeDAO;
    private final DAO<Region> areaDAO;
    private final DAO<Tag> tagDAO;

    ///// Constructeurs :

    public JDBCResourceDAO(final DataSource dataSource) {
        super(dataSource, "resource", "res");
        this.setBeanTranscoder(RESOURCE_TRANSCODER);
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);

        // Initialisation des DAO's :
        this.resourceTagDAO = new JDBCResourceTagDAO(dataSource);
        this.resourceRoleDAO = new JDBCResourceRoleDAO(dataSource);
        this.resourceRegionDAO = new JDBCResourceRegionDAO(dataSource);
        this.resourceQuotaDAO = new JDBCResourceQuotaDAO(dataSource);
        this.resourceTypeDAO = new JDBCResourceTypeDAO(dataSource);
        this.areaDAO = new JDBCRegionDAO(dataSource);
        this.tagDAO = new JDBCTagDAO(dataSource);
    }

    ///// Méthodes de l'interface DAO :

    @Override
    public void start() throws Exception {
        super.start();
        this.tagDAO.start();
        this.areaDAO.start();
        this.resourceTypeDAO.start();
        this.resourceTagDAO.start();
        this.resourceRoleDAO.start();
        this.resourceRegionDAO.start();
        this.resourceQuotaDAO.start();
    }

    @Override
    public void close() throws IOException {
        this.resourceQuotaDAO.close();
        this.resourceRegionDAO.close();
        this.resourceRoleDAO.close();
        this.resourceTagDAO.close();
        this.resourceTypeDAO.close();
        this.areaDAO.close();
        this.tagDAO.close();
        super.close();
    }

    ///// Création des requêtes SQL :

    @Override
    public String getSelectAllQuery() {
        return "SELECT res.id AS res_id, " +
                "   res.\"name\" AS res_name, " +
                "   res.description AS res_description, " +
                "   res.external_id AS res_external_id, " +
                "   res.resource_type AS res_resource_type, " +
                "   res.region AS res_region, " +
                "   res.zone AS res_zone, " +
                "   res.status AS res_status, " +
                "   res.project AS res_project, " +
                "   res.created_at AS res_created_at, " +
                "   res.updated_at AS res_updated_at," +
                "   resType.id AS res_type_id," +
                "   resType.\"name\" AS res_type_name," +
                "   resType.\"label\" AS res_type_label," +
                "   resType.category AS res_type_category," +
                "   resType.color AS res_type_color," +
                "   tenantRegion.id as iaas_region_id," +
                "   tenantRegion.\"name\" as iaas_region_name," +
                "   tenantRegion.\"label\" as iaas_region_label," +
                "   tenantRegion.color as iaas_region_color," +
                "   proj.id AS proj_id, " +
                "   proj.\"name\" AS proj_name, " +
                "   proj.owner_id AS proj_owner_id," +
                "   projRole.id AS proj_role_id," +
                "   projRole.project AS proj_role_project_id," +
                "   projRole.\"role\" AS proj_role_role_id," +
                "   projRole.uid AS proj_role_uid," +
                "   projRole.service_account AS proj_role_service_account_id," +
                "   projRole.is_synchronized AS proj_role_is_synchronized," +
                "   resRole.id AS res_role_id, " +
                "   resRole.uid AS res_role_uid, " +
                "   resRole.role AS res_role_role, " +
                "   resRole.service_account AS res_role_service_account, " +
                "   resRole.is_synchronized AS res_role_is_synchronized, " +
                "   resQuota.id AS res_quota_id, " +
                "   resQuota.quota_type AS res_quota_type, " +
                "   resQuota.resource AS res_quota_resource_id, " +
                "   resQuota.quota_value AS res_quota_value, " +
                "   resTag.id as res_tag_id, " +
                "   resTag.resource as res_tag_resource_id, " +
                "   resTag.tag as res_tag_tag_id, " +
                "   resTag.created_at AS res_tag_created_at, " +
                "   resTag.updated_at AS res_tag_updated_at, " +
                "   resRegion.id AS res_region_id," +
                "   resRegion.resource AS res_region_resource_id," +
                "   resRegion.region AS res_region_region_id," +
                "   s3Region.id as s3_region_id," +
                "   s3Region.\"name\" as s3_region_name," +
                "   s3Region.\"label\" as s3_region_label," +
                "   s3Region.color as s3_region_color" +
                " FROM " + this.tableName + " AS " + tableAlias +
                "   LEFT JOIN resource_type AS resType ON (resType.id = res.resource_type)" +
                "   LEFT JOIN resource_role AS resRole ON (resRole.resource = res.id)" +
                "   LEFT JOIN project AS proj ON (proj.id = res.project)" +
                "   LEFT JOIN project_role projRole ON (projRole.project = res.project)" +
                "   LEFT JOIN resource_quota AS resQuota ON (resQuota.resource = res.id)" +
                "   LEFT JOIN resource_tag AS resTag ON (resTag.resource = res.id)" +
                "   LEFT JOIN resource_region AS resRegion ON (resRegion.resource = res.id)" +
                "   LEFT JOIN region AS s3Region ON (s3Region.id = resRegion.region)" +
                "   LEFT JOIN region AS tenantRegion ON (tenantRegion.id = res.region)";
    }

    @Override
    protected String getInsertQuery(final Resource resource) throws Exception {
        if (resource == null) {
            throw new Exception("L'instance Resource est nulle => On ne peut donc pas construire la requête d'insertion");
        }
        return "INSERT INTO " +
                this.tableName + " AS res " +
                "(name, description, external_id, resource_type, region, \"zone\", status, project, created_at, updated_at) " +
                " VALUES (%s, %s, %s, %d, %d, %d, %d, %d, now(), null)"
                        .formatted(escapeSQL(resource.getName()),
                                escapeSQL(resource.getDescription()),
                                escapeSQL(resource.getExternalId()),
                                resource.getResourceType(),
                                resource.getRegion(),
                                resource.getZone(),
                                resource.getStatus(),
                                resource.getProject());
    }

    @Override
    protected String getUpdateQuery(final Resource resource) throws Exception {
        if (resource == null) {
            throw new Exception("L'instance Resource est nulle => On ne peut donc pas construire la requête de mise à jour");
        }
        return "UPDATE " +
                this.tableName +
                " SET name=%s, description=%s, external_id=%s, resource_type=%d, region=%d, \"zone\"=%d, status=%d, project=%d, updated_at=now() WHERE id=%d"
                        .formatted(escapeSQL(resource.getName()),
                                escapeSQL(resource.getDescription()),
                                escapeSQL(resource.getExternalId()),
                                resource.getResourceType(),
                                resource.getRegion(),
                                resource.getZone(),
                                resource.getStatus(),
                                resource.getProject(),
                                resource.getId());
    }

    ///// Méthodes de AbstractDefaultJdbcDAO :

    @Override
    protected List<Resource> selectFromQuery(final String sqlQuery) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.getConnection();
            connection.setAutoCommit(false);
            if (isConnectionClosed(connection)) {
                throw new Exception("La connexion est soit nulle, soit déjà fermée !!");
            }
            LOGGER.info("Execution de la requête Select : {}", sqlQuery);
            preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setFetchSize(50);
            resultSet = preparedStatement.executeQuery();
            final Map<Resource, Set<ResourceRole>> resRoleMap = new HashMap<>();
            final Map<Resource, Set<ResourceQuota>> resQuotasMap = new HashMap<>();
            final Map<Resource, Set<ResourceTag>> resTagsMap = new HashMap<>();
            final Map<Resource, Set<ProjectRole>> projRoleMap = new HashMap<>();
            final Map<Resource, Set<Region>> areaMap = new HashMap<>();
            Resource resource;
            ResourceRole resourceRole;
            ResourceQuota resourceQuota;
            ResourceTag resourceTag;
            ProjectRole projectRole;
            Set<Region> areas;
            while (resultSet.next()) {
                resource = RESOURCE_TRANSCODER.transcode(resultSet);
                resource.setProjectBean(PROJECT_TRANSCODER.transcode(resultSet));
                resource.setResourceTypeBean(RESOURCE_TYPE_TRANSCODER.transcode(resultSet));

                // On ajoute les project-role :
                if (!projRoleMap.containsKey(resource)) {
                    projRoleMap.put(resource, new HashSet<>());
                }
                projectRole = PROJECT_ROLE_TRANSCODER.transcode(resultSet);
                if (projectRole != null) {
                    projRoleMap.get(resource).add(projectRole);
                }

                // On ajoute les resource-role :
                if (!resRoleMap.containsKey(resource)) {
                    resRoleMap.put(resource, new HashSet<>());
                }
                resourceRole = RESOURCE_ROLE_TRANSCODER.transcode(resultSet);
                if (resourceRole != null) {
                    resRoleMap.get(resource).add(resourceRole);
                }

                // On ajoute les quotas :
                if (!resQuotasMap.containsKey(resource)) {
                    resQuotasMap.put(resource, new HashSet<>());
                }
                resourceQuota = RESOURCE_QUOTA_TRANSCODER.transcode(resultSet);
                if (resourceQuota != null) {
                    resQuotasMap.get(resource).add(resourceQuota);
                }

                // On ajoute les tags :
                if (!resTagsMap.containsKey(resource)) {
                    resTagsMap.put(resource, new HashSet<>());
                }
                resourceTag = RESOURCE_TAG_TRANSCODER.transcode(resultSet);
                if (resourceTag != null) {
                    resTagsMap.get(resource).add(resourceTag);
                }

                // On ajoute les régions et les liens correspondants
                if (!areaMap.containsKey(resource)) {
                    areaMap.put(resource, new HashSet<>());
                }
                areas = RESOURCE_AREA_TRANSCODER.transcode(resultSet);
                if (!isCollectionEmpty(areas)) {
                    areaMap.get(resource).addAll(areas);
                }

            }

            final Set<Resource> resources = new HashSet<>();

            // On complète les rôles des projets :
            Project projectBean;
            for (Resource res : projRoleMap.keySet()) {
                projectBean = res.getProjectBean();
                if (projectBean == null) {
                    continue;
                }
                projectBean.setProjectRoles(projRoleMap.get(res));
            }

            // On complète les rôles des resources :
            for (Resource res : resRoleMap.keySet()) {
                res.setResourceRoles(resRoleMap.get(res));
                resources.add(res);
            }

            // On complète les quotas :
            for (Resource res : resQuotasMap.keySet()) {
                res.setResourceQuotas(resQuotasMap.get(res));
                resources.add(res);
            }

            // On complète les tags :
            for (Resource res : resTagsMap.keySet()) {
                res.setResourceTags(resTagsMap.get(res));
                resources.add(res);
            }

            // On complète par les liens resource ↔ régions :
            for (Resource res : areaMap.keySet()) {
                res.setRegions(areaMap.get(res));
                resources.add(res);
            }

            // Retourne la liste :
            return new ArrayList<>(resources);
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }
    }

    @Override
    public Resource save(final Resource resource) throws Exception {
        if (resource == null) {
            LOGGER.info("Pas de mis à jour de la resource en base de données car elle est nulle");
            return null;
        }
        if (this.resourceTagDAO == null) {
            LOGGER.error("Le DAO des entités ResourceTag est nul !!");
            throw new Exception("Le DAO des entités ResourceTag est nul !!");
        }
        if (this.resourceRoleDAO == null) {
            LOGGER.error("Le DAO des roles ResourceRole est nul !!");
            throw new Exception("Le DAO des roles ResourceTag est nul !!");
        }
        if (this.resourceRegionDAO == null) {
            LOGGER.error("Le DAO des régions ResourceRegion est nul !!");
            throw new Exception("Le DAO des roles ResourceRegion est nul !!");
        }
        if (this.resourceQuotaDAO == null) {
            LOGGER.error("Le DAO des quotas ResourceQuota est nul !!");
            throw new Exception("Le DAO des roles ResourceQuota est nul !!");
        }

        LOGGER.info("DEBUT => Mis à jour de la resource {} dans la base de données", buildJSONObject(resource));

        // Sauvegarde de la resource :
        final Resource savedResource = super.save(resource);

        // Mis à jour du type de ressource :
        final ResourceType resourceType = resource.getResourceTypeBean();
        if (resourceType != null) {
            savedResource.setResourceTypeBean(this.resourceTypeDAO.save(resourceType));
        }

        // Mis à jour des liens Resource ↔ Tag :
        LOGGER.info("Mis à jour dans la BDD des liens Resource <-> Tag");
        this.resourceTagDAO.delete(withJDBCFieldEquals(ResourceTag.class, "resource", savedResource.getId()));
        savedResource.setTags(this.tagDAO.save(resource.getTags()));
        final Set<ResourceTag> resourceTags = new HashSet<>();
        for (Tag tag : savedResource.getTags()) {
            resourceTags.add(new ResourceTag(null, savedResource.getId(), tag.getId()));
        }
        for (ResourceTag resourceTag : resource.getResourceTags()) {
            resourceTags.add(new ResourceTag(null, savedResource.getId(), resourceTag.getTag()));
        }
        savedResource.setResourceTags(this.resourceTagDAO.save(resourceTags));


        // Mis à jour des liens Resource ↔ Role :
        LOGGER.info("Mis à jour dans la BDD des liens Resource <-> Role");
        this.resourceRoleDAO.delete(withJDBCFieldEquals(ResourceRole.class, "resource", savedResource.getId()));
        final Set<ResourceRole> resourceRoles = resource.getResourceRoles();
        if (!isCollectionEmpty(resourceRoles)) {
            for (ResourceRole resourceRole : resourceRoles) {
                resourceRole.setId(null);
                resourceRole.setResource(savedResource.getId());
            }
            this.resourceRoleDAO.save(resourceRoles);
        }

        // Mis à jour des liens Resource ↔ région :
        LOGGER.info("Mis à jour dans la BDD des liens Resource <-> Region");
        savedResource.setRegions(this.areaDAO.save(resource.getRegions()));
        final Set<ResourceRegion> newResourceRegions = savedResource.getResourceRegions();
        final List<ResourceRegion> existingResourceRegions = this.resourceRegionDAO.select(withJDBCFieldEquals(ResourceRegion.class, "resource", savedResource.getId()));
        this.resourceRegionDAO.delete(diff(existingResourceRegions, newResourceRegions));
        final Set<ResourceRegion> resourceRegions = new HashSet<>();
        Optional<ResourceRegion> foundExistingResourceRegionOpt;
        for (ResourceRegion newResourceArea : newResourceRegions) {
            foundExistingResourceRegionOpt = existingResourceRegions.stream().filter(areEqualsPredicate(newResourceArea)).findFirst();
            if (foundExistingResourceRegionOpt.isEmpty()) {
                resourceRegions.add(newResourceArea);
            }
        }
        this.resourceRegionDAO.save(resourceRegions);

        // Mis à jour des quotas :
        LOGGER.info("Mis à jour dans la BDD des liens Resource <-> Quotas");
        final Set<ResourceQuota> newResourceQuotas = resource.getResourceQuotas();
        this.resourceQuotaDAO.delete(diff(this.resourceQuotaDAO.select(withJDBCFieldEquals(ResourceQuota.class, "resource", savedResource.getId())),
                newResourceQuotas));
        if (!isCollectionEmpty(resource.getResourceQuotas())) {
            for (ResourceQuota resourceQuota : resource.getResourceQuotas()) {
                resourceQuota.setResource(savedResource.getId());
            }
            savedResource.setResourceQuotas(this.resourceQuotaDAO.save(resource.getResourceQuotas()));
        }
        LOGGER.info("FIN => Mis à jour de la resource dans la base de données");
        return savedResource;
    }

    @Override
    public void delete(final Predicate<Resource> predicate) throws Exception {
        final Set<Long> resourceIds = this.select(predicate).stream().map(Resource::getId).filter(Objects::nonNull).collect(toSet());
        if (!isCollectionEmpty(resourceIds)) {
            this.resourceRoleDAO.delete(withFieldInCollection(ResourceRole.class, "resource", resourceIds));
            this.resourceTagDAO.delete(withFieldInCollection(ResourceTag.class, "resource", resourceIds));
            this.resourceRegionDAO.delete(withFieldInCollection(ResourceRegion.class, "resource", resourceIds));
            this.resourceQuotaDAO.delete(withFieldInCollection(ResourceQuota.class, "resource", resourceIds));
        }
        super.delete(predicate);
    }

    @Override
    public void deleteAll() throws Exception {
        this.resourceQuotaDAO.deleteAll();
        this.resourceTagDAO.deleteAll();
        this.resourceRegionDAO.deleteAll();
        this.resourceRoleDAO.deleteAll();
        super.deleteAll();
    }

    ///// Getters :

    public DAO<ResourceTag> getResourceTagDAO() {
        return this.resourceTagDAO;
    }

    ///// Classe(s) interne(s) :

    private static class ResourceTranscoder extends AbstractResultSetTranscoder<Resource> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "res_id") == null);
            return isNull;
        }

        @Override
        protected Resource doTranscode(final ResultSet resultSet) throws SQLException {
            final Resource resource = new Resource();
            resource.setId(processLongValue(resultSet, "res_id"));
            resource.setName(resultSet.getString("res_name"));
            resource.setDescription(resultSet.getString("res_description"));
            resource.setExternalId(resultSet.getString("res_external_id"));
            resource.setResourceType(processLongValue(resultSet, "res_resource_type"));
            resource.setRegion(processLongValue(resultSet, "res_region"));
            resource.setZone(processLongValue(resultSet, "res_zone"));
            resource.setStatus(processLongValue(resultSet, "res_status"));
            resource.setProject(processLongValue(resultSet, "res_project"));
            resource.setCreatedAt(processTimestampField(resultSet, "res_created_at"));
            resource.setUpdatedAt(processTimestampField(resultSet, "res_updated_at"));
            return resource;
        }
    }

    private static class ProjectTranscoder extends AbstractResultSetTranscoder<Project> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "proj_id") == null);
            return isNull;
        }

        @Override
        protected Project doTranscode(final ResultSet resultSet) throws SQLException {
            final Project project = new Project();
            project.setId(processLongValue(resultSet, "proj_id"));
            project.setName(resultSet.getString("proj_name"));
            project.setOwnerId(resultSet.getString("proj_owner_id"));
            return project;
        }
    }

    private static class ProjectRoleTranscoder extends AbstractResultSetTranscoder<ProjectRole> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "proj_role_id") == null);
            return isNull;
        }

        @Override
        protected ProjectRole doTranscode(final ResultSet resultSet) throws SQLException {
            final ProjectRole projectRole = new ProjectRole();
            projectRole.setId(processLongValue(resultSet, "proj_role_id"));
            projectRole.setProject(processLongValue(resultSet, "proj_role_project_id"));
            projectRole.setRole(processLongValue(resultSet, "proj_role_role_id"));
            projectRole.setServiceAccount(processLongValue(resultSet, "proj_role_service_account_id"));
            projectRole.setSynchronized(resultSet.getBoolean("proj_role_is_synchronized"));
            return projectRole;
        }
    }

    private static class ResourceRoleTranscoder extends AbstractResultSetTranscoder<ResourceRole> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "res_role_id") == null);
            return isNull;
        }

        @Override
        protected ResourceRole doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceRole resourceRole = new ResourceRole();
            resourceRole.setId(processLongValue(resultSet, "res_role_id"));
            resourceRole.setUid(resultSet.getString("res_role_uid"));
            resourceRole.setResource(processLongValue(resultSet, "res_id"));
            resourceRole.setRole(processLongValue(resultSet, "res_role_role"));
            resourceRole.setServiceAccount(processLongValue(resultSet, "res_role_service_account"));
            resourceRole.setSynchronized(resultSet.getBoolean("res_role_is_synchronized"));
            return resourceRole;
        }

    }

    private static class ResourceQuotaTranscoder extends AbstractResultSetTranscoder<ResourceQuota> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "res_quota_id") == null);
            return isNull;
        }

        @Override
        protected ResourceQuota doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceQuota resourceQuota = new ResourceQuota();
            resourceQuota.setId(processLongValue(resultSet, "res_quota_id"));
            resourceQuota.setQuotaType(processLongValue(resultSet, "res_quota_type"));
            resourceQuota.setResource(processLongValue(resultSet, "res_quota_resource_id"));
            resourceQuota.setQuotaValue(processLongValue(resultSet, "res_quota_value"));
            return resourceQuota;
        }

    }

    private static class ResourceTagTranscoder extends AbstractResultSetTranscoder<ResourceTag> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "res_tag_id") == null);
            return isNull;
        }

        @Override
        protected ResourceTag doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceTag resourceTag = new ResourceTag();
            resourceTag.setId(processLongValue(resultSet, "res_tag_id"));
            resourceTag.setResource(processLongValue(resultSet, "res_tag_resource_id"));
            resourceTag.setTag(processLongValue(resultSet, "res_tag_tag_id"));
            resourceTag.setCreatedAt(processTimestampField(resultSet, "res_tag_created_at"));
            resourceTag.setUpdatedAt(processTimestampField(resultSet, "res_tag_updated_at"));
            return resourceTag;
        }
    }

    private static class AreaTranscoder extends AbstractResultSetTranscoder<Set<Region>> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || ((processLongValue(resultSet, "iaas_region_id") == null)
                    && (processLongValue(resultSet, "s3_region_id") == null));
            return isNull;
        }

        @Override
        protected Set<Region> doTranscode(final ResultSet resultSet) throws SQLException {
            final Set<Region> areas = new HashSet<>();
            Region area;
            if (processLongValue(resultSet, "iaas_region_id") != null) {
                area = new Region();
                area.setId(processLongValue(resultSet, "iaas_region_id"));
                area.setName(resultSet.getString("iaas_region_name"));
                area.setLabel(resultSet.getString("iaas_region_label"));
                area.setColor(resultSet.getString("iaas_region_color"));
                areas.add(area);
            }
            if (processLongValue(resultSet, "s3_region_id") != null) {
                area = new Region();
                area.setId(processLongValue(resultSet, "s3_region_id"));
                area.setName(resultSet.getString("s3_region_name"));
                area.setLabel(resultSet.getString("s3_region_label"));
                area.setColor(resultSet.getString("s3_region_color"));
                areas.add(area);
            }
            return areas;
        }
    }

    private static class ResourceTypeTranscoder extends AbstractResultSetTranscoder<ResourceType> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "res_type_id") == null);
            return isNull;
        }

        @Override
        protected ResourceType doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceType resourceType = new ResourceType();
            resourceType.setId(processLongValue(resultSet, "res_type_id"));
            resourceType.setName(resultSet.getString("res_type_name"));
            resourceType.setLabel(resultSet.getString("res_type_label"));
            resourceType.setCategory(resultSet.getString("res_type_category"));
            resourceType.setColor(resultSet.getString("res_type_color"));
            return resourceType;
        }
    }
}
