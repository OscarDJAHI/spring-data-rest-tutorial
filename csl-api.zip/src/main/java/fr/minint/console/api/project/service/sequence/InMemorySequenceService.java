package fr.minint.console.api.project.service.sequence;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class InMemorySequenceService implements SequenceService, AutoCloseable {
    private final Long initValue;
    private final transient ReentrantReadWriteLock lock;
    private Long seqValue;

    public InMemorySequenceService(final Long initValue) {
        this.seqValue = (initValue == null ? 0L : initValue);
        this.initValue = initValue;
        this.lock = new ReentrantReadWriteLock();
    }

    @Override
    public Long getCurrentValue() {
        lock.readLock().lock();
        try {
            return this.seqValue;
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public void setCurrentValue(final Long value) {
        lock.writeLock().lock();
        try {
            this.seqValue = (value == null ? 0L : value);
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public Long getNextValue() {
        lock.writeLock().lock();
        try {
            this.seqValue += 1;
            return this.seqValue;
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public void close() {
        this.setCurrentValue(this.initValue);
    }
}
