package fr.minint.console.api.project.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isEmpty;

public class RequestBodyUtils {

    public RequestBodyUtils() {
        // EMPTY
    }

    public static Collection<?> getCollectionFromRequestBody(final Map<String, Object> requestBody,
                                                             final String fieldName) {
        if (requestBody == null || requestBody.isEmpty()) {
            return new ArrayList<>();
        }
        if (isEmpty(fieldName) || isBlank(fieldName) || !requestBody.containsKey(fieldName.trim())) {
            return new ArrayList<>();
        }
        final Object value = requestBody.get(fieldName.trim());
        if (!(value instanceof Collection<?>)) {
            throw new ClassCastException("Le champs %s n'est pas une collection".formatted(fieldName));
        }
        return ((Collection<?>) value);
    }
}
