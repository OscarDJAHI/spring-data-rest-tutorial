package fr.minint.console.api.project.service;

import lombok.Data;

@Data
public class ActionResponse {
    private String message;
    private int code;
}
