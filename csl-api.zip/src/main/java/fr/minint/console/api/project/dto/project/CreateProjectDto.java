package fr.minint.console.api.project.dto.project;

import fr.minint.console.api.project.model.project.ProjectTag;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Set;

@Getter
@Setter
public class CreateProjectDto {

    @NotBlank(message = "Project name is mandatory")
    @Size(max = 33, message = "Name size must be lesser than 33 characters")
    @Pattern(regexp = "^[a-z][a-z0-9-]+$", message = "Must begin by lower case characters and contain only lower case characters, numbers and hyphens")
    String name;

    @NotBlank(message = "Label is mandatory")
    @Size(max = 28, message = "Label size must be lesser than 28 characters")
    String label;

    @Size(max = 4000, message = "Description must be lesser than 4000 characters")
    String description;

    private Long statusId;
    private Long paiId;

    @NotBlank(message = "Must not be empty or blank")
    private String ownerId;

    private String rssi;

    @NotNull Set<ProjectTag> tags;
}
