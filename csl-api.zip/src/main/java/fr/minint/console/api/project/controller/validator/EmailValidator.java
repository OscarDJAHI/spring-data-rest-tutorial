package fr.minint.console.api.project.controller.validator;

import fr.minint.console.library.validator.Validator;

import java.util.regex.Pattern;

import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static java.util.regex.Pattern.compile;
import static org.apache.commons.lang3.StringUtils.isEmpty;

public class EmailValidator implements Validator<String> {
    private static final Pattern VALID_EMAIL_PATTERN = compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", CASE_INSENSITIVE);

    @Override
    public boolean validate(final String fieldName,
                            final String fieldValue,
                            final StringBuilder errorMsgBuffer) {
        final boolean isEmailOK = !isEmpty(fieldValue) && VALID_EMAIL_PATTERN.matcher(fieldValue.trim()).find();
        if (!isEmailOK && !errorMsgBuffer.isEmpty()) {
            errorMsgBuffer.append(" et '");
            errorMsgBuffer.append(fieldValue);
            errorMsgBuffer.append("'");
            errorMsgBuffer.append(" n'est pas un email valide");
            return false;
        } else if (!isEmailOK) {
            errorMsgBuffer.append("'");
            errorMsgBuffer.append(fieldValue);
            errorMsgBuffer.append("'");
            errorMsgBuffer.append(" n'est pas un email valide");
            return false;
        }
        return true;
    }
}
