package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.QuotaType;
import fr.minint.console.api.project.entities.ResourceQuota;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

public interface ResourceQuotaRepository extends JpaRepository<ResourceQuota, Long>, JpaSpecificationExecutor<ResourceQuota> {
    Optional<QuotaType> findByQuotaType(QuotaType quotaType);

}
