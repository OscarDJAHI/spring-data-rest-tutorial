package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.controller.AbstractRestController;
import fr.minint.console.api.project.ldap.dto.CreateServiceAccountDto;
import fr.minint.console.api.project.ldap.dto.CreateUserDto;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.UserService;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.ResponseEntity.ok;

@RestController
public class LdapUserController extends AbstractRestController {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapUserController.class);
    private UserService userService;

    @GetMapping("/api/ldap/rdn")
    public void getRdn() {

    }

    @PostMapping("/api/ldap/users")
    public void create(final CreateUserDto createUserDto) {
        userService.create(
                createUserDto.getRdn(),
                createUserDto.getUid(),
                createUserDto.getCn(),
                createUserDto.getSn(),
                createUserDto.getUidNumber(),
                createUserDto.getGidNumber()
        );
    }

    @PostMapping("/api/ldap/external-users")
    public ResponseEntity<String> createExternalUser(@RequestBody final Map<String, String> requestBody) {
        if (requestBody == null) {
            throw new ResponseStatusException(BAD_REQUEST, "Il manque le corps (body) de la requête");
        }
        final StringBuilder errorMsgBuffer = new StringBuilder();
        boolean isRequestBodyValid = true;
        for (String fieldName : asList("firstName", "name", "password")) {
            isRequestBodyValid = NOT_BLANK_VALIDATOR.validate(fieldName, requestBody.get(fieldName), errorMsgBuffer) && isRequestBodyValid;
        }
        isRequestBodyValid = EMAIL_VALIDATOR.validate("email", requestBody.get("email"), errorMsgBuffer) && isRequestBodyValid;
        if (!isRequestBodyValid) {
            LOGGER.error("Bad request : {}", errorMsgBuffer);
            throw new ResponseStatusException(BAD_REQUEST, errorMsgBuffer.toString());
        }
        final JSONObject jsonResponse = new JSONObject();
        final Optional<LdapUser> existingLDAPUserOption = userService.findLDAPUserByEmail(requestBody.get("email"));
        if (existingLDAPUserOption.isPresent()) {
            LOGGER.info("---> Utilisateur déjà dans le LDAP");
            final LdapUser ldapUser = existingLDAPUserOption.get();
            Pair<String, String> firstAndLastNames = ldapUser.getFirstAndLastNames();
            jsonResponse.put("status", "fetched");
            jsonResponse.put("uid", ldapUser.getUid());
            jsonResponse.put("name", firstAndLastNames.getRight().toLowerCase());
            jsonResponse.put("firstName", firstAndLastNames.getLeft().toLowerCase());
            jsonResponse.put("email", ldapUser.getMail());
            jsonResponse.put("organization", ldapUser.getOu());
            return ok(jsonResponse.toString());
        }
        LOGGER.info("---> Création du nouvel utilisateur dans le LDAP");
        final Long generatedUid = userService.createExternalUser(requestBody.get("firstName"),
                requestBody.get("name"),
                requestBody.get("email"),
                requestBody.get("password"),
                requestBody.get("organization"));
        jsonResponse.put("status", "created");
        jsonResponse.put("uid", generatedUid);
        jsonResponse.put("name", requestBody.get("name"));
        jsonResponse.put("firstName", requestBody.get("firstName"));
        jsonResponse.put("email", requestBody.get("email"));
        jsonResponse.put("organization", requestBody.get("organization"));
        LOGGER.info("---> Utilisateur créé");
        return ok(jsonResponse.toString());
    }

    @GetMapping("/api/ldap/users")
    public List<LdapUser> list() {
        return userService.list();
    }

    @GetMapping("/api/ldap/users/{uid}")
    public LdapUser get(@PathVariable() String uid) {
        final Optional<LdapUser> optionalUser = userService.get(uid);
        if (optionalUser.isEmpty()) {
            throw new ResponseStatusException(NOT_FOUND, "User not found");
        }
        return optionalUser.get();
    }

    @PostMapping("/api/ldap/service-accounts")
    public LdapUser createServiceUser(@RequestBody CreateServiceAccountDto createServiceAccountDto) {
        return userService.createServiceUser(
                createServiceAccountDto.getCategory(),
                createServiceAccountDto.getName(),
                createServiceAccountDto.getPassword()
        );
    }

    ///// Getters & Setters :

    @Autowired
    public void setUserService(final UserService userService) {
        this.userService = userService;
    }

}
