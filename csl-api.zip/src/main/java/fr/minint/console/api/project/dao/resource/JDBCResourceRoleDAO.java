package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.model.resource.ResourceRole;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCResourceRoleDAO extends AbstractJDBCDAO<Long, ResourceRole> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCResourceRoleDAO.class);
    private static final Transcoder<ResultSet, ResourceRole> RESULT_SET_RESOURCE_ROLE_TRANSCODER = new ResultSetResourceRoleTranscoder();

    ///// Constructeur(s) :

    public JDBCResourceRoleDAO(final DataSource dataSource) {
        super(dataSource, "resource_role", "");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_RESOURCE_ROLE_TRANSCODER);
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    public String getSelectAllQuery() {
        return "SELECT id," +
                " role AS role_id," +
                " resource AS resource_id," +
                " uid," +
                " service_account," +
                " is_synchronized," +
                " created_at," +
                " updated_at " +
                " FROM " + this.tableName;
    }

    @Override
    protected String getInsertQuery(final ResourceRole resourceRole) throws Exception {
        if (resourceRole == null) {
            throw new Exception("L'objet resourceRole est nul -> on ne peut pas construire la requête");
        }
        final String insertSQLQuery = "INSERT INTO " +
                this.tableName +
                " (resource, \"role\", uid, service_account, is_synchronized, created_at, updated_at) " +
                "VALUES (%d, %d, %s, %d, %s, now(), now())"
                        .formatted(resourceRole.getResource(),
                                resourceRole.getRole(),
                                escapeSQL(resourceRole.getUid()),
                                resourceRole.getServiceAccount(),
                                (resourceRole.isSynchronized() ? "true" : "false"));
        LOGGER.info("Insertion de ResourceRole avec la requete SQL : {}", insertSQLQuery);
        return insertSQLQuery;
    }

    @Override
    protected String getUpdateQuery(final ResourceRole resourceRole) throws Exception {
        if (resourceRole == null) {
            throw new Exception("L'objet resourceRole est nul -> on ne peut pas construire la requête");
        }
        final String updateSQLQuery = "UPDATE " +
                this.tableName +
                " SET resource=%d, \"role\"=%d, uid=%s, service_account=%d, is_synchronized=%s, updated_at=now() WHERE id=%d"
                        .formatted(resourceRole.getResource(),
                                resourceRole.getRole(),
                                escapeSQL(resourceRole.getUid()),
                                resourceRole.getServiceAccount(),
                                (resourceRole.isSynchronized() ? "true" : "false"),
                                resourceRole.getId());
        LOGGER.info("Mis à jour de ResourceRole avec la requete SQL : {}", updateSQLQuery);
        return updateSQLQuery;
    }

    ///// Classe(s) statique(s) :

    /**
     * <p>
     * Transcodeur permettant de transformer une instance de ResultSet
     * en ResourceRole.<br />
     * </p>
     *
     * @see ResultSet
     */
    private static class ResultSetResourceRoleTranscoder extends AbstractResultSetTranscoder<ResourceRole> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = (resultSet == null);
            isNull = isNull || (processLongValue(resultSet, "id") == null);
            return isNull;
        }

        @Override
        protected ResourceRole doTranscode(final ResultSet resultSet) throws SQLException {
            final ResourceRole resourceRole = new ResourceRole();
            resourceRole.setId(processLongValue(resultSet, "id"));
            resourceRole.setRole(processLongValue(resultSet, "role_id"));
            resourceRole.setUid(resultSet.getString("uid"));
            resourceRole.setServiceAccount(processLongValue(resultSet, "service_account"));
            resourceRole.setSynchronized(resultSet.getBoolean("is_synchronized"));
            return resourceRole;
        }
    }
}
