package fr.minint.console.api.project.model.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import fr.minint.console.api.project.model.*;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.utils.ResourceUtils;
import fr.minint.console.library.utils.json.ToJSON;
import fr.minint.console.persistence.bean.AbstractDAOBean;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.data.annotation.Transient;

import java.time.Instant;
import java.util.*;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.json.JSONUtils.buildJSONArrayFromCollection;
import static java.util.Collections.singleton;

@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Resource extends AbstractDAOBean<Long> implements ToJSON, HasProject {
    private Long id;
    private String name;
    private String description;
    private String externalId;

    @JsonProperty("resourceTypeId")
    private Long resourceType;
    @JsonProperty("zoneId")
    private Long zone;
    @JsonProperty("regionId")
    private Long region;
    @JsonProperty("statusId")
    private Long status;
    @JsonProperty("projectId")
    private Long project;
    private Instant createdAt;
    private Instant updatedAt;

    //// Champs transients :

    // TODO : A supprimer
    @Transient
    private Set<ResourceQuota> quotas;

    // TODO : A supprimer
    @Transient
    private Set<ResourceRole> resourceRoles;

    // TODO : A supprimer
    @Transient
    private Set<ResourceTag> resourceTags;

    @Transient
    private Set<Tag> tags;

    @Transient
    private ResourceType resourceTypeBean;

    @Transient
    private Project projectBean;

    @Transient
    private Set<Region> regions;


    ///// Constructeur(s) :

    public Resource(final Long id, final String name) {
        this.id = id;
        this.setName(name);
    }

    public Resource(final Long id, final Long projectId) {
        this.id = id;
        this.project = projectId;
    }

    public Resource(final Long id, final Long projectId, final Long resourceTypeId) {
        this.id = id;
        this.project = projectId;
        this.resourceType = resourceTypeId;
    }

    ///// Implémentation de l'interface ToJSON :

    @Override
    public JSONObject toJSON() {
        try {
            final JSONObject jsonResource = new JSONObject();
            jsonResource.put("id", this.id);
            jsonResource.put("name", this.name);
            jsonResource.put("description", this.description);
            jsonResource.put("externalId", this.externalId);
            jsonResource.put("resourceTypeId", this.resourceType);
            jsonResource.put("zoneId", this.zone);
            jsonResource.put("regionId", this.region);
            jsonResource.put("statusId", this.status);
            jsonResource.put("projectId", this.getProject());
            jsonResource.put("createdAt", this.createdAt);
            jsonResource.put("updatedAt", this.updatedAt);

            // liste des éléments :
            jsonResource.put("quotas", buildJSONArrayFromCollection(this.quotas));
            jsonResource.put("roles", buildJSONArrayFromCollection(this.resourceRoles));
            jsonResource.put("tags", buildJSONArrayFromCollection(this.resourceTags));
            final JSONArray jsonResourceAreas = new JSONArray();
            for (Region area : this.getRegions()) {
                jsonResourceAreas.put(new ResourceRegion(null, this.getId(), area.getId()).toJSON());
            }
            jsonResource.put("regions", jsonResourceAreas);
            return jsonResource;
        } catch (final JsonProcessingException processingException) {
            throw new RuntimeException(processingException);
        }
    }

    ///// Méthodes de la classe Object :

    @Override
    protected int functionnalHashCode() {
        return Objects.hash(this.name);
    }

    @Override
    protected boolean isFunctionnallyEquals(final AbstractDAOBean<?> that) {
        if (this == that) {
            return true;
        }
        if ((that == null) || (this.getClass() != that.getClass())) {
            return false;
        }
        return Objects.equals(this.getName(), ((Resource) that).getName());
    }

    @Override
    public String toString() {
        return "Resource(id=%d, name=%s)"
                .formatted(this.id, (this.name == null ? "null" : "'" + this.name + "'"));
    }

    ///// Méthodes générales :

    public Map<String, Boolean> validate(final Iterable<QuotaType> quotaTypes) {
        return ResourceUtils.validate(quotaTypes, this);
    }

    /**
     * Méthode permettant de tester si un utilisateur possède un rôle
     * sur l'instance courante de la ressource. <br />
     *
     * @param userUid : uid de l'utilisateur
     * @param role    : rôle
     * @return booléen montrant si l'utilisateur
     */
    public boolean hasUserWithRole(final String userUid, final Role role) {
        if (role == null) {
            return false;
        }
        boolean isOk;
        for (ResourceRole resourceRole : this.getResourceRoles()) {
            isOk = Objects.equals(role.getId(), resourceRole.getRole());
            isOk = isOk && Objects.equals(userUid, resourceRole.getUid());
            if (isOk) {
                return true;
            }
        }
        return false;
    }

    public void addRole(final String userUid, final Role role) {
        if (role == null) {
            return;
        }
        this.getResourceRoles().add(new ResourceRole(null, userUid, this.getId(), role.getId(), null, true));
    }

    public void addResourceRole(final ResourceRole resourceRole) {
        if (this.resourceRoles == null) {
            this.resourceRoles = new HashSet<>();
        }
        if (resourceRole == null) {
            return;
        }
        resourceRole.setResource(this.getId());
        this.resourceRoles.add(resourceRole);
    }

    public void addTag(final Tag tag) {
        if (tag == null) {
            return;
        }
        this.getTags().add(tag);
        final Long tagId = tag.getId();
        if (tagId != null) {
            this.getResourceTags().add(new ResourceTag(null, this.id, tagId));
        }
    }

    public void addResourceTag(final ResourceTag resourceTag) {
        this.getResourceTags().add(resourceTag);
    }

    public void addRegion(final Region region) {
        if (region == null) {
            return;
        }
        this.getRegions().add(region);
    }

    public void addQuota(final Number quotaValue, final QuotaType quotaType) {
        if (quotaValue == null) {
            return;
        }
        this.getResourceQuotas().add(new ResourceQuota(null, quotaValue.longValue(), quotaType.getId(), this.getId()));
    }

    ///// Getters & Setters :

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return (name == null ? null : name.trim());
    }

    public void setName(final String name) {
        this.name = (name == null ? null : name.trim());
    }

    public Set<Region> getRegions() {
        if (regions == null) {
            this.regions = new TreeSet<>();
        }
        return regions;
    }

    public void setRegions(final Collection<Region> regions) {
        this.regions = new HashSet<>();
        if (isCollectionEmpty(regions)) {
            return;
        }
        for (Region region : regions) {
            if (region == null) {
                continue;
            }
            this.regions.add(region);
        }
    }

    public Set<ResourceRegion> getResourceRegions() {
        final Set<ResourceRegion> resourceRegions = new HashSet<>();
        for (Region area : this.regions) {
            resourceRegions.add(new ResourceRegion(null, this.id, (area == null ? null : area.getId())));
        }
        return resourceRegions;
    }

    /**
     * Initialise la région de la ressource IAAS. <br />
     *
     * @param mainArea : région
     */
    public void setIAASRegion(final Region mainArea) {
        this.region = (mainArea == null ? null : mainArea.getId());
        this.setRegions(singleton(mainArea));
    }

    @Deprecated
    public void setRegion(final Long mainAreaId) {
        this.region = mainAreaId;
    }

    @Deprecated
    public Long getRegion() {
        return region;
    }

    public void setResourceRoles(final Collection<? extends ResourceRole> resourceRoles) {
        this.getResourceRoles().clear();
        if (isCollectionEmpty(resourceRoles)) {
            return;
        }
        this.getResourceRoles().addAll(resourceRoles);
        this.getResourceRoles().forEach(resRole -> resRole.setResource(this.getId()));
    }

    public Set<ResourceRole> getResourceRoles() {
        if (resourceRoles == null) {
            this.resourceRoles = new HashSet<>();
        }
        return resourceRoles;
    }

    public void setTags(final Collection<? extends Tag> tags) {
        this.tags = new HashSet<>();
        for (Tag tag : tags) {
            if (tag == null) {
                continue;
            }
            this.tags.add(tag);
        }
    }

    public Set<Tag> getTags() {
        if (tags == null) {
            this.tags = new HashSet<>();
        }
        return tags;
    }

    @Deprecated
    public void setResourceTags(final Collection<? extends ResourceTag> tags) {
        this.getResourceTags().clear();
        if (isCollectionEmpty(tags)) {
            return;
        }
        this.getResourceTags().addAll(tags);
        this.getResourceTags().forEach(tag -> tag.setResource(this.getId()));
    }

    public Set<ResourceTag> getResourceTags() {
        if (resourceTags == null) {
            this.resourceTags = new HashSet<>();
        }
        return this.resourceTags;
    }

    public void setResourceQuotas(final Collection<? extends ResourceQuota> quotas) {
        this.getResourceQuotas().clear();
        if (isCollectionEmpty(quotas)) {
            return;
        }
        this.getResourceQuotas().addAll(quotas);
        this.getResourceQuotas().forEach(quota -> quota.setResource(this.getId()));
    }

    public Set<ResourceQuota> getResourceQuotas() {
        if (quotas == null) {
            this.quotas = new HashSet<>();
        }
        return quotas;
    }

    public ResourceType getResourceTypeBean() {
        return resourceTypeBean;
    }

    public void setResourceTypeBean(final ResourceType resourceType) {
        this.resourceTypeBean = (resourceType == null ? null : resourceType.copy());
        this.resourceType = (resourceType == null ? null : resourceType.getId());
    }

    public String getCategory() {
        return (resourceTypeBean == null ? null : resourceTypeBean.getCategory());
    }

    @Override
    public Project getProjectBean() {
        return projectBean;
    }

    public void setProjectBean(final Project project) {
        this.projectBean = project;
        this.project = (project == null ? null : project.getId());
    }

    // TODO : A renommer !!
    @Deprecated
    public void setProject(final Long projectId) {
        this.project = projectId;
    }

    // TODO : A Renommer !!
    @Deprecated
    public Long getProject() {
        return this.project;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(final String externalId) {
        this.externalId = externalId;
    }

    public Long getResourceType() {
        return resourceType;
    }

    public void setResourceType(final Long resourceType) {
        this.resourceType = resourceType;
    }

    public Long getZone() {
        return zone;
    }

    public void setZone(Long zone) {
        this.zone = zone;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(final Long status) {
        this.status = status;
    }

    public void setCreatedAt(final Instant createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(final Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Set<ResourceQuota> getQuotas() {
        return quotas;
    }

    public void setQuotas(final Set<ResourceQuota> quotas) {
        this.quotas = quotas;
    }


}
