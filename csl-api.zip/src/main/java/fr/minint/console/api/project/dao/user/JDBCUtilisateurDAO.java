package fr.minint.console.api.project.dao.user;

import fr.minint.console.api.project.model.User;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;

/**
 * <p>
 * DAO permettant de gérer les Utilisateurs en JDBC. <br />
 * </p>
 *
 * @see DAO
 */
@SuppressWarnings("SqlSourceToSinkFlow")
public class JDBCUtilisateurDAO extends AbstractJDBCDAO<Long, User> {
    private static final Transcoder<ResultSet, User> RESULT_SET_UTILISATEUR_TRANSCODER = new ResultSetUtilisateurTranscoder();

    ///// Constructeur(s) :

    public JDBCUtilisateurDAO(final DataSource dataSource) {
        super(dataSource, "\"user\"", "user");
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_UTILISATEUR_TRANSCODER);
    }

    @Override
    public void start() throws Exception {
        super.start();
    }

    @Override
    public void close() throws IOException {
        super.close();
    }

    ///// Requête SQL :


    @Override
    public String getSelectCountQuery() {
        return "SELECT COUNT(id) FROM \"user\"";
    }

    @Override
    public String getSelectAllQuery() {
        return "SELECT id AS user_id, " +
                "   nom AS user_nom," +
                "   prenom AS user_prenom," +
                "   rio AS user_rio," +
                "   email AS user_email," +
                "   is_service_account AS user_is_service_account," +
                "   created_at AS user_created_at," +
                "   updated_at AS user_updated_at " +
                "   FROM \"user\"";
    }

    @Override
    protected String getInsertQuery(final User user) throws Exception {
        if (user == null) {
            throw new Exception("L'instance Utilisateur est nulle --> on ne peut pas construire la requête SQL d'insertion");
        }
        return "INSERT INTO \"user\" " +
                "(nom, prenom, rio, is_service_account, created_at, updated_at, email) VALUES (%s, %s, %s, %b, now(), NULL, %s)"
                        .formatted(escapeSQL(user.getLastName()),
                                escapeSQL(user.getFirstName()),
                                escapeSQL(user.getRio()),
                                user.getIsServiceAccount(),
                                escapeSQL(user.getEmail()));
    }

    @Override
    protected String getUpdateQuery(final User user) throws Exception {
        if (user == null) {
            throw new Exception("L'instance Utilisateur est null --> on ne peut pas construire la requête SQL de mise à jour");
        }
        return "UPDATE \"user\" " +
                "SET nom=%s, prenom=%s, rio=%s, is_service_account=%b, email=%s, updated_at=now() WHERE id = %d"
                        .formatted(escapeSQL(user.getLastName()),
                                escapeSQL(user.getFirstName()),
                                escapeSQL(user.getRio()),
                                user.getIsServiceAccount(),
                                escapeSQL(user.getEmail()),
                                user.getId());
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    protected List<User> selectFromQuery(final String selectQuery) throws Exception {
        final List<User> projects = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        User user;
        try {
            connection = this.getConnection();
            preparedStatement = connection.prepareStatement(selectQuery);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                user = RESULT_SET_UTILISATEUR_TRANSCODER.transcode(resultSet);
                projects.add(user);
            }

            // Renvoi de la liste :
            return projects;
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }
    }

    @Override
    public User save(final User user) throws Exception {
       return super.save(user);
     }

    ///// Getters & Setters :


    ///// Classe(s) interne(s) :

    private static class ResultSetUtilisateurTranscoder extends AbstractResultSetTranscoder<User> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "user_id") == null);
            return isNull;
        }

        @Override
        protected User doTranscode(final ResultSet resultSet) throws SQLException {
            final User user = new User();
            user.setId(processLongValue(resultSet, "user_id"));
            user.setLastName(resultSet.getString("user_nom"));
            user.setFirstName(resultSet.getString("user_prenom"));
            user.setIsServiceAccount(resultSet.getBoolean("user_is_service_account"));
            user.setRio(resultSet.getString("user_rio"));
            user.setCreatedAt(processTimestampField(resultSet, "user_created_at"));
            user.setUpdatedAt(processTimestampField(resultSet, "user_updated_at"));
            user.setEmail(resultSet.getString("user_email"));
            return user;
        }
    }
}
