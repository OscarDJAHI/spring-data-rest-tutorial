package fr.minint.console.api.project.repositories;

import fr.minint.console.api.project.entities.FlavorQuota;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface FlavorQuotaRepository extends JpaRepository<FlavorQuota, Long>, JpaSpecificationExecutor<FlavorQuota> {
}
