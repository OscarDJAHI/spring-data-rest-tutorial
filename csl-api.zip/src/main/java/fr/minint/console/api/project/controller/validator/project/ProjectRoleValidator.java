package fr.minint.console.api.project.controller.validator.project;

import fr.minint.console.api.project.entities.*;
import fr.minint.console.api.project.repositories.*;
import fr.minint.console.library.validator.Validator;
import fr.minint.console.persistence.dao.DAO;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

import static fr.minint.console.api.project.model.Role.SOUSCRIPTEUR_ROLE_NAME;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * Permet de valider, avec la paire (userId, resourceId), qu'un utilisateur a les autorisations
 * afin de modifier une resource représentée par son id (resourceId). <br />
 */
@Setter(onMethod = @__(@Autowired))
public class ProjectRoleValidator implements Validator<Pair<String, Long>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProjectRoleValidator.class);
    private ProjectRepository projectRepository;
    private RoleRepository roleRepository;
    private ResourceRepository resourceRepository;
    private RoleAssignementRepository roleAssignementRepository;
    public ProjectRoleValidator(final ProjectRepository projectRepository,
                                final ResourceRepository resourceRepository,
                                final RoleRepository roleRepository) {
        this.projectRepository = projectRepository;
        this.resourceRepository = resourceRepository;
        this.roleRepository = roleRepository;
    }

    ///// Méthodes générales :

    private static void completeErrorMessageBuffer(final StringBuilder errorMsgBuffer, final String message) {
        if (isEmpty(message)) {
            return;
        }
        if (!errorMsgBuffer.isEmpty()) {
            errorMsgBuffer.append(",");
        }
        errorMsgBuffer.append(message.trim());
    }

    @Override
    public boolean validate(final String fieldName,
                            final Pair<String, Long> ownerResourceIdPair,
                            final StringBuilder errorMsgBuffer) {
        if (ownerResourceIdPair == null) {
            return false;
        }
        final String tokenUserId = ownerResourceIdPair.getLeft();
        final Long resourceId = ownerResourceIdPair.getRight();
        try {
            final Optional<Resource> resourceOpt = resourceRepository.findById(resourceId);
            if (resourceOpt.isEmpty()) {
                LOGGER.error("Pas de ressource avec l'id = {}", resourceId);
                completeErrorMessageBuffer(errorMsgBuffer, "Pas de ressource avec l'id = %d".formatted(resourceId));
                return false;
            }
            final Optional<Project> projectOptional = projectRepository.findById(resourceOpt.get().getProject().getId());
            if (projectOptional.isEmpty()) {
                LOGGER.error("Pas de projet avec l'id = {}", resourceOpt.get().getProject());
                completeErrorMessageBuffer(errorMsgBuffer, "Pas de projet avec l'id = %s".formatted(resourceOpt.get().getProject()));
                return false;
            }

            // On vérifie si l'utilsateur est "owner"
            final Project project = projectOptional.get();
            if (!project.getRoleAssignements().stream().filter(roleAssignement -> roleAssignement.getRole().getName().equals(SOUSCRIPTEUR_ROLE_NAME)
                                        &&roleAssignement.getProject().getId().equals(project.getId())&&roleAssignement.getUser().getUid().equals(tokenUserId)).toList().isEmpty()) {
                 return true;
            }

            // On vérifie si l'utilsateur est souscripteur délégué
            final Optional<Role> roleOpt = roleRepository.findByName("delegue");
            if (roleOpt.isEmpty()) {
                LOGGER.error("Pas de rôle 'delegue' dans la base de données");
                completeErrorMessageBuffer(errorMsgBuffer, "Pas de rôle 'delegue' dans la base de données");
                return false;
            }
            final List<Project> userDelegateprojects = new ArrayList<>();
            //noinspection CollectionAddAllCanBeReplacedWithConstructor
            userDelegateprojects.addAll(roleAssignementRepository.findByUserUidAndRoleId(tokenUserId, roleOpt.get().getId()).stream().map(RoleAssignement::getProject).toList());
            final boolean isUserDelegate = userDelegateprojects.contains(project);
            if (!isUserDelegate) {
                completeErrorMessageBuffer(errorMsgBuffer, "L'utilisateur (token id = %s) n' a aucun droits sur la ressource (id = %d) pour la modifier"
                        .formatted(tokenUserId, resourceId));
                LOGGER.error("L'utilisateur (token id = {}) n' a aucun droits sur la ressource (id = {}) pour la modifier", tokenUserId, resourceId);
                return false;
            }
            return true;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            completeErrorMessageBuffer(errorMsgBuffer, e.getMessage());
            return false;
        }
    }

    ///// Getters & Setters :

    public ProjectRoleValidator(RoleAssignementRepository roleAssignementRepository, ResourceRepository resourceRepository, RoleRepository roleRepository, ProjectRepository projectRepository) {
        this.roleAssignementRepository = roleAssignementRepository;
        this.resourceRepository = resourceRepository;
        this.roleRepository = roleRepository;
        this.projectRepository = projectRepository;
    }


//    public ResourceRepository getResourceRepository() {
//        return resourceRepository;
//    }
//
//    public void setResourceRepository(final ResourceRepository resourceRepository) {
//        this.resourceRepository = resourceRepository;
//    }

    public RoleRepository getRoleRepository() {
        return roleRepository;
    }

    public void setRoleRepository(final RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }
}
