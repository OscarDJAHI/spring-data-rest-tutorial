package fr.minint.console.api.project.entities;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "flavor_quota", schema = "public", catalog = "ConsoleAdapation")
public class FlavorQuota {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Basic
    @Column(name = "flavor_value")
    private Long flavorValue;

    @Basic
    @Column(name = "created_at")
    private Timestamp createdAt;

    @Basic
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @ManyToOne
    @JoinColumn(name = "quota_type", referencedColumnName = "id")
    private QuotaType quotaType;

    @ManyToOne
    @JoinColumn(name = "flavor", referencedColumnName = "id")
    private Flavor flavor;
}
