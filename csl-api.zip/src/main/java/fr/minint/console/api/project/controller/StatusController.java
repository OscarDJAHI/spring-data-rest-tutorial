package fr.minint.console.api.project.controller;

 import fr.minint.console.api.project.entities.Status;
 import fr.minint.console.api.project.repositories.StatusRepository;
 import lombok.Setter;
 import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/status")
@Setter(onMethod = @__(@Autowired))
public class StatusController extends AbstractRestController {
    private StatusRepository statusRepository;

    @GetMapping
    public Iterable<Status> list(KeycloakAuthenticationToken keycloakAuthenticationToken) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return statusRepository.findAll();
    }

    @GetMapping("/{status_id}")
    public Optional<Status> get(final KeycloakAuthenticationToken keycloakAuthenticationToken,
            @PathVariable("status_id") final Long statusId) {
        this.assertHasSubscriberOrDelegatedSubscriberGroup(keycloakAuthenticationToken);
        return statusRepository.findById(statusId);
    }

    ///// Getters & Setters :

    @Autowired
    public void setStatusRepository(final StatusRepository statusRepository) {
        this.statusRepository = statusRepository;
    }
}
