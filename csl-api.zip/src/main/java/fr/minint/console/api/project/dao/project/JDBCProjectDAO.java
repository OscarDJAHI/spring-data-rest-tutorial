package fr.minint.console.api.project.dao.project;

import fr.minint.console.api.project.dao.document.JDBCVersionedDocumentDAO;
import fr.minint.console.api.project.dao.document.JDBCVersionedDocumentDAO.ResultSetVersionedDocumentTranscoder;
import fr.minint.console.api.project.dao.pai.JDBCPaiDAO;
import fr.minint.console.api.project.dao.pai.JDBCPaiDAO.ResultSetPaiTranscoder;
import fr.minint.console.api.project.model.Pai;
import fr.minint.console.api.project.model.document.VersionedDocument;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.library.transcoder.Transcoder;
import fr.minint.console.persistence.dao.DAO;
import fr.minint.console.persistence.dao.sql.AbstractJDBCDAO;
import fr.minint.console.persistence.dao.sql.AbstractResultSetTranscoder;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static fr.minint.console.library.utils.collection.CollectionUtils.isCollectionEmpty;
import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;

/**
 * <p>
 * DAO permettant de gérer les projets en JDBC. <br />
 * </p>
 *
 * @see DAO
 */
@SuppressWarnings("SqlSourceToSinkFlow")
public class JDBCProjectDAO extends AbstractJDBCDAO<Long, Project> {
    private static final Transcoder<ResultSet, Project> RESULT_SET_PROJECT_TRANSCODER = new ResultSetProjectTranscoder();
    private static final Transcoder<ResultSet, ProjectRole> RESULT_SET_PROJECT_ROLE_TRANSCODER = new ResultSetProjectRoleTranscoder("proj_role");
    private static final Transcoder<ResultSet, VersionedDocument> RESULT_SET_PROJECT_VERSIONED_DOCUMENT_TRANSCODER = new ResultSetVersionedDocumentTranscoder("proj_doc");
    private static final Transcoder<ResultSet, Pai> RESULT_SET_PAI_TRANSCODER = new ResultSetPaiTranscoder("pai");
    private DAO<ProjectRole> projectRoleDAO;
    private DAO<Pai> paiDAO;
    private DAO<VersionedDocument> documentDAO;

    ///// Constructeur(s) :

    public JDBCProjectDAO(final DataSource dataSource) {
        super(dataSource, "project", "proj");
        this.projectRoleDAO = new JDBCProjectRoleDAO(dataSource);
        this.paiDAO = new JDBCPaiDAO(dataSource);
        this.documentDAO = new JDBCVersionedDocumentDAO(dataSource);
        this.setBeanIdTranscoder(LONG_ID_TRANSCODER);
        this.setBeanTranscoder(RESULT_SET_PROJECT_TRANSCODER);
    }

    ///// Méthodes de la classe AbstractJDBCDAO :

    @Override
    public void start() throws Exception {
        super.start();
        this.projectRoleDAO.start();
        this.paiDAO.start();
        this.documentDAO.start();
    }

    @Override
    public void close() throws IOException {
        this.documentDAO.close();
        this.paiDAO.close();
        this.projectRoleDAO.close();
        super.close();
    }

    ///// Requête SQL :

    @Override
    public String getSelectCountQuery() {
        return "SELECT COUNT(proj.id) FROM project AS proj" +
                " LEFT JOIN project_role AS proj_role ON (proj.id = proj_role.project)";
    }

    @Override
    public String getSelectAllQuery() {
        return "SELECT proj.id AS proj_id, " +
                "   proj.\"name\" AS proj_name," +
                "   proj.\"label\" AS proj_label," +
                "   proj.description AS proj_description," +
                "   proj.status AS proj_status," +
                "   proj.pai AS proj_pai," +
                "   proj.owner_id AS proj_owner_id," +
                "   proj.created_at AS proj_created_at," +
                "   proj.updated_at AS proj_updated_at," +
                "   proj.cgu_id AS proj_cgu_id," +
                "   proj_role.id AS proj_role_id," +
                "   ro.name AS proj_role_name," +
                "   proj_role.project AS proj_role_project," +
                "   proj_role.role AS proj_role_role," +
                "   proj_role.uid AS proj_role_uid," +
                "   proj_role.service_account AS proj_role_service_account," +
                "   proj_role.is_synchronized AS proj_role_is_synchronized, " +
                "   pai.id AS pai_id, " +
                "   pai.name AS pai_name, " +
                "   pai.code AS pai_code, " +
                "   pai.description AS pai_description, " +
                "   doc.id AS proj_doc_id, " +
                "   doc.doc_path AS proj_doc_doc_path, " +
                "   doc.doc_type_name AS proj_doc_doc_type_name, " +
                "   doc.version_number AS proj_doc_version_number " +
                "   FROM project AS proj" +
                "       LEFT JOIN project_role AS proj_role ON (proj_role.project = proj.id) " +
                "       LEFT JOIN \"role\" as ro on (ro.id = proj_role.\"role\") " +
                "       LEFT JOIN pai AS pai ON (pai.id = proj.pai) " +
                "       LEFT JOIN versioned_document AS doc ON (doc.id = proj.cgu_id)";
    }

    @Override
    protected String getInsertQuery(final Project project) throws Exception {
        if (project == null) {
            throw new Exception("L'instance Project est nulle --> on ne peut pas construire la requête SQL d'insertion");
        }
        return "INSERT INTO public.project " +
                "(name, \"label\", description, status, pai, owner_id, created_at, updated_at, cgu_id) VALUES (%s, %s, %s, %d, %d, %s, now(), now(), %d)"
                        .formatted(escapeSQL(project.getName()),
                                escapeSQL(project.getLabel()),
                                escapeSQL(project.getDescription()),
                                project.getStatus(),
                                project.getPai(),
                                escapeSQL(project.getOwnerId()),
                                project.getCguId());
    }

    @Override
    protected String getUpdateQuery(final Project project) throws Exception {
        if (project == null) {
            throw new Exception("L'instance Project est nulle --> on ne peut pas construire la requête SQL de mise à jour");
        }
        return "UPDATE project " +
                "SET \"name\"=%s, \"label\"=%s, description=%s, status=%d, pai=%d, owner_id=%s, updated_at=now(), cgu_id=%d WHERE id = %d"
                        .formatted(escapeSQL(project.getName()),
                                escapeSQL(project.getLabel()),
                                escapeSQL(project.getDescription()),
                                project.getStatus(),
                                project.getPai(),
                                escapeSQL(project.getOwnerId()),
                                project.getCguId(),
                                project.getId());
    }

    ///// Méthodes de la classe AbstractDefaultJdbcDAO :

    @Override
    protected List<Project> selectFromQuery(final String selectQuery) throws Exception {
        final List<Project> projects = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Project project;
        try {
            final Map<Project, Set<ProjectRole>> projectRoleMap = new HashMap<>();
            final Map<Project, Set<VersionedDocument>> projectVersionedDocumentMap = new HashMap<>();
            connection = this.getConnection();
            preparedStatement = connection.prepareStatement(selectQuery);
            resultSet = preparedStatement.executeQuery();
            VersionedDocument versionedDocument;
            ProjectRole projectRole;
            while (resultSet.next()) {
                project = RESULT_SET_PROJECT_TRANSCODER.transcode(resultSet);

                // Pai :
                project.setProjectPai(RESULT_SET_PAI_TRANSCODER.transcode(resultSet));

                // Lecture Project ↔ Role :
                if (!projectRoleMap.containsKey(project)) {
                    projectRoleMap.put(project, new HashSet<>());
                }
                projectRole = RESULT_SET_PROJECT_ROLE_TRANSCODER.transcode(resultSet);
                if (projectRole != null) {
                    projectRoleMap.get(project).add(projectRole);
                }

                // Lecture Project ↔ Document :
                if (!projectVersionedDocumentMap.containsKey(project)) {
                    projectVersionedDocumentMap.put(project, new HashSet<>());
                }
                versionedDocument = RESULT_SET_PROJECT_VERSIONED_DOCUMENT_TRANSCODER.transcode(resultSet);
                if (versionedDocument != null) {
                    projectVersionedDocumentMap.get(project).add(versionedDocument);
                }
            }

            // Complétion
            for (Project proj : projectRoleMap.keySet()) {
                proj.setProjectRoles(projectRoleMap.get(proj));
                proj.setProjectDocuments(projectVersionedDocumentMap.get(proj));
                projects.add(proj);
            }

            // Renvoi de la liste :
            return projects;
        } finally {
            closeQuietly(resultSet);
            closeQuietly(preparedStatement);
            closeQuietly(connection);
        }
    }

    @Override
    public Project save(final Project project) throws Exception {

        // Vérification
        if (project == null) {
            return null;
        }

        // Sauvegarde du pai
        Pai savedPai;
        if (project.getProjectPai() != null) {
            savedPai = paiDAO.save(project.getProjectPai());
            project.setPai(savedPai);
        }

        // Sauvegarde des documents :
        if (!isCollectionEmpty(project.getProjectDocuments())) {
            project.setProjectDocuments(this.documentDAO.save(project.getProjectDocuments()));
        }

        // Sauvegarde dans la table Project
        final Project savedProject = super.save(project);

        // Sauvegarde des rôles
        final Set<ProjectRole> projectRoles = project.getProjectRoles();
        this.projectRoleDAO.delete(withJDBCFieldEquals(ProjectRole.class, "project", savedProject.getId()));
        if (!isCollectionEmpty(projectRoles)) {
            for (ProjectRole projectRole : projectRoles) {
                projectRole.setId(null);
                projectRole.setProject(savedProject.getId());
            }
            savedProject.setProjectRoles(this.projectRoleDAO.save(projectRoles));
        }

        // Retourne le projet sauvegardé :
        return savedProject;
    }

    ///// Getters & Setters :

    public DAO<ProjectRole> getProjectRoleDAO() {
        return projectRoleDAO;
    }

    public void setProjectRoleDAO(final DAO<ProjectRole> projectRoleDAO) {
        this.projectRoleDAO = projectRoleDAO;
    }

    public void setPaiDAO(final DAO<Pai> paiDAO) {
        this.paiDAO = paiDAO;
    }

    public DAO<Pai> getPaiDAO() {
        return paiDAO;
    }

    ///// Classe(s) interne(s) :

    private static class ResultSetProjectTranscoder extends AbstractResultSetTranscoder<Project> {

        @Override
        protected boolean shouldBeConsideredAsNull(final ResultSet resultSet) throws SQLException {
            boolean isNull = resultSet == null;
            isNull = isNull || (processLongValue(resultSet, "proj_id") == null);
            return isNull;
        }

        @Override
        protected Project doTranscode(final ResultSet resultSet) throws SQLException {
            final Project project = new Project();
            project.setId(processLongValue(resultSet, "proj_id"));
            project.setName(resultSet.getString("proj_name"));
            project.setLabel(resultSet.getString("proj_label"));
            project.setDescription(resultSet.getString("proj_description"));
            project.setStatus(processLongValue(resultSet, "proj_status"));
            project.setPai(processLongValue(resultSet, "proj_pai"));
            project.setOwnerId(resultSet.getString("proj_owner_id"));
            try {
                final Pai pai = RESULT_SET_PAI_TRANSCODER.transcode(resultSet);
                project.setProjectPai(pai);
            } catch (final Exception exception) {
                throw new SQLException(exception.getMessage(), exception);
            }
            return project;
        }
    }
}
