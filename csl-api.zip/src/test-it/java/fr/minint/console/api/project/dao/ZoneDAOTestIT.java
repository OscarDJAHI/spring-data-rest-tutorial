package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.model.Zone;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ZoneDAOTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(ZoneDAOTestIT.class);

    @Autowired
    private ZoneDAO zoneDAO;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetAllZones() throws Exception {
        assertThat(zoneDAO).isNotNull();
        final List<Zone> zones = zoneDAO.selectAll();
        assertThat(zones).isNotNull();
        assertThat(zones).isNotEmpty();
        for (Zone zone : zones) {
            LOGGER.info("Zone [id = {}, name = {}]", zone.getId(), zone.getName());
        }
    }
}