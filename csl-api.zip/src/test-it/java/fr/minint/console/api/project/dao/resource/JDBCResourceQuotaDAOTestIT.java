package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.quota.JDBCQuotaTypeDAO;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceQuota;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCResourceQuotaDAOTestIT extends AbstractDAOTestIT {
    private JDBCResourceQuotaDAO resourceQuotaDAO;
    private DAO<Resource> resourceDAO;
    private DAO<QuotaType> quotaTypeDAO;

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation des DAO's :
        resourceDAO = new JDBCResourceDAO(this.dataSource);
        resourceQuotaDAO = new JDBCResourceQuotaDAO(this.dataSource);
        quotaTypeDAO = new JDBCQuotaTypeDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(resourceQuotaDAO);
        closeDAO(resourceDAO);
        closeDAO(quotaTypeDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(dataSource).isNotNull();
        assertThat(resourceDAO).isNotNull();
        assertThat(resourceQuotaDAO).isNotNull();
        assertThat(quotaTypeDAO).isNotNull();
    }


    @Test
    public void shouldInsert() throws Exception {

        // Création de la resource :
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource"));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création du type de quota :
        final QuotaType quotaType1 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType1", "Label du type de quota 1", "icon1.jpg", 15L, 20L, 16L, "Go", 1L));
        final QuotaType quotaType2 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType2", "Label du type de quota 2", "icon2.jpg", 16L, 21L, 17L, "Go", 2L));


        // Création de l'instance ResourceQuota :
        final ResourceQuota resourceQuota = new ResourceQuota(null, 15L, quotaType1.getId(), savedResource.getId());
        final ResourceQuota savedResourceQuota = this.resourceQuotaDAO.save(resourceQuota);
        assertThat(savedResourceQuota).isNotNull();
        assertThat(savedResourceQuota.getId()).isNotNull();

        // Vérification de la base de données :
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(1);
        final List<ResourceQuota> foundResourceQuotas = this.resourceQuotaDAO.selectAll();
        assertThat(foundResourceQuotas).isNotNull();
        assertThat(foundResourceQuotas.size()).isEqualTo(1);
        assertThat(foundResourceQuotas.get(0).getResource()).isEqualTo(savedResource.getId());
        assertThat(foundResourceQuotas.get(0).getQuotaType()).isEqualTo(quotaType1.getId());
        assertThat(foundResourceQuotas.get(0).getQuotaValue()).isEqualTo(15L);
    }


    @Test
    public void shouldUpdateResourceQuota() throws Exception {

        // Création de la resource :
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource2"));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création du type de quota :
        final QuotaType quotaType1 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType1", "Label du type de quota 1", "icon1.jpg", 15L, 20L, 16L, "Go", 1L));
        final QuotaType quotaType2 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType2", "Label du type de quota 2", "icon2.jpg", 16L, 21L, 17L, "Go", 2L));


        // Création de l'instance ResourceQuota :
        ResourceQuota savedResourceQuota = this.resourceQuotaDAO.save(new ResourceQuota(null, 15L, quotaType1.getId(), savedResource.getId()));
        assertThat(savedResourceQuota).isNotNull();
        assertThat(savedResourceQuota.getId()).isNotNull();
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(1);

        // Mis à jour :
        savedResourceQuota.setQuotaTypeBean(quotaType2);
        savedResourceQuota.setQuotaValue(17L);
        this.resourceQuotaDAO.save(savedResourceQuota);
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(1);

        // Vérification des champs :
        final Optional<ResourceQuota> foundResourceOpt = this.resourceQuotaDAO
                .selectFirst(withJDBCFieldEquals(ResourceQuota.class, "resource", savedResource.getId()));
        assertThat(foundResourceOpt).isNotEmpty();
        assertThat(foundResourceOpt.get().getQuotaValue()).isEqualTo(17L);
        assertThat(foundResourceOpt.get().getQuotaTypeBean()).isEqualTo(quotaType2);
    }


    @Test
    public void shouldDeleteAll() throws Exception {

        // Création de la resource :
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource2"));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création du type de quota :
        final QuotaType quotaType1 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType1", "Label du type de quota 1", "icon1.jpg", 15L, 20L, 16L, "Go", 1L));
        final QuotaType quotaType2 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType2", "Label du type de quota 2", "icon2.jpg", 16L, 21L, 17L, "Go", 2L));


        // Création des instances ResourceQuota :
        this.resourceQuotaDAO.save(new ResourceQuota(null, 15L, quotaType1.getId(), savedResource.getId()));
        this.resourceQuotaDAO.save(new ResourceQuota(null, 17L, quotaType2.getId(), savedResource.getId()));
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(2);

        // Et on supprime tout :
        this.resourceQuotaDAO.deleteAll();
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(0);
    }


    @Test
    public void shouldDeleteWithPredicate() throws Exception {

        // Création de la resource :
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource2"));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création du type de quota :
        final QuotaType quotaType1 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType1", "Label du type de quota 1", "icon1.jpg", 15L, 20L, 16L, "Go", 1L));
        final QuotaType quotaType2 = quotaTypeDAO
                .save(new QuotaType(null, "quotaType2", "Label du type de quota 2", "icon2.jpg", 16L, 21L, 17L, "Go", 2L));


        // Création des instances ResourceQuota :
        this.resourceQuotaDAO.save(new ResourceQuota(null, 15L, quotaType1.getId(), savedResource.getId()));
        this.resourceQuotaDAO.save(new ResourceQuota(null, 17L, quotaType2.getId(), savedResource.getId()));
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(2);

        // On supprime
        this.resourceQuotaDAO.delete(withJDBCFieldEquals(ResourceQuota.class, "quota_type", quotaType1.getId()));
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(1);
        final List<ResourceQuota> resourceQuotas = this.resourceQuotaDAO.selectAll();
        assertThat(resourceQuotas).isNotEmpty();
        assertThat(resourceQuotas.get(0).getQuotaTypeBean()).isEqualTo(quotaType2);
        assertThat(resourceQuotas.get(0).getQuotaValue()).isEqualTo(17L);
        assertThat(resourceQuotas.get(0).getResource()).isEqualTo(savedResource.getId());
    }

}