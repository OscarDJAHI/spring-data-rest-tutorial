package fr.minint.console.api.project.controller.validator.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.DAO;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class NotExistingResourceValidatorTestIT extends AbstractDAOTestIT {
    private DAO<Project> projectDAO;
    private DAO<ResourceType> resourceTypeDAO;
    private DAO<Resource> resourceDAO;
    private NotExistingResourceValidator notExistingResourceValidator;

    private static Project createProject(final String projectName,
                                         final String projectLabel,
                                         final String ownerUid) {
        final Project project = new Project(null, projectName, ownerUid);
        project.setLabel(projectLabel);
        return project;
    }

    private static Resource createResource(final String resourceName,
                                           final Long resourceTypeId,
                                           final Long projectId) {
        final Resource resource = new Resource(null, resourceName);
        resource.setResourceType(resourceTypeId);
        resource.setProject(projectId);
        return resource;
    }

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {
        this.cleanDatabase();

        // Création du validateur :
        notExistingResourceValidator = new NotExistingResourceValidator(resourceDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.projectDAO).isNotNull();
        assertThat(this.resourceTypeDAO).isNotNull();
        assertThat(this.resourceDAO).isNotNull();
    }

    @Test
    public void shouldValidateOrNot() throws Exception {

        // Bouchonnage de la base de données :
        final ResourceType iaasResourceType = resourceTypeDAO.save(new ResourceType(null, "iaas", "Type IAAS", "cat1"));
        final ResourceType s3ResourceType = resourceTypeDAO.save(new ResourceType(null, "s3", "Type S3", "cat2"));

        // Bouchonnage des ressources et des projets :
        final Project savedProject = projectDAO.save(createProject("fredProject", "Projet de fred", "projectUid"));
        final Resource savedFredResource = resourceDAO.save(createResource("fredIaasResource", iaasResourceType.getId(), savedProject.getId()));
        assertThat(savedFredResource).isNotNull();
        assertThat(savedFredResource.getId()).isNotNull();

        // On lance le validateur :
        assertThat(notExistingResourceValidator.validate("name", Pair.of("fredIaasResource", iaasResourceType.getId()), new StringBuilder())).isFalse();
        assertThat(notExistingResourceValidator.validate("name", Pair.of("fredIaasResource", s3ResourceType.getId()), new StringBuilder())).isTrue();
        assertThat(notExistingResourceValidator.validate("name", Pair.of("otherIaasResource", iaasResourceType.getId()), new StringBuilder())).isTrue();
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceDAO(final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setResourceTypeDAO(@Qualifier("resourceTypeDAO") final DAO<ResourceType> resourceTypeDAO) {
        this.resourceTypeDAO = resourceTypeDAO;
    }

    @Autowired
    public void setProjectDAO(@Qualifier("projectDAO") final DAO<Project> projectDAO) {
        this.projectDAO = projectDAO;
    }
}