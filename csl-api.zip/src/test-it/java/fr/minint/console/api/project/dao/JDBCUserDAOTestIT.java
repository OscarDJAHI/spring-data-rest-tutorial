package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.User;
import fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCUserDAOTestIT extends AbstractDAOTestIT {
    private JDBCUserDAO jdbcUserDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {
        this.cleanDatabase();

        // Init du DAO :
        this.jdbcUserDAO = new JDBCUserDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(this.jdbcUserDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTheTestParameters() {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.jdbcUserDAO).isNotNull();
    }

    @Test
    public void shouldSelectWithEmptyCollection() throws Exception {

        // Bouchonnage de la base de données :
        final List<User> users = new ArrayList<>();
        users.add(new User("mouleRio", "frederic", "moule", "frederic.moule@gmail.com"));
        users.add(new User("nadiaRio", "nadia", "lastName", "nadia.lastName@gmail.com"));
        users.add(new User("fabienRio", "fabien", "limousin", "fabien.limousin@interieur.gouv.fr"));
        this.jdbcUserDAO.save(users);

        // Vérification de la base
        assertThat(this.jdbcUserDAO.selectCount()).isEqualTo(3L);

        // Sélection avec une collection vide :
        final List<User> foundUsers = this.jdbcUserDAO.select(withFieldInCollection(User.class, "rio", new ArrayList<>()));
        assertThat(foundUsers).isNotNull();
        assertThat(foundUsers).isEmpty();
    }

    @Test
    public void shouldSave() throws Exception {

        // Sauvegarde
        this.jdbcUserDAO.save(new User("1020067", "frederic", "moule", "frederic.moule@gmail.com"));

        // Vérification
        assertThat(this.jdbcUserDAO.selectCount()).isEqualTo(1L);
        final Optional<User> foundUserOptional = this.jdbcUserDAO.selectFirst(Objects::nonNull);
        assertThat(foundUserOptional).isNotEmpty();
        final User foundUser = foundUserOptional.get();
        assertThat(foundUser.getFirstName()).isEqualTo("frederic");
        assertThat(foundUser.getLastName()).isEqualTo("moule");
        assertThat(foundUser.getRio()).isEqualTo("1020067");
        assertThat(foundUser.getEmail()).isEqualTo("frederic.moule@gmail.com");
    }


    @Test
    public void shouldUpdate() throws Exception {

        // Sauvegarde
        User savedUser = this.jdbcUserDAO.save(new User("1020067", "frederic", "moule", "frederic.moule@gmail.com"));
        assertThat(savedUser).isNotNull();
        assertThat(savedUser.getIsServiceAccount()).isFalse();
        assertThat(this.jdbcUserDAO.selectCount()).isEqualTo(1);

        // Mis à jour
        savedUser.setIsServiceAccount(true);
        savedUser = this.jdbcUserDAO.save(savedUser);
        assertThat(savedUser.getIsServiceAccount()).isTrue();

        // Vérification de la base de données :
        assertThat(this.jdbcUserDAO.selectCount()).isEqualTo(1);
        final Optional<User> foundUserOpt = this.jdbcUserDAO.selectFirst(user -> "1020067".equals(user.getRio()));
        assertThat(foundUserOpt).isNotEmpty();
        final User foundUser = foundUserOpt.get();
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getIsServiceAccount()).isTrue();
        assertThat(foundUser.getFirstName()).isEqualTo("frederic");
        assertThat(foundUser.getLastName()).isEqualTo("moule");
    }


}