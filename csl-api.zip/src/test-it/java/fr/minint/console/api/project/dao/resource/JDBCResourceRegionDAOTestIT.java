package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Region;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceRegion;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCResourceRegionDAOTestIT extends AbstractDAOTestIT {
    private DAO<Region> areaDAO;
    private DAO<Resource> resourceDAO;
    private JDBCResourceRegionDAO resourceRegionDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation des DAO's :
        this.resourceRegionDAO = new JDBCResourceRegionDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() {
        closeQuietly(resourceRegionDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(dataSource).isNotNull();
        assertThat(areaDAO).isNotNull();
        assertThat(resourceDAO).isNotNull();
        assertThat(resourceRegionDAO).isNotNull();
    }

    @Test
    public void shouldInsertAnLinkAreaResource() throws Exception {

        // Bouchonnage de la base de données :
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource"));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();
        final Region savedArea = this.areaDAO.save(new Region(null, "fr", "France"));
        assertThat(savedArea).isNotNull();
        assertThat(savedArea.getId()).isNotNull();

        // Insertion du lien Resource ↔ Region :test_
        final ResourceRegion savedResourceArea = this.resourceRegionDAO.save(new ResourceRegion(null, savedResource.getId(), savedArea.getId()));
        assertThat(savedResourceArea).isNotNull();
        assertThat(savedResourceArea.getId()).isNotNull();

        // On sélectionne depuis la base de données :
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(1);
        final Optional<ResourceRegion> areaResourceOptional = this.resourceRegionDAO.selectFirst(withJDBCFieldEquals(ResourceRegion.class, "resource", savedResource.getId()));
        assertThat(areaResourceOptional).isNotEmpty();
        assertThat(areaResourceOptional.get().getResource()).isEqualTo(savedResource.getId());
        assertThat(areaResourceOptional.get().getRegion()).isEqualTo(savedArea.getId());
    }

    @Test
    public void shouldDeleteAll() throws Exception {
        final Region savedArea = this.areaDAO.save(new Region(null, "fr", "France"));
        Resource savedResource;
        for (int i = 0; i < 5; i++) {
            savedResource = this.resourceDAO.save(new Resource(null, "fredResource" + i));
            this.resourceRegionDAO.save(new ResourceRegion(null, savedResource.getId(), savedArea.getId()));
        }
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(5);
        this.resourceRegionDAO.deleteAll();
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(0);
    }


    @Test
    public void shouldSelectFromAPredicate() throws Exception {
        final Region savedArea = this.areaDAO.save(new Region(null, "fr", "France"));
        Resource savedResource;
        for (int i = 0; i < 5; i++) {
            savedResource = this.resourceDAO.save(new Resource(null, "fredResource" + i));
            this.resourceRegionDAO.save(new ResourceRegion(null, savedResource.getId(), savedArea.getId()));
        }
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(5);

        // On sélectionne la resource :
        final Optional<Resource> foundResourceOptional = this.resourceDAO.selectFirst(withJDBCFieldEquals(Resource.class, true, "name", "fredResource2"));
        assertThat(foundResourceOptional).isNotEmpty();

        // Puis le lien :
        final Optional<ResourceRegion> foundResourceAreaOptional = this.resourceRegionDAO.selectFirst(withJDBCFieldEquals(ResourceRegion.class, "resource", foundResourceOptional.get().getId()));
        assertThat(foundResourceAreaOptional).isNotNull();
        assertThat(foundResourceAreaOptional).isNotEmpty();
        assertThat(foundResourceAreaOptional.get().getResource()).isEqualTo(foundResourceOptional.get().getId());
        assertThat(foundResourceAreaOptional.get().getRegion()).isEqualTo(savedArea.getId());
    }


    @Test
    public void shouldUpdate() throws Exception {
        final Region savedArea = this.areaDAO.save(new Region(null, "fr", "France"));
        final List<Resource> savedResources = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            savedResources.add(this.resourceDAO.save(new Resource(null, "fredResource" + i)));
        }
        assertThat(savedResources.size()).isEqualTo(5);

        // On créé un lien :
        ResourceRegion savedResourceArea = this.resourceRegionDAO.save(new ResourceRegion(null, savedResources.get(0).getId(), savedArea.getId()));
        assertThat(savedResourceArea).isNotNull();
        assertThat(savedResourceArea.getId()).isNotNull();

        // On met à jour
        savedResourceArea.setResource(savedResources.get(1).getId());
        this.resourceRegionDAO.save(savedResourceArea);
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(1);
        savedResourceArea = this.resourceRegionDAO.selectFirst(withJDBCFieldEquals(ResourceRegion.class, "id", savedResourceArea.getId())).orElse(null);
        assertThat(savedResourceArea).isNotNull();
        assertThat(savedResourceArea.getResource()).isEqualTo(savedResources.get(1).getId());
        assertThat(savedResourceArea.getRegion()).isEqualTo(savedArea.getId());
    }

    ///// Getters & Setters :

    @Autowired
    public void setAreaDAO(@Qualifier("regionDAO") final DAO<Region> areaDAO) {
        this.areaDAO = areaDAO;
    }

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }
}