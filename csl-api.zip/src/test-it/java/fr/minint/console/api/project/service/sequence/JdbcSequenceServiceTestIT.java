package fr.minint.console.api.project.service.sequence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles({"test"})
class JdbcSequenceServiceTestIT {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetNeededParameters() {
        assertThat(jdbcTemplate).isNotNull();
    }

    @Test
    public void shouldGetNextValue() {
        final JdbcSequenceService seqService = new JdbcSequenceService("ext_users_rio_seq", this.jdbcTemplate);
        final Long initialValue = seqService.getNextValue();
        Long nextValue = seqService.getNextValue();

        assertThat(initialValue).isNotNull();
        assertThat(nextValue).isNotNull();
        assertThat(nextValue).isEqualTo(initialValue + 1L);
        nextValue = seqService.getNextValue();
        assertThat(nextValue).isEqualTo(initialValue + 2L);
        assertThat(seqService.getCurrentValue()).isEqualTo(initialValue + 2L);
    }

    @Test
    public void shouldSetTheValue() {
        final JdbcSequenceService seqService = new JdbcSequenceService("ext_users_rio_seq", this.jdbcTemplate);
        final Long initialValue = seqService.getNextValue();

        seqService.setCurrentValue(9000015L);
        final Long nextValue = seqService.getNextValue();
        assertThat(nextValue).isNotNull();
        assertThat(nextValue).isEqualTo(9000015L);
        seqService.setCurrentValue(initialValue);
        assertThat(seqService.getNextValue()).isEqualTo(initialValue);
    }

}