package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.DAO;
import org.json.JSONArray;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import javax.sql.DataSource;
import java.time.Duration;
import java.util.Optional;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.JDBCUtils.executeUpdateQuery;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.time.temporal.ChronoUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.OK;

@SpringBootTest
@ActiveProfiles({"test"})
class ResourceControllerTestIT extends AbstractControllerTest {
    private DataSource dataSource;
    private ResourceController resourceController;
    private JDBCProjectDAO projectDAO;
    private DAO<Role> roleDAO;
    private DAO<Resource> resourceDAO;

    ///// Méthode(s) statique(s) :

    private static Project createProject(final String projectName, final String ownerUid) {
        final Project project = new Project(null, projectName, ownerUid);
        project.setLabel("Label de " + projectName);
        return project;
    }

    private static Resource createResource(final String resourceName, final Project project) {
        final Resource resource = new Resource(null, resourceName);
        resource.setProjectBean(project);
        return resource;
    }

    ///// Initialisation

    @BeforeEach
    void setUp() throws Exception {
        resourceDAO = resourceController.getResourceDAO();
        projectDAO = new JDBCProjectDAO(dataSource);

        // Nettoyage de la base de données :
        executeUpdateQuery(dataSource, "DELETE FROM resource");
        executeUpdateQuery(dataSource, "DELETE FROM project");
        executeUpdateQuery(dataSource, "DELETE FROM role");

        // Initialisation des rôles :
        this.roleDAO.save(new Role(null, "delegue"));
        this.roleDAO.save(new Role(null, "souscripteur"));
    }

    @AfterEach
    void tearDown() {
        closeQuietly(projectDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetDAOs() {
        assertThat(dataSource).isNotNull();
        assertThat(resourceController.getResourceDAO()).isNotNull();
        assertThat(resourceController.getResourceTypeDAO()).isNotNull();
        assertThat(resourceController.getRoleDAO()).isNotNull();
        assertThat(resourceController.getTagDAO()).isNotNull();
        assertThat(resourceController.getAreaDAO()).isNotNull();
        assertThat(resourceController.getZoneDAO()).isNotNull();
        assertThat(resourceController.getHistoryRecordDAO()).isNotNull();
    }

    @Test
    public void shouldGetExecutorService() {
        assertThat(resourceController).isNotNull();
        assertThat(resourceController.getExecutorService()).isNotNull();
        assertThat(resourceController.getRoleRepository()).isNotNull();
        assertThat(resourceController.getProjectRepository()).isNotNull();
    }

    @Test
    public void shouldGetThePredicates() {
        assertThat(resourceController).isNotNull();
        assertThat(resourceController.getHasSubscriberGroupPredicate()).isNotNull();
        assertThat(resourceController.getHasSubscriberOrDelegatedSubscriberGroupPredicate()).isNotNull();
    }

    @Test
    public void shouldGetWorkflowParameters() {
        assertThat(resourceController.getNbMaxCreatedTenants()).isEqualTo(10);
        final Duration duration = resourceController.getNbMaxCreatedTenantsDuration();
        assertThat(duration).isNotNull();
        assertThat(duration.get(SECONDS)).isEqualTo(5 * 60);
    }


    /**
     * <p>
     * Ce test permet de tester la correction de la
     * faille de sécurité décrite par le ticket <a href="https://git.forge.pi.dsic.minint.fr/pi/portail/console/console-back/-/issues/84">PEN04</a>
     * </p>
     *
     * @throws Exception : En cas de problème
     */
    @Test
    public void shouldGetResourceForUser() throws Exception {

        // Récupération du ou des rôles :
        final Optional<Role> delegueRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "delegue"));
        assertThat(delegueRoleOpt).isNotNull();
        assertThat(delegueRoleOpt).isNotEmpty();
        final Role delegueRole = delegueRoleOpt.get();

        // Création du projet
        final Project savedProject1 = projectDAO.save(createProject("projet1", "fredUid"));
        final Project savedProject2 = projectDAO.save(createProject("projet2", "oscarUid"));
        final Project project3 = createProject("projet3", "oscarUid");
        project3.addRoleToUser("fredUid", delegueRole);
        final Project savedProject3 = projectDAO.save(project3);

        // Création des resources :
        final Resource savedResource1 = resourceDAO.save(createResource("resource1", savedProject1));
        final Resource savedResource2 = resourceDAO.save(createResource("resource2", savedProject2));
        final Resource savedResource3 = resourceDAO.save(createResource("resource3", savedProject3));

        // On sélectionne les resources pour lesquelles "fredUid" est soit souscripteur, soit souscripteur délégué :
        ResponseEntity<String> responseEntity = this.resourceController.get(createMockedKeycloakAuthenticationToken("fredUid"), savedResource1.getId());
        assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
        assertThat(responseEntity.getBody()).isNotEmpty();
        responseEntity = this.resourceController.get(createMockedKeycloakAuthenticationToken("fredUid"), savedResource2.getId());
        assertThat(responseEntity.getStatusCode()).isEqualTo(NOT_FOUND);
        responseEntity = this.resourceController.get(createMockedKeycloakAuthenticationToken("fredUid"), savedResource3.getId());
        assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
        assertThat(responseEntity.getBody()).isNotEmpty();
    }


    @Test
    public void shouldListResourceForUser() throws Exception {

        // Récupération du ou des rôles :
        final Optional<Role> delegueRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "delegue"));
        assertThat(delegueRoleOpt).isNotNull();
        assertThat(delegueRoleOpt).isNotEmpty();
        final Role delegueRole = delegueRoleOpt.get();

        // Création du projet
        final Project savedProject1 = projectDAO.save(createProject("projet1", "fredUid"));
        final Project savedProject2 = projectDAO.save(createProject("projet2", "oscarUid"));
        final Project project3 = createProject("projet3", "oscarUid");
        project3.addRoleToUser("fredUid", delegueRole);
        final Project savedProject3 = projectDAO.save(project3);

        // Création des resources :
        final Resource savedResource1 = resourceDAO.save(createResource("resource1", savedProject1));
        resourceDAO.save(createResource("resource2", savedProject2));
        final Resource savedResource3 = resourceDAO.save(createResource("resource3", savedProject3));

        // On sélectionne les resources pour lesquelles "fredUid" est soit souscripteur, soit souscripteur délégué :
        ResponseEntity<String> responseEntity = this.resourceController.list(createMockedKeycloakAuthenticationToken("fredUid"), null);
        assertThat(responseEntity.getStatusCode()).isEqualTo(OK);
        assertThat(responseEntity.getBody()).isNotEmpty();
        final JSONArray jsonResources = new JSONArray(responseEntity.getBody());
        assertThat(jsonResources.length()).isEqualTo(2);
        assertThat(jsonResources.getJSONObject(0).getLong("id")).isIn(savedResource1.getId(), savedResource3.getId());
        assertThat(jsonResources.getJSONObject(1).getLong("id")).isIn(savedResource1.getId(), savedResource3.getId());
    }

    ///// Getters & Setters :

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Autowired
    public void setResourceController(final ResourceController resourceController) {
        this.resourceController = resourceController;
    }

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roldeDAO) {
        this.roleDAO = roldeDAO;
    }
}