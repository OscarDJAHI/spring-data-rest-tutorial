package fr.minint.console.api.project.dao.project;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Pai;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.library.utils.collection.CollectionUtils.findFirst;
import static fr.minint.console.library.utils.predicate.IdPredicate.withId;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCProjectDAOTestIT extends AbstractDAOTestIT {
    private JDBCProjectDAO projectDAO;
    private DAO<Role> roleDAO;

    private static Project createProject(final String projectName,
                                         final String ownerUid,
                                         final String projectLabel) {
        final Project project = new Project(null, projectName, ownerUid);
        project.setLabel(projectLabel);
        return project;
    }

    ///// Initialisation

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage :
        this.cleanDatabase();

        // Initialisation du DAO :
        this.projectDAO = new JDBCProjectDAO(dataSource);
    }

    @AfterEach
    void tearDown() throws Exception {
        closeDAO(this.projectDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.roleDAO).isNotNull();
        assertThat(this.projectDAO).isNotNull();
        assertThat(this.projectDAO.getProjectRoleDAO()).isNotNull();
    }


    @Test
    public void shouldSaveProjectWithRole() throws Exception {

        // Bouchonnage des rôles :
        final Role delegueRole = this.roleDAO.save(new Role(null, "delegue"));
        assertThat(delegueRole).isNotNull();

        // On sauvegarde le projet :
        final Project project = createProject("fredProject", "fredUid", "Label de fredProject");
        project.addRoleToUser("oscarUid", delegueRole);
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // On le récupère depuis la base de données :
        final Optional<Project> foundProjectOptional =
                this.projectDAO.selectFirst(withJDBCFieldEquals(Project.class, "proj", "id", savedProject.getId()));
        assertThat(foundProjectOptional).isNotEmpty();
        final Project foundProject = foundProjectOptional.get();
        assertThat(foundProject.getName()).isEqualTo("fredProject");
        assertThat(foundProject.getOwnerId()).isEqualTo("fredUid");
        assertThat(foundProject.getOwnerId()).isEqualTo("fredUid");
        assertThat(foundProject.getLabel()).isEqualTo("Label de fredProject");
        final Set<ProjectRole> projectRoles = foundProject.getProjectRoles();
        assertThat(projectRoles).isNotNull();
        assertThat(projectRoles).isNotEmpty();
        assertThat(projectRoles.size()).isEqualTo(1);
        final ProjectRole foundResourceRole = findFirst(projectRoles, Objects::nonNull);
        assertThat(foundResourceRole).isNotNull();
        assertThat(foundResourceRole.getId()).isNotNull();
        assertThat(foundResourceRole.getRole()).isEqualTo(delegueRole.getId());
        assertThat(foundResourceRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(foundResourceRole.getUid()).isEqualTo("oscarUid");
    }


    @Test
    public void shouldSaveAndSelectProjectWithPai() throws Exception {

        // On sauvegarde le projet :
        final Project project = createProject("fredProject", "fredUid", "Label de fredProject");
        project.setPai(new Pai("fredPai", "paiCode", "paiDescription"));

        // Sauvegarde du projet :
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();
        assertThat(savedProject.getProjectPai()).isNotNull();

        // Vérification de la base de données :
        final Optional<Project> foundProjectOpt = this.projectDAO.selectFirst(withId(savedProject.getId()));
        assertThat(foundProjectOpt).isNotEmpty();
        final Project foundProject = foundProjectOpt.get();
        assertThat(foundProject).isNotNull();
        assertThat(foundProject.getName()).isEqualTo("fredProject");
        assertThat(foundProject.getLabel()).isEqualTo("Label de fredProject");
        final Pai projectPai = foundProject.getProjectPai();
        assertThat(projectPai).isNotNull();
    }


    @Test
    public void shouldFetchTheRSSIField() throws Exception {

        // Bouchonnage des rôles :
        final Role delegueRole = this.roleDAO.save(new Role(null, "delegue"));
        assertThat(delegueRole).isNotNull();
        final Role rssiRole = this.roleDAO.save(new Role(null, Role.RSSI_ROLE_NAME));
        assertThat(rssiRole).isNotNull();

        // On sauvegarde le projet :
        final Project project = createProject("fredProject", "fredUid", "Label de fredProject");
        project.addRoleToUser("francisUid", rssiRole);
        project.addRoleToUser("oscarUid", delegueRole);
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Récupération du projet de la base de données :
        final Optional<Project> foundProjectOpt = this.projectDAO.selectFirst(withJDBCFieldEquals(Project.class, "id", savedProject.getId()));
        assertThat(foundProjectOpt).isNotNull();
        assertThat(foundProjectOpt).isNotEmpty();
        final Project foundProject = foundProjectOpt.get();

        // Vérification du rôle RSSI :
        final Set<ProjectRole> projectRoles = foundProject.getProjectRoles();
        assertThat(projectRoles).isNotEmpty();
        final Optional<ProjectRole> foundRssiProjRoleOpt = projectRoles.stream().filter(projRole -> Role.RSSI_ROLE_NAME.equals(projRole.getRoleName())).findFirst();
        assertThat(foundRssiProjRoleOpt).isNotEmpty();
        assertThat(foundRssiProjRoleOpt.get().getUid()).isEqualTo("francisUid");
        assertThat(foundRssiProjRoleOpt.get().getProject()).isEqualTo(savedProject.getId());
        assertThat(foundRssiProjRoleOpt.get().getRole()).isEqualTo(rssiRole.getId());
    }


    @Test
    public void shouldUpdateProject() throws Exception {

        // Bouchonnage des rôles :
        final Role delegueRole = this.roleDAO.save(new Role(null, "delegue"));
        assertThat(delegueRole).isNotNull();
        final Role concepteurRole = this.roleDAO.save(new Role(null, "concepteur"));
        assertThat(concepteurRole).isNotNull();

        // Création du projet :
        final Project project = createProject("fredProject", "fredUid", "Label du projet");
        project.addRoleToUser("oscarUid", delegueRole);
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Mis à jour
        savedProject.setLabel("Nouveau label");
        savedProject.clearRoles();
        savedProject.addRoleToUser("oscarUid", concepteurRole);
        this.projectDAO.save(savedProject);

        // Vérification de la base de données :
        assertThat(this.projectDAO.selectCount()).isEqualTo(1L);
        assertThat(this.projectDAO.getProjectRoleDAO().selectCount()).isEqualTo(1L);
        final Optional<Project> foundProjectOpt = this.projectDAO
                .selectFirst(withJDBCFieldEquals(Project.class, "proj", "name", "fredProject"));
        assertThat(foundProjectOpt).isNotNull();
        assertThat(foundProjectOpt).isNotEmpty();
        final Project foundProject = foundProjectOpt.get();
        assertThat(foundProject.getLabel()).isEqualTo("Nouveau label");
        assertThat(foundProject.getProjectRoles()).isNotEmpty();
        assertThat(foundProject.getProjectRoles().size()).isEqualTo(1);
        final ProjectRole foundProjectRole = findFirst(foundProject.getProjectRoles(), Objects::nonNull);
        assertThat(foundProjectRole).isNotNull();
        assertThat(foundProjectRole.getRole()).isEqualTo(concepteurRole.getId());
        assertThat(foundProjectRole.getProject()).isEqualTo(foundProject.getId());
        assertThat(foundProjectRole.getUid()).isEqualTo("oscarUid");
    }


    @Test
    public void shouldDeleteAll() throws Exception {

        // Bouchonnage des rôles :
        final Role concepteurRole = this.roleDAO.save(new Role(null, "concepteur"));
        assertThat(concepteurRole).isNotNull();
        assertThat(concepteurRole.getId()).isNotNull();

        // Création des projets :
        final Project project = createProject("testProject", "fredUid", "label");
        project.addRoleToUser("fabienUid", concepteurRole);
        projectDAO.save(project);
        projectDAO.save(createProject("testProject2", "fredUid2", "label2"));

        // Vérification :
        assertThat(this.projectDAO.selectCount()).isEqualTo(2);
        assertThat(this.projectDAO.getProjectRoleDAO().selectCount()).isEqualTo(1);

        // Suppression des projets :
        this.projectDAO.deleteAll();
        assertThat(this.projectDAO.selectCount()).isEqualTo(0);
        assertThat(this.projectDAO.getProjectRoleDAO().selectCount()).isEqualTo(0);
    }


    @Test
    public void shouldDeleteFromPredicate() throws Exception {

        // Bouchonnage des rôles :
        final Role delegueRole = this.roleDAO.save(new Role(null, "delegue"));
        assertThat(delegueRole).isNotNull();
        final Role concepteurRole = this.roleDAO.save(new Role(null, "concepteur"));
        assertThat(concepteurRole).isNotNull();

        // Création des projets :
        final Project project = createProject("testProject", "fredUid", "label");
        project.addRoleToUser("fabienUid", concepteurRole);
        projectDAO.save(project);
        final Project project2 = createProject("testProject2", "fredUid2", "label2");
        project2.addRoleToUser("oscarUid", delegueRole);
        projectDAO.save(project2);
        assertThat(this.projectDAO.selectCount()).isEqualTo(2L);
        assertThat(this.projectDAO.getProjectRoleDAO().selectCount()).isEqualTo(2L);

        // Suppression
        this.projectDAO.delete(withJDBCFieldEquals(Project.class, "name", "testProject"));
        assertThat(this.projectDAO.selectCount()).isEqualTo(1L);
        assertThat(this.projectDAO.getProjectRoleDAO().selectCount()).isEqualTo(1L);
    }

    ///// Getters & Setters :

    @Autowired
    public void setRoleDAO(final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}