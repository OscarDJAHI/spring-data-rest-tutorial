package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.dao.role.JDBCRoleDAO;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.model.Pai;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.document.VersionedDocument;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.persistence.dao.DAO;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.util.*;

import static fr.minint.console.api.project.model.Role.DELEGUE_ROLE_NAME;
import static fr.minint.console.api.project.model.Role.RSSI_ROLE_NAME;
import static fr.minint.console.api.project.model.document.VersionedDocumentType.CGU;
import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.library.utils.json.JSONUtils.filterJSONArray;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

@SpringBootTest
@ActiveProfiles({"test"})
class ProjectControllerTestIT extends AbstractDAOTestIT {
    @Autowired
    private ProjectController projectController;
    private DAO<Project> projectDAO;
    private DAO<Role> roleDAO;
    private DAO<LdapUser> ldapUserDAO;

    ///// Intialisation

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Création des DAO's
        this.roleDAO = new JDBCRoleDAO(this.dataSource);
        this.roleDAO.start();
        this.projectDAO = new JDBCProjectDAO(this.dataSource);
        this.projectDAO.start();

        // Bouchonnage des roles
        this.roleDAO.save(new Role(null, DELEGUE_ROLE_NAME));
        this.roleDAO.save(new Role(null, "souscripteur"));
        this.roleDAO.save(new Role(null, RSSI_ROLE_NAME));
    }

    @AfterEach
    void tearDown() {
        closeQuietly(this.projectDAO);
        closeQuietly(this.roleDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTestParameters() {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.projectDAO).isNotNull();
    }

    @Test
    public void shouldGetProjectParameters() {

        // Vérification du controlleur :
        assertThat(projectController).isNotNull();

        // Vérification des DAO's :
        assertThat(projectController.getResourceDAO()).isNotNull();
        assertThat(projectController.getExecutorService()).isNotNull();
        assertThat(projectController.getPaiDAO()).isNotNull();
        assertThat(projectController.getLdapUserDAO()).isNotNull();
        assertThat(projectController.getUserDAO()).isNotNull();
        assertThat(projectController.getProjectRoleDAO()).isNotNull();

        // Vérification pour le multi-threading :
        assertThat(projectController.getExecutorService()).isNotNull();
    }

    @Test
    public void shouldListBasicProjects() throws Exception {

        // Ajout dans la base de données :
        final Set<Project> projects = new HashSet<>();
        projects.add(new Project(null, "projet1", "fmouleUid"));
        projects.add(new Project(null, "projet2", "oscarUid"));
        projects.add(new Project(null, "projet3", "fmouleUid"));
        this.projectDAO.save(projects);

        // Vérification de la réponse HTTP :
        final ResponseEntity<String> httpResponse = this.projectController.list(createMockedKeycloakAuthenticationToken("fmouleUid"));
        assertThat(httpResponse).isNotNull();
        assertThat(httpResponse.getStatusCode()).isEqualTo(OK);
        final JSONArray jsonProjects = new JSONArray(httpResponse.getBody());
        assertThat(jsonProjects).isNotEmpty();
        assertThat(jsonProjects.length()).isEqualTo(2);

        JSONObject jsonProject = filterJSONArray(jsonProjects, (jsonProj -> "projet1".equals(jsonProj.getString("name"))));
        assertThat(jsonProject).isNotNull();
        assertThat(jsonProject.getString("name")).isEqualTo("projet1");
        assertThat(jsonProject.getString("label")).isEqualTo("projet1");
        assertThat(jsonProject.getString("ownerId")).isEqualTo("fmouleUid");
        jsonProject = filterJSONArray(jsonProjects, (jsonProj -> "projet3".equals(jsonProj.getString("name"))));
        assertThat(jsonProject).isNotNull();
        assertThat(jsonProject.getString("name")).isEqualTo("projet3");
        assertThat(jsonProject.getString("label")).isEqualTo("projet3");
        assertThat(jsonProject.getString("ownerId")).isEqualTo("fmouleUid");
    }


    @Test
    public void shouldListProjectsWithPaiAndDocs() throws Exception {

        // Récupération du rôle délégue
        final Optional<Role> delegueRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", DELEGUE_ROLE_NAME));
        assertThat(delegueRoleOpt).isNotEmpty();
        final Role delegueRole = delegueRoleOpt.get();
        assertThat(delegueRole.getName()).isEqualTo(DELEGUE_ROLE_NAME);

        // Ajout dans la base de données :
        final Set<Project> projects = new HashSet<>();
        final Project project1 = new Project(null, "projet1", "fmouleUid");
        project1.setProjectPai(new Pai("pai1", "paiCode1", "1er PAI"));
        project1.setProjectDocuments(singleton(new VersionedDocument("/cgu1.txt", CGU, 1)));
        project1.addRoleToUser("julietteUid", delegueRole);
        projects.add(project1);
        projects.add(new Project(null, "projet2", "oscarUid"));
        projects.add(new Project(null, "projet3", "fmouleUid"));
        this.projectDAO.save(projects);

        // Récupération du projet
        final ResponseEntity<String> httpResponse = this.projectController.list(createMockedKeycloakAuthenticationToken("fmouleUid"));
        assertThat(httpResponse).isNotNull();
        assertThat(httpResponse.getStatusCode()).isEqualTo(OK);
        final JSONArray jsonProjects = new JSONArray(httpResponse.getBody());
        assertThat(jsonProjects).isNotEmpty();
        assertThat(jsonProjects.length()).isEqualTo(2);

        // Vérification de la récupération du PAI :
        final JSONObject jsonProject = filterJSONArray(jsonProjects, (jsonProj -> "projet1".equals(jsonProj.getString("name"))));
        assertThat(jsonProject).isNotNull();
        assertThat(jsonProject.getString("name")).isEqualTo("projet1");
        assertThat(jsonProject.getString("label")).isEqualTo("projet1");
        assertThat(jsonProject.has("pai")).isTrue();
        final JSONObject jsonPai = jsonProject.getJSONObject("pai");
        assertThat(jsonPai).isNotNull();
        assertThat(jsonPai.getString("name")).isEqualTo("pai1");
        assertThat(jsonPai.getString("code")).isEqualTo("paiCode1");
        assertThat(jsonPai.getString("description")).isEqualTo("1er PAI");

        // Vérification des documents :
        assertThat(jsonProject.has("docs")).isTrue();
        final JSONArray jsonDocs = jsonProject.getJSONArray("docs");
        assertThat(jsonDocs).isNotNull();
        assertThat(jsonDocs.length()).isEqualTo(1);
        final JSONObject jsonCguDoc = jsonDocs.getJSONObject(0);
        assertThat(jsonCguDoc.getString("type")).isEqualTo("cgu");
        assertThat(jsonCguDoc.getString("path")).isEqualTo("/cgu1.txt");
        assertThat(jsonCguDoc.getInt("version")).isEqualTo(1);
    }


    @Test
    public void shouldUpdateRssiProject() throws Exception {

        // Récupération du rôle 'rssi'
        final Optional<Role> rssiRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", RSSI_ROLE_NAME));
        assertThat(rssiRoleOpt).isNotEmpty();
        final Role rssiRole = rssiRoleOpt.get();
        assertThat(rssiRole.getName()).isEqualTo(RSSI_ROLE_NAME);

        final Optional<Role> delegueRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", DELEGUE_ROLE_NAME));
        assertThat(delegueRoleOpt).isNotEmpty();
        final Role delegueRole = delegueRoleOpt.get();
        assertThat(delegueRole.getName()).isEqualTo(DELEGUE_ROLE_NAME);

        // Création du projet :
        final Project project = new Project(null, "projet1", "fmouleUid");
        project.setProjectPai(new Pai("pai1", "paiCode1", "1er PAI"));
        project.setProjectDocuments(singleton(new VersionedDocument("/cgu1.txt", CGU, 1)));
        project.addRoleToUser("julietteUid", delegueRole);
        project.addRoleToUser("fabienUid", rssiRole);
        final Project savedProject = this.projectDAO.save(project);
        Optional<Project> foundProjectOpt = this.projectDAO.selectFirst(withJDBCFieldEquals(Project.class, "id", savedProject.getId()));
        assertThat(foundProjectOpt).isNotEmpty();
        assertThat(foundProjectOpt.get().getRssi()).isEqualTo("fabienUid");

        // Mis à jour
        final Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("id", savedProject.getId());
        requestBody.put("rssi", "9000059");
        final ResponseEntity<String> httpResponse = this.projectController.update(createMockedKeycloakAuthenticationToken("fmouleUid"), savedProject.getId(), requestBody);
        assertThat(httpResponse).isNotNull();
        assertThat(httpResponse.getStatusCode()).isEqualTo(OK);

        // Vérification de la base de données :
        foundProjectOpt = this.projectDAO.selectFirst(withJDBCFieldEquals(Project.class, "id", savedProject.getId()));
        assertThat(foundProjectOpt).isNotEmpty();
        assertThat(foundProjectOpt.get().getProjectRoles()).isNotEmpty();
        assertThat(foundProjectOpt.get().getProjectRoles().size()).isEqualTo(2);
        assertThat(foundProjectOpt.get().getRssi()).isEqualTo("9000059");
    }

}