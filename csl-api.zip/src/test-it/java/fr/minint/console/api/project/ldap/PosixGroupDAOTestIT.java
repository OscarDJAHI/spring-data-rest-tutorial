package fr.minint.console.api.project.ldap;

import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.api.project.ldap.model.PosixGroup.PosixGroupCnPredicat.withCn;
import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("DataFlowIssue")
@SpringBootTest
@ActiveProfiles({"test"})
class PosixGroupDAOTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(PosixGroupDAOTestIT.class);
    private DAO<PosixGroup> posixGroupDAO;

    ///// Tests fonctionnels :

    @Test
    public void shouldSelectAll() throws Exception {
        assertThat(this.posixGroupDAO).isNotNull();
        final List<PosixGroup> posixGroups = this.posixGroupDAO.selectAll();
        assertThat(posixGroups).isNotNull();
        assertThat(posixGroups).isNotEmpty();
    }


    @Test
    public void shouldSelectPosixGroupFromName() throws Exception {
        final Optional<PosixGroup> foundPosixGroupOptional = this.posixGroupDAO.selectFirst(withCn("bastion-r1-s1"));
        assertThat(foundPosixGroupOptional).isNotEmpty();
    }

    @Test
    public void shouldAddMember() throws Exception {
        Optional<PosixGroup> foundPosixGroupOptional = this.posixGroupDAO.selectFirst(withCn("bastion-r1-s1"));
        assertThat(foundPosixGroupOptional).isNotEmpty();
        PosixGroup posixGroup = foundPosixGroupOptional.get();
        posixGroup.addMember("9000002");
        this.posixGroupDAO.save(posixGroup);
        foundPosixGroupOptional = this.posixGroupDAO.selectFirst(withCn("bastion-r1-s1"));
        assertThat(foundPosixGroupOptional).isNotEmpty();
        final Set<String> members = foundPosixGroupOptional.get().getMembers();
        assertThat(members).isNotEmpty();
        assertThat(members.contains("9000002")).isTrue();
    }

    ///// Getters & Setters :

    @Autowired
    public void setPosixGroupDAO(@Qualifier("posixGroupDAO") final DAO<PosixGroup> posixGroupDAO) {
        LOGGER.info("---> Initialisation du posixGroupDAO");
        this.posixGroupDAO = posixGroupDAO;
    }

}