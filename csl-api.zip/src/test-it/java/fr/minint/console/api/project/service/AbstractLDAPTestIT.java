package fr.minint.console.api.project.service;

import com.unboundid.ldap.listener.InMemoryDirectoryServer;
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
import com.unboundid.ldap.listener.InMemoryListenerConfig;
import com.unboundid.ldap.sdk.LDAPException;
import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.ldap.repository.support.SimpleLdapRepository;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.odm.core.impl.DefaultObjectDirectoryMapper;

import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.ldap.query.LdapQueryBuilder.query;

public abstract class AbstractLDAPTestIT {
    protected static final String DEFAULT_BASE_DN = "dc=interieur,dc=gouv,dc=fr";
    protected static final int DEFAULT_LDAP_PORT = 9321;
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractLDAPTestIT.class);
    public static final String DEFAULT_LOGIN_DN = "cn=admin";
    public static final String DEFAULT_PASSWORD = "password";
    private transient boolean isStarted;
    private String baseDn;
    private String loginDn;
    private String password;
    private InMemoryDirectoryServer server;
    private int listenPort;

    ///// Constructeurs :

    public AbstractLDAPTestIT(final String baseDn, final int listenPort) {
        this.baseDn = baseDn;
        this.loginDn = DEFAULT_LOGIN_DN;
        this.password = DEFAULT_PASSWORD;
        this.listenPort = listenPort;
        this.isStarted = false;
    }

    public AbstractLDAPTestIT() {
        this(DEFAULT_BASE_DN, DEFAULT_LDAP_PORT);
    }

    ///// Méthodes générales :

    protected void start(final String lDiffFilePath) {
        InMemoryDirectoryServerConfig config;
        try {
            LOGGER.info("LDAP server " + this + " starting...");
            config = new InMemoryDirectoryServerConfig(getBaseDn());
            config.addAdditionalBindCredentials(getLoginDn(), getPassword());
            config.setSchema(null);
            config.setListenerConfigs(InMemoryListenerConfig.createLDAPConfig("LDAP", getListenPort()));
            setServer(new InMemoryDirectoryServer(config));
            if (!isEmpty(lDiffFilePath)) {
                getServer().importFromLDIF(true, lDiffFilePath);
            }
            getServer().startListening();
            this.isStarted = true;
            LOGGER.info("LDAP server " + this + " started. Listen on port " + getServer().getListenPort());
        } catch (final Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
            this.isStarted = false;
            throw new RuntimeException(exception);
        }

    }

    protected void stop() {
        server.shutDown(true);
        this.isStarted = false;
        LOGGER.info("LDAP server " + this + " stopped");
    }

    ///// Méthodes de la classe Object :

    @Override
    public String toString() {
        //noinspection StringBufferReplaceableByString
        final StringBuilder buffer = new StringBuilder();
        buffer.append("AbstractLDAPTestIT [");
        buffer.append("baseDN = ").append(this.baseDn);
        buffer.append(",listenPort = ").append(this.listenPort);
        buffer.append("]");
        return buffer.toString();
    }

    ///// Getters & Setters :

    public LdapTemplate getLdapTemplate() throws Exception {
        final LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUserDn(this.loginDn);
        contextSource.setPassword(this.password);
        contextSource.setBase(this.baseDn);
        contextSource.setUrls(new String[]{this.getLDAPHostAddress()});
        contextSource.afterPropertiesSet();
        final LdapTemplate ldapTemplate = new LdapTemplate(contextSource);
        ldapTemplate.afterPropertiesSet();
        return ldapTemplate;
    }

    protected String getLDAPHostAddress() throws LDAPException {
        return "ldap://" + this.getServer().getConnection().getHostPort();
    }

    public boolean isStarted() {
        return isStarted;
    }

    public int getRunningPort() {
        return getServer().getListenPort();
    }

    public String getBaseDn() {
        return baseDn;
    }

    public String getLoginDn() {
        return loginDn;
    }

    public String getPassword() {
        return password;
    }

    public InMemoryDirectoryServer getServer() {
        return server;
    }

    public void setServer(final InMemoryDirectoryServer server) {
        this.server = server;
    }

    public int getListenPort() {
        return listenPort;
    }

    ///// Classe(s) interne(s) :

    protected static class TestITLDAPUserRepository extends SimpleLdapRepository<LdapUser> implements UserLdapRepository {
        private static final DefaultObjectDirectoryMapper ODM = new DefaultObjectDirectoryMapper();

        /**
         * Creates a new {@link SimpleLdapRepository}.
         *
         * @param ldapTemplate must not be {@literal null}.
         */
        public TestITLDAPUserRepository(final LdapTemplate ldapTemplate) {
            super(ldapTemplate, ODM, LdapUser.class);
        }

        @Override
        public Optional<LdapUser> findByUid(final String uid) {
            return this.findOne(query().where("uid").is(uid));
        }

        @Override
        public Optional<LdapUser> findByMail(final String email) {
            return this.findOne(query().where("mail").is(email));
        }
    }
}
