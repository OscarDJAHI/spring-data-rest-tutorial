package fr.minint.console.api.project.dao.quota;

import fr.minint.console.api.project.model.QuotaPricing;
import fr.minint.console.api.project.model.QuotaType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.Optional;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.JDBCUtils.executeUpdateQuery;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCQuotaPricingDAOTestIT {
    private DataSource dataSource;
    private JDBCQuotaPricingDAO quotaPricingDAO;
    private JDBCQuotaTypeDAO quotaTypeDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {
        this.quotaPricingDAO = new JDBCQuotaPricingDAO(dataSource);
        this.quotaTypeDAO = new JDBCQuotaTypeDAO(dataSource);

        // Nettoyage de la base de données :

        // Nettoyage des données :
        executeUpdateQuery(dataSource, "DELETE FROM flavor_quota");
        executeUpdateQuery(dataSource, "DELETE FROM flavor");
        executeUpdateQuery(dataSource, "DELETE FROM resource_role");
        executeUpdateQuery(dataSource, "DELETE FROM resource_quota");
        executeUpdateQuery(dataSource, "DELETE FROM resource_region");
        executeUpdateQuery(dataSource, "DELETE FROM resource_tag");
        executeUpdateQuery(dataSource, "DELETE FROM tag");
        executeUpdateQuery(dataSource, "DELETE FROM role");
        executeUpdateQuery(dataSource, "DELETE FROM resource");
        executeUpdateQuery(dataSource, "DELETE FROM project");
        executeUpdateQuery(dataSource, "DELETE FROM region");
        executeUpdateQuery(dataSource, "DELETE FROM quota_pricing");
        executeUpdateQuery(dataSource, "DELETE FROM quota_type");
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(this.quotaPricingDAO);
        closeDAO(this.quotaTypeDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(dataSource).isNotNull();
    }

    @Test
    public void shouldInsertQuotaPricing() throws Exception {
        final QuotaType savedQuotaType = this.quotaTypeDAO
                .save(new QuotaType(null, "fredQuotaType", "Label du quota", "icon", 5L, 10L, 5L, "Go", 1L));
        assertThat(savedQuotaType).isNotNull();

        // Insertion de l'instance QuotaPricing :
        final QuotaPricing savedQuotaPricing = this.quotaPricingDAO
                .save(new QuotaPricing(null, "Go", 15D, 10D, savedQuotaType.getId()));
        assertThat(savedQuotaPricing).isNotNull();
        assertThat(savedQuotaPricing.getId()).isNotNull();
    }

    @Test
    public void shouldDeleteAll() throws Exception {
        QuotaType quotaType;
        for (int i = 0; i < 5; i++) {
            quotaType = this.quotaTypeDAO.save(new QuotaType(null, "fredQuotaType" + i, "Label du quota" + i, "icon" + i, 5L, 10L, 5L, "Go", 1L));
            this.quotaPricingDAO.save(new QuotaPricing(null, "Go", (double) (15 + i), (double) (10 + i), quotaType.getId()));
        }

        // Sélectionne :
        assertThat(this.quotaPricingDAO.selectCount()).isEqualTo(5);
        this.quotaPricingDAO.deleteAll();
        assertThat(this.quotaPricingDAO.selectCount()).isEqualTo(0);
    }


    @Test
    public void shouldUpdate() throws Exception {
        final QuotaType quotaType = this.quotaTypeDAO
                .save(new QuotaType(null, "fredQuotaType", "Label du quota", "icon", 5L, 10L, 5L, "Go", 1L));
        final QuotaPricing savedQuotaPricing = this.quotaPricingDAO.save(new QuotaPricing(null, "Go", 15D, 10D, quotaType.getId()));

        // On vérifie :
        assertThat(savedQuotaPricing).isNotNull();
        assertThat(savedQuotaPricing.getId()).isNotNull();
        assertThat(savedQuotaPricing.getQuotaUnit()).isEqualTo("Go");

        // On met à jour
        savedQuotaPricing.setQuotaUnit("Mo");
        this.quotaPricingDAO.save(savedQuotaPricing);
        final Optional<QuotaPricing> quotaPricingOptional = this.quotaPricingDAO.selectFirst(withJDBCFieldEquals(QuotaPricing.class, "id", savedQuotaPricing.getId()));
        assertThat(quotaPricingOptional).isNotEmpty();
        assertThat(quotaPricingOptional.get().getQuotaUnit()).isEqualTo("Mo");
    }

    ///// Getters & Setters :

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }
}