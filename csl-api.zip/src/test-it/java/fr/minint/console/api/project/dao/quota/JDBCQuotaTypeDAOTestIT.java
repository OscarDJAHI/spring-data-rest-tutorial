package fr.minint.console.api.project.dao.quota;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.QuotaPricing;
import fr.minint.console.api.project.model.QuotaType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.util.stream.Collectors.toSet;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCQuotaTypeDAOTestIT extends AbstractDAOTestIT {
    private JDBCQuotaTypeDAO quotaTypeDAO;
    private JDBCQuotaPricingDAO quotaPricingDAO;

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation des DAO's :
        this.quotaTypeDAO = new JDBCQuotaTypeDAO(dataSource);
        this.quotaPricingDAO = new JDBCQuotaPricingDAO(dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(quotaTypeDAO);
        closeDAO(quotaPricingDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(dataSource).isNotNull();
        assertThat(quotaTypeDAO).isNotNull();
    }

    @Test
    public void shouldSelectAll() throws Exception {

        // On vérifie que la table est vide :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);

        // On bouchonne la base de données :
        for (int i = 0; i < 5; i++) {
            this.quotaTypeDAO.save(new QuotaType(null, "quotaTypeName" + i, "Label quota " + i, "icon", 5L, 6L, 5L, "G", 1L));
        }
        final List<QuotaType> foundQuotaTypes = this.quotaTypeDAO.selectAll();
        assertThat(foundQuotaTypes).isNotNull();
        assertThat(foundQuotaTypes).isNotEmpty();
        assertThat(foundQuotaTypes.size()).isEqualTo(5);

        // On vérifie avec un prédicat
        Optional<QuotaType> foundQuotaTypeOpt;
        for (int i = 0; i < 5; i++) {
            foundQuotaTypeOpt = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaTypeName" + i));
            assertThat(foundQuotaTypeOpt).isNotNull();
            assertThat(foundQuotaTypeOpt).isNotEmpty();
        }
    }

    @Test
    public void shouldSelectWithPricing() throws Exception {

        // On insère le type en premier :
        final QuotaType savedQuotaType = this.quotaTypeDAO.save(new QuotaType(null, "fredQuoteType"));
        assertThat(savedQuotaType).isNotNull();
        assertThat(savedQuotaType.getId()).isNotNull();

        // On insère le pricing en deuxième :
        final QuotaPricing savedQuotaPricing = this.quotaPricingDAO.save(new QuotaPricing("Go", 15, 25, savedQuotaType.getId()));
        assertThat(savedQuotaPricing).isNotNull();

        // On sélectionne depuis la base de données :
        final Optional<QuotaType> foundQuotaTypeOpt = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "id", savedQuotaType.getId()));
        assertThat(foundQuotaTypeOpt).isNotEmpty();
        final QuotaType foundQuotaType = foundQuotaTypeOpt.get();
        assertThat(foundQuotaType.getQuotaPricing()).isNotNull();
        assertThat(foundQuotaType.getQuotaPricing()).isEqualTo(savedQuotaPricing);
    }

    @Test
    public void shouldInsertQuotaType() throws Exception {
        final QuotaType savedQuotaType
                = this.quotaTypeDAO.save(new QuotaType(null, "quotaType", "Label quota", "icon", 5L, 6L, 5L, "Go", 1L, null));
        assertThat(savedQuotaType).isNotNull();
        assertThat(savedQuotaType.getId()).isNotNull();

        // On récupère depuis la base de données :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(1L);
        final List<QuotaType> foundQuotas = this.quotaTypeDAO.select(withJDBCFieldEquals(QuotaType.class, "quotaType", "id", savedQuotaType.getId()));
        assertThat(foundQuotas.size()).isEqualTo(1);
        assertThat(foundQuotas.get(0).getName()).isEqualTo("quotaType");
        assertThat(foundQuotas.get(0).getLabel()).isEqualTo("Label quota");
        assertThat(foundQuotas.get(0).getQuotaIcon()).isEqualTo("icon");
        assertThat(foundQuotas.get(0).getQuotaMin()).isEqualTo(5L);
        assertThat(foundQuotas.get(0).getQuotaMax()).isEqualTo(6L);
        assertThat(foundQuotas.get(0).getQuotaDefault()).isEqualTo(5L);
        assertThat(foundQuotas.get(0).getQuotaUnit()).isEqualTo("Go");
        assertThat(foundQuotas.get(0).getPriority()).isEqualTo(1L);
    }


    @Test
    public void shouldInsertQuotaTypeWithPricing() throws Exception {

        // Définition du pricing :
        final QuotaPricing quotaPricing = new QuotaPricing("Go", 15, 25, null);

        // Insertion des "quota-types"
        QuotaType quotaType;
        for (int i = 0; i < 2; i++) {
            quotaType = new QuotaType(null, "quotaType" + i);
            quotaType.setQuotaPricing(quotaPricing);
            quotaTypeDAO.save(quotaType);
        }

        // Vérification des "quota-type" en base de données :
        final List<QuotaType> quotaTypes = this.quotaTypeDAO.selectAll();
        assertThat(quotaTypes).isNotNull();
        assertThat(quotaTypes).isNotEmpty();
        assertThat(quotaTypes.size()).isEqualTo(2);

        // Vérification des "pricing" en base de données :
        final List<QuotaPricing> quotaPricings = this.quotaPricingDAO.selectAll();
        assertThat(quotaPricings).isNotNull();
        assertThat(quotaPricings).isNotEmpty();
        assertThat(quotaPricings.size()).isEqualTo(2);
        final Set<Long> quotaTypeIds = quotaTypes.stream().map(QuotaType::getId).collect(toSet());
        Long quotaTypeId;
        for (QuotaPricing pricing : quotaPricings) {
            quotaTypeId = pricing.getQuotaType();
            assertThat(quotaTypeId).isNotNull();
            assertThat(quotaTypeIds.contains(quotaTypeId)).isTrue();
        }
    }


    @Test
    public void shouldUpdateQuotaType() throws Exception {
        final QuotaType savedQuotaType
                = this.quotaTypeDAO.save(new QuotaType(null, "quotaType", "Label quota", "icon", 5L, 6L, 5L, "G", 1L, null));
        assertThat(savedQuotaType).isNotNull();
        assertThat(savedQuotaType.getId()).isNotNull();

        // On met à jour :
        savedQuotaType.setLabel("Autre label");
        this.quotaTypeDAO.save(savedQuotaType);

        // On vérifie la base de données :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(1L);
        final Optional<QuotaType> quotaTypeOptional = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "quotaType", "id", savedQuotaType.getId()));
        assertThat(quotaTypeOptional).isNotNull();
        assertThat(quotaTypeOptional).isNotEmpty();
        assertThat(quotaTypeOptional.get().getLabel()).isEqualTo("Autre label");
    }


    @Test
    public void shouldDeleteAll() throws Exception {

        // On vérifie que la table est vide :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);

        // On bouchonne la base de données :
        for (int i = 0; i < 5; i++) {
            this.quotaTypeDAO.save(new QuotaType(null, "quotaTypeName" + i, "Label quota " + i, "icon", 5L, 6L, 5L, "G", 1L));
        }
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(5L);

        // On efface tout :
        this.quotaTypeDAO.deleteAll();
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);
    }
}