package fr.minint.console.api.project.dao.role;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class RoleDAOTestIT extends AbstractDAOTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(RoleDAOTestIT.class);
    private DAO<Role> roleDAO;

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage des données :
        this.cleanDatabase();
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetDAO() {
        assertThat(dataSource).isNotNull();
        assertThat(roleDAO).isNotNull();
    }

    @Test
    public void shouldSelectAll() throws Exception {

        // Insertion :
        this.roleDAO.save(new Role(null, "role1"));
        this.roleDAO.save(new Role(null, "role2"));

        // Sélection :
        final List<Role> roles = this.roleDAO.selectAll();
        assertThat(roles).isNotNull();
        assertThat(roles).isNotEmpty();
        for (Role role : roles) {
            LOGGER.info("Role trouvé : {}", role);
        }
    }


    @Test
    public void shouldSelectWithJDBCPredicate() throws Exception {

        // Insertion
        this.roleDAO.save(new Role(null, "role1"));
        this.roleDAO.save(new Role(null, "role2"));

        // On sélectionne :
        final Optional<Role> roleOptional = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1"));
        assertThat(roleOptional).isNotNull();
        assertThat(roleOptional).isNotEmpty();

        // Vérification des champs :
        final Role foundRole = roleOptional.get();
        assertThat(foundRole.getId()).isNotNull();
        assertThat(foundRole.getName()).isEqualTo("role1");
    }

    ///// Getters & Setters :

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}