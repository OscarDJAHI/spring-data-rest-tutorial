package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.dao.quota.JDBCQuotaTypeDAO;
import fr.minint.console.api.project.model.*;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.api.project.model.resource.*;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.Instant;
import java.util.*;

import static fr.minint.console.api.project.model.Tag.createTag;
import static fr.minint.console.api.project.utils.predicate.project.JDBCUserHasProjectRolePredicate.withUserHavingProjectRole;
import static fr.minint.console.library.utils.collection.CollectionUtils.findFirst;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldInCollectionPredicate.withFieldInCollection;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
public class JDBCResourceDAOTestIT extends AbstractDAOTestIT {
    protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractDAOTestIT.class);
    private DAO<ResourceType> resourceTypeDAO;
    private DAO<Resource> resourceDAO;
    private DAO<Project> projectDAO;
    private DAO<Tag> tagDAO;
    private DAO<Role> roleDAO;
    private DAO<Region> areaDAO;
    private DAO<ResourceTag> resourceTagDAO;
    private DAO<ResourceRole> resourceRoleDAO;
    private DAO<ResourceRegion> resourceRegionDAO;
    private DAO<ResourceQuota> resourceQuotaDAO;
    private DAO<QuotaType> quotaTypeDAO;

    // Constantes :
    private ResourceType iaasRessourceType;
    private ResourceType s3RessourceType;

    ///// Méthodes statiques :

    private static Resource createResource(final String resourceName,
                                           final String description,
                                           final ResourceType resourceType) {
        final Resource resource = new Resource();
        resource.setName(resourceName);
        resource.setDescription(description);
        resource.setResourceTypeBean(resourceType);
        return resource;
    }

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage des données :
        cleanDatabase();

        // Initialisation de certains DAOs :
        if (this.resourceDAO instanceof JDBCResourceDAO) {
            this.resourceTagDAO = ((JDBCResourceDAO) this.resourceDAO).getResourceTagDAO();
        } else {
            this.resourceTagDAO = new JDBCResourceTagDAO(dataSource);
        }
        this.quotaTypeDAO = new JDBCQuotaTypeDAO(dataSource);
        this.resourceRoleDAO = new JDBCResourceRoleDAO(dataSource);
        this.resourceRegionDAO = new JDBCResourceRegionDAO(dataSource);
        this.resourceQuotaDAO = new JDBCResourceQuotaDAO(dataSource);
        this.projectDAO = new JDBCProjectDAO(dataSource);

        // Insertion des types de quotas :
        this.quotaTypeDAO.save(new QuotaType(null, "quotaType1", "type de quota 1", "icon1", 5L, 10L, 6L, "Go", 1L));
        this.quotaTypeDAO.save(new QuotaType(null, "quotaType2", "type de quota 2", "icon2", 6L, 10L, 6L, "Mo", 2L));

        // Insertion des rôles :
        this.roleDAO.save(new Role(null, "role1"));
        this.roleDAO.save(new Role(null, "role2"));

        // Insertion des types de ressources :
        iaasRessourceType = this.resourceTypeDAO.save(new ResourceType(null, "iaas", "Type de ressource IAAS", "categorie1"));
        s3RessourceType = this.resourceTypeDAO.save(new ResourceType(null, "s3", "Type de ressource S3", "categorie2"));
    }

    @AfterEach
    void tearDown() throws Exception {
        closeDAO(resourceTypeDAO);
        closeDAO(resourceTagDAO);
        closeDAO(resourceRoleDAO);
        closeDAO(resourceRegionDAO);
        closeDAO(resourceQuotaDAO);
        closeDAO(projectDAO);
        closeDAO(tagDAO);
        closeDAO(roleDAO);
        closeDAO(areaDAO);
        closeDAO(quotaTypeDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetAutowiredParameters() {
        assertThat(dataSource).isNotNull();
        assertThat(resourceTypeDAO).isNotNull();
        assertThat(resourceDAO).isNotNull();
        assertThat(projectDAO).isNotNull();
        assertThat(tagDAO).isNotNull();
        assertThat(resourceTagDAO).isNotNull();
        assertThat(roleDAO).isNotNull();
        assertThat(areaDAO).isNotNull();
    }

    @Test
    public void shouldInsertResource() throws Exception {
        final Resource savedResource = resourceDAO.save(createResource("fredResource", "Resource de test", iaasRessourceType));
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // On vérifie le nombre de lignes :
        assertThat(resourceDAO.selectCount()).isEqualTo(1L);
    }

    @Test
    public void shouldSelectWithEmptyCollection() throws Exception {

        // Sauvegarde des ressources :
        final List<Resource> resources = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            resources.add(new Resource(null, "resource" + i));
        }
        resourceDAO.save(resources);

        // Vérification de la BDD :
        assertThat(resourceDAO.selectCount()).isEqualTo(4L);
        List<Resource> foundResources = resourceDAO.select(withFieldInCollection(Resource.class, "id", new ArrayList<>()));
        assertThat(foundResources).isNotNull();
        assertThat(foundResources).isEmpty();
        foundResources = resourceDAO.select(withFieldInCollection(Resource.class, "id", null));
        assertThat(foundResources).isNotNull();
        assertThat(foundResources).isEmpty();
    }


    @Test
    public void shouldSaveWithTag() throws Exception {

        // Définition des tags :
        final Tag savedTag = tagDAO.save(createTag("fredTag", "Tag de fred", "#FFFFFF"));
        assertThat(savedTag).isNotNull();
        assertThat(savedTag.getId()).isNotNull();

        // Définition de la resource à sauver :
        final Resource resource = createResource("fredResource", "Resource de test", iaasRessourceType);
        resource.addResourceTag(new ResourceTag(null, null, savedTag.getId()));

        // Sauvegarde
        final Resource savedResource = resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // On vérifie le lien avec le tag :
        final List<ResourceTag> resourceTags = resourceTagDAO.selectAll();
        assertThat(resourceTags).isNotEmpty();
        assertThat(resourceTags.size()).isEqualTo(1);
        assertThat(resourceTags.get(0).getId()).isGreaterThan(0L);
        assertThat(resourceTags.get(0).getTag()).isEqualTo(savedTag.getId());
        assertThat(resourceTags.get(0).getResource()).isEqualTo(savedResource.getId());
    }


    @Test
    public void shouldSaveWithAreas() throws Exception {

        // Création de la région existante :
        final Region savedR1Area = this.areaDAO.save(new Region("R1", "region R1"));
        assertThat(this.areaDAO.selectCount()).isEqualTo(1L);

        // Définition de la resource à sauver :
        final Resource resource = createResource("fredResource", "Resource de test", iaasRessourceType);
        resource.addRegion(savedR1Area);
        resource.addRegion(new Region("R2", "region R2"));

        // On sauve la ressource :
        final Resource savedResource = this.resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        final Set<Region> savedAreas = savedResource.getRegions();
        assertThat(savedAreas).isNotEmpty();
        assertThat(savedAreas.size()).isEqualTo(2L);
        for (Region savedArea : savedAreas) {
            assertThat(savedArea.getId()).isNotNull();
        }

        // On vérifie la base de données :
        final List<Region> foundAreas = this.areaDAO.selectAll();
        assertThat(foundAreas).isNotNull();
        assertThat(foundAreas).isNotEmpty();
        assertThat(foundAreas.size()).isEqualTo(2L);
    }


    @Test
    public void shouldSaveResourceWithTags() throws Exception {

        // Bouchonnage du tag
        final Tag tag1 = this.tagDAO.save(new Tag(null, "tag1", "tag1", "#FFF888", Instant.now(), Instant.now()));
        assertThat(tag1).isNotNull();
        assertThat(tag1.getId()).isNotNull();

        // Définition de la resource à sauver :
        final Resource resource = createResource("fredResource", "Resource de test", iaasRessourceType);
        resource.addRegion(new Region("R2", "region R2"));
        resource.addTag(tag1);
        resource.addTag(new Tag(null, "tag2", "tag2", "#FFF000", Instant.now(), Instant.now()));

        // Persistance de la ressource :
        final Resource savedResource = this.resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();
        assertThat(savedResource.getTags()).isNotNull();
        assertThat(savedResource.getTags()).isNotEmpty();
        assertThat(savedResource.getTags().size()).isEqualTo(2);

        // Vérification de la base de données :
        assertThat(this.tagDAO.selectCount()).isEqualTo(2L);
    }


    @Test
    public void shouldSaveWithResourceType() throws Exception {

        // Création de la ressource :
        final Resource resource = createResource("fredResource", "Resource de fred", s3RessourceType);
        final Resource savedResource = this.resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getResourceTypeBean()).isNotNull();
        assertThat(savedResource.getResourceType()).isNotNull();

        // On récupère depuis la base de données :
        final Optional<Resource> foundResourceOpt = this.resourceDAO.selectFirst(withJDBCFieldEquals(Resource.class, "id", savedResource.getId()));
        assertThat(foundResourceOpt).isNotEmpty();
        assertThat(foundResourceOpt.get().getResourceTypeBean()).isEqualTo(s3RessourceType);
    }


    @Test
    public void shouldSaveS3ResourceWithAllParameters() throws Exception {

        // Insertions des tags :
        final Tag fredTag1 = tagDAO.save(createTag("fredTag1", "Tag de fred", "#FFFFFF"));
        tagDAO.save(createTag("fredTag2", "Tag 2 de fred", "#FFFFFF"));

        // Insertions des régions :
        final Region area1 = areaDAO.save(new Region(null, "r1", "region r1", "#FFFAAA"));
        final Region area2 = areaDAO.save(new Region(null, "r2", "region r2", "#FFFAAA"));

        // Ajout/récupération du rôle :
        final Role role1 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1")).orElse(null);
        assertThat(role1).isNotNull();
        final Role role2 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role2")).orElse(null);
        assertThat(role2).isNotNull();

        // Recupération des types de quotas :
        final QuotaType quotaType1 = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaType1")).orElse(null);
        assertThat(quotaType1).isNotNull();

        // Insertion de la resource :
        final Resource resource = createResource("fredResource", "Resource de fred", s3RessourceType);
        resource.setRegions(List.of(area1));          // On ajoute la région en tant que S3
        resource.addTag(fredTag1);
        resource.addRole("karine", role1);
        resource.addRole("francis", role2);
        resource.addQuota(15, quotaType1);
        this.resourceDAO.save(resource);

        // On récupère depuis la base de données :
        final List<Resource> resources = this.resourceDAO.selectAll();
        assertThat(resources).isNotNull();
        assertThat(resources.size()).isEqualTo(1);

        // On vérifie les champs :
        final Resource foundResource = resources.get(0);

        // vérification → les régions :
        assertThat(foundResource.getRegion()).isNull();
        final Set<Region> foundRegions = foundResource.getRegions();
        assertThat(foundRegions).isNotNull();
        assertThat(foundRegions.size()).isEqualTo(1);
        assertThat(foundRegions.contains(area1)).isTrue();
        assertThat(foundRegions.contains(area2)).isFalse();

        // vérification → les tags :
        assertThat(foundResource.getResourceTags()).isNotNull();
        assertThat(foundResource.getResourceTags()).isNotEmpty();
        final List<ResourceTag> resourceTags = new ArrayList<>(foundResource.getResourceTags());
        assertThat(resourceTags.size()).isEqualTo(1);
        assertThat(resourceTags.get(0).getTag()).isEqualTo(fredTag1.getId());
        assertThat(resourceTags.get(0).getResource()).isEqualTo(foundResource.getId());

        // Vérification → rôles :
        assertThat(foundResource.getResourceRoles()).isNotNull();
        assertThat(foundResource.getResourceRoles()).isNotEmpty();
        final List<ResourceRole> foundResourceRoles = new ArrayList<>(foundResource.getResourceRoles());
        assertThat(foundResourceRoles.size()).isEqualTo(2);

        // Vérification --> Quotas :
        assertThat(foundResource.getResourceQuotas()).isNotNull();
        assertThat(foundResource.getResourceQuotas()).isNotEmpty();
        final List<ResourceQuota> resourceQuotas = new ArrayList<>(foundResource.getResourceQuotas());
        assertThat(resourceQuotas.get(0).getQuotaType()).isEqualTo(quotaType1.getId());
        assertThat(resourceQuotas.get(0).getQuotaValue()).isEqualTo(15L);
    }


    @Test
    public void shouldSaveIAASResourceWithAllParameters() throws Exception {

        // Insertions des tags :
        final Tag fredTag1 = tagDAO.save(createTag("fredTag1", "Tag de fred", "#FFFFFF"));
        tagDAO.save(createTag("fredTag2", "Tag 2 de fred", "#FFFFFF"));

        // Insertions des régions :
        final Region area1 = areaDAO.save(new Region(null, "r1", "region r1", "#FFFAAA"));
        final Region area2 = areaDAO.save(new Region(null, "r2", "region r2", "#FFFAAA"));

        // Ajout/récupération du rôle :
        final Role role1 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1")).orElse(null);
        assertThat(role1).isNotNull();
        final Role role2 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role2")).orElse(null);
        assertThat(role2).isNotNull();

        // Recupération des types de quotas :
        final QuotaType quotaType1 = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaType1")).orElse(null);
        assertThat(quotaType1).isNotNull();

        // Insertion de la resource :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.setIAASRegion(area2);          // On ajoute la région en tant que IAAS
        resource.addTag(fredTag1);
        resource.addRole("karine", role1);
        resource.addRole("francis", role2);
        resource.addQuota(15, quotaType1);
        this.resourceDAO.save(resource);

        // On récupère depuis la base de données :
        final List<Resource> resources = this.resourceDAO.selectAll();
        assertThat(resources).isNotNull();
        assertThat(resources.size()).isEqualTo(1);

        // On vérifie les champs :
        final Resource foundResource = resources.get(0);

        // vérification → les régions :
        assertThat(foundResource.getRegion()).isEqualTo(area2.getId());
        final Set<Region> foundRegions = foundResource.getRegions();
        assertThat(foundRegions).isNotNull();
        assertThat(foundRegions.size()).isEqualTo(1);
        assertThat(foundRegions.contains(area2)).isTrue();

        // vérification → les tags :
        assertThat(foundResource.getResourceTags()).isNotNull();
        assertThat(foundResource.getResourceTags()).isNotEmpty();
        final List<ResourceTag> resourceTags = new ArrayList<>(foundResource.getResourceTags());
        assertThat(resourceTags.size()).isEqualTo(1);
        assertThat(resourceTags.get(0).getTag()).isEqualTo(fredTag1.getId());
        assertThat(resourceTags.get(0).getResource()).isEqualTo(foundResource.getId());

        // Vérification → rôles :
        assertThat(foundResource.getResourceRoles()).isNotNull();
        assertThat(foundResource.getResourceRoles()).isNotEmpty();
        final List<ResourceRole> foundResourceRoles = new ArrayList<>(foundResource.getResourceRoles());
        assertThat(foundResourceRoles.size()).isEqualTo(2);

        // Vérification --> Quotas :
        assertThat(foundResource.getResourceQuotas()).isNotNull();
        assertThat(foundResource.getResourceQuotas()).isNotEmpty();
        final List<ResourceQuota> resourceQuotas = new ArrayList<>(foundResource.getResourceQuotas());
        assertThat(resourceQuotas.get(0).getQuotaType()).isEqualTo(quotaType1.getId());
        assertThat(resourceQuotas.get(0).getQuotaValue()).isEqualTo(15L);
    }

    @Test
    public void shouldUpdateS3ResourceWithAllParameters() throws Exception {

        // Insertions des tags :
        final Tag fredTag1 = tagDAO.save(createTag("fredTag1", "Tag de fred", "#FFFFFF"));
        final Tag fredTag2 = tagDAO.save(createTag("fredTag2", "Tag 2 de fred", "#FFFFFF"));

        // Insertions des régions :
        final Region area1 = areaDAO.save(new Region(null, "r1", "region r1", "#FFFAAA"));
        final Region area2 = areaDAO.save(new Region(null, "r2", "region r2", "#FFFAAA"));

        // Ajout/récupération du rôle :
        final Role role1 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1")).orElse(null);
        assertThat(role1).isNotNull();
        final Role role2 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role2")).orElse(null);
        assertThat(role2).isNotNull();

        // Recupération des types de quotas :
        final QuotaType quotaType1 = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaType1")).orElse(null);
        assertThat(quotaType1).isNotNull();

        // Insertion de la resource :
        final Resource resource = createResource("fredResource", "Resource de fred", s3RessourceType);
        resource.setRegions(List.of(area1));
        resource.addTag(fredTag1);
        resource.addRole("karine", role1);
        resource.addRole("francis", role2);
        resource.addQuota(15, quotaType1);
        Resource savedResource = this.resourceDAO.save(resource);

        // vérification → les régions :
        assertThat(savedResource.getRegion()).isNull();
        assertThat(savedResource.getRegions()).isNotNull();
        assertThat(savedResource.getRegions().size()).isEqualTo(1);
        assertThat(savedResource.getRegions().contains(area1)).isTrue();

        // vérification → les tags :
        assertThat(savedResource.getResourceTags()).isNotNull();
        assertThat(savedResource.getResourceTags()).isNotEmpty();
        final List<ResourceTag> resourceTags = new ArrayList<>(savedResource.getResourceTags());
        assertThat(resourceTags.size()).isEqualTo(1);
        assertThat(resourceTags.get(0).getTag()).isEqualTo(fredTag1.getId());
        assertThat(resourceTags.get(0).getResource()).isEqualTo(savedResource.getId());

        // Vérification → rôles :
        assertThat(savedResource.getResourceRoles()).isNotNull();
        assertThat(savedResource.getResourceRoles()).isNotEmpty();
        final List<ResourceRole> foundResourceRoles = new ArrayList<>(savedResource.getResourceRoles());
        assertThat(foundResourceRoles.size()).isEqualTo(2);

        // Vérification --> Quotas :
        assertThat(savedResource.getResourceQuotas()).isNotNull();
        assertThat(savedResource.getResourceQuotas()).isNotEmpty();
        final List<ResourceQuota> resourceQuotas = new ArrayList<>(savedResource.getResourceQuotas());
        assertThat(resourceQuotas.get(0).getQuotaType()).isEqualTo(quotaType1.getId());
        assertThat(resourceQuotas.get(0).getQuotaValue()).isEqualTo(15L);

        ////// Mis à jour :

        savedResource.setName("newFredResource");
        savedResource.addTag(fredTag2);
        savedResource.setRegions(List.of(area2, area1));
        this.resourceDAO.save(savedResource);
        assertThat(this.resourceDAO.selectCount()).isEqualTo(1L);
        final Optional<Resource> resOptional = this.resourceDAO
                .selectFirst(withJDBCFieldEquals(Resource.class, "id", savedResource.getId()));
        assertThat(resOptional).isNotEmpty();
        savedResource = resOptional.get();
        assertThat(savedResource.getName()).isEqualTo("newFredResource");
        assertThat(savedResource.getResourceTags()).isNotEmpty();
        assertThat(savedResource.getResourceTags().size()).isEqualTo(2);
        final Set<Region> foundRegions = savedResource.getRegions();
        assertThat(foundRegions.size()).isEqualTo(2);
        assertThat(foundRegions.contains(area2)).isTrue();
        assertThat(foundRegions.contains(area1)).isTrue();
    }


    @Test
    public void shouldUpdateIAASResourceWithAllParameters() throws Exception {

        // Insertions des tags :
        final Tag fredTag1 = tagDAO.save(createTag("fredTag1", "Tag de fred", "#FFFFFF"));
        final Tag fredTag2 = tagDAO.save(createTag("fredTag2", "Tag 2 de fred", "#FFFFFF"));

        // Insertions des régions :
        final Region area1 = areaDAO.save(new Region(null, "r1", "region r1", "#FFFAAA"));
        final Region area2 = areaDAO.save(new Region(null, "r2", "region r2", "#FFFAAA"));

        // Ajout/récupération du rôle :
        final Role role1 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1")).orElse(null);
        assertThat(role1).isNotNull();
        final Role role2 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role2")).orElse(null);
        assertThat(role2).isNotNull();

        // Recupération des types de quotas :
        final QuotaType quotaType1 = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaType1")).orElse(null);
        assertThat(quotaType1).isNotNull();

        // Insertion de la resource :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.setIAASRegion(area1);
        resource.addTag(fredTag1);
        resource.addRole("karine", role1);
        resource.addRole("francis", role2);
        resource.addQuota(15, quotaType1);
        Resource foundResource = this.resourceDAO.save(resource);

        // vérification → les régions :
        assertThat(foundResource.getRegion()).isEqualTo(area1.getId());
        assertThat(foundResource.getRegions()).isNotNull();
        assertThat(foundResource.getRegions().size()).isEqualTo(1);
        assertThat(foundResource.getRegions().contains(area1)).isTrue();

        // vérification → les tags :
        assertThat(foundResource.getResourceTags()).isNotNull();
        assertThat(foundResource.getResourceTags()).isNotEmpty();
        final List<ResourceTag> resourceTags = new ArrayList<>(foundResource.getResourceTags());
        assertThat(resourceTags.size()).isEqualTo(1);
        assertThat(resourceTags.get(0).getTag()).isEqualTo(fredTag1.getId());
        assertThat(resourceTags.get(0).getResource()).isEqualTo(foundResource.getId());

        // Vérification → rôles :
        assertThat(foundResource.getResourceRoles()).isNotNull();
        assertThat(foundResource.getResourceRoles()).isNotEmpty();
        final List<ResourceRole> foundResourceRoles = new ArrayList<>(foundResource.getResourceRoles());
        assertThat(foundResourceRoles.size()).isEqualTo(2);

        // Vérification --> Quotas :
        assertThat(foundResource.getResourceQuotas()).isNotNull();
        assertThat(foundResource.getResourceQuotas()).isNotEmpty();
        final List<ResourceQuota> resourceQuotas = new ArrayList<>(foundResource.getResourceQuotas());
        assertThat(resourceQuotas.get(0).getQuotaType()).isEqualTo(quotaType1.getId());
        assertThat(resourceQuotas.get(0).getQuotaValue()).isEqualTo(15L);

        ////// Mis à jour :

        foundResource.setName("newFredResource");
        foundResource.addTag(fredTag2);
        foundResource.setIAASRegion(area2);
        this.resourceDAO.save(foundResource);
        assertThat(this.resourceDAO.selectCount()).isEqualTo(1L);
        final Optional<Resource> resOptional = this.resourceDAO
                .selectFirst(withJDBCFieldEquals(Resource.class, "id", foundResource.getId()));
        assertThat(resOptional).isNotEmpty();
        foundResource = resOptional.get();
        assertThat(foundResource.getName()).isEqualTo("newFredResource");
        assertThat(foundResource.getResourceTags()).isNotEmpty();
        assertThat(foundResource.getResourceTags().size()).isEqualTo(2);
        final Set<Region> foundRegions = foundResource.getRegions();
        assertThat(foundRegions.size()).isEqualTo(1);
        assertThat(foundRegions.contains(area2)).isTrue();
        assertThat(foundRegions.contains(area1)).isFalse();
    }

    @Test
    public void shouldDeleteAll() throws Exception {
        resourceDAO.save(createResource("fredResource", "Resource de fred", iaasRessourceType));
        resourceDAO.save(createResource("oscarResource", "Resource d'oscar", iaasRessourceType));

        // Vérification du nombre
        assertThat(resourceDAO.selectCount()).isEqualTo(2L);

        // Suppression :
        resourceDAO.deleteAll();

        // Vérification :
        assertThat(resourceDAO.selectCount()).isEqualTo(0L);
    }


    @Test
    public void shouldDeleteIAASResourceWithAllTheLinks() throws Exception {

        // Insertions des tags :
        final Tag fredTag1 = tagDAO.save(createTag("fredTag1", "Tag de fred", "#FFFFFF"));
        tagDAO.save(createTag("fredTag2", "Tag 2 de fred", "#FFFFFF"));

        // Insertions des régions :
        final Region area1 = areaDAO.save(new Region(null, "r1", "region r1", "#FFFAAA"));
        final Region area2 = areaDAO.save(new Region(null, "r2", "region r2", "#FFFAAA"));

        // Ajout/récupération du rôle :
        final Role role1 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1")).orElse(null);
        assertThat(role1).isNotNull();
        final Role role2 = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role2")).orElse(null);
        assertThat(role2).isNotNull();

        // Recupération des types de quotas :
        final QuotaType quotaType1 = this.quotaTypeDAO.selectFirst(withJDBCFieldEquals(QuotaType.class, "name", "quotaType1")).orElse(null);
        assertThat(quotaType1).isNotNull();

        // Insertion de la resource :
        this.resourceDAO.save(new Resource(null, "otherResource"));
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.setIAASRegion(area2);
        resource.addTag(fredTag1);
        resource.addRole("karine", role1);
        resource.addRole("francis", role2);
        resource.addQuota(15, quotaType1);
        final Resource savedResource = this.resourceDAO.save(resource);
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(1);
        assertThat(this.resourceTagDAO.selectCount()).isEqualTo(1);
        assertThat(this.resourceRoleDAO.selectCount()).isEqualTo(2);
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(1);

        // On supprime :
        this.resourceDAO.delete(withJDBCFieldEquals(Resource.class, "id", savedResource.getId()));
        assertThat(this.resourceDAO.selectCount()).isEqualTo(1);
        assertThat(this.resourceRegionDAO.selectCount()).isEqualTo(0);
        assertThat(this.resourceTagDAO.selectCount()).isEqualTo(0);
        assertThat(this.resourceRoleDAO.selectCount()).isEqualTo(0);
        assertThat(this.resourceQuotaDAO.selectCount()).isEqualTo(0);

        // On vérifie que l'on n'a pas supprimé la mauvaise resource :
        final List<Resource> allFoundResources = this.resourceDAO.selectAll();
        assertThat(allFoundResources).isNotNull();
        assertThat(allFoundResources).isNotEmpty();
        assertThat(allFoundResources.get(0)).isNotEqualTo(savedResource);
    }


    @Test
    public void shouldFetchResourceWithRole() throws Exception {

        // On insère le rôle :
        final Optional<Role> roleOptional = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1"));
        assertThat(roleOptional).isNotEmpty();
        assertThat(roleOptional.get().getId()).isNotNull();

        // On insère la resource et le lien Resource ↔ role :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.addResourceRole(new ResourceRole(null, "fredUid", null, roleOptional.get().getId(), null, true));
        final Resource savedResource = resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isGreaterThan(0L);

        // On récupère la resource en fonction de son nom :
        final List<Resource> foundResources = resourceDAO.select(withJDBCFieldEquals(Resource.class, true, "name", "fredResource"));
        assertThat(foundResources).isNotNull();
        assertThat(foundResources.size()).isEqualTo(1);
        final Resource foundResource = foundResources.get(0);
        assertThat(foundResource.getName()).isEqualTo("fredResource");
        assertThat(foundResource.getResourceRoles()).isNotEmpty();
    }


    @Test
    public void shouldFetchResourceWithResourceType() throws Exception {

        // On insère la resource et le lien Resource ↔ resourceType :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        final Resource savedResource = resourceDAO.save(resource);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isGreaterThan(0L);
        assertThat(savedResource.getResourceTypeBean()).isEqualTo(iaasRessourceType);
        assertThat(savedResource.getResourceType()).isEqualTo(iaasRessourceType.getId());

        // On récupère la resource en fonction de son nom :
        final List<Resource> foundResources = resourceDAO.select(withJDBCFieldEquals(Resource.class, true, "name", "fredResource"));
        assertThat(foundResources).isNotNull();
        assertThat(foundResources.size()).isEqualTo(1);
        final Resource foundResource = foundResources.get(0);
        assertThat(foundResource.getName()).isEqualTo("fredResource");
        assertThat(foundResource.getResourceTypeBean()).isEqualTo(iaasRessourceType);
        assertThat(foundResource.getResourceType()).isEqualTo(iaasRessourceType.getId());
    }


    @Test
    public void shouldFetchResourceWithProject() throws Exception {

        // Création du projet :
        final Project project = new Project(null, "testProject", "fredOwner");
        project.setLabel("Project de test");
        final Project savedProject = projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Création de la ressource :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.setProjectBean(savedProject);
        resourceDAO.save(resource);

        // Sélectionne la resource
        final Optional<Resource> resOptional =
                this.resourceDAO.selectFirst(withJDBCFieldEquals(Resource.class, true, "name", "fredResource"));
        assertThat(resOptional).isNotEmpty();
        final Resource foundResource = resOptional.get();
        assertThat(foundResource.getProjectBean()).isNotNull();
        assertThat(foundResource.getProjectBean().getId()).isEqualTo(savedProject.getId());
        assertThat(foundResource.getProjectBean().getOwnerId()).isEqualTo("fredOwner");
    }


    @Test
    public void shouldFetchResourceWithProjectRole() throws Exception {

        // Création du lien Projet ↔ Role :
        final Optional<Role> role1Optional = roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", "role1"));
        assertThat(role1Optional).isNotNull();
        assertThat(role1Optional).isNotEmpty();

        // Création du projet :
        final Project project = new Project(null, "testProject", "fredOwner");
        project.setLabel("Project de test");
        project.addRoleToUser("fredUid", role1Optional.get());
        final Project savedProject = projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();
        final Set<ProjectRole> savedProjectRoles = savedProject.getProjectRoles();
        assertThat(savedProjectRoles).isNotNull();
        assertThat(savedProjectRoles).isNotEmpty();
        assertThat(savedProjectRoles.size()).isEqualTo(1);

        // Création de la ressource :
        final Resource resource = createResource("fredResource", "Resource de fred", iaasRessourceType);
        resource.setProjectBean(savedProject);
        resourceDAO.save(resource);
        resourceDAO.save(createResource("fredResource2", "2ième resource de fred", iaasRessourceType));
        assertThat(resourceDAO.selectCount()).isEqualTo(2L);

        // On récupère la resource :
        final Optional<Resource> resourceOptional = resourceDAO.selectFirst(withUserHavingProjectRole("fredUid", role1Optional.get()));
        assertThat(resourceOptional).isNotNull();
        assertThat(resourceOptional).isNotEmpty();
        final Resource foundResource = resourceOptional.get();
        assertThat(foundResource.getProjectBean()).isNotNull();
        final Set<ProjectRole> projectRoles = foundResource.getProjectBean().getProjectRoles();
        assertThat(projectRoles).isNotNull();
        assertThat(projectRoles).isNotEmpty();
        assertThat(projectRoles.size()).isEqualTo(1L);
        final ProjectRole projectRole = findFirst(projectRoles, Objects::nonNull);
        assertThat(projectRole).isNotNull();
        assertThat(projectRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(projectRole.getRole()).isEqualTo(role1Optional.get().getId());
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceTypeDAO(@Qualifier("resourceTypeDAO") final DAO<ResourceType> resourceTypeDAO) {
        this.resourceTypeDAO = resourceTypeDAO;
    }

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setTagDAO(@Qualifier("tagDAO") final DAO<Tag> tagDAO) {
        this.tagDAO = tagDAO;
    }

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }

    @Autowired
    public void setAreaDAO(@Qualifier("regionDAO") final DAO<Region> areaDAO) {
        this.areaDAO = areaDAO;
    }

    @Autowired
    public void setResourceTagDAO(@Qualifier("resourceTagDAO") final DAO<ResourceTag> resourceTagDAO) {
        this.resourceTagDAO = resourceTagDAO;
    }
}