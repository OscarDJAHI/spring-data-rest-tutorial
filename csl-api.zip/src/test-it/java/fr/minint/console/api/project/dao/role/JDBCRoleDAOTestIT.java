package fr.minint.console.api.project.dao.role;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCRoleDAOTestIT extends AbstractDAOTestIT {
    private DAO<Role> roleDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage des données :
        this.cleanDatabase();

        // Initialisation du DAO :
        this.roleDAO = new JDBCRoleDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(this.roleDAO);
    }

    ////// Tests fonctionnels :

    @Test
    public void shouldInsertAndSelectRoles() throws Exception {

        // Bouchonnage de la base de données :
        final List<Role> roles = new ArrayList<>();
        roles.add(new Role(null, "souscripteur", "label1", "color1", "1er role", true, "ldap1"));
        roles.add(new Role(null, "delegue", "label2", "color2", "2ième role", false, "ldap2"));
        this.roleDAO.save(roles);

        // On vérifie dans la base :
        final List<Role> foundRoles = this.roleDAO.selectAll();
        assertThat(this.roleDAO.selectCount()).isEqualTo(2L);
        assertThat(foundRoles.size()).isEqualTo(2);

        // On récupère :
        Role role = foundRoles.get(0);
        assertThat(role.getId()).isNotNull();
        assertThat(role.getName()).isEqualTo("souscripteur");
        role = foundRoles.get(1);
        assertThat(role.getId()).isNotNull();
        assertThat(role.getName()).isEqualTo("delegue");
    }


}