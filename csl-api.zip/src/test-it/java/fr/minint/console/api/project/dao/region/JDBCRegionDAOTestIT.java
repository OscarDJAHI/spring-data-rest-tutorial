package fr.minint.console.api.project.dao.region;

import fr.minint.console.api.project.model.Region;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.sql.DataSource;
import java.util.List;
import java.util.Optional;

import static fr.minint.console.persistence.dao.sql.JDBCUtils.executeUpdateQuery;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCRegionDAOTestIT {
    private DataSource dataSource;
    private DAO<Region> areaDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {
        executeUpdateQuery(dataSource, "DELETE FROM region");
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(areaDAO).isNotNull();
        assertThat(areaDAO instanceof JDBCRegionDAO).isTrue();
    }

    @Test
    public void shouldInsert() throws Exception {

        // Initialisation
        final Region savedArea = this.areaDAO.save(new Region("FR", "France"));
        assertThat(savedArea).isNotNull();
        assertThat(savedArea.getId()).isNotNull();
        assertThat(savedArea.getName()).isEqualTo("FR");
        assertThat(savedArea.getLabel()).isEqualTo("France");

        // Vérification de la base :
        assertThat(this.areaDAO.selectCount()).isEqualTo(1);
    }


    @Test
    public void shouldSelectFromPredicate() throws Exception {
        for (int i = 0; i < 5; i++) {
            this.areaDAO.save(new Region("area" + i, "Label de la région " + i));
        }
        assertThat(this.areaDAO.selectCount()).isEqualTo(5);

        // On sélectionne à l'aide d'un prédicat :
        final List<Region> foundAreas = this.areaDAO.select(withJDBCFieldEquals(Region.class, "name", "area2"));
        assertThat(foundAreas).isNotEmpty();
        assertThat(foundAreas.size()).isEqualTo(1);
        assertThat(foundAreas.get(0).getName()).isEqualTo("area2");
        assertThat(foundAreas.get(0).getLabel()).isEqualTo("Label de la région 2");

        final Optional<Region> foundRegionOptional = this.areaDAO.selectFirst(withJDBCFieldEquals(Region.class, "name", "area3"));
        assertThat(foundRegionOptional).isNotNull();
        assertThat(foundRegionOptional).isNotEmpty();
        assertThat(foundRegionOptional.get().getId()).isNotNull();
        assertThat(foundRegionOptional.get().getName()).isEqualTo("area3");
        assertThat(foundRegionOptional.get().getLabel()).isEqualTo("Label de la région 3");
    }


    @Test
    public void shouldUpdate() throws Exception {

        // Bouchonnage de la base de données :
        for (int i = 0; i < 3; i++) {
            this.areaDAO.save(new Region("area" + i, "Label de la région " + i));
        }
        assertThat(this.areaDAO.selectCount()).isEqualTo(3);

        // On créé la région :
        final Region savedArea = this.areaDAO.save(new Region("fr", "France"));
        assertThat(savedArea).isNotNull();
        assertThat(savedArea.getId()).isNotNull();
        assertThat(savedArea.getLabel()).isEqualTo("France");
        assertThat(savedArea.getColor()).isNull();

        // Puis on la met à jour :
        savedArea.setLabel("Pays France");
        savedArea.setColor("#FFFA14");
        this.areaDAO.save(savedArea);
        final Optional<Region> areaOptional = this.areaDAO.selectFirst(withJDBCFieldEquals(Region.class, "name", "fr"));
        assertThat(areaOptional).isNotEmpty();
        assertThat(areaOptional.get().getName()).isEqualTo("fr");
        assertThat(areaOptional.get().getLabel()).isEqualTo("Pays France");
        assertThat(areaOptional.get().getColor()).isEqualTo("#FFFA14");
    }


    @Test
    public void shouldUpdateWithNullField() throws Exception {
        final Region savedArea = this.areaDAO.save(new Region(null, "fr", "France", "#FFFFFF"));
        assertThat(savedArea).isNotNull();
        assertThat(savedArea.getId()).isNotNull();
        assertThat(this.areaDAO.selectCount()).isEqualTo(1);

        // On met à jour :
        savedArea.setColor(null);
        this.areaDAO.save(savedArea);
        final Optional<Region> areaOptional = this.areaDAO.selectFirst(withJDBCFieldEquals(Region.class, "id", savedArea.getId()));
        assertThat(areaOptional).isNotEmpty();
        assertThat(areaOptional.get().getColor()).isNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Autowired
    public void setAreaDAO(@Qualifier("regionDAO") final DAO<Region> areaDAO) {
        this.areaDAO = areaDAO;
    }
}