package fr.minint.console.api.project.dao.ldap;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class LdapUserDAOTestIT {
    private DAO<LdapUser> ldapUserDAO;

    ///// Initialisation :

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(this.ldapUserDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTestFields() {
        assertThat(this.ldapUserDAO).isNotNull();
    }

    @Test
    public void shouldSelectAllUsers() throws Exception {
        final List<LdapUser> ldapUsers = this.ldapUserDAO.selectAll();
        assertThat(ldapUsers).isNotNull();
        assertThat(ldapUsers).isNotEmpty();
        assertThat(this.ldapUserDAO.selectCount()).isEqualTo(ldapUsers.size());
    }

    @Test
    public void shouldSelectWithPredicate() throws Exception {
        final Optional<LdapUser> foundLdapUserOpt = this.ldapUserDAO.selectFirst((ldapUser -> "moulefre".equals(ldapUser.getUid())));
        assertThat(foundLdapUserOpt).isNotEmpty();
        final LdapUser foundLdapUser = foundLdapUserOpt.get();
        assertThat(foundLdapUser.getUid()).isEqualTo("moulefre");
        assertThat(foundLdapUser.getDisplayName()).isEqualTo("MOULE FREDERIC");
        assertThat(foundLdapUser.getMail()).isEqualTo("frederic.moule-econocom@interieur.gouv.fr");
        assertThat(foundLdapUser.getSn()).isEqualTo("moule");
        assertThat(foundLdapUser.getCn()).isEqualTo("FREDERIC MOULE moulefre");
    }

    ///// Getters & Setters :

    @Autowired
    public void setLdapUserDAO(@Qualifier("ldapUserDAO") final DAO<LdapUser> ldapUserDAO) {
        this.ldapUserDAO = ldapUserDAO;
    }
}