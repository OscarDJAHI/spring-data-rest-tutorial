package fr.minint.console.api.project.service.iaas;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@SpringBootTest
@ActiveProfiles({"test"})
class TenantServiceTestIT {
    private TenantService tenantService;

    ///// Tests fonctionnels :

    @Test
    public void shouldInitTheTenantService() {
        assertThat(tenantService).isNotNull();
        assertThat(tenantService.getPosixGroupDAO()).isNotNull();
        assertThat(tenantService.getAreaDAO()).isNotNull();
        assertThat(tenantService.getZoneDAO()).isNotNull();
        assertThat(tenantService.getResourceDAO()).isNotNull();
        assertThat(tenantService.getRoleDAO()).isNotNull();
        assertThat(tenantService.getServiceAccountDAO()).isNotNull();
        assertThat(tenantService.getExecutorService()).isNotNull();
    }


    @Test
    public void shouldGetServiceAccountDAO() {
        assertThat(tenantService.getServiceAccountDAO()).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setTenantService(final TenantService tenantService) {
        this.tenantService = tenantService;
    }
}