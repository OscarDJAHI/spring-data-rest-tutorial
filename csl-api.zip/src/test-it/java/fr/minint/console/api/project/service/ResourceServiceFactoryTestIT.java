package fr.minint.console.api.project.service;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Region;
import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.service.iaas.NamespaceResourceService;
import fr.minint.console.api.project.service.iaas.TenantService;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Optional;

import static fr.minint.console.api.project.types.Category.IAAS;
import static fr.minint.console.api.project.types.Category.S3;
import static fr.minint.console.api.project.types.ResourceType.NAMESPACE;
import static fr.minint.console.api.project.types.ResourceType.TENANT;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ResourceServiceFactoryTestIT extends AbstractDAOTestIT {
    private ResourceServiceFactory resourceServiceFactory;
    private DAO<ResourceType> resourceTypeDAO;


    private static Resource create(final String name, final String description, final String externalId) {
        final Resource resource = new Resource();
        resource.setName(name);
        resource.setDescription(description);
        resource.setExternalId(externalId);
        resource.setResourceType(null);
        resource.setZone(null);
        resource.setIAASRegion((Region) null);
        resource.setStatus(null);
        resource.setProject(null);
        return resource;
    }

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Insertions des types de ressources :
        this.resourceTypeDAO.save(new ResourceType(null, TENANT.getName(), "Label de " + TENANT.getName(), IAAS.name()));
        this.resourceTypeDAO.save(new ResourceType(null, NAMESPACE.getName(), "Label de " + NAMESPACE.getName(), S3.name()));
    }

    ///// Tests unitaires :

    @Test
    public void shouldGetTheParameters() {
        assertThat(resourceServiceFactory.isS3NamespaceFeatureEnabled()).isTrue();
        assertThat(resourceServiceFactory.isIaasTenantFeatureEnabled()).isTrue();
        assertThat(resourceServiceFactory.getResourceTypeDAO()).isNotNull();
    }

    @Test
    public void shouldUseTenantService() throws Exception {

        // On récupère le type IAAS de la BDD :
        final Optional<ResourceType> iaasResourceTypeOpt = this.resourceTypeDAO.selectFirst(withJDBCFieldEquals(ResourceType.class, "name", TENANT.getName()));
        assertThat(iaasResourceTypeOpt).isNotEmpty();

        final Resource resource = create("test-resource", "resource description", "0000-0000-0000-0000");
        resource.setResourceType(iaasResourceTypeOpt.get().getId());
        assertThat(resourceServiceFactory.service(resource)).isInstanceOf(TenantService.class);
    }

    @Test
    public void shouldUseNamespaceService() throws Exception {

        // On récupère le type IAAS de la BDD :
        final Optional<ResourceType> namespaceResourceTypeOpt = this.resourceTypeDAO.selectFirst(withJDBCFieldEquals(ResourceType.class, "name", NAMESPACE.getName()));
        assertThat(namespaceResourceTypeOpt).isNotEmpty();

        final Resource resource = create("test-resource", "resource description", "0000-0000-0000-0000");
        resource.setResourceType(namespaceResourceTypeOpt.get().getId());
        assertThat(resourceServiceFactory.service(resource)).isInstanceOf(NamespaceResourceService.class);
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceServiceFactory(final ResourceServiceFactory resourceServiceFactory) {
        this.resourceServiceFactory = resourceServiceFactory;
    }

    @Autowired
    public void setResourceTypeDAO(@Qualifier("resourceTypeDAO") final DAO<ResourceType> resourceTypeDAO) {
        this.resourceTypeDAO = resourceTypeDAO;
    }
}