package fr.minint.console.api.project;

import fr.minint.console.api.project.controller.AbstractControllerTest;
import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;

import static fr.minint.console.persistence.dao.sql.JDBCUtils.executeUpdateQuery;

public abstract class AbstractDAOTestIT extends AbstractControllerTest {
    protected DataSource dataSource;


    ///// Méthodes protégées :

    /**
     * Méthode permettant de nettoyer la base de données
     * avant chaque test fonctionnel. <br />
     *
     * @throws Exception : En cas d'exception
     */
    protected void cleanDatabase() throws Exception {
        executeUpdateQuery(dataSource, "DELETE FROM quota_pricing");
        executeUpdateQuery(dataSource, "DELETE FROM flavor_quota");
        executeUpdateQuery(dataSource, "DELETE FROM flavor");
        executeUpdateQuery(dataSource, "DELETE FROM resource_role");
        executeUpdateQuery(dataSource, "DELETE FROM resource_quota");
        executeUpdateQuery(dataSource, "DELETE FROM quota_type");
        executeUpdateQuery(dataSource, "DELETE FROM resource_region");
        executeUpdateQuery(dataSource, "DELETE FROM resource_tag");
        executeUpdateQuery(dataSource, "DELETE FROM project_role");
        executeUpdateQuery(dataSource, "DELETE FROM tag");
        executeUpdateQuery(dataSource, "DELETE FROM role");
        executeUpdateQuery(dataSource, "DELETE FROM service_account");
        executeUpdateQuery(dataSource, "DELETE FROM resource");
        executeUpdateQuery(dataSource, "DELETE FROM resource_type");
        executeUpdateQuery(dataSource, "DELETE FROM project");
        executeUpdateQuery(dataSource, "DELETE FROM pai");
        executeUpdateQuery(dataSource, "DELETE FROM versioned_document");
        executeUpdateQuery(dataSource, "DELETE FROM region");
        executeUpdateQuery(dataSource, "DELETE FROM \"user\"");
        executeUpdateQuery(dataSource, "DELETE FROM history");
    }

    ///// Getters & Setters :

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public DataSource getDataSource() {
        return dataSource;
    }
}
