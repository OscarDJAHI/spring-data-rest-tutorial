package fr.minint.console.api.project.ldap.controller;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.UserService;
import fr.minint.console.api.project.service.AbstractLDAPTestIT;
import fr.minint.console.api.project.service.sequence.InMemorySequenceService;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.ldap.core.LdapTemplate;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.OK;

class LdapUserControllerTestIT extends AbstractLDAPTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapUserControllerTestIT.class);
    private final InMemorySequenceService rioSeqService = new InMemorySequenceService(9000000L);
    private final InMemorySequenceService uidNumberSeqService = new InMemorySequenceService(2000000L);
    private LdapUserController ldapUserController;
    private TestITLDAPUserRepository userRepository;

    ///// Méthodes statiques et/ou privées :

    private static Map<String, String> createRequestBody(final String firstName,
                                                         final String name,
                                                         final String email,
                                                         final String password,
                                                         final String organization) {
        final Map<String, String> requestBody = new HashMap<>();
        requestBody.put("firstName", firstName);
        requestBody.put("name", name);
        requestBody.put("email", email);
        requestBody.put("password", password);
        requestBody.put("organization", organization);
        return requestBody;
    }

    private void initTest() throws Exception {
        this.start(LdapUserControllerTestIT.class.getResource("/bootstrap.ldif").getPath());
        final LdapTemplate ldapTemplate = this.getLdapTemplate();
        final UserService userService = new UserService();
        userService.setUserLdapRepository(new TestITLDAPUserRepository(ldapTemplate));
        userService.setLdapTemplate(ldapTemplate);
        userService.setExtUserRioSequence(this.rioSeqService);
        userService.setExtUserUidNumberSequence(this.uidNumberSeqService);
        userService.setExternalUserDn("ou=users,ou=bas,ou=pi,ou=applications");
        ldapUserController.setUserService(userService);
        userRepository = new TestITLDAPUserRepository(ldapTemplate);
    }

    ///// Set-up

    @BeforeEach
    void setUp() {
        ldapUserController = new LdapUserController();
    }

    @AfterEach
    void tearDown() {
        if (this.isStarted()) {
            this.stop();
        }
        this.rioSeqService.close();
        this.uidNumberSeqService.close();
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetLDIFFile() {
        final URL resource = LdapUserControllerTestIT.class.getResource("/bootstrap.ldif");
        assertThat(resource).isNotNull();
    }

    @Test
    public void shouldCreateExternalUser() throws Exception {

        // Initialisation :
        this.initTest();

        // Création :
        final ResponseEntity<String> httpResponse = ldapUserController
                .createExternalUser(createRequestBody("jean-paul", "rouve", "jean-paul.rouve@defense.gouv.fr", "jpPassword", "defense"));
        assertThat(httpResponse).isNotNull();
        assertThat(httpResponse.getStatusCode()).isEqualTo(OK);

        // Vérification de la réponse
        LOGGER.info("---> réponse : {}", httpResponse.getBody());
        final JSONObject jsonResponse = new JSONObject(httpResponse.getBody());
        assertThat(jsonResponse.getString("status")).isEqualTo("created");
        assertThat(jsonResponse.getString("firstName")).isEqualTo("jean-paul");
        assertThat(jsonResponse.getString("name")).isEqualTo("rouve");
        assertThat(jsonResponse.getString("email")).isEqualTo("jean-paul.rouve@defense.gouv.fr");

        // On vérifie dans le LDAP (en mémoire) :
        final Optional<LdapUser> ldapUserOption = this.userRepository.findByMail("jean-paul.rouve@defense.gouv.fr");
        assertThat(ldapUserOption.isPresent()).isTrue();
        final LdapUser ldapUser = ldapUserOption.get();
        assertThat(ldapUser.getSn()).isEqualTo("rouve");
        assertThat(ldapUser.getGivenName()).isEqualTo("jean-paul");
        assertThat(ldapUser.getMail()).isEqualTo("jean-paul.rouve@defense.gouv.fr");
        assertThat(ldapUser.getOu()).isEqualTo("defense");
        assertThat(ldapUser.getPassword()).isNotEmpty();
    }

    @Test
    public void shouldNotCreateExistingUser() throws Exception {

        // Initialisation :
        this.initTest();

        // Vérification de l'utilisateur existant :
        final Optional<LdapUser> existingUserOption = this.userRepository.findByMail("frederic.moule-econocom@interieur.gouv.fr");
        assertThat(existingUserOption).isNotNull();
        assertThat(existingUserOption.isPresent()).isTrue();

        // Appel du contrôleur :
        final ResponseEntity<String> httpResponse = ldapUserController
                .createExternalUser(createRequestBody("frederic", "moule", "frederic.moule-econocom@interieur.gouv.fr", "generatedPassword", "sdait"));
        assertThat(httpResponse).isNotNull();
        assertThat(httpResponse.getStatusCode()).isEqualTo(OK);

        // Vérification de la réponse
        LOGGER.info("---> réponse : {}", httpResponse.getBody());
        final JSONObject jsonResponse = new JSONObject(httpResponse.getBody());
        assertThat(jsonResponse.getString("status")).isEqualTo("fetched");
        assertThat(jsonResponse.getString("firstName")).isEqualTo("frederic");
        assertThat(jsonResponse.getString("name")).isEqualTo("moule");
        assertThat(jsonResponse.getString("email")).isEqualTo("frederic.moule-econocom@interieur.gouv.fr");
        assertThat(jsonResponse.has("password")).isFalse();

    }

}