package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceRole;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCResourceRoleDAOTestIT extends AbstractDAOTestIT {
    private DAO<Resource> resourceDAO;
    private DAO<Role> roleDAO;
    private JDBCResourceRoleDAO resourceRoleDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation du DAO :
        this.resourceRoleDAO = new JDBCResourceRoleDAO(dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(resourceRoleDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.resourceDAO).isNotNull();
        assertThat(this.roleDAO).isNotNull();
    }

    @Test
    public void shouldInsert() throws Exception {

        // Bouchonnage de la base de données :
        final Role savedRole = this.roleDAO.save(new Role(null, "role1"));
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "resource1"));
        assertThat(savedRole).isNotNull();
        assertThat(savedResource).isNotNull();

        // Insertion du lien resource ↔ role :
        final ResourceRole savedResourceRole = resourceRoleDAO.save(new ResourceRole(null, "fredUid", savedResource.getId(), savedRole.getId(), null, true));
        assertThat(this.resourceRoleDAO.selectCount()).isEqualTo(1);

        // Vérification des champs :
        assertThat(savedResourceRole).isNotNull();
        assertThat(savedResourceRole.getId()).isNotNull();
        assertThat(savedResourceRole.getUid()).isEqualTo("fredUid");
        assertThat(savedResourceRole.getResource()).isEqualTo(savedResource.getId());
        assertThat(savedResourceRole.getRole()).isEqualTo(savedRole.getId());
        assertThat(savedResourceRole.getServiceAccount()).isNull();
        assertThat(savedResourceRole.isSynchronized()).isTrue();
    }


    @Test
    public void shouldSelectByPredicate() throws Exception {

        // Bouchonnage de la base de données :
        final Role savedRole = this.roleDAO.save(new Role(null, "role1"));
        final Role savedRole2 = this.roleDAO.save(new Role(null, "role2"));

        Resource savedResource;
        for (int i = 0; i < 5; i++) {
            savedResource = this.resourceDAO.save(new Resource(null, "resource" + i));
            assertThat(savedResource).isNotNull();
            if (i % 2 == 0) {
                this.resourceRoleDAO.save(new ResourceRole(null, "fredUid", savedResource.getId(), savedRole.getId(), null, true));
            } else {
                this.resourceRoleDAO.save(new ResourceRole(null, "fredUid", savedResource.getId(), savedRole2.getId(), null, true));
            }
        }

        // Sélection par prédicat :
        final List<ResourceRole> resourceRoles = this.resourceRoleDAO.select(withJDBCFieldEquals(ResourceRole.class, "role", savedRole.getId()));
        assertThat(resourceRoles).isNotNull();
        assertThat(resourceRoles).isNotEmpty();
        assertThat(resourceRoles.size()).isEqualTo(3);
    }


    @Test
    public void shouldDeleteAll() throws Exception {
        // Bouchonnage de la base de données :
        final Role savedRole = this.roleDAO.save(new Role(null, "role1"));
        final Role savedRole2 = this.roleDAO.save(new Role(null, "role2"));

        Resource savedResource;
        for (int i = 0; i < 10; i++) {
            savedResource = this.resourceDAO.save(new Resource(null, "resource" + i));
            assertThat(savedResource).isNotNull();
            if (i % 2 == 0) {
                this.resourceRoleDAO.save(new ResourceRole(null, "fredUid", savedResource.getId(), savedRole.getId(), null, true));
            } else {
                this.resourceRoleDAO.save(new ResourceRole(null, "fredUid", savedResource.getId(), savedRole2.getId(), null, true));
            }
        }

        // On détruit tout :
        assertThat(this.resourceRoleDAO.selectCount()).isEqualTo(10);
        this.resourceRoleDAO.deleteAll();
        assertThat(this.resourceRoleDAO.selectCount()).isEqualTo(0);

    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}