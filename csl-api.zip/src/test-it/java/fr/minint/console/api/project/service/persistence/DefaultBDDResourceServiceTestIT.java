package fr.minint.console.api.project.service.persistence;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.resource.JDBCResourceDAO;
import fr.minint.console.api.project.model.Tag;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceTag;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class DefaultBDDResourceServiceTestIT extends AbstractDAOTestIT {
    private DefaultBDDResourceService bddResourceService;
    private DAO<Tag> tagDAO;

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(tagDAO);
    }

    ///// Tests unitaires :

    @Test
    public void shouldHaveADatasource() {
        assertThat(this.dataSource).isNotNull();
    }

    @Test
    public void shouldGetTheDAOs() {
        assertThat(tagDAO).isNotNull();
        assertThat(bddResourceService).isNotNull();
        assertThat(bddResourceService.getServiceAccountDAO()).isNotNull();
        assertThat(bddResourceService.getExecutorService()).isNotNull();
        final DAO<Resource> resourceDAO = bddResourceService.getResourceDAO();
        assertThat(resourceDAO).isNotNull();
        assertThat(resourceDAO instanceof JDBCResourceDAO).isTrue();
    }

    @Test
    public void shouldInsertASimpleResource() throws Exception {

        // Définition de la resource à créer :
        final Resource resource = new Resource();
        resource.setName("testResource1");
        resource.setDescription("Resource de test");
        resource.setExternalId("externalId");

        // Insertion de la resource :
        final Resource savedResource = bddResourceService.create(resource);
        assertThat(savedResource).isNotNull();
        final Long idResource =  savedResource.getId();
        assertThat(idResource).isNotNull();
        assertThat(idResource).isGreaterThan(0L);

        // On récupère
        final List<Resource> resources = bddResourceService.list();
        assertThat(resources).isNotNull();
        assertThat(resources).isNotEmpty();
    }


    @Test
    public void shouldInsertResourceWithTag() throws Exception {

        // Initialisation de la base de données (tag, project, ...)
        final Tag savedTag = tagDAO.save(new Tag(null, "fredTag", "tag de frédéric", "#FFFFFF", null, null));

        // Définition de la resource à créer :
        final Resource resource = new Resource();
        resource.setName("testResource1");
        resource.setDescription("Resource de test");
        resource.setExternalId("externalId");

        // Ajout du lien resource ↔ tag
        final ResourceTag resourceTag = new ResourceTag();
        resourceTag.setTag(savedTag.getId());
        resource.setResourceTags(singleton(resourceTag));

        final Resource savedResource = bddResourceService.create(resource);
        assertThat(savedResource).isNotNull();
        final Long idResource = savedResource.getId();
        assertThat(idResource).isGreaterThan(0L);
    }

    ///// Getters & Setters :

    @Autowired
    public void setBddResourceService(final DefaultBDDResourceService bddResourceService) {
        this.bddResourceService = bddResourceService;
    }

    @Autowired
    public void setTagDAO(@Qualifier("tagDAO") final DAO<Tag> tagDAO) {
        this.tagDAO = tagDAO;
    }
}