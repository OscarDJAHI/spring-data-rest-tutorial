package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Tag;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.api.project.model.resource.ResourceTag;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.*;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCResourceTagDAOTestIT extends AbstractDAOTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(JDBCResourceTagDAOTestIT.class);
    private DAO<ResourceTag> resourceTagDAO;
    private DAO<Resource> resourceDAO;
    private DAO<Tag> tagDAO;

    ///// Méthodes statiques :

    private static Tag createTag(final int index) {
        return new Tag(null, "tag" + index, "Label du tag " + index, "color" + index, null, null);
    }

    private static Resource createResource(final int index) {
        return new Resource(null, "resource" + index);
    }

    ///// Initialisation des tests :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage des données :
        this.cleanDatabase();
    }

    @AfterEach
    void tearDown() {
        closeQuietly(resourceTagDAO);
        closeQuietly(resourceDAO);
        closeQuietly(tagDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(resourceTagDAO).isNotNull();
        assertThat(resourceTagDAO instanceof JDBCResourceTagDAO).isTrue();
        assertThat(resourceDAO).isNotNull();
        assertThat(tagDAO).isNotNull();
    }

    @Test
    public void shouldSave() throws Exception {

        // Ajout de la resource et du tag :
        final Tag savedTag = this.tagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#FFFFFF", null, null));
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource"));

        // Ajout
        final ResourceTag savedResourceTag = this.resourceTagDAO.save(new ResourceTag(null, savedResource.getId(), savedTag.getId()));
        assertThat(savedResourceTag).isNotNull();
        assertThat(savedResourceTag.getResource()).isEqualTo(savedResource.getId());
        assertThat(savedResourceTag.getTag()).isEqualTo(savedTag.getId());
    }


    @Test
    public void shouldUpdateTag() throws Exception {

        // Ajout de la resource et du tag :
        final Tag savedTag1 = this.tagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#FFFFFF", null, null));
        final Tag savedTag2 = this.tagDAO.save(new Tag(null, "fredTag2", "deuxième tag de Fred", "#FFFFFF", null, null));
        final Resource savedResource = this.resourceDAO.save(new Resource(null, "fredResource"));

        // Mis à jour
        final ResourceTag savedResourceTag = this.resourceTagDAO.save(new ResourceTag(null, savedResource.getId(), savedTag1.getId()));
        assertThat(savedResourceTag).isNotNull();
        savedResourceTag.setTag(savedTag2.getId());
        this.resourceTagDAO.save(savedResourceTag);

        // Récupération :
        assertThat(this.resourceTagDAO.selectCount()).isEqualTo(1);
        final Optional<ResourceTag> foundResourceTagOptional = this.resourceTagDAO.selectFirst(withJDBCFieldEquals(ResourceTag.class, "id", savedResourceTag.getId()));
        assertThat(foundResourceTagOptional).isNotEmpty();
        final ResourceTag foundResourceTag = foundResourceTagOptional.get();
        assertThat(foundResourceTag.getTag()).isEqualTo(savedTag2.getId());
    }


    @Test
    public void shouldSelectAll() throws Exception {
        Tag savedTag;
        Resource savedResource;
        for (int i = 0; i < 10; i++) {
            savedTag = tagDAO.save(createTag(i));
            savedResource = resourceDAO.save(createResource(i));
            resourceTagDAO.save(new ResourceTag(null, savedResource.getId(), savedTag.getId()));
        }

        // On sélectionne :
        final List<ResourceTag> resourceTags = this.resourceTagDAO.selectAll();
        assertThat(resourceTags).isNotNull();
        assertThat(resourceTags).isNotEmpty();
        assertThat(resourceTags.size()).isEqualTo(10);
    }


    @Test
    public void shouldSelectFromAPredicate() throws Exception {
        final Map<Long, Resource> resourceMap = new HashMap<>();
        final Map<Long, Tag> tagMap = new HashMap<>();
        final List<Long> resourceTagIds = new ArrayList<>();
        Tag savedTag;
        Resource savedResource;
        ResourceTag savedResourceTag;
        for (int i = 0; i < 5; i++) {
            savedTag = tagDAO.save(createTag(i));
            savedResource = resourceDAO.save(createResource(i));
            resourceMap.put(savedResource.getId(), savedResource);
            tagMap.put(savedTag.getId(), savedTag);
            savedResourceTag = resourceTagDAO.save(new ResourceTag(null, savedResource.getId(), savedTag.getId()));
            resourceTagIds.add(savedResourceTag.getId());
        }

        // On sélectionne :
        final Optional<ResourceTag> foundResourceTagOptional = this.resourceTagDAO.selectFirst(withJDBCFieldEquals(ResourceTag.class, "id", resourceTagIds.get(4)));
        assertThat(foundResourceTagOptional).isNotEmpty();
        final ResourceTag resourceTag = foundResourceTagOptional.get();
        assertThat(resourceMap.get(resourceTag.getResource()).getName()).isEqualTo("resource4");
        assertThat(tagMap.get(resourceTag.getTag()).getName()).isEqualTo("tag4");
    }


    @Test
    public void shouldDeleteAll() throws Exception {
        Tag savedTag;
        Resource savedResource;
        for (int i = 0; i < 5; i++) {
            savedTag = tagDAO.save(createTag(i));
            savedResource = resourceDAO.save(createResource(i));
            resourceTagDAO.save(new ResourceTag(null, savedResource.getId(), savedTag.getId()));
        }

        // Suppression :
        assertThat(this.resourceTagDAO.selectCount()).isEqualTo(5);
        this.resourceTagDAO.deleteAll();
        assertThat(this.resourceTagDAO.selectCount()).isEqualTo(0);
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceTagDAO(@Qualifier("resourceTagDAO") final DAO<ResourceTag> resourceTagDAO) {
        this.resourceTagDAO = resourceTagDAO;
    }

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setTagDAO(@Qualifier("tagDAO") final DAO<Tag> tagDAO) {
        this.tagDAO = tagDAO;
    }
}