package fr.minint.console.api.project.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class VersionedDocumentControllerTestIT {

    @Autowired
    private VersionedDocumentController versionedDocumentController;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() {
        assertThat(versionedDocumentController).isNotNull();
        assertThat(versionedDocumentController.getVersionedDocumentDAO()).isNotNull();
    }



}