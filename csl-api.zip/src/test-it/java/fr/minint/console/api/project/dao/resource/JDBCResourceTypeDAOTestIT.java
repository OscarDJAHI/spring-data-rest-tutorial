package fr.minint.console.api.project.dao.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.api.project.model.ResourceType;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static java.util.Collections.singleton;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCResourceTypeDAOTestIT extends AbstractDAOTestIT {
    private JDBCResourceTypeDAO resourceTypeDAO;
    private DAO<QuotaType> quotaTypeDAO;

    ///// Méthodes statiques :

    private static QuotaType createQuotaType(final long numQuotaType) {
        return new QuotaType(null,
                "quotaType" + numQuotaType,
                "type de quota " + numQuotaType,
                "icon" + numQuotaType,
                numQuotaType,
                numQuotaType * 10,
                numQuotaType + 2,
                "Go",
                1L);
    }

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Création des DAO's
        this.resourceTypeDAO = new JDBCResourceTypeDAO(dataSource);
    }

    @AfterEach
    void tearDown() throws Exception {
        closeDAO(this.resourceTypeDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.quotaTypeDAO).isNotNull();
    }

    @Test
    public void shouldSaveWithoutQuotaType() throws Exception {

        // On sauve
        final ResourceType savedResourceType = this.resourceTypeDAO
                .save(new ResourceType(null, "iaas", "type IAAS", "IAAS", "#FFFFF8", null));
        assertThat(savedResourceType).isNotNull();

        // On vérifie en base de données :
        assertThat(resourceTypeDAO.selectCount()).isEqualTo(1L);
        final Optional<ResourceType> foundResourceTypeOpt = resourceTypeDAO.selectFirst(withJDBCFieldEquals(ResourceType.class, "name", "iaas"));
        assertThat(foundResourceTypeOpt).isNotEmpty();
        final ResourceType foundResourceType = foundResourceTypeOpt.get();
        assertThat(foundResourceType.getId()).isNotNull();
        assertThat(foundResourceType.getName()).isEqualTo("iaas");
        assertThat(foundResourceType.getLabel()).isEqualTo("type IAAS");
        assertThat(foundResourceType.getCategory()).isEqualTo("IAAS");
        assertThat(foundResourceType.getColor()).isEqualTo("#FFFFF8");
    }


    @Test
    public void shouldSaveWithQuotaType() throws Exception {

        // On crée les types de quotas :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);
        final Set<QuotaType> quotaTypes = new HashSet<>();
        for (int i = 0; i < 5; i++) {
            quotaTypes.add(createQuotaType(i));
        }

        final ResourceType resourceType = new ResourceType(null, "iaas", "type IAAS", "IAAS", "#FFFFF8", quotaTypes);
        final ResourceType savedResourceType = resourceTypeDAO.save(resourceType);
        assertThat(savedResourceType).isNotNull();
        assertThat(savedResourceType.getId()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotEmpty();
        for (QuotaType savedQuotaType : savedResourceType.getQuotaTypes()) {
            assertThat(savedQuotaType.getId()).isNotNull();
        }

        // On vérifie les types de ressource en base de données :
        final List<ResourceType> foundResources = this.resourceTypeDAO.select(withJDBCFieldEquals(ResourceType.class, "name", "iaas"));
        assertThat(foundResources).isNotNull();
        assertThat(foundResources.size()).isEqualTo(1);
        final ResourceType foundResourceType = foundResources.get(0);
        assertThat(foundResourceType.getId()).isNotNull();
        assertThat(foundResourceType.getName()).isEqualTo("iaas");
        assertThat(foundResourceType.getLabel()).isEqualTo("type IAAS");
        assertThat(foundResourceType.getCategory()).isEqualTo("IAAS");
        assertThat(foundResourceType.getColor()).isEqualTo("#FFFFF8");

        final Set<QuotaType> foundQuotaTypes = foundResourceType.getQuotaTypes();
        assertThat(foundQuotaTypes).isNotNull();
        assertThat(foundQuotaTypes.size()).isEqualTo(5);
        for (QuotaType foundQuotaType : foundQuotaTypes) {
            assertThat(foundQuotaType.getId()).isNotNull();
        }
    }


    @Test
    public void shouldDeleteWithQuotaType() throws Exception {

        // On bouchonne la base de données
        final Set<QuotaType> quotaTypes = new HashSet<>();
        for (int i = 0; i < 5; i++) {
            quotaTypes.add(createQuotaType(i));
        }
        final ResourceType resourceType = new ResourceType(null, "iaas", "type IAAS", "IAAS", "#FFFFF8", quotaTypes);
        final ResourceType savedResourceType = resourceTypeDAO.save(resourceType);
        assertThat(savedResourceType).isNotNull();
        assertThat(savedResourceType.getId()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotEmpty();
        for (QuotaType savedQuotaType : savedResourceType.getQuotaTypes()) {
            assertThat(savedQuotaType.getId()).isNotNull();
        }

        // On vérifie la base :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(5L);
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(1L);

        // On supprime et on vérifie en base de données :
        this.resourceTypeDAO.deleteAll();
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(0L);
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);
    }

    @Test
    public void shouldDeleteFromInstance() throws Exception {

        // On bouchonne la base de données
        final Set<QuotaType> quotaTypes = new HashSet<>();
        for (int i = 0; i < 5; i++) {
            quotaTypes.add(createQuotaType(i));
        }

        final ResourceType resourceType = new ResourceType(null, "iaas", "type IAAS", "IAAS", "#FFFFF8", quotaTypes);
        final ResourceType savedResourceType = resourceTypeDAO.save(resourceType);
        assertThat(savedResourceType).isNotNull();
        assertThat(savedResourceType.getId()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotNull();
        assertThat(savedResourceType.getQuotaTypes()).isNotEmpty();
        for (QuotaType savedQuotaType : savedResourceType.getQuotaTypes()) {
            assertThat(savedQuotaType.getId()).isNotNull();
        }

        // On vérifie la base :
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(1L);

        // On supprime et on vérifie en base de données :
        this.resourceTypeDAO.delete(singleton(savedResourceType));
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(0L);
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);
    }

    @Test
    public void shouldDeleteFromPredicate() throws Exception {

        // On supprime tous les types de quota :
        this.quotaTypeDAO.deleteAll();
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(0L);

        // On bouchonne la base de données
        final Set<QuotaType> quotaTypes = new HashSet<>();
        for (int i = 0; i < 5; i++) {
            quotaTypes.add(createQuotaType(i));
        }
        resourceTypeDAO.save(new ResourceType(null, "iaas", "type IAAS", "IAAS", "#FFFFF8", quotaTypes));
        resourceTypeDAO.save(new ResourceType(null, "s3", "type S3", "s3", "#FFFFF8", quotaTypes));

        // On vérifie la base :
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(10L);
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(2L);

        // On supprime et on vérifie en base de données :
        this.resourceTypeDAO.delete(withJDBCFieldEquals(ResourceType.class, "name", "iaas"));
        assertThat(this.resourceTypeDAO.selectCount()).isEqualTo(1L);
        assertThat(this.quotaTypeDAO.selectCount()).isEqualTo(5L);
    }

    ///// Getters & Setters :

    @Autowired
    public void setQuotaTypeDAO(final DAO<QuotaType> quotaTypeDAO) {
        this.quotaTypeDAO = quotaTypeDAO;
    }

}