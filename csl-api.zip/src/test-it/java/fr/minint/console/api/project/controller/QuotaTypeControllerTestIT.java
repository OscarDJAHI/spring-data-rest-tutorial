package fr.minint.console.api.project.controller;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.QuotaPricing;
import fr.minint.console.api.project.model.QuotaType;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class QuotaTypeControllerTestIT extends AbstractDAOTestIT {
    private DAO<QuotaType> quotaTypeDAO;
    private DAO<QuotaPricing> quotaPrincingDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {
        this.cleanDatabase();
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTheDAOs() {
        assertThat(this.quotaTypeDAO).isNotNull();
        assertThat(this.quotaPrincingDAO).isNotNull();
    }


    @Test
    public void shouldSelectTheTypes() throws Exception {

        // On bouchonne la base de données :
        this.quotaTypeDAO.save(new QuotaType(null, "fredQuotaType"));
    }

    ///// Getters & Setters :

    @Autowired
    public void setQuotaTypeDAO(@Qualifier("quotaTypeDAO") final DAO<QuotaType> quotaTypeDAO) {
        this.quotaTypeDAO = quotaTypeDAO;
    }

    @Autowired
    public void setQuotaPricingDAO(@Qualifier("quotaPricingDAO") final DAO<QuotaPricing> quotaPrincingDAO) {
        this.quotaPrincingDAO = quotaPrincingDAO;
    }
}