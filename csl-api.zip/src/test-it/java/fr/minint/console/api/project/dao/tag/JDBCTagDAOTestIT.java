package fr.minint.console.api.project.dao.tag;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Tag;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Optional;

import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCTagDAOTestIT extends AbstractDAOTestIT {
    private JDBCTagDAO jdbcTagDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation du DAO :
        this.jdbcTagDAO = new JDBCTagDAO(dataSource);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetDAO() {
        assertThat(dataSource).isNotNull();
        assertThat(jdbcTagDAO).isNotNull();
    }

    @Test
    public void shouldInsertTag() throws Exception {
        final Tag savedTag = jdbcTagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#123456", null, null));
        assertThat(savedTag).isNotNull();

        // Vérification
        final List<Tag> allTags = jdbcTagDAO.selectAll();
        assertThat(allTags).isNotNull();
        assertThat(allTags).isNotEmpty();
        assertThat(allTags.size()).isEqualTo(1);
    }

    @Test
    public void shouldUpdateTag() throws Exception {

        // Création du tag :
        Tag savedTag = jdbcTagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#123456", null, null));
        assertThat(jdbcTagDAO.selectCount()).isEqualTo(1);

        // On met à jour
        savedTag.setColor("#FFFFFF");
        jdbcTagDAO.save(savedTag);

        // On récupère le tag modifié
        Optional<Tag> foundTagOptional = jdbcTagDAO.selectFirst(withJDBCFieldEquals(Tag.class, "id", savedTag.getId()));
        assertThat(foundTagOptional).isNotEmpty();
        savedTag = foundTagOptional.get();
        assertThat(savedTag.getColor()).isEqualTo("#FFFFFF");
    }


    @Test
    public void shouldSelectByPredicate() throws Exception {
        jdbcTagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#123456", null, null));
        jdbcTagDAO.save(new Tag(null, "karineTag", "tag de Karine", "#FFFFFF", null, null));
        assertThat(jdbcTagDAO.selectCount()).isEqualTo(2);

        // On sélectionne :
        final List<Tag> foundTags = jdbcTagDAO.select(withJDBCFieldEquals(Tag.class, "name", "karinetag"));
        assertThat(foundTags).isNotNull();
        assertThat(foundTags).isNotEmpty();
        assertThat(foundTags.size()).isEqualTo(1);
        final Tag foundTag = foundTags.get(0);
        assertThat(foundTag.getId()).isGreaterThan(0L);
        assertThat(foundTag.getName()).isEqualTo("karinetag");
        assertThat(foundTag.getLabel()).isEqualTo("tag de Karine");
        assertThat(foundTag.getColor()).isEqualTo("#FFFFFF");
    }


    @Test
    public void shouldSelectIfTagNotExists() throws Exception {

        // Initialisation
        jdbcTagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#123456", null, null));
        jdbcTagDAO.save(new Tag(null, "karineTag", "tag de Karine", "#FFFFFF", null, null));
        assertThat(jdbcTagDAO.selectCount()).isEqualTo(2);

        // Dans le cas où le tag n'existe pas !!
        final Optional<Tag> foundTagOptional = jdbcTagDAO.selectFirst(withJDBCFieldEquals(Tag.class, "name", "notExistingTagName"));
        assertThat(foundTagOptional).isNotNull();
        assertThat(foundTagOptional).isEmpty();

        // Dans le cas de la liste :
        final List<Tag> foundTags = jdbcTagDAO.select(withJDBCFieldEquals(Tag.class, "name", "notExistingTagName"));
        assertThat(foundTags).isNotNull();
        assertThat(foundTags).isEmpty();
    }


    @Test
    public void shouldDeleteAll() throws Exception {

        // Initialisation
        jdbcTagDAO.save(new Tag(null, "fredTag", "tag de Fred", "#123456", null, null));
        jdbcTagDAO.save(new Tag(null, "karineTag", "tag de Karine", "#FFFFFF", null, null));
        jdbcTagDAO.save(new Tag(null, "francisTag", "tag de Francis", "#FFF125", null, null));
        assertThat(jdbcTagDAO.selectCount()).isEqualTo(3);

        // On supprime tout :
        jdbcTagDAO.deleteAll();
        assertThat(jdbcTagDAO.selectCount()).isEqualTo(0);

    }
}