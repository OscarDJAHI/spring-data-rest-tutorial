package fr.minint.console.api.project.client.s3;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.minint.console.api.project.client.s3.S3NamespaceClient;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;

@Slf4j
@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ActiveProfiles({"test"})
class S3NamespaceClientTest {
    @Autowired
    ObjectMapper objectMapper;
    @Mock
    Environment environment;
    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    S3NamespaceClient mockedS3NamespaceClientClient;

    private static Map<String, Object> createNamespaceCreateDto(String namespace, Long blockSize, Long notificationSize) {
        final Map<String, Object> payload = new HashMap<>();
        payload.put("namespace", namespace);
        payload.put("blockSize", blockSize);
        payload.put("notificationSize", notificationSize);
        return payload;
    }

    private static Map<String, Object> getNamespaceCreateDto() {
        return createNamespaceCreateDto("test-namespace", 300L, 200L);
    }

    private void mockEnvironment() {
        Mockito.when(environment.getProperty("console.api.iaas.url")).thenReturn("https://namespace.provider");
    }

    @BeforeEach
    public void setup() throws JsonProcessingException {
        this.mockEnvironment();
    }

    @Test
    public void shouldCreateCompleteNamespace() throws JsonProcessingException {
        final String createNamespaceEndpointUrl = "https://namespace.provider/ecs/namespaces";
        final Map<String, Object> namespaceCreateDto = createNamespaceCreateDto("test-namespace", 300L, 200L);
        Mockito.when(environment.getProperty("console.api.iaas.url")).thenReturn("https://namespace.provider");
        Mockito.when(restTemplate.postForEntity(createNamespaceEndpointUrl, getNamespaceCreateDto(), String.class)).thenReturn(ResponseEntity.of(Optional.of(objectMapper.writeValueAsString(namespaceCreateDto))));
        ResponseEntity<String> responseEntity = mockedS3NamespaceClientClient.create(namespaceCreateDto);

        Assertions.assertThat(responseEntity.hasBody()).isTrue();
        Assertions.assertThat(responseEntity.getBody()).isEqualTo(objectMapper.writeValueAsString(getNamespaceCreateDto()));
    }

    @Test
    public void shouldListNamespaces() throws IOException {
        final String createNamespaceEndpointUrl = "https://namespace.provider/ecs/namespaces";
        Map<String, Object> namespaceCreateDto = createNamespaceCreateDto("test-namespace", 300L, 200L);
        List<Object> namespaces = new ArrayList<>();
        namespaces.add(namespaceCreateDto);
        namespaces.add(namespaceCreateDto);
        namespaces.add(namespaceCreateDto);
        Mockito.when(environment.getProperty("console.api.iaas.url")).thenReturn("https://namespace.provider");
        Mockito.when(restTemplate.getForEntity("%s".formatted(createNamespaceEndpointUrl), String.class)).thenReturn(ResponseEntity.of(Optional.of(objectMapper.writeValueAsString(namespaces))));
        ResponseEntity<String> responseEntity = mockedS3NamespaceClientClient.list();
        List<Object> expected = new ArrayList<>();
        expected.add(namespaceCreateDto);
        expected.add(namespaceCreateDto);
        expected.add(namespaceCreateDto);

        Assertions.assertThat(responseEntity.hasBody()).isTrue();
        Assertions.assertThat(responseEntity.getBody()).isEqualTo(objectMapper.writeValueAsString(expected));
        Assertions.assertThat(objectMapper.readValue(responseEntity.getBody(), ArrayList.class)).hasSize(3);
    }

    @Test
    public void shouldGetNamespaces() throws JsonProcessingException {
        final String createNamespaceEndpointUrl = "https://namespace.provider/ecs/namespaces";
        Map<String, Object> namespaceCreateDto = createNamespaceCreateDto("test-namespace", 300L, 200L);
        Mockito.when(environment.getProperty("console.api.iaas.url")).thenReturn("https://namespace.provider");
        Mockito.when(restTemplate.getForEntity("%s/%s".formatted(createNamespaceEndpointUrl, namespaceCreateDto.get("namespace")), String.class)).thenReturn(ResponseEntity.of(Optional.of(objectMapper.writeValueAsString(namespaceCreateDto))));
        ResponseEntity<String> responseEntity = mockedS3NamespaceClientClient.get("test-namespace");

        Assertions.assertThat(responseEntity.hasBody()).isTrue();
        Assertions.assertThat(responseEntity.getBody()).isEqualTo(objectMapper.writeValueAsString(namespaceCreateDto));
    }
}