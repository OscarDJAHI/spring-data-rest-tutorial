package fr.minint.console.api.project.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ResourceQuotaServiceImplTestIT {
    private ResourceQuotaServiceImpl resourceQuotaService;

    ///// Tests fonctionnels :

    @Test
    public void shouldBuildInstance() {
        assertThat(resourceQuotaService).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setResourceQuotaService(final ResourceQuotaServiceImpl resourceQuotaService) {
        this.resourceQuotaService = resourceQuotaService;
    }
}