package fr.minint.console.api.project.dao.serviceAccount;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.project.JDBCProjectDAO;
import fr.minint.console.api.project.dao.resource.JDBCResourceDAO;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.ServiceAccount;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static fr.minint.console.api.project.utils.predicate.project.JDBCProjectOwnerPredicate.withProjectOwner;
import static fr.minint.console.api.project.utils.predicate.project.JDBCUserHasProjectRolePredicate.withUserHavingProjectRole;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCServiceAccountDAOTestIT extends AbstractDAOTestIT {
    private JDBCServiceAccountDAO serviceAccountDAO;
    private DAO<Project> projectDAO;
    private DAO<Resource> resourceDAO;
    private DAO<Role> roleDAO;

    ///// Méthodes statiques :

    private static ServiceAccount createServiceAccount(final String servAccountUid,
                                                       final Project savedProject,
                                                       final Resource savedResource) {
        final ServiceAccount serviceAccount = new ServiceAccount();
        serviceAccount.setUid(servAccountUid);
        serviceAccount.setDescription("Compte de service de test : " + servAccountUid);
        serviceAccount.setEnabled(true);
        serviceAccount.setProjectBean(savedProject);
        serviceAccount.setResourceBean(savedResource);
        return serviceAccount;
    }

    ///// Initialisation

    @BeforeEach
    void setUp() throws Exception {
        this.cleanDatabase();
        this.serviceAccountDAO = new JDBCServiceAccountDAO(this.dataSource);
        this.serviceAccountDAO.start();
        this.projectDAO = new JDBCProjectDAO(this.dataSource);
        this.projectDAO.start();
        this.resourceDAO = new JDBCResourceDAO(this.dataSource);
        this.resourceDAO.start();
    }

    @AfterEach
    void afterAll() throws IOException {
        closeDAO(this.projectDAO);
        closeDAO(this.resourceDAO);
        closeDAO(this.serviceAccountDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.serviceAccountDAO).isNotNull();
        assertThat(this.serviceAccountDAO.isClosed()).isFalse();
    }

    @Test
    public void shouldSaveSimpleServiceAccount() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Sauvegarde du compte de service :
        final ServiceAccount savedServiceAccount = this.serviceAccountDAO
                .save(createServiceAccount("fredAccountServiceUid", savedProject, savedResource));
        assertThat(savedServiceAccount).isNotNull();
        assertThat(savedServiceAccount.getId()).isNotNull();

        // On vérifie les données en base de données :
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);
        assertThat(this.resourceDAO.selectCount()).isEqualTo(1);
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(1);

        // On récupère les données de la base de données :
        final Optional<ServiceAccount> foundServiceAccountOpt = this.serviceAccountDAO
                .selectFirst(withJDBCFieldEquals(ServiceAccount.class, "id", savedServiceAccount.getId()));
        assertThat(foundServiceAccountOpt).isNotNull();
        assertThat(foundServiceAccountOpt).isNotEmpty();
        final ServiceAccount foundServiceAccount = foundServiceAccountOpt.get();
        assertThat(foundServiceAccount.isEnabled()).isTrue();
        assertThat(foundServiceAccount.getDescription()).isEqualTo("Compte de service de test : fredAccountServiceUid");
        assertThat(foundServiceAccount.getUid()).isEqualTo("fredAccountServiceUid");

        // --> on vérifie le projet
        final Project foundProject = foundServiceAccount.getProjectBean();
        assertThat(foundProject).isEqualTo(savedProject);
        assertThat(foundProject.getLabel()).isEqualTo("projet de Frédéric");
        assertThat(foundProject.getName()).isEqualTo("fredProject");
        assertThat(foundProject.getOwnerId()).isEqualTo("fredUid");

        // --> on vérifie la resource associée
        final Resource foundResource = foundServiceAccount.getResourceBean();
        assertThat(foundResource).isNotNull();
        assertThat(foundResource.getId()).isNotNull();
        assertThat(foundResource.getProjectBean()).isEqualTo(foundProject);
        assertThat(foundResource.getName()).isEqualTo("fredResource");
    }


    @Test
    public void shouldUpdate() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Sauvegarde du compte de service :
        final ServiceAccount savedServiceAccount = this.serviceAccountDAO
                .save(createServiceAccount("fredAccountServiceUid", savedProject, savedResource));
        assertThat(savedServiceAccount).isNotNull();
        assertThat(savedServiceAccount.getId()).isNotNull();

        // Mis à jour du compte de service
        savedServiceAccount.setDescription("Description mis à jour");
        this.serviceAccountDAO.save(savedServiceAccount);
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(1L);
        final Optional<ServiceAccount> foundServAccountOpt = this.serviceAccountDAO
                .selectFirst(withJDBCFieldEquals(ServiceAccount.class, "uid", "fredAccountServiceUid"));
        assertThat(foundServAccountOpt).isNotNull();
        assertThat(foundServAccountOpt).isNotEmpty();
        final ServiceAccount foundServiceAccount = foundServAccountOpt.get();
        assertThat(foundServiceAccount).isNotNull();
        assertThat(foundServiceAccount.getUid()).isEqualTo("fredAccountServiceUid");
        assertThat(foundServiceAccount.getDescription()).isEqualTo("Description mis à jour");
        assertThat(foundServiceAccount.getResourceBean()).isEqualTo(savedResource);
        assertThat(foundServiceAccount.getProjectBean()).isEqualTo(savedProject);
    }


    @Test
    public void shouldSelectFromPredicate() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création des différentes ressources :
        this.serviceAccountDAO.save(createServiceAccount("servAccount1", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount2", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount3", savedProject, savedResource));
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(3L);

        // On sélectionne avec un prédicat sans préfix :
        final Optional<ServiceAccount> foundServAccountOpt = this.serviceAccountDAO
                .selectFirst(withJDBCFieldEquals(ServiceAccount.class, "uid", "servAccount2"));
        assertThat(foundServAccountOpt).isNotNull();
        assertThat(foundServAccountOpt).isNotEmpty();
        final ServiceAccount foundServAccount = foundServAccountOpt.get();
        assertThat(foundServAccount).isNotNull();
        assertThat(foundServAccount.getUid()).isEqualTo("servAccount2");
        assertThat(foundServAccount.getDescription()).isEqualTo("Compte de service de test : servAccount2");
        assertThat(foundServAccount.getResourceBean()).isEqualTo(savedResource);
        assertThat(foundServAccount.getProjectBean()).isEqualTo(savedProject);
    }



    @Test
    public void shouldSelectFromAMoreComplexPredicate() throws Exception {

        // Rôles :
        this.roleDAO.save(new Role(null, "souscripteur"));
        final Role delegueRole = this.roleDAO.save(new Role(null, "delegue"));

        // Création du projet
        Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        project = new Project(null, "fredProject2", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject2 = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(2);

        // Création de la ressource :
        Resource resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject2);
        final Resource savedResource2 = this.resourceDAO.save(resourceBean);

        // Création des différentes ressources :
        this.serviceAccountDAO.save(createServiceAccount("servAccount1", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount2", savedProject2, savedResource2));

        // Récupération des comptes de services :
        Predicate<ServiceAccount> serviceAccountPredicate = withProjectOwner("proj", "fredUid");
        serviceAccountPredicate = serviceAccountPredicate.or(withUserHavingProjectRole("fredUid", delegueRole));
        serviceAccountPredicate = serviceAccountPredicate.and(withJDBCFieldEquals(ServiceAccount.class, "project", savedProject.getId()));
        final List<ServiceAccount> foundServiceAccounts = this.serviceAccountDAO.select(serviceAccountPredicate);
        assertThat(foundServiceAccounts).isNotNull();
        assertThat(foundServiceAccounts).isNotEmpty();
        assertThat(foundServiceAccounts.size()).isEqualTo(1L);
    }


    @Test
    public void shouldFetchTimestampFields() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création du compte de service :
        this.serviceAccountDAO.save(createServiceAccount("servAccount1", savedProject, savedResource));

        // Vérification de la base de données :
        final Optional<ServiceAccount> foundServiceAccount = this.serviceAccountDAO.selectFirst(withJDBCFieldEquals(ServiceAccount.class, "uid", "servAccount1"));
        assertThat(foundServiceAccount).isNotEmpty();
        assertThat(foundServiceAccount.get().getCreatedAt()).isNotNull();
        assertThat(foundServiceAccount.get().getUpdatedAt()).isNotNull();
    }

    @Test
    public void shouldDeleteAll() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject2", "fredUid");
        project.setLabel("projet 2 de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource2");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création des différentes ressources :
        this.serviceAccountDAO.save(createServiceAccount("servAccount1", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount2", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount3", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount4", savedProject, savedResource));
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(4L);
        this.serviceAccountDAO.deleteAll();
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(0L);
    }

    @Test
    public void shouldDeleteFromPredicate() throws Exception {

        // Création du projet
        final Project project = new Project(null, "fredProject2", "fredUid");
        project.setLabel("projet 2 de Frédéric");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(this.projectDAO.selectCount()).isEqualTo(1);

        // Création de la ressource :
        final Resource resourceBean = new Resource();
        resourceBean.setName("fredResource2");
        resourceBean.setProjectBean(savedProject);
        final Resource savedResource = this.resourceDAO.save(resourceBean);
        assertThat(savedResource).isNotNull();
        assertThat(savedResource.getId()).isNotNull();

        // Création des différentes ressources :
        this.serviceAccountDAO.save(createServiceAccount("servAccount1", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount2", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount3", savedProject, savedResource));
        this.serviceAccountDAO.save(createServiceAccount("servAccount4", savedProject, savedResource));
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(4L);
        this.serviceAccountDAO.delete(withJDBCFieldEquals(ServiceAccount.class, "uid", "servAccount3"));
        assertThat(this.serviceAccountDAO.selectCount()).isEqualTo(3L);

        // On vérifie que l'on ne trouve pas
        final Optional<ServiceAccount> foundServiceAccountOpt = this.serviceAccountDAO
                .selectFirst(withJDBCFieldEquals(ServiceAccount.class, "uid", "servAccount3"));
        assertThat(foundServiceAccountOpt).isNotNull();
        assertThat(foundServiceAccountOpt).isEmpty();
    }


    ///// Getters & Setters :

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}