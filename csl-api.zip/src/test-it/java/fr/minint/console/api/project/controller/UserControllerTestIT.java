package fr.minint.console.api.project.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class UserControllerTestIT {

    @Autowired
    private UserController userController;

    ///// Tests fonctionnels :

    @Test
    public void shouldHaveTheDAOs() {
        assertThat(this.userController).isNotNull();
        assertThat(this.userController.getUserDAO()).isNotNull();
    }

}