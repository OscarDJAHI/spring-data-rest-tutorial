package fr.minint.console.api.project.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ProjectRoleServiceImplTestIT {
    private ProjectRoleService projectRoleService;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTheService() {
        assertThat(this.projectRoleService).isNotNull();
        assertThat(this.projectRoleService instanceof ProjectRoleServiceImpl).isTrue();
    }

    @Test
    public void shouldGetTheDAOs() {
        assertThat(((ProjectRoleServiceImpl) projectRoleService).getServiceAccountDAO()).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setProjectRoleService(final ProjectRoleService projectRoleService) {
        this.projectRoleService = projectRoleService;
    }
}