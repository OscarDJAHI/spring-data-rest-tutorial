package fr.minint.console.api.project.dao.project;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.project.ProjectRole;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCProjectRoleDAOTestIT extends AbstractDAOTestIT {
    private DAO<Project> projectDAO;
    private DAO<Role> roleDAO;
    private JDBCProjectRoleDAO projectRoleDAO;

    ///// Méthodes privées :

    private static Project createProject(final String projectName,
                                         final String projectLabel,
                                         final String ownerUid) {
        final Project project = new Project(null, projectName, ownerUid);
        project.setLabel(projectLabel);
        return project;
    }

    ///// Initialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation du DAO :
        projectRoleDAO = new JDBCProjectRoleDAO(this.dataSource);

        // Initialisation des rôles :
        final Set<Role> roles = new HashSet<>();
        roles.add(new Role(null, "souscripteur"));
        roles.add(new Role(null, "delegue"));
        this.roleDAO.save(roles);
    }

    @AfterEach
    void tearDown() {

        // Fermeture des DAO's :
        closeQuietly(this.projectDAO);
        closeQuietly(this.roleDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetDAOs() {
        assertThat(this.projectDAO).isNotNull();
        assertThat(this.roleDAO).isNotNull();
    }


    @Test
    public void shouldInsertAProjectRole() throws Exception {

        // Insertion du projet :
        final Project savedProject = this.projectDAO.save(createProject("projetTest", "projet de test", "fredUid"));
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Ajout du rôle
        final Role souscripteurRole = this.roleDAO.selectFirst(role -> "souscripteur".equals(role.getName())).orElse(null);
        assertThat(souscripteurRole).isNotNull();
        this.projectRoleDAO.save(new ProjectRole("oscarUid", savedProject.getId(), souscripteurRole.getId()));

        // Vérification :
        final List<ProjectRole> projectRoles = this.projectRoleDAO.selectAll();
        assertThat(projectRoles.size()).isEqualTo(1L);
        final ProjectRole projectRole = projectRoles.get(0);
        assertThat(projectRole).isNotNull();
        assertThat(projectRole.getRole()).isEqualTo(souscripteurRole.getId());
        assertThat(projectRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(projectRole.getUid()).isEqualTo("oscarUid");
    }


    @Test
    public void shouldUpdate() throws Exception {

        // Insertion du projet :
        final Project savedProject = this.projectDAO.save(createProject("projetTest", "projet de test", "fredUid"));
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Ajout du lien project ↔ rôle
        final Role souscripteurRole = this.roleDAO.selectFirst(role -> "souscripteur".equals(role.getName())).orElse(null);
        assertThat(souscripteurRole).isNotNull();
        this.projectRoleDAO.save(new ProjectRole("oscarUid", savedProject.getId(), souscripteurRole.getId()));

        // Vérification :
        final List<ProjectRole> projectRoles = this.projectRoleDAO.selectAll();
        assertThat(projectRoles.size()).isEqualTo(1L);
        ProjectRole foundProjectRole = projectRoles.get(0);
        assertThat(foundProjectRole).isNotNull();
        assertThat(foundProjectRole.getRole()).isEqualTo(souscripteurRole.getId());
        assertThat(foundProjectRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(foundProjectRole.getUid()).isEqualTo("oscarUid");

        foundProjectRole.setUid("abdelKarimUid");
        foundProjectRole = this.projectRoleDAO.save(foundProjectRole);
        assertThat(foundProjectRole).isNotNull();
        assertThat(foundProjectRole.getRole()).isEqualTo(souscripteurRole.getId());
        assertThat(foundProjectRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(foundProjectRole.getUid()).isEqualTo("abdelKarimUid");
    }

    @Test
    public void shouldSelectFromPredicate() throws Exception {

        // Insertion du ou des projets :
        final Project savedProject = this.projectDAO.save(createProject("projetTest1", "projet de test", "fredUid"));
        final Project savedProject2 = this.projectDAO.save(createProject("projetTest2", "projet de test", "oscarUid"));

        // Ajout du rôle
        final Role souscripteurRole = this.roleDAO.selectFirst(role -> "souscripteur".equals(role.getName())).orElse(null);
        assertThat(souscripteurRole).isNotNull();

        // Insertion des liens projets ↔ rôles :
        this.projectRoleDAO.save(new ProjectRole("trecyUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject2.getId(), souscripteurRole.getId()));

        // Récupération de la part d'un prédicat :
        final List<ProjectRole> foundProjectRoles = this.projectRoleDAO.select(projectRole -> {
            boolean isOK = (projectRole != null);
            isOK = isOK && ("abdelKarimUid".equals(projectRole.getUid()));
            return isOK;
        });
        assertThat(foundProjectRoles).isNotNull();
        assertThat(foundProjectRoles).isNotEmpty();
        assertThat(foundProjectRoles.size()).isEqualTo(2);
        for (ProjectRole foundProjectRole : foundProjectRoles) {
            assertThat(foundProjectRole.getUid()).isEqualTo("abdelKarimUid");
            assertThat(foundProjectRole.getRole()).isEqualTo(souscripteurRole.getId());
            assertThat(Objects.equals(foundProjectRole.getProject(), savedProject.getId())
                    || Objects.equals(foundProjectRole.getProject(), savedProject2.getId())).isTrue();
        }
    }


    @Test
    public void shouldDeleteFromPredicate() throws Exception {

        // Insertion du ou des projets :
        final Project savedProject = this.projectDAO.save(createProject("projetTest1", "projet de test", "fredUid"));
        final Project savedProject2 = this.projectDAO.save(createProject("projetTest2", "projet de test", "oscarUid"));

        // Ajout du rôle
        final Role souscripteurRole = this.roleDAO.selectFirst(role -> "souscripteur".equals(role.getName())).orElse(null);
        assertThat(souscripteurRole).isNotNull();

        // Insertion des liens projets ↔ rôles :
        this.projectRoleDAO.save(new ProjectRole("trecyUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject2.getId(), souscripteurRole.getId()));
        assertThat(this.projectRoleDAO.selectCount()).isEqualTo(3);

        // Suppression des project-role avec AbdelKarim :
        this.projectRoleDAO.delete(withJDBCFieldEquals(ProjectRole.class, "uid", "abdelKarimUid"));

        // Récupération de la part d'un prédicat :
        final List<ProjectRole> foundProjectRoles = this.projectRoleDAO.selectAll();
        assertThat(foundProjectRoles).isNotNull();
        assertThat(foundProjectRoles).isNotEmpty();
        assertThat(foundProjectRoles.size()).isEqualTo(1);
        final ProjectRole projectRole = foundProjectRoles.get(0);
        assertThat(projectRole.getProject()).isEqualTo(savedProject.getId());
        assertThat(projectRole.getUid()).isEqualTo("trecyUid");
        assertThat(projectRole.getRole()).isEqualTo(souscripteurRole.getId());
    }


    @Test
    public void shouldDeleteAll() throws Exception {

        // Insertion du ou des projets :
        final Project savedProject = this.projectDAO.save(createProject("projetTest1", "projet de test", "fredUid"));
        final Project savedProject2 = this.projectDAO.save(createProject("projetTest2", "projet de test", "oscarUid"));

        // Ajout du rôle
        final Role souscripteurRole = this.roleDAO.selectFirst(role -> "souscripteur".equals(role.getName())).orElse(null);
        assertThat(souscripteurRole).isNotNull();

        // Insertion des liens projets ↔ rôles :
        this.projectRoleDAO.save(new ProjectRole("trecyUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject.getId(), souscripteurRole.getId()));
        this.projectRoleDAO.save(new ProjectRole("abdelKarimUid", savedProject2.getId(), souscripteurRole.getId()));
        assertThat(this.projectRoleDAO.selectCount()).isEqualTo(3L);

        // On supprime tout :
        this.projectRoleDAO.deleteAll();
        assertThat(this.projectRoleDAO.selectCount()).isEqualTo(0);
    }

    ///// Getters & Setters :

    @Autowired
    public void setProjectDAO(@Qualifier("projectDAO") final DAO<Project> projectDAO) {
        this.projectDAO = projectDAO;
    }

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}