package fr.minint.console.api.project.service.iaas;

import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@Slf4j
@SpringBootTest
@ActiveProfiles({ "test" })
public class NamespaceResourceServiceTestIT {
    private TenantService tenantService;
    private NamespaceResourceService namespaceResourceService;

    @BeforeEach
    void setUp() {
        this.namespaceResourceService = new NamespaceResourceService(tenantService);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTheDAOsFromTenantService() {
        assertThat(tenantService).isNotNull();
        assertThat(tenantService.getServiceAccountDAO()).isNotNull();
        assertThat(namespaceResourceService).isNotNull();
        assertThat(namespaceResourceService.getServiceAccountDAO()).isNotNull();
        assertThat(namespaceResourceService.getZoneDAO()).isNotNull();
        assertThat(namespaceResourceService.getAreaDAO()).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setTenantService(final TenantService tenantService) {
        this.tenantService = tenantService;
    }
}
