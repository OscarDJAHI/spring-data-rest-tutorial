package fr.minint.console.api.project.model;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.dao.serviceAccount.JDBCServiceAccountDAO;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ServiceAccountTestIT extends AbstractDAOTestIT {
    private DAO<ServiceAccount> serviceAccountRepositoryDAO;

    ///// Initialisation :

    @BeforeEach
    void setUp() {
        this.serviceAccountRepositoryDAO = new JDBCServiceAccountDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() {
        closeQuietly(this.serviceAccountRepositoryDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.serviceAccountRepositoryDAO).isNotNull();
    }
}