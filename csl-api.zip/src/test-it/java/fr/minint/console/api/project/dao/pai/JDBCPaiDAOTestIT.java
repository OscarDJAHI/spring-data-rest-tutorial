package fr.minint.console.api.project.dao.pai;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.Pai;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static fr.minint.console.library.utils.predicate.IdPredicate.withId;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
public class JDBCPaiDAOTestIT extends AbstractDAOTestIT {
    private JDBCPaiDAO jdbcPaiDAO;

    ///// Initialisation / fermeture des tests :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation du DAO :
        jdbcPaiDAO = new JDBCPaiDAO(this.dataSource);
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(jdbcPaiDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldHaveFields() {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.jdbcPaiDAO).isNotNull();
    }

    @Test
    public void shouldCreate() throws Exception {
        final Pai savedPai = jdbcPaiDAO.save(new Pai("paiFred", "paiCode", "description"));
        assertThat(savedPai).isNotNull();
        assertThat(savedPai.getId()).isNotNull();

        // Récupération depuis la base de données :
        final Optional<Pai> foundPaiOpt = jdbcPaiDAO.selectFirst(withId(savedPai.getId()));
        assertThat(foundPaiOpt).isNotNull();
        assertThat(foundPaiOpt).isNotEmpty();
        final Pai foundPai = foundPaiOpt.get();
        assertThat(foundPai.getName()).isEqualTo("paiFred");
        assertThat(foundPai.getCode()).isEqualTo("paiCode");
        assertThat(foundPai.getDescription()).isEqualTo("description");
    }


    @Test
    public void shouldUpdate() throws Exception {

        // Bouchonnage :
        final Pai savedPai = jdbcPaiDAO.save(new Pai("paiFred", "paiCode", "description"));
        assertThat(savedPai).isNotNull();
        assertThat(savedPai.getId()).isNotNull();

        // Vérification de la base de données :
        assertThat(jdbcPaiDAO.selectCount()).isEqualTo(1L);

        // Mis à jour :
        savedPai.setDescription("autre description");
        jdbcPaiDAO.save(savedPai);

        // Récupération de la base de données :
        final Optional<Pai> foundPaiOpt = jdbcPaiDAO.selectFirst(withId(savedPai.getId()));
        assertThat(foundPaiOpt).isNotEmpty();
        final Pai foundPai = foundPaiOpt.get();
        assertThat(foundPai.getName()).isEqualTo("paiFred");
        assertThat(foundPai.getCode()).isEqualTo("paiCode");
        assertThat(foundPai.getDescription()).isEqualTo("autre description");
    }


    @Test
    public void shouldCount() throws Exception {
        Pai savedPai;
        for (int i = 0; i < 3; i++) {
            savedPai = jdbcPaiDAO.save(new Pai("paiFred" + i, "paiCode" + i, i + "2ème pai"));
            assertThat(savedPai).isNotNull();
            assertThat(savedPai.getId()).isNotNull();
        }

        // Récupération :
        assertThat(jdbcPaiDAO.selectCount()).isEqualTo(3L);
    }

    @Test
    public void shouldDelete() throws Exception {
        final Map<String, Long> paiIds = new HashMap<>();
        Pai savedPai;
        for (int i = 0; i < 3; i++) {
            savedPai = jdbcPaiDAO.save(new Pai("paiFred" + i, "paiCode" + i, i + "ème pai"));
            assertThat(savedPai).isNotNull();
            assertThat(savedPai.getId()).isNotNull();
            paiIds.put(savedPai.getName(), savedPai.getId());
        }

        // Suppression :
        jdbcPaiDAO.delete(withId(paiIds.get("paiFred1")));
        assertThat(jdbcPaiDAO.selectCount()).isEqualTo(2L);
        final List<Pai> foundPais = jdbcPaiDAO.selectAll();
        assertThat(foundPais).isNotNull();
        assertThat(foundPais).isNotEmpty();
        assertThat(foundPais.size()).isEqualTo(2);
        assertThat(foundPais.stream().map(Pai::getId).filter(id -> id == 2L)).isEmpty();
    }

}