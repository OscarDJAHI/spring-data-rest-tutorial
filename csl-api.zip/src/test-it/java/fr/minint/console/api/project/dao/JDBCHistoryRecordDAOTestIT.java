package fr.minint.console.api.project.dao;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.HistoryRecord;
import fr.minint.console.persistence.dao.sql.predicate.JDBCCompositePredicate;
import fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

import static fr.minint.console.library.utils.io.IOUtils.closeQuietly;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class JDBCHistoryRecordDAOTestIT extends AbstractDAOTestIT {
    private JDBCHistoryRecordDAO historyRecordDAO;

    ///// Nettoyage de la base de données :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage
        this.cleanDatabase();

        // Initialisation du DAO :
        this.historyRecordDAO = new JDBCHistoryRecordDAO(dataSource);
    }

    @AfterEach
    void tearDown() {
        closeQuietly(historyRecordDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(dataSource).isNotNull();
        assertThat(historyRecordDAO).isNotNull();
    }

    @Test
    public void shouldInsertHistoryRecord() throws Exception {

        // Sauvegarde
        this.historyRecordDAO.save(new HistoryRecord(null, "change-quota-objet", "15", "20", "", "fmouleUid"));

        // Récupération de l'historique sauvegardé :
        assertThat(this.historyRecordDAO.selectCount()).isEqualTo(1L);

        // Récupération & vérification de la donnée
        final Optional<HistoryRecord> foundHistoryRecordOpt = this.historyRecordDAO
                .selectFirst(withJDBCFieldEquals(HistoryRecord.class, "updated_by", "fmouleUid"));
        assertThat(foundHistoryRecordOpt).isNotEmpty();
        final HistoryRecord foundHistoryRecord = foundHistoryRecordOpt.get();
        assertThat(foundHistoryRecord.getId()).isNotNull();
        assertThat(foundHistoryRecord.getUpdatedBy()).isEqualTo("fmouleUid");
        assertThat(foundHistoryRecord.getAction()).isEqualTo("change-quota-objet");
        assertThat(foundHistoryRecord.getAncienneValeur()).isEqualTo("15");
        assertThat(foundHistoryRecord.getNouvelleValeur()).isEqualTo("20");
    }

    @Test
    public void shouldUpdateARecord() throws Exception {

        // Sauvegarde
        final HistoryRecord savedHistoryRecord = this.historyRecordDAO.save(new HistoryRecord(null, "change-quota-objet", "15", "20", "", "fmouleUid"));
        assertThat(savedHistoryRecord).isNotNull();
        assertThat(savedHistoryRecord.getId()).isNotNull();
        assertThat(this.historyRecordDAO.selectCount()).isEqualTo(1L);

        // Mis à jour
        savedHistoryRecord.setModifiedTable("theTable");
        this.historyRecordDAO.save(savedHistoryRecord);

        // Vérification de la base de données :
        assertThat(this.historyRecordDAO.selectCount()).isEqualTo(1L);
        final Optional<HistoryRecord> foundHistoryRecordOpt = this.historyRecordDAO
                .selectFirst(withJDBCFieldEquals(HistoryRecord.class, "id", savedHistoryRecord.getId()));
        assertThat(foundHistoryRecordOpt).isNotEmpty();
        assertThat(foundHistoryRecordOpt.get().getAction()).isEqualTo("change-quota-objet");
        assertThat(foundHistoryRecordOpt.get().getModifiedTable()).isEqualTo("theTable");
        assertThat(foundHistoryRecordOpt.get().getAncienneValeur()).isEqualTo("15");
        assertThat(foundHistoryRecordOpt.get().getNouvelleValeur()).isEqualTo("20");
        assertThat(foundHistoryRecordOpt.get().getUpdatedBy()).isEqualTo("fmouleUid");
    }


    @Test
    public void shouldSelectFromPredicate() throws Exception {

        // Bouchonnage de la base de données :
        final Set<HistoryRecord> historyRecords = new HashSet<>();
        HistoryRecord historyRecord;
        String ownerUid = null;
        for (int i = 0; i < 5; i++) {
            ownerUid = switch ((i % 3)) {
                case 0 -> "fredUid";
                case 1 -> "oscarUid";
                case 2 -> "trecyUid";
                default -> ownerUid;
            };
            historyRecord = new HistoryRecord(null, "action" + i, String.valueOf(10 * (i + 1)), String.valueOf(11 * (i + 1)), "table" + i, ownerUid);
            historyRecords.add(historyRecord);
        }
        this.historyRecordDAO.save(historyRecords);

        // Vérification de la base de données :
        final JDBCFieldPredicate<HistoryRecord> updatedByFredPredicate = withJDBCFieldEquals(HistoryRecord.class, "updated_by", "fredUid");
        assertThat(this.historyRecordDAO.selectCount(updatedByFredPredicate)).isEqualTo(2L);

        Predicate<HistoryRecord> andPredicate = new JDBCCompositePredicate<>(updatedByFredPredicate);
        andPredicate = andPredicate.and(withJDBCFieldEquals(HistoryRecord.class, "action", "action0"));
        final Optional<HistoryRecord> foundHistoryRecordOpt = this.historyRecordDAO.selectFirst(andPredicate);
        assertThat(foundHistoryRecordOpt).isNotEmpty();
        assertThat(foundHistoryRecordOpt.get().getAction()).isEqualTo("action0");
        assertThat(foundHistoryRecordOpt.get().getAncienneValeur()).isEqualTo("10");
        assertThat(foundHistoryRecordOpt.get().getNouvelleValeur()).isEqualTo("11");
        assertThat(foundHistoryRecordOpt.get().getUpdatedBy()).isEqualTo("fredUid");
    }



}