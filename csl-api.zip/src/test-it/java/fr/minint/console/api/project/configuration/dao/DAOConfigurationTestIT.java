package fr.minint.console.api.project.configuration.dao;

import com.zaxxer.hikari.HikariDataSource;
import fr.minint.console.api.project.ldap.model.PosixGroup;
import fr.minint.console.api.project.model.*;
import fr.minint.console.api.project.model.document.VersionedDocument;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.sql.DataSource;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class DAOConfigurationTestIT {
    private DataSource dataSource;
    private DAO<VersionedDocument> versionedDocumentDAO;
    private DAO<PosixGroup> posixGroupDAO;
    private DAO<Region> regionDAO;
    private DAO<Zone> zoneDAO;
    private DAO<Project> projectDAO;
    private DAO<Resource> resourceDAO;
    private DAO<Tag> tagDAO;
    private DAO<QuotaType> quotaTypeDAO;
    private DAO<User> userDAO;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetDatasource() {
        assertThat(dataSource).isNotNull();
        assertThat(dataSource instanceof HikariDataSource).isTrue();
    }

    @Test
    public void shouldGetAllDAOs() {
        assertThat(this.versionedDocumentDAO).isNotNull();
        assertThat(this.posixGroupDAO).isNotNull();
        assertThat(this.regionDAO).isNotNull();
        assertThat(this.zoneDAO).isNotNull();
        assertThat(this.projectDAO).isNotNull();
        assertThat(this.resourceDAO).isNotNull();
        assertThat(this.tagDAO).isNotNull();
        assertThat(this.quotaTypeDAO).isNotNull();
        assertThat(this.userDAO).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setDataSource(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Autowired
    public void setVersionedDocumentDAO(@Qualifier(value = "versionedDocumentDAO") final DAO<VersionedDocument> versionedDocumentDAO) {
        this.versionedDocumentDAO = versionedDocumentDAO;
    }

    @Autowired
    public void setPosixGroupDAO(@Qualifier(value = "posixGroupDAO") final DAO<PosixGroup> posixGroupDAO) {
        this.posixGroupDAO = posixGroupDAO;
    }

    @Autowired
    public void setRegionDAO(@Qualifier("regionDAO") final DAO<Region> regionDAO) {
        this.regionDAO = regionDAO;
    }

    @Autowired
    public void setZoneDAO(@Qualifier("zoneDAO") final DAO<Zone> zoneDAO) {
        this.zoneDAO = zoneDAO;
    }

    @Autowired
    public void setProjectDAO(@Qualifier("projectDAO") final DAO<Project> projectDAO) {
        this.projectDAO = projectDAO;
    }

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setTagDAO(@Qualifier("tagDAO") final DAO<Tag> tagDAO) {
        this.tagDAO = tagDAO;
    }

    @Autowired
    public void setQuotaTypeDAO(@Qualifier("quotaTypeDAO") final DAO<QuotaType> quotaTypeDAO) {
        this.quotaTypeDAO = quotaTypeDAO;
    }

    @Autowired
    public void setUserDAO(@Qualifier("userDAO") final DAO<User> userDAO) {
        this.userDAO = userDAO;
    }
}