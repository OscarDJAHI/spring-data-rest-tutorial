package fr.minint.console.api.project.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class ServiceAccountControllerTestIT {
    private ServiceAccountController serviceAccountController;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTheParameters() {
        assertThat(serviceAccountController).isNotNull();
        assertThat(serviceAccountController.getServiceAccountDAO()).isNotNull();
        assertThat(serviceAccountController.getResourceRoleDAO()).isNotNull();
    }

    ///// Getters & Setters :

    @Autowired
    public void setServiceAccountController(final ServiceAccountController serviceAccountController) {
        this.serviceAccountController = serviceAccountController;
    }
}