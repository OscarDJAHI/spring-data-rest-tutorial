package fr.minint.console.api.project.controller.validator.resource;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.HistoryRecord;
import fr.minint.console.api.project.service.EmailNotificationService;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.Duration;
import java.time.Instant;

import static java.lang.Thread.sleep;
import static java.time.temporal.ChronoUnit.HOURS;
import static java.time.temporal.ChronoUnit.MINUTES;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class NumberCreatedResourceValidatorTestIT extends AbstractDAOTestIT {
    private DAO<HistoryRecord> historyRecordDAO;
    private NumberCreatedResourceValidator numberCreatedResourceValidator;
    private EmailNotificationService emailService;

    ///// Intialisation :

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation
        this.numberCreatedResourceValidator = new NumberCreatedResourceValidator(historyRecordDAO, 10, Duration.of(1, HOURS), emailService);

    }

    ///// Tests unitaires :

    @Test
    public void shouldGetTheParameters() {
        assertThat(this.historyRecordDAO).isNotNull();
        assertThat(this.emailService).isNotNull();
    }

    @Test
    public void shouldReturnOK() throws Exception {

        // Bouchonnage de la base de données :
        this.historyRecordDAO.save(new HistoryRecord(null, "create-tenant", "", "tenant1", "resource", "fredUid"));

        // Vérification :
        final StringBuilder errorMsgBuffer = new StringBuilder();
        assertThat(this.numberCreatedResourceValidator.validate("tenant", createMockedKeycloakAuthenticationToken("fredUid"), errorMsgBuffer)).isTrue();
        assertThat(errorMsgBuffer.toString()).isEmpty();
    }


    @Test
    public void shouldReturnKOBecauseTooMany() throws Exception {

        // Bouchonnage de la base de données :
        final Instant updatedAt = Instant.now().minus(10, MINUTES);
        for (int i = 0; i < 11; i++) {
            this.historyRecordDAO.save(new HistoryRecord(null, "create-tenant", "", "tenant" + i, "resource", "fredUid", null, updatedAt));
        }

        // Petite attente :
        sleep(1000);

        // Vérification :
        final StringBuilder errorMsgBuffer = new StringBuilder();
        assertThat(this.numberCreatedResourceValidator.validate("tenant", createMockedKeycloakAuthenticationToken("fredUid"), errorMsgBuffer)).isFalse();
        assertThat(errorMsgBuffer.toString()).isNotEmpty();
    }

    ///// Getters & Setters :

    @Autowired
    public void setHistoryRecordDAO(@Qualifier("historiqueDAO") final DAO<HistoryRecord> historyRecordDAO) {
        this.historyRecordDAO = historyRecordDAO;
    }

    @Autowired
    public void setEmailService(final EmailNotificationService emailService) {
        this.emailService = emailService;
    }
}