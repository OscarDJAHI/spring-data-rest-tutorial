package fr.minint.console.api.project.service;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.ConsoleRole;
import fr.minint.console.api.project.model.Role;
import fr.minint.console.api.project.model.project.Project;
import fr.minint.console.api.project.model.resource.Resource;
import fr.minint.console.persistence.dao.DAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static fr.minint.console.api.project.ConsoleRole.DELEGUE;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
class BusinessRuleImplTestIT extends AbstractDAOTestIT {
    private DAO<Project> projectDAO;
    private DAO<Resource> resourceDAO;
    private DAO<Role> roleDAO;
    private BusinessRuleImpl businessRule;

    ///// Initialisation

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation des rôles :
        final Set<Role> roles = new HashSet<>();
        for (ConsoleRole consoleRole : ConsoleRole.values()) {
            roles.add(new Role(null, consoleRole.value()));
        }
        this.roleDAO.save(roles);

        // Initialisation
        businessRule = new BusinessRuleImpl(projectDAO, resourceDAO, roleDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetParameters() throws Exception {
        assertThat(projectDAO).isNotNull();
        assertThat(roleDAO).isNotNull();
        assertThat(resourceDAO).isNotNull();
    }

    @Test
    public void shouldHaveSavedTheRoles() throws Exception {
        final List<Role> savedRoles = this.roleDAO.selectAll();
        assertThat(savedRoles).isNotEmpty();
        assertThat(savedRoles.size()).isEqualTo(ConsoleRole.values().length);

        // On vérifie que le rôle 'délégué' existe :
        assertThat(savedRoles
                .stream()
                .filter(withJDBCFieldEquals(Role.class, "name", DELEGUE.value()))
                .count()).isEqualTo(1);
    }

    @Test
    public void shouldCheckProjectOwner() throws Exception {
        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("Projet de test");
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(this.businessRule.isProjectOwnerOrManager(savedProject.getId(), "fredUid")).isTrue();
        assertThat(this.businessRule.isProjectOwnerOrManager(savedProject.getId(), "oscarUid")).isFalse();
    }

    @Test
    public void shouldCheckProjectDelegue() throws Exception {

        // Récupération du rôle :
        final Optional<Role> delegueRoleOpt = this.roleDAO.selectFirst(withJDBCFieldEquals(Role.class, "name", DELEGUE.value()));
        assertThat(delegueRoleOpt).isNotEmpty();

        final Project project = new Project(null, "fredProject", "fredUid");
        project.setLabel("projet de test");
        project.addRoleToUser("oscarUid", delegueRoleOpt.get());
        final Project savedProject = this.projectDAO.save(project);
        assertThat(savedProject).isNotNull();
        assertThat(savedProject.getId()).isNotNull();

        // Vérification :
        assertThat(this.businessRule.isProjectOwnerOrManager(savedProject.getId(), "fredUid")).isTrue();
        assertThat(this.businessRule.isProjectOwnerOrManager(savedProject.getId(), "trecyUid")).isFalse();
    }

    ///// Getters & Setters :

    @Autowired
    public void setProjectDAO(@Qualifier("projectDAO") final DAO<Project> projectDAO) {
        this.projectDAO = projectDAO;
    }

    @Autowired
    public void setResourceDAO(@Qualifier("resourceDAO") final DAO<Resource> resourceDAO) {
        this.resourceDAO = resourceDAO;
    }

    @Autowired
    public void setRoleDAO(@Qualifier("roleDAO") final DAO<Role> roleDAO) {
        this.roleDAO = roleDAO;
    }
}