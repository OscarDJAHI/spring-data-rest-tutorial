package fr.minint.console.api.project.dao.document;

import fr.minint.console.api.project.AbstractDAOTestIT;
import fr.minint.console.api.project.model.document.VersionedDocument;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static fr.minint.console.api.project.model.document.VersionedDocumentType.DOCX;
import static fr.minint.console.api.project.model.document.VersionedDocumentType.PDF;
import static fr.minint.console.persistence.dao.DAO.closeDAO;
import static fr.minint.console.persistence.dao.sql.predicate.JDBCFieldPredicate.withJDBCFieldEquals;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles({"test"})
public class JDBCVersionedDocumentDAOTestIT extends AbstractDAOTestIT {
    private JDBCVersionedDocumentDAO versionedDocumentDAO;

    @BeforeEach
    void setUp() throws Exception {

        // Nettoyage de la base de données :
        this.cleanDatabase();

        // Initialisation du DAO :
        this.versionedDocumentDAO = new JDBCVersionedDocumentDAO(this.dataSource);
        this.versionedDocumentDAO.start();
    }

    @AfterEach
    void tearDown() throws IOException {
        closeDAO(this.versionedDocumentDAO);
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldGetTestParamters() {
        assertThat(this.dataSource).isNotNull();
        assertThat(this.versionedDocumentDAO).isNotNull();
    }


    @Test
    public void shouldSave() throws Exception {

        // Insertion des données :
        this.versionedDocumentDAO.save(new VersionedDocument("path1.doc", DOCX, 1));
        this.versionedDocumentDAO.save(new VersionedDocument("path2.doc", DOCX, 2));
        this.versionedDocumentDAO.save(new VersionedDocument("path3.pdf", PDF, 2));

        // Récupération des données :
        final List<VersionedDocument> foundDocs = this.versionedDocumentDAO.selectAll();
        assertThat(foundDocs).isNotNull();
        assertThat(foundDocs.size()).isEqualTo(3);
    }


    @Test
    public void shouldSelectFromPredicate() throws Exception {

        // Bouchonnage de la base de données :
        this.versionedDocumentDAO.save(new VersionedDocument("path1.doc", DOCX, 1));
        this.versionedDocumentDAO.save(new VersionedDocument("path2.doc", DOCX, 2));
        this.versionedDocumentDAO.save(new VersionedDocument("path3.pdf", PDF, 2));

        // Selection
        final Optional<VersionedDocument> foundDocOptional = this.versionedDocumentDAO
                .selectFirst(withJDBCFieldEquals(VersionedDocument.class, "doc_path", "path3.pdf"));
        assertThat(foundDocOptional).isNotNull();
        assertThat(foundDocOptional).isNotEmpty();
        final VersionedDocument foundDoc = foundDocOptional.get();
        assertThat(foundDoc.getId()).isNotNull();
        assertThat(foundDoc.getDocPath()).isEqualTo("path3.pdf");
        assertThat(foundDoc.getDocType()).isEqualTo(PDF);
        assertThat(foundDoc.getVersionNumber()).isEqualTo(2);
    }


    @Test
    public void shouldUpdateTheDoc() throws Exception {

        // Bouchonnage de la base de données :
        this.versionedDocumentDAO.save(new VersionedDocument("path1.doc", DOCX, 1));
        this.versionedDocumentDAO.save(new VersionedDocument("path2.doc", DOCX, 2));
        this.versionedDocumentDAO.save(new VersionedDocument("path3.pdf", PDF, 2));

        // Modification
        Optional<VersionedDocument> foundDocOptional = this.versionedDocumentDAO
                .selectFirst(withJDBCFieldEquals(VersionedDocument.class, "doc_path", "path3.pdf"));
        assertThat(foundDocOptional).isNotEmpty();
        final VersionedDocument versionedDocument = foundDocOptional.get();
        versionedDocument.setVersionNumber(3);
        this.versionedDocumentDAO.save(versionedDocument);

        // Récupération :
        assertThat(this.versionedDocumentDAO.selectCount()).isEqualTo(3);
        foundDocOptional = this.versionedDocumentDAO.selectFirst(withJDBCFieldEquals(VersionedDocument.class, "doc_path", "path3.pdf"));
        assertThat(foundDocOptional).isNotEmpty();
        assertThat(foundDocOptional.get().getVersionNumber()).isEqualTo(3);
        assertThat(foundDocOptional.get().getDocType()).isEqualTo(PDF);
        assertThat(foundDocOptional.get().getDocPath()).isEqualTo("path3.pdf");
    }


    @Test
    public void shouldDeleteFromPredicate() throws Exception {

        // Insertion des données :
        this.versionedDocumentDAO.save(new VersionedDocument("path1.doc", DOCX, 1));
        this.versionedDocumentDAO.save(new VersionedDocument("path1.doc", DOCX, 2));
        this.versionedDocumentDAO.save(new VersionedDocument("path3.pdf", PDF, 2));

        // Suppression de la ligne :
        Predicate<VersionedDocument> jdbcPredicate = withJDBCFieldEquals(VersionedDocument.class, "doc_path", "path1.doc");
        jdbcPredicate = jdbcPredicate.and(withJDBCFieldEquals(VersionedDocument.class, "version_number", 2));
        this.versionedDocumentDAO.delete(jdbcPredicate);

        // Vérification de la base de données :
        final List<VersionedDocument> foundDocs = this.versionedDocumentDAO.selectAll();
        assertThat(foundDocs).isNotNull();
        assertThat(foundDocs.size()).isEqualTo(2);
        assertThat(foundDocs.stream().filter(jdbcPredicate).findFirst()).isEmpty();
    }


}