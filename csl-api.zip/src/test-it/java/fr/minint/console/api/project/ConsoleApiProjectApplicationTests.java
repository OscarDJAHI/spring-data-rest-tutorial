package fr.minint.console.api.project;

import fr.minint.console.api.project.controller.ResourceController;
import fr.minint.console.api.project.service.region.RegionService;
import fr.minint.console.api.project.service.sequence.SequenceService;
import fr.minint.console.api.project.service.zone.ZoneService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.beans.factory.BeanFactoryUtils.beansOfTypeIncludingAncestors;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles({"test"})
class ConsoleApiProjectApplicationTests {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("extUserRIOSeqService")
	private SequenceService extUserRioSeqService;

	@Autowired
	@Qualifier("extUserUidNumberSeqService")
	private SequenceService extUserUidNumberSeqService;

	@Autowired
	private GenericApplicationContext appContext;

	///// Tests fonctionnels :

	@Test
	public void shouldGetTheContext() {
	  	assertThat(this.appContext).isNotNull();
	}

	@Test
	public void shouldLoadGeneralServices() {
		final Map<String, RegionService> foundRegionServices = beansOfTypeIncludingAncestors(appContext, RegionService.class);
		assertThat(foundRegionServices).isNotNull();
		assertThat(foundRegionServices).isNotEmpty();
		final Map<String, ZoneService> foundZoneServices = beansOfTypeIncludingAncestors(appContext, ZoneService.class);
		assertThat(foundZoneServices).isNotNull();
		assertThat(foundZoneServices).isNotEmpty();
	}

	@Test
	public void shouldLoadSpecificServices() {
		assertThat(jdbcTemplate).isNotNull();
		assertThat(extUserRioSeqService).isNotNull();
		assertThat(extUserUidNumberSeqService).isNotNull();
	}


	@Test
	public void shouldLoadControllers() {
		final Map<String, ResourceController> foundControllers = beansOfTypeIncludingAncestors(appContext, ResourceController.class);
		assertThat(foundControllers).isNotNull();
		assertThat(foundControllers).isNotEmpty();
	}

}
