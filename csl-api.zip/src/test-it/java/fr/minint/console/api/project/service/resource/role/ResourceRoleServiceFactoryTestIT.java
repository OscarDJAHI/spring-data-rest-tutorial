package fr.minint.console.api.project.service.resource.role;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles({"test"})
class ResourceRoleServiceFactoryTestIT {

    @Autowired
    private ResourceRoleServiceFactory resourceRoleServiceFactory;

    /////

    @Test
    public void shouldGetExecutorService() {
        Assertions.assertThat(resourceRoleServiceFactory).isNotNull();
        Assertions.assertThat(resourceRoleServiceFactory.getExecutorService()).isNotNull();
    }
}