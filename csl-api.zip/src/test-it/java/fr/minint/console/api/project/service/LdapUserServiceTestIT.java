package fr.minint.console.api.project.service;

import fr.minint.console.api.project.ldap.model.LdapUser;
import fr.minint.console.api.project.ldap.service.UserService;
import fr.minint.console.api.project.repository.ldap.UserLdapRepository;
import fr.minint.console.api.project.service.sequence.InMemorySequenceService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ldap.core.LdapTemplate;

import java.io.File;
import java.net.URI;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class LdapUserServiceTestIT extends AbstractLDAPTestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(LdapUserServiceTestIT.class);
    private final InMemorySequenceService rioSeqService = new InMemorySequenceService(9000000L);
    private final InMemorySequenceService uidNumberSeqService = new InMemorySequenceService(2000000L);
    private UserService userService;

    ///// Constructeurs :

    public LdapUserServiceTestIT() {
        super(DEFAULT_BASE_DN, DEFAULT_LDAP_PORT);
    }

    ///// Méthodes privées :

    private void initLdapRepository() throws Exception {
        final LdapTemplate ldapTemplate = this.getLdapTemplate();
        this.userService.setUserLdapRepository(new TestITLDAPUserRepository(ldapTemplate));
        this.userService.setLdapTemplate(ldapTemplate);
    }

    ///// Initialisation :

    @BeforeEach
    void setUp() {
        this.userService = new UserService();
        this.userService.setExtUserRioSequence(this.rioSeqService);
        this.userService.setExtUserUidNumberSequence(this.uidNumberSeqService);
        this.userService.setExternalUserDn("ou=users,ou=bas,ou=pi,ou=applications");
    }

    @AfterEach
    void tearDown() {
        if (this.isStarted()) {
            this.stop();
        }
        this.rioSeqService.close();
        this.uidNumberSeqService.close();
    }

    ///// Tests fonctionnels :

    @Test
    public void shouldStartEmbeddedLDAPServerWithoutFile() {
        try {
            this.start(null);
            assertThat(this.getServer()).isNotNull();
        } finally {
            this.stop();
        }
    }

    @Test
    public void shouldStartEmbeddedLDAPServer() {
        assertThat(LdapUserServiceTestIT.class.getResource("/bootstrap.ldif")).isNotNull();
        final File ldifFile = new File(LdapUserServiceTestIT.class.getResource("/bootstrap.ldif").getPath());
        assertThat(ldifFile).exists();
        this.start(ldifFile.getAbsolutePath());
        assertThat(this.getServer()).isNotNull();
    }

    @Test
    public void shouldGetHostAddress() throws Exception {
        this.start(LdapUserServiceTestIT.class.getResource("/bootstrap.ldif").getPath());
        final String hostAddress = getLDAPHostAddress();
        assertThat(hostAddress).isNotEmpty();
        LOGGER.info("Host address : {}", hostAddress);
        final URI uri = URI.create("ldap://127.0.1.1:9321/dc=interieur,dc=gouv,dc=fr");
        assertThat(uri).isNotNull();
    }


    @Test
    public void shouldCheckLDIFImport() throws Exception {
        this.start(LdapUserServiceTestIT.class.getResource("/bootstrap.ldif").getPath());
        final LdapTemplate ldapTemplate = this.getLdapTemplate();
        assertThat(ldapTemplate).isNotNull();
        final List<LdapUser> foundLdapUsers = ldapTemplate.findAll(LdapUser.class);
        assertThat(foundLdapUsers).isNotEmpty();
        LOGGER.info("{} utilisateurs importés", foundLdapUsers.size());
    }

    @Test
    public void shouldCreateNewExternalUser() throws Exception {
        this.start(LdapUserServiceTestIT.class.getResource("/bootstrap.ldif").getPath());
        this.initLdapRepository();
        userService.createExternalUser("frederic", "moule", "frederic.moule@laposte.net", "monMotDePasse", "org");
        final UserLdapRepository userLdapRepository = userService.getUserLdapRepository();
        assertThat(userLdapRepository).isNotNull();
        final LdapUser ldapUser = userLdapRepository.findByMail("frederic.moule@laposte.net").orElse(null);
        assertThat(ldapUser).isNotNull();
        assertThat(ldapUser.getSn()).isEqualTo("moule");
        assertThat(ldapUser.getMail()).isEqualTo("frederic.moule@laposte.net");
        assertThat(ldapUser.getInitials()).isEqualTo("F M");
        assertThat(ldapUser.getUidNumber()).isEqualTo("2000001");
        assertThat(ldapUser.getGidNumber()).isEqualTo("1000000");
    }


}
