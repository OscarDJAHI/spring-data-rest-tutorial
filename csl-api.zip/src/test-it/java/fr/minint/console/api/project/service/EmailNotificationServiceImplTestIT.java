package fr.minint.console.api.project.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles({"test"})
class EmailNotificationServiceImplTestIT {

    @Autowired
    private EmailNotificationServiceImpl emailNotificationService;

    ///// Tests fonctionnels :

    @Test
    public void shouldGetBeansFromSpring() {
        assertThat(emailNotificationService).isNotNull();
        assertThat(emailNotificationService.getEnvironment()).isNotNull();
    }

    @Test
    public void shouldGetPropertiesFromEnv() {
        assertThat(emailNotificationService.getEnvironment().getProperty("server.port")).isNotEmpty();
        assertThat(emailNotificationService.getEnvironment().getProperty("console.api.email.openstack.dashboard.r1.url")).isNotEmpty();
    }

    @Test
    public void shouldGetTheEmailAdresses() {
        final Environment environment = emailNotificationService.getEnvironment();
        assertThat(environment.getProperty("console.api.project.workflow.email.alert-ssi-pi"))
                .isEqualTo("alertes-ssi-pi@interieur.gouv.fr");
        assertThat(environment.getProperty("console.api.project.workflow.email.alert-ssi-pi-cc"))
                .isEqualTo("dtnum-mpssi@interieur.gouv.fr");
    }

    @Test
    public void shouldGetRegionUrl() {
        assertThat(emailNotificationService.getDashboardUrlByRegionName("r1"))
                .isEqualTo("https://dashboard.pi-bas.cloudmi.minint.fr");
        assertThat(emailNotificationService.getDashboardUrlByRegionName("r2"))
                .isEqualTo("https://dashboard.r2.pi-pp.dsic.minint.fr");
    }

}
