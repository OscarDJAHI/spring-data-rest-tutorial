INSERT INTO public.status ("name","label",color,created_at,updated_at) VALUES
	 ('enabled','Activé','#7DC580','2022-11-14 10:04:54.271825','2024-04-17 10:45:03.931321'),
	 ('disabled','Désactivé','#8CA2B5','2022-11-14 10:04:54.271825','2024-04-17 10:45:03.931321');
