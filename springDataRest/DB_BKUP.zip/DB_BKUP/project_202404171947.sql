INSERT INTO public.project ("name","label",description,status,pai,owner_id,created_at,updated_at,cgu_id,rssi) VALUES
	 ('first-project-8fc6','first-project','Test',NULL,2,'djahiosc','2024-04-17 11:13:44.6822','2024-04-17 11:13:48.899198',1,NULL);
