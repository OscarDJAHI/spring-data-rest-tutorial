INSERT INTO public.resource_type ("name","label",category,color,created_at,updated_at) VALUES
	 ('tenant','IaaS','iaas','#A558A0','2022-11-14 10:04:54.294302','2024-04-17 10:45:03.931321'),
	 ('namespace','CaaS','caas','#CE614A','2022-11-14 10:04:54.294302','2024-04-17 10:45:03.931321'),
	 ('namespace','S3','s3','#E4794A','2022-11-14 10:04:54.294302','2024-04-17 10:45:03.931321');
