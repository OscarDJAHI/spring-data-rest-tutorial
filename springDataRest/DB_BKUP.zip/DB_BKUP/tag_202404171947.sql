INSERT INTO public.tag ("name","label",color,created_at,updated_at) VALUES
	 ('dev','Développement','#68AE52','2022-11-14 10:04:54.345559',NULL),
	 ('int','Intégration','#B3D99D','2022-11-14 10:04:54.345559',NULL),
	 ('met','Métrologie','#BEA79C','2022-11-14 10:04:54.345559',NULL),
	 ('poc','Poc','#BCD7EF','2022-11-14 10:04:54.345559',NULL),
	 ('preprod','Préproduction','#96B996','2022-11-14 10:04:54.345559',NULL),
	 ('prod','Production','#91C4BE','2022-11-14 10:04:54.345559',NULL),
	 ('qual','Qualification','#D494C3','2022-11-14 10:04:54.345559',NULL),
	 ('rec','Recette','#ECD292','2022-11-14 10:04:54.345559',NULL),
	 ('test','Test','#F8BD90','2022-11-14 10:04:54.345559',NULL),
	 ('form','Formation','#8B9FC8','2022-11-14 10:04:54.345559','2024-04-17 10:51:16.7159');
INSERT INTO public.tag ("name","label",color,created_at,updated_at) VALUES
	 ('iia','Intégration-inter-applicative','#CC9E9E','2022-11-14 10:04:54.345559','2024-04-17 11:42:50.272143'),
	 ('s1','S1','#AEA397','2024-04-17 10:51:16.718074','2024-04-17 11:43:11.617961'),
	 ('r1','R1','#AEA397','2024-04-17 10:51:16.721937','2024-04-17 11:43:11.619512');
