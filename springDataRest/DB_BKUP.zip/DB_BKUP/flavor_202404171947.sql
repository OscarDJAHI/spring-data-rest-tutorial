INSERT INTO public.flavor ("name",external_id,"zone",created_at,updated_at) VALUES
	 ('standard 1-0.5','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 1-1','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 1-2','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 2-2','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 2-4','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 2-8','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 4-4','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 4-8','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 4-16','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 4-32','none',1,'2022-11-14 10:04:54.314678',NULL);
INSERT INTO public.flavor ("name",external_id,"zone",created_at,updated_at) VALUES
	 ('standard 8-16','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('standard 8-32','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('high 8-64','none',1,'2022-11-14 10:04:54.314678',NULL),
	 ('high 16-64','none',1,'2022-11-14 10:04:54.314678',NULL);
