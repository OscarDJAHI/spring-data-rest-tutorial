INSERT INTO public.resource_region (resource,region,created_at,updated_at) VALUES
	 (3,1,'2024-04-17 11:42:50.292383','2024-04-17 11:42:50.292383'),
	 (4,1,'2024-04-17 11:43:11.628965','2024-04-17 11:43:11.628965');
