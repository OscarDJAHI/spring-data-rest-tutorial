INSERT INTO public.project_role (project,"role",uid,service_account,is_synchronized,created_at,updated_at) VALUES
	 (3,3,'djahiosc',NULL,true,'2024-04-17 11:13:48.905805','2024-04-17 11:13:48.905805'),
	 (3,4,'tayachea',NULL,true,'2024-04-17 11:41:50.414121',NULL);
