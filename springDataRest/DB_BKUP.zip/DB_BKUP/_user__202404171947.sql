INSERT INTO public."user" (last_name,first_name,email,rio,is_service_account,created_at,updated_at) VALUES
	 (NULL,NULL,NULL,'djahiosc',false,'2024-04-17 11:13:44.847336',NULL),
	 ('frederic','moule','frederic.moule-econocom@interieur.gouv.fr','moulefre',false,'2024-04-17 11:44:00.450339',NULL),
	 ('abdelkarim','tayache','abdelkarim.tayache-oiseaurare@interieur.gouv.fr','tayachea',false,'2024-04-17 11:58:16.54973',NULL);
