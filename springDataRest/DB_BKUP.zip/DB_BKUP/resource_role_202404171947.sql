INSERT INTO public.resource_role (resource,"role",uid,service_account,is_synchronized,created_at,updated_at) VALUES
	 (3,5,'moulefre',NULL,true,'2024-04-17 11:43:47.595407',NULL),
	 (3,5,'tayachea',NULL,true,'2024-04-17 12:54:15.907803',NULL);
