INSERT INTO public.history ("action",ancienne_valeur,nouvelle_valeur,updated_by,modified_table,created_at,updated_at) VALUES
	 ('create-tenant',NULL,'first-project-7780-test-iaas1','djahiosc','resource','2024-04-17 10:51:16.79553','2024-04-17 10:51:16.79553'),
	 ('create-tenant',NULL,'first-project-7780-test-s31','djahiosc','resource','2024-04-17 10:51:43.151149','2024-04-17 10:51:43.151149'),
	 ('create-tenant',NULL,'first-project-8fc6-iaas-1','djahiosc','resource','2024-04-17 11:42:50.302413','2024-04-17 11:42:50.302413'),
	 ('create-tenant',NULL,'first-project-8fc6-s3-1','djahiosc','resource','2024-04-17 11:43:11.635559','2024-04-17 11:43:11.635559');
