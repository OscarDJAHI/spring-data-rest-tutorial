INSERT INTO public.versioned_document (doc_path,doc_type_name,version_number,created_at,updated_at) VALUES
	 ('/opt/console/cgus/cgu1.md','cgu',1,'2024-04-17 11:13:48.896574','2024-04-17 11:13:48.896574');
