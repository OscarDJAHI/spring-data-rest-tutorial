INSERT INTO public.region ("name","label",created_at,updated_at,color) VALUES
	 ('r2','R2','2024-04-17 10:45:03.907248','2024-04-17 10:45:03.931321','#AEA397'),
	 ('r1','R1','2022-11-14 10:04:54.286558','2024-04-17 11:43:11.626434','#AEA397');
