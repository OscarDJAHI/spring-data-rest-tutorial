INSERT INTO public.quota_type ("name","label",quota_icon,quota_min,quota_max,quota_default,quota_unit,resource_type,priority,created_at,updated_at) VALUES
	 ('cpu','VCPUs','cpu',10,200,10,'',1,1,'2022-11-14 10:04:54.298718',NULL),
	 ('ram','RAM','ram',10,200,10,'Go',1,2,'2022-11-14 10:04:54.298718',NULL),
	 ('disk','Stockage Bloc','disk',10,512,10,'Go',1,3,'2022-11-14 10:04:54.298718',NULL),
	 ('object','Stockage Objet','object',0,1024,0,'Go',1,4,'2022-11-14 10:04:54.298718',NULL),
	 ('object-storage','Stockage Objet','objectStorage',300,5000,300,'Go',3,1,'2024-04-17 10:45:03.91828','2024-04-17 10:45:03.963778');
