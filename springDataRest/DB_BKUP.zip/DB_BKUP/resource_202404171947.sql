INSERT INTO public.resource ("name",description,external_id,resource_type,region,"zone",status,project,created_at,updated_at) VALUES
	 ('first-project-8fc6-iaas-1','Test',NULL,1,1,1,1,3,'2024-04-17 11:42:50.261341',NULL),
	 ('first-project-8fc6-s3-1',NULL,NULL,3,NULL,1,1,3,'2024-04-17 11:43:11.609967',NULL);
