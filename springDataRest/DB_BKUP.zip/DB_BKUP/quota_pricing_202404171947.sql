INSERT INTO public.quota_pricing (quota_type,quota_unit,monthly_price,yearly_price,created_at,updated_at) VALUES
	 (1,'vcpu',9.166667,110.0,'2022-11-14 10:04:54.30689',NULL),
	 (2,'Mo',0.004475912,0.053710938,'2022-11-14 10:04:54.30689',NULL),
	 (3,'To',33.333332,400.0,'2022-11-14 10:04:54.30689',NULL),
	 (4,'To',19.916668,239.0,'2022-11-14 10:04:54.30689',NULL);
