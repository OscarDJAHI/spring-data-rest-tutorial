INSERT INTO public."role" ("name","label",color,description,ldap_group_rdn,enabled,created_at,updated_at) VALUES
	 ('souscripteur','Souscripteur','#7AB1E8','Souscripteur console cloud pi',NULL,true,'2022-11-14 10:04:54.339928',NULL),
	 ('delegue','Souscripteur délégué','#34BAB5','Le rôle de délégué fournit les mêmes autorisations qu''un propriétaire sauf la modification/suppression d''un souscripteur.',NULL,true,'2022-11-14 10:04:54.339928',NULL),
	 ('admin','Administrateur','#E18B76','Administrateur console cloud pi',NULL,true,'2022-11-14 10:04:54.339928','2024-04-17 10:45:03.931321'),
	 ('lecteur','Lecteur','#009099','Lecteur console cloud pi',NULL,true,'2022-11-14 10:04:54.339928','2024-04-17 10:45:03.931321'),
	 ('concepteur','Concepteur','#417DC4','Concepteur console cloud pi',NULL,true,'2022-11-14 10:04:54.339928','2024-04-17 10:45:03.931321');
